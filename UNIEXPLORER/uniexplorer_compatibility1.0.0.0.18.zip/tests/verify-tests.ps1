# UniExplorer compatibility 1.0.0.0.18 - verify-tests.ps1
param([switch]$AllowSaveTest)
$ErrorActionPreference = 'Stop'
$root = Join-Path $PSScriptRoot 'files'
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$failed = 0
foreach ($case in $manifest) {
    $path = Join-Path $root $case.path
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { Write-Host "FAIL $($case.id): missing"; $failed++; continue }
    $hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
    $expected = $case.sha256
    if ($AllowSaveTest -and $case.id -eq '04') {
        $bytes = [IO.File]::ReadAllBytes($path)
        $original = "UNIEXPLORER TEST 04`r`nExpected original file: 04`r`n"
        $text = [Text.Encoding]::ASCII.GetString($bytes).Replace("`r`n", "`n")
        if ($text -eq ($original.Replace("`r`n", "`n") + "SAVE TEST 04`n")) { Write-Host 'PASS 04: expected save'; continue }
        Write-Host 'FAIL 04: expected saved marker not found'; $failed++; continue
    }
    if ($hash -eq $expected) { Write-Host "PASS $($case.id)" } else { Write-Host "FAIL $($case.id): changed"; $failed++ }
}
$actual = @(Get-ChildItem -LiteralPath $root -File -Recurse -Force)
foreach ($file in $actual) {
    $relative = $file.FullName.Substring($root.Length + 1).Replace('\','/')
    if (-not @($manifest | Where-Object { $_.path -ceq $relative }).Count) { Write-Host "FAIL unexpected file: $relative"; $failed++ }
}
Write-Host "Failures: $failed"
if ($failed) { exit 1 } else { exit 0 }
