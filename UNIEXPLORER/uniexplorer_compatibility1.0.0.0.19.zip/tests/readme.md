# UniExplorer compatibility 1.0.0.0.19 - test suite
27 November 2026

**Important — open files one at a time:** After double-clicking a filename in Windows Explorer, wait until that file is fully loaded and visibly displayed in the original TSE editing window before double-clicking the next filename. If the Buffer List, a menu or a dialog is open, close it first (for example, press Escape). This allows the mailbox receiver to finish loading and acknowledging the current request. Opening another file too early may cause a timeout or leave an additional TSE instance open.

Extract the complete ZIP using Windows File Explorer or a Unicode-aware ZIP extractor. Use a disposable local drive-letter directory, not a UNC path. Installing and adding uniexplorer.mac to AutoLoad is mandatory and essential. Follow the mandatory installation section of the main README. In Explorer choose Open with > Choose another app and browse to the exact intended g32.exe; set it as the default if double-click opening is desired. Keep native Single Instance OFF for ordinary version 19 testing. Once Open with has set the intended g32.exe as the default for that extension, double-clicking filenames in Explorer may suffice. For the separate -1- command-line override experiment, see the main README. Do not autoload the debug macro. Compile with the editor's own compiler.

1. From a console in this tests directory, run `powershell -NoProfile -ExecutionPolicy Bypass -File .\verify-tests.ps1`. Expect 16 PASS lines and zero failures. If not, check extraction before testing.
2. Open the files in tests/files directly from Windows File Explorer, using Open with TSE, the TSE context menu, or double-click when TSE is the default application. Do not use TSE's internal Open dialog for this test. For each nonempty file verify that the first line says UNIEXPLORER TEST followed by the ID in the table. On legacy TSE a generated ASCII temporary filename is expected for non-ASCII source paths; compare the marker and log, not the original filename. The file must not be another file or an unexpected empty buffer. Case 14 is deliberately empty; verify its identity separately.
3. Run once with TSE already open and once with TSE closed (close without saving). Repeat the collision cases 03-05 and Chinese case 07 at least 20 times, closing the corresponding buffers between attempts. Record failures, crashes and incorrect filenames in results.txt. If applicable repeat with multiple files selected; treat that as exploratory, not guaranteed functionality.
4. Run the verifier again before saving: all files should be unchanged. Unexpected extra files inside tests/files (including backup files) are reported for review.
5. Complete the loading test without saving; check the verifier. Then follow the separate save tests in the top-level README using disposable copies outside tests/files.

The verifier checks disk contents, not which buffer TSE opened. Manual checks are essential. It does not inspect files outside tests/files. No changes to code pages or system settings are required. If 8.3 aliases are unavailable, record this; `dir /x` in cmd.exe can show aliases. Code-page-specific behavior and random crashes cannot be ruled out by passing these tests.

| ID | Filename | Purpose |
|---|---|---|
| 01 | `plain.txt` | ASCII baseline |
| 02 | `café.txt` | ANSI accented name |
| 03 | `pair-a.txt` | ASCII collision control |
| 04 | `pair-ă.txt` | Best-fit collision with 03 |
| 05 | `pair-α.txt` | Greek best-fit collision with 03 |
| 06 | `only-ă.txt` | No ASCII counterpart |
| 07 | `中文.txt` | Chinese filename / startup |
| 08 | `日本語.txt` | Japanese filename |
| 09 | `кириллица.txt` | Cyrillic filename |
| 11 | `space in café.txt` | Spaces and accented name |
| 12 | `nested-中文/inside-ă.txt` | Unicode directory and filename |
| 13 | `long filename with spaces and café and 中文.txt` | Long filename |
| 14 | `empty-中文.txt` | Intentionally empty file |
| 15 | `Accused_of_wasting_€20Bln_on_AI_computing_dreams_EU_Compute_without_purpose.txt` | Long filename with euro sign |
| 16 | `Was_KI-Rechenzentren_von_gewöhnlichen_unterscheidet.txt` | German filename with umlaut |
| 17 | `nested/汉字.txt` | Chinese filename in ASCII subdirectory |

Test 10 is intentionally omitted due to observed JPSoft console cursor corruption with an emoji filename. IDs 11-14 are unchanged. Version 18 adds IDs 15-17, for 16 fixtures in total. Extract into a fresh directory, or remove the old test 10 fixture before verification.

## Version 1.0.0.0.19 diagnostic run
Logging is disabled by default in version 19. For diagnostic runs, set `logging=true` in `[UniExplorer]` in `uniexplorer.ini` and restart all TSE instances. First test case 06 alone with TSE closed. Do not save. Collect uniexplorer.log from the directory containing the autoloaded macro. For save-back tests, follow the top-level README and use disposable copies outside the fixture directory.


Version 10: after the initial successful startup test, keep TSE running and open test 04 and test 07 from Explorer. Upload the log even if opening fails. The event hooks are diagnostic only.

Version 1.0.0.0.19: use the primary/secondary mailbox procedure in the top-level README with native Single Instance OFF. Prior fresh-start instructions remain useful as a baseline.

Version 12: use the top-level README for the mailbox closure/focus test. Native Single Instance must remain OFF. Verify secondary windows actually disappear and the primary ring contains the expected test IDs.

Version 1.0.0.0.19: repeat test 06 and test 04 in the same ring, check duplicate selection, then verify tests 03 and 05 remain distinct. See top-level README for extension and association tests.
