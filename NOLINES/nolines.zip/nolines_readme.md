# NoLines

**Package version:** 1.0.0.0.1  
**Updated:** 2026-09-24 23:50 UTC  
**Original macro:** Carlo Hogeveen, version 3 (2004-10-03)  
**Packaging and startup message:** GPT-6

## Description

NoLines hides the eight-character line-number column in TSE Pro Find results created with the `V` search option. The results list also remains without those line numbers when opened for editing with <Alt E>. Running the macro again toggles line numbers back on. When the macro loads, line numbers are shown.

## Requirements

- The SemWare Editor Professional and its SAL compiler. The original author specifies TSE Pro 2.5 or later.
- The original macro requires compatible installations of `Global.zip`, `MacPar3.zip`, and `ClipBor2.zip`. In particular, it invokes the `clipbord` macro. These dependencies are **not** included in this ZIP.

## Install and run

1. Install the three original dependencies according to their instructions.
2. Extract `NoLines.s` and `File_Id.diz` from this package. Put `NoLines.s` where TSE can compile and load it, such as its macro directory.
3. Compile `NoLines.s` in TSE using **Escape → Macro → Compile**, or compile it with your compatible `sc32` compiler.
4. Add `NoLines` to TSE's **Macro AutoloadList** and restart TSE. Its hooks will then apply to Find results. At startup, line numbers remain visible.
5. Place `nolines.ini` in the directory that was current when TSE started. This is the `StartUpPath` used by the macro; it need not be TSE's installation directory. Set `silent=true` there if you want to suppress the message when toggling.
6. Run a Find with the `V` option to display its results list. Run the `NoLines` macro through TSE's macro execution command whenever you want to switch between hiding and showing line numbers. With `silent=false`, the resulting state appears in a `Warn()` box.

## Configuration

```ini
[nolines]
silent=false
```

`silent=false` (the default, including when the INI is missing) displays the status `Warn()` box each time you run the macro. `silent=true` suppresses that box; the toggle still happens. Configuration affects the manual toggle message, not the Find results hooks.

## Notes

The macro changes the presentation of generated Find lists. It preserves the line-number data temporarily so that TSE can restore it during the list cleanup process when appropriate. The original source and `File_Id.diz` are included; the source retains its original author and version history. This package version starts with line numbers visible and includes the INI setting and status message. Compile and run it in your TSE installation to verify compatibility with your installed dependency versions.
