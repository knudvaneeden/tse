 @REM version: 1.0.0.0.0 [kn, ri, fr, 25-09-2026 01:50:04]

 @echo off
 g:
 cd /d g:\versioncontrol\git\ddd01\NOLINES\
 git add file_id.diz
 git add nolines.s
 git add nolines.zip
 git add nolines_readme.md
 git add nolines.ini
 git add 01.png
 git commit -m "Update nolines directory files"
 git push origin HEAD:TRUNK
 start https://github.com/knudvaneeden/tse/tree/TRUNK/NOLINES
