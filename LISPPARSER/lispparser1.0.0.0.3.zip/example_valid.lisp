; Minimal Lisp-like source, syntax validation only
(define square (lambda (x) (* x x)))
(square 5)
'(a b (c d))
(+ 12 -3 4.5)
(display "hello, world")
