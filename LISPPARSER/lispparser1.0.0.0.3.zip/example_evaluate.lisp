; Integer Lisp evaluator smoke test: result 25
(define square
    (lambda (x)
        (* x x)))

(square 5)
