#include ["projdialogs.si"]
// PROJSTART.S - portable launcher for PROJ v2.00
// Package version 1.0.0.0.339 - OpenAI Codex (GPT-6)
// Compile with the same SAL compiler used for proj.si.

dll "<kernel32.dll>"
    integer proc PROJSetDllDirectory(string directory:cstrval) : "SetDllDirectoryA"
end

proc PROCProjectMainActions()
    string scriptArgumentS[255] = Trim(Query(MacroCmdLine))
    string installDir[255] = SplitPath(CurrMacroFilename(), _DRIVE_|_PATH_)

    if not Length(installDir)
        FNProjectWarning(Format("Cannot find the PROJ installation directory."))
        return()
    endif
    if installDir[Length(installDir)] <> "\" and
            installDir[Length(installDir)] <> "/"
        installDir = installDir + "\"
    endif

    if not PROJSetDllDirectory(installDir)
        FNProjectWarning(Format("Cannot set the DLL search directory: " + installDir))
        return()
    endif

    if not FileExists(installDir + "proj.mac")
        FNProjectWarning(Format("Cannot find proj.mac in " + installDir))
        return()
    endif
    if not FileExists(installDir + "ProjDLL.dll") or
            not FileExists(installDir + "msbsc60.dll")
        FNProjectWarning(Format("Put ProjDLL.dll and msbsc60.dll beside projstart.mac."))
        return()
    endif

    SetGlobalStr("PROJ0200_FromLauncher", "true")
    ExecMacro(QuotePath(installDir + "proj.mac") + iif(Length(scriptArgumentS), " " + scriptArgumentS, ""))
    SetGlobalStr("PROJ0200_FromLauncher", "")
end

// PROJ0200 1.0.0.0.339 - OpenAI Codex (GPT-6)
// Set() returns the previous value; restore it after all actions return.
proc Main()
    integer IOldCommonDialogs = Set(UseCommonDialogs, FNProjectWindowsDialogs())
    PROCProjectMainActions()
    Set(UseCommonDialogs, IOldCommonDialogs)
end
