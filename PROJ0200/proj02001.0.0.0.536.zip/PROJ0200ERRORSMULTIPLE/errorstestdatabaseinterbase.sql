/* errorstestdatabaseinterbase.sql version 1.0.0.0.11 */
/* Three independent intentional syntax errors. Use a test database. */
SELECT FROM RDB$DATABASE;
SELECT FROM RDB$DATABASE;
SELECT FROM RDB$DATABASE;
