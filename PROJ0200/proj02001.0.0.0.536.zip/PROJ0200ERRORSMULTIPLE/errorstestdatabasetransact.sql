-- errorstestdatabasetransact.sql version 1.0.0.0.13
-- Prepared with OpenAI ChatGPT GPT-6.1 Sol.
-- Three syntax errors in ONE batch: expected lines 7, 9 and 11.
-- No GO separators: SQL Server line numbers match source file lines.
-- No database objects or data are changed.

SELECT 1 + ;

SELECT 2 + ;

SELECT 3 + ;
