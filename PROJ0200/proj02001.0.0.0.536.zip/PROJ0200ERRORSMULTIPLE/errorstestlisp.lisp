; errorstest.lisp version 1.0.0.0.7 - OpenAI GPT-6
; Install: F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.lisp
; Three independent evaluation errors; expected jumps 6:1, 8:3, 10:5.
; Continuing after errors is supplied by COMLISP.BAT's inline runner.

(comlisp-missing-one)

  (comlisp-missing-two)

    (comlisp-missing-three)
