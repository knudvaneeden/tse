// errorstestreact.jsx - version 1.0.0.0.8 - 2026-11-06
// Three independent no-undef errors; valid JSX syntax allows all to be found.
// Expected locations: line 6 column 17, line 7 column 18, line 8 column 17.
// This file must fail checking and must not replace src/App.js.
export default function App() {
  const first = missingFirst;
  const second = missingSecond;
  const third = missingThird;
  return <div>{first} {second} {third}</div>;
}
