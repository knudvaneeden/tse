# errorstestapl.apl version 1.0.0.0.10
# Three independent top-level errors using ASCII only.
1+'x'
1 2+1 2 3
COMAPL_UNDEFINED_NAME
)OFF
