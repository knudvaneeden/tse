# errorstestmake.mk version 1.0.0.0.8 - OpenAI ChatGPT / Codex
# Borland MAKE normally stops on the first fatal parse error.
# Select CASE=1, CASE=2 or CASE=3 through COMMAKE_OPTIONS=-DCASE=n.
# Default CASE=1; corrected TSE lines: 10, 13, 16. Column fallback: 1.
!ifndef CASE
CASE=1
!endif

!if $(CASE) == 1
!error Deliberate MAKE error one
!endif
!if $(CASE) == 2
!error Deliberate MAKE error two
!endif
!if $(CASE) == 3
!error Deliberate MAKE error three
!endif

all:
	@echo Select CASE=1, CASE=2 or CASE=3 to test an error.
