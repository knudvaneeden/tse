-- errorstestdatabaseaccess.sql version 1.0.0.0.8
-- Each statement has its own error. The helper continues after each one.
SELECT * FROM MissingTableOne;
SELECT * FROM MissingTableTwo;
SELECT * FROM MissingTableThree;
