(* errorstest.ml version 1.0.0.0.7 - OpenAI GPT-6 *)
(* OCaml stops at the first compilation error.
   After checking each TSE jump, apply the fix noted below and recompile.
   Keep these ASCII lines unchanged to preserve test positions. *)

(* Error 1: unbound value. Fix: replace missing_one with 1. *)
let first = missing_one

(* Error 2: unbound value. Fix: replace missing_two with 2. *)
let second = missing_two

(* Error 3: unbound value. Fix: replace missing_three with 3. *)
let third = missing_three

let () = Printf.printf "%d %d %d\n" first second third
