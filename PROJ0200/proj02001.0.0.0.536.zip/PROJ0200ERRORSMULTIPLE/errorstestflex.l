/* errorstest.l version 1.0.0.0.8 - OpenAI ChatGPT GPT-6 */
/* Three independent undefined definitions at lines 8, 9, 10. */
%option noyywrap nounistd never-interactive
%{
#include <stdio.h>
%}
%%
{ONE}       ;
{TWO}       ;
{THREE}     ;
.           ;
\n          ;
%%
int main(void) { return 0; }
