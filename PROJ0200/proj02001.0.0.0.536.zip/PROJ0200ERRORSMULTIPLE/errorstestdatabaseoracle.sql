-- errorstestdatabaseoracle.sql version 1.0.0.0.9
-- Three independent statements: expected error lines 4, 7, 10.
-- Knud van Eeden / OpenAI ChatGPT GPT-6
SELECT TSE_MISSING_COLUMN_ONE FROM DUAL;
-- Each statement continues after the preceding error.
-- Second error:
SELECT TSE_MISSING_COLUMN_TWO FROM DUAL;
-- Third error:
-- No tables or procedures are created by this test.
SELECT TSE_MISSING_COLUMN_THREE FROM DUAL;
