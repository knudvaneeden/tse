<?xml version="1.0" encoding="UTF-8"?>
<!-- Version 1.0.0.0.0 - 2026-11-01 -->
<!-- Three intentional XPath errors on lines 6, 7 and 8. -->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:template match="/">
    <xsl:value-of select="("/>
    <xsl:value-of select="["/>
    <xsl:value-of select="1 +"/>
  </xsl:template>
</xsl:stylesheet>
