\ errorstestforth.fth - version 1.0.0.0.8
\ Date: 2026-11-05
\ Three independent undefined words; ordinary Gforth stops at the first.
\ Fix each by commenting its entire line with a backslash, then rerun.
\ Expected error lines: 10, then 13, then 16.
\ Each failing word starts at column 1; this is known test data only.
\ Older Gforth does not emit that numeric column in its diagnostics.
\ No CATCH recovery is added: this tests normal source loading.

forth_missing_word_one

\ Second error, visible after fixing the first:
forth_missing_word_two

\ Third error, visible after fixing the second:
forth_missing_word_three
