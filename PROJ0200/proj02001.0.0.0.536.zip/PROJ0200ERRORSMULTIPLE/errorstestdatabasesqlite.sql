-- errorstestdatabasesqlite.sql version 1.0.0.0.8
-- Knud van Eeden / OpenAI ChatGPT GPT-6
-- Three independent errors; expected jump lines 5, 8, 11 (column 1).
-- Error 1: SQL keyword misspelled.
SELEC 'first error';

-- Error 2: missing table.
SELECT * FROM missing_table_sqlite_test;

-- Error 3: missing function.
SELECT missing_function_sqlite_test(123);

SELECT 'Reached end: all three errors were attempted.';
