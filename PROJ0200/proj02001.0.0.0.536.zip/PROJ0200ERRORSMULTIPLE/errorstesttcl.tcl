# errorstesttcl.tcl - version 1.0.0.0.7 - 2026-11-04
# Three independent faults, revealed ONE AT A TIME (no catch/helper).
# Run 1: line 8, unknown command. Comment out line 8 and rerun.
# Run 2: line 11, missing variable. Comment out line 11 and rerun.
# Run 3: line 14, invalid expression operand. Comment out line 14.
# Final run: success. Rule uses column 1 as a fallback, not exact column.
puts "Testing Tcl errors (one per run)."
this_command_does_not_exist

# Error 2: this variable has deliberately never been defined.
puts $comtcl_missing_variable_100007

# Error 3: a word is not a valid numeric operand for addition.
puts [expr {1 + "not_a_number"}]
puts "All three test faults have been removed."
