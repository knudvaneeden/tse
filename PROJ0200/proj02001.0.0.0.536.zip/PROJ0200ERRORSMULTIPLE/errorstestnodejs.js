// errorstestnodejs.js - version 1.0.0.0.9 - 2026-11-02
// Save in f:\bbc\taal\proj0200errorsmultiple\errorstestnodejs.js
// Node reports ONE syntax error per run, not three together.
// Expected jumps: line 9 col 15; line 12 col 16; line 15 col 15.
// Replace each empty initializer with 1, then compile again.
// After all three fixes, this file prints 3 and exits successfully.
"use strict";
// Error 1:
const first = ;

// Error 2:
const second = ;

// Error 3:
const third = ;
console.log(first + second + third);
