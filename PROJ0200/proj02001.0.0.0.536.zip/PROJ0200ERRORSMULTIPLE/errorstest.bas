' errorstest.bas version 1.0.0.0.7
' OpenAI GPT-6 / Codex - three independent BC30451 errors.
Option Explicit On
Option Strict On
Module ErrorsTest
    Sub Main()
        missingOne = 1
        missingTwo = 2
        missingThree = 3
    End Sub
End Module
