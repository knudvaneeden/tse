greet(name) {
 return name
}
