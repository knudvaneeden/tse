defmodule Greeting do
  def greet(name), do: name
end
