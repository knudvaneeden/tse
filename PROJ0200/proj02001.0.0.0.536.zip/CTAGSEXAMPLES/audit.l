greet [a-z]+
%%
{greet} ECHO;
%%
