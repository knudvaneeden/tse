Definition greet := 1.
