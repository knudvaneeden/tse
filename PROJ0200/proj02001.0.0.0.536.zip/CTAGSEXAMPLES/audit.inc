// PROC fake()
integer proc greet()
 return(1)
end
