function Greet { "Hello" }
Greet
