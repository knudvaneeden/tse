Function Greet(name)
 Greet = name
End Function
