%token HELLO
%%
greet: HELLO ;
%%
