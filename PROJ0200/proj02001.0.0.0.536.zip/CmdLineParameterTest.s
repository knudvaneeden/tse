/*
  Macro           CmdLineParameterTest
  Author          Carlo.Hogeveen@xs4all.nl
  Compatibility   TSE Pro 4.0 upwards
  Version         1.0 - 19 Dec 2019


  This is a test tool to test passing parameters from the command line.


  INSTALLATION

  Just put this source file in TSE's "mac" folder and compile it there, for
  instance by opening the file in TSE and applying the Macro, Compile menu.


  USAGE

  Preconditions:
    The CmdLineParameter macro is installed according to its specifications.
    The TSE folder is in your path or is the current folder in the command line.

  From a Windows command line (prompt) you can test supplying parameters
  to the "CmdLineParameterTest" macro, for example with these commands:
    g32 -eCmdLineParameterTest -p Hello World!
    g32 -eCmdLineParameterTest -p "Hello World!"
    g32 -eCmdLineParameterTest -p "Hello World!" "Goodbye World!"
    g32 -eCmdLineParameterTest -p "Hello World!" -p- "Goodbye World!"
    g32 -p "Hello World!" -p- -eCmdLineParameterTest
    g32 -p "Hello World!" -eCmdLineParameterTest -p- -eCmdLineParameterTest


  HISTORY

  v1.0 - 19 Dec 2019
    Initial release.
*/



// Global constant
string  parameter_macro_name [MAXSTRINGLEN] = 'CmdLineParameter'

// Global variable
string  my_macro_name [MAXSTRINGLEN] = ''

proc test(string test_macro_name)
  integer i                              = 0
  string  parameter_name  [MAXSTRINGLEN] = ''
  string  parameter_value [MAXSTRINGLEN] = ''
  repeat
    i = i + 1
    parameter_name  = Format(parameter_macro_name, ':', test_macro_name, ':', i)
    parameter_value = GetGlobalStr(parameter_name)
    if parameter_value <> ''
      Warn('The value of "', parameter_name, '" is "', parameter_value, '".')
    endif
  until parameter_value == ''
end test

proc WhenLoaded()
  my_macro_name = SplitPath(CurrMacroFilename(), _NAME_)
end WhenLoaded

proc Main()
  test(my_macro_name)
  test('')
  PurgeMacro(my_macro_name)
end Main

