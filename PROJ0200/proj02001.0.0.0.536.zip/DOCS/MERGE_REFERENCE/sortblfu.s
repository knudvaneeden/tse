FORWARD INTEGER PROC FNBlockCheckLineEmptyAllB()
FORWARD INTEGER PROC FNBlockSortLogFileLogDateTimeAllMergeToBufferCanonicalFrontSimpleB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3, INTEGER i4 )
FORWARD INTEGER PROC FNDateCheckYearLeapB( INTEGER i1 )
FORWARD INTEGER PROC FNErrorCheckSB( STRING s1 )
FORWARD INTEGER PROC FNFileCheckLineEmptyAllB( STRING s1 )
FORWARD INTEGER PROC FNMacroCheckExecB( STRING s1 )
FORWARD INTEGER PROC FNMacroCheckLoadB( STRING s1 )
FORWARD INTEGER PROC FNMathCheckGetLogicFalseB()
FORWARD INTEGER PROC FNMathCheckGetLogicTrueB()
FORWARD INTEGER PROC FNMathCheckLogicNotB( INTEGER i1 )
FORWARD INTEGER PROC FNMathCheckLogicOrB( INTEGER i1, INTEGER i2 )
FORWARD INTEGER PROC FNMathGetDateTodayTotalI( INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNStringCheckEmptyB( STRING s1 )
FORWARD INTEGER PROC FNStringCheckEnvironmentFoundNotB( STRING s1 )
FORWARD INTEGER PROC FNStringCheckEqualB( STRING s1, STRING s2 )
FORWARD INTEGER PROC FNStringCheckEqualCharacterLastNB( STRING s1, STRING s2 )
FORWARD INTEGER PROC FNStringCheckEqualErrorOrEmptyB( STRING s1 )
FORWARD INTEGER PROC FNStringGetLengthI( STRING s1 )
FORWARD PROC Main()
FORWARD PROC PROCFileRun4NtAliasCommandListUser( STRING s1 )
FORWARD PROC PROCMacroExec( STRING s1 )
FORWARD PROC PROCMacroRunKeep( STRING s1 )
FORWARD PROC PROCWarn( STRING s1 )
FORWARD PROC PROCWarnCons3( STRING s1, STRING s2, STRING s3 )
FORWARD STRING PROC FNStringGetAsciiToCharacterS( INTEGER i1 )
FORWARD STRING PROC FNStringGetCarS( STRING s1 )
FORWARD STRING PROC FNStringGetCharacterEndBackSlashNotEqualInsertEndS( STRING s1 )
FORWARD STRING PROC FNStringGetCharacterInsertEndIfEqualNotS( STRING s1, STRING s2 )
FORWARD STRING PROC FNStringGetCharacterSymbolCentralS( INTEGER i1 )
FORWARD STRING PROC FNStringGetCharacterSymbolSlashBackwardS()
FORWARD STRING PROC FNStringGetCharacterSymbolSpaceS()
FORWARD STRING PROC FNStringGetConcatS( STRING s1, STRING s2 )
FORWARD STRING PROC FNStringGetConcatSeparatorS( STRING s1, STRING s2, STRING s3 )
FORWARD STRING PROC FNStringGetConcatTailS( STRING s1, STRING s2 )
FORWARD STRING PROC FNStringGetCons3S( STRING s1, STRING s2, STRING s3 )
FORWARD STRING PROC FNStringGetConsS( STRING s1, STRING s2 )
FORWARD STRING PROC FNStringGetDateChangeMonthToIntegerS( STRING s1 )
FORWARD STRING PROC FNStringGetDateWeekDayNameS( INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD STRING PROC FNStringGetEmptyS()
FORWARD STRING PROC FNStringGetEnvironmentS( STRING s1 )
FORWARD STRING PROC FNStringGetErrorS()
FORWARD STRING PROC FNStringGetFileGetFilenamePathDefaultS( STRING s1 )
FORWARD STRING PROC FNStringGetFileIniDefaultS( STRING s1 )
FORWARD STRING PROC FNStringGetFilenameEndBackSlashNotEqualInsertEndS( STRING s1 )
FORWARD STRING PROC FNStringGetFilenameIniDefaultS()
FORWARD STRING PROC FNStringGetInitializationGlobalS( STRING s1, STRING s2, STRING s3 )
FORWARD STRING PROC FNStringGetMidStringS( STRING s1, INTEGER i1, INTEGER i2 )
FORWARD STRING PROC FNStringGetPathFileAliasUnicode4Dos4NtFilenameS()
FORWARD STRING PROC FNStringGetPathUser_DataApplicationCurrentBackslashNotS()
FORWARD STRING PROC FNStringGetPathUser_DataApplicationCurrentBackslashS()
FORWARD STRING PROC FNStringGetProgram4ntFilenameS()
FORWARD STRING PROC FNStringGetRightStringLengthEqualS( STRING s1, STRING s2 )
FORWARD STRING PROC FNStringGetRightStringS( STRING s1, INTEGER i1 )
FORWARD STRING PROC FNStringGetSectionSeparatorS()
FORWARD STRING PROC FNStringGet_FilenameIniDefaultS()


// --- MAIN --- //

PROC Main()
 STRING s1[255] = "g:\mydownloadfiles\from_job_to_home\dddlogmergeregularexpressionall.txt" // change this // make sure this exists with the latest unique regular expressions in it: file containing unique regular expressions to search with
 STRING s2[255] = "c:\temp\ddd.log" // change this
 STRING s3[255] = "1" // 0 = do not show weekday / 1 = show weekday
 STRING s4[255] = "1" // 0 = do not remove file from ring / 1 = do remove file from ring
 STRING s5[255] = "0" // 0 = do not run LogViewPlus / 1 = run LogViewPlus
 //
 INTEGER buffer1I = 0
 //
 PushPosition()
 buffer1I = CreateTempBuffer()
 PopPosition()
 //
 Message( FNBlockSortLogFileLogDateTimeAllMergeToBufferCanonicalFrontSimpleB( s1, s2, Val( s3 ), Val( s4 ), Val( s5 ), buffer1I ) ) // gives e.g. TRUE
 //
 EditFile( s2 )
 //
END

<F12> Main()

// --- LIBRARY --- //

// library: block: sort: log: file: log: date: time: all: merge: to: buffer: canonical: front: simple <description></description> <version control></version control> <version>1.0.0.0.162</version> <version control></version control> (filenamemacro=sortblfu.s) [<Program>] [<Research>] [kn, ri, th, 07-04-2022 01:01:10]
INTEGER PROC FNBlockSortLogFileLogDateTimeAllMergeToBufferCanonicalFrontSimpleB( STRING fileNameExpressionRegularS, STRING fileNameOutputS, INTEGER weekDayB, INTEGER removeFileFromRingB, INTEGER runLogViewPlusB, INTEGER buffer1I )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = "g:\mydownloadfiles\from_job_to_home\dddlogmergeregularexpressionall.txt" // change this // make sure this exists with the latest unique regular expressions in it: file containing unique regular expressions to search with
 // e.g.  STRING s2[255] = "c:\temp\ddd.log" // change this
 // e.g.  STRING s3[255] = "1" // 0 = do not show weekday / 1 = show weekday
 // e.g.  STRING s4[255] = "1" // 0 = do not remove file from ring / 1 = do remove file from ring
 // e.g.  STRING s5[255] = "0" // 0 = do not run LogViewPlus / 1 = run LogViewPlus
 // e.g.  //
 // e.g.  INTEGER buffer1I = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer1I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  Message( FNBlockSortLogFileLogDateTimeAllMergeToBufferCanonicalFrontSimpleB( s1, s2, Val( s3 ), Val( s4 ), Val( s5 ), buffer1I ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  EditFile( s2 )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Use case =
 //
 //  Constraints:
 //
 //   -milliseconds are ignored
 //
 //   -time zone differences are ignored
 //
 //   -It might be that the incorrect regular expression is used, because it was found before the correct one,
 //    and then e.g. it indeed finds hits using that regular expression, but usually it finds much less than
 //    when using the correct regular expression.
 //
 //   -Adding new regular expressions might influence other present regular expressions as they are e.g. smaller subsets of each other
 //    which might lead to one overruling the other and become active and taken the regular expression handling over.
 //    So it is a dependent system in general, where the parts might influence each other.
 //
 //    Thus e.g. the order (thus which regular expression comes first and which regular expression comes next)
 //    in which these regular expressions are applied and added is significant.
 //
 // ===
 //
 // Method =
 //
 // Tried, but did not work:
 //
 // 1. -the difference between e.g. YYYY MM DD and YYYY DD MM (e.g. 2022-06-02 versus 2022-02-06) can not be determined unambiguously,
 //     so no unique order of s1 s2 s3 s4 can be determined.
 //
 // 2. -the difference between YY MM DD (e.g. 19 3 31 23) (e.g. when a date/time stamp with YY is used) can not be determined so no,
 //     no unique order of s1 s2 s3 s4 can be determined.
 //
 // Conclusion: You must also include the correct order (e.g. s1 s2 s3 s4)
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 // ===
 //
 // Do not work, debug
 //
 /*
--- cut here: begin --------------------------------------------------
 //
 // ===
 //
 // Smaller tham expected date/timestamp output
 //
 //  -Root cause 1: When only a partial part of the file is handled, check the caseI of the regular expression used.
 //                 Move the correct regular expression to and earlier position in the regular expression file
 //                 (higher and before the number shown of the 'CaseI' output when debugging)
 //
 // ===
 //
 // No applicable search string was found
 //
 //  -Make sure you add the regular expression both to the file + also in the WHEN ... case and recompile.
 //
 // ===
 //
 // No regular expression found
 //
 //  -root cause 1: empty file
 //  -root cause 2: wrong file, e.g. not a Wireshark format file, but something else
 //  -root cause 3: incorrect regular expression (e.g. only partially correct)
 //
 // ===
 //
 // Only a partial search result is shown
 //
 //  -root cause 1: the wrong regular expression is chosen in the file. Move that regular expression further down in the file to give it lower priority as it is found later.
 //
 // ===
 //
 //
 // Format: '>' truncated
 //
 //  -root cause 1: Occurrence of alphanumeric month in the date/timestamp which is not taken into account and not converted (e.g. 24 Nov 2021 16:12:13)
 //  -root cause 2: Do not add extra {} in the regular expression, because that changes GetFoundText( 1 ), GetFoundText( 2 ), ...
 //  -root cause 3: Wrong order of {} (e.g. too many {}, e.g. including the time zone also. Or too little {}.
 //
 //  ===
 //
 // Format: HH:mm:SS missing
 //
 // ===
 //
 // Format: Weekday wrong
 //
 //  -root cause1: not passing the strings s1, s2, s3, s4 in the order day, month, year
 //
 // ===
 //
 // Empty file as a result
 //
 // ===
 //
 // Case 0 not known
 //
 //  -root cause: no regular expression found in the regular expression file. Check the regular expression in the .csv record. If not found add it to the end of the list.
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // To check still:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // Work OK:
 //
 /*
--- cut here: begin --------------------------------------------------
c:\mydownloadfiles\job\softwareag\case\casenumber1-005398522\_full_.log
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\13jvm_thread_dumps\low1.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\13jvm_thread_dumps\low2.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\13jvm_thread_dumps\low3.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\13jvm_thread_dumps\low4.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005415448\1brokerdatalogs\diag.log
c:\mydownloadfiles\job\softwareag\case\casenumber1-005415448\1brokerdatalogs\diag.log.1579613256
c:\mydownloadfiles\job\softwareag\case\casenumber1-005415448\1brokerdatalogs\diag.log.1588866870
c:\mydownloadfiles\job\softwareag\case\casenumber1-005415448\1brokerdatalogs\diag.log.1589281634
c:\mydownloadfiles\job\softwareag\case\casenumber1-005415448\1brokerdatalogs\diag.log.1590585954
c:\mydownloadfiles\job\softwareag\case\casenumber1-005415448\1brokerdatalogs\diag.log.1590769499
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\12is_thread_dumps\thread_dump_1.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\12is_thread_dumps\thread_dump_2.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\12is_thread_dumps\thread_dump_3.txt
"c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\15lu failure\lu_thread_dump.txt"
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\1diagnostics_esbwp21.escb.eu_5001_2021022418085\runtime\threaddump.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\2diagnostics_exdi-gw.cz.escb.eu_5001_\runtime\threaddump.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\3diagnostics_exdi-gw.cz.escb.eu_5001_2021052\runtime\threaddump.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\4diagnostics_exdi-gw.cz.escb.eu_6001_2021022\runtime\threaddump.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\5diagnostics_exdi-gw.ext.nbp.pl_5001_2021031\runtime\threaddump.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\6diagnostics_exdi-gw.lu.escb.eu_7001_2021061\runtime\threaddump.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\7diagnostics_m999exdix002p.in.bu\runtime\threaddump.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\8diagnostics_m999exdix002p.in.bu\runtime\threaddump.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\9diagnostics_m999exdix002p.in.bu\runtime\threaddump.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\thread dump_pl_low_prod.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005441113\2logsnirvana_um58152\umrealmservice.log
c:\mydownloadfiles\job\softwareag\case\casenumber1-005444369\3sr5444369esb_live_20210614151652785\universalmessaging\server\umhigh\plugins\log\plugin.log
c:\mydownloadfiles\job\softwareag\case\casenumber1-005444636\wrapper.log
c:\softwareag\broker96\broker\data\awbrokers96\default\diag.log
c:\softwareag\integrationserver\instances\default\logs\umclient.log
g:\messaging\universalmessaging1030\universalmessaging\server\umserver\data\nirvana.log
g:\mydownloadfiles\from_job_to_home\log\dddiis.log
g:\mydownloadfiles\from_job_to_home\log\dddmysqlserver.err
g:\mydownloadfiles\from_job_to_home\log\dddwindowseventviewer.txt
g:\mydownloadfiles\from_job_to_home\log\oracle_alert_xe.log
g:\utils\apache\logs\error.log
g:\utils\tomcat\apache-tomcat-7.0.2\logs\catalina.2010-09-12.log
g:\utils\tomcat\apache-tomcat-7.0.2\logs\manager.2018-09-07.log
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\1diagnostics_esbwp21.escb.eu_5001_2021022418085\logs\stats.log
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\1diagnostics_esbwp21.escb.eu_5001_2021022418085\runtime\threadlist.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\1diagnostics_esbwp21.escb.eu_5001_2021022418085\runtime\threadlocal.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\2diagnostics_exdi-gw.cz.escb.eu_5001_\runtime\threadlist.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\2diagnostics_exdi-gw.cz.escb.eu_5001_\runtime\threadlocal.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\3diagnostics_exdi-gw.cz.escb.eu_5001_2021052\runtime\threadlist.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\3diagnostics_exdi-gw.cz.escb.eu_5001_2021052\runtime\threadlocal.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\4diagnostics_exdi-gw.cz.escb.eu_6001_2021022\runtime\threadlist.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\4diagnostics_exdi-gw.cz.escb.eu_6001_2021022\runtime\threadlocal.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\5diagnostics_exdi-gw.ext.nbp.pl_5001_2021031\runtime\threadlist.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\5diagnostics_exdi-gw.ext.nbp.pl_5001_2021031\runtime\threadlocal.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\6diagnostics_exdi-gw.lu.escb.eu_7001_2021061\logs\error.log
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\6diagnostics_exdi-gw.lu.escb.eu_7001_2021061\runtime\threadlist.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\6diagnostics_exdi-gw.lu.escb.eu_7001_2021061\runtime\threadlocal.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\7diagnostics_m999exdix002p.in.bu\runtime\threadlist.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\7diagnostics_m999exdix002p.in.bu\runtime\threadlocal.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\8diagnostics_m999exdix002p.in.bu\runtime\threadlist.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\8diagnostics_m999exdix002p.in.bu\runtime\threadlocal.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\9diagnostics_m999exdix002p.in.bu\runtime\threadlist.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\9diagnostics_m999exdix002p.in.bu\runtime\threadlocal.txt
c:\mydownloadfiles\job\softwareag\case\casenumber1-005447235\2sr5447235sr5447235_diagnostics_rtmas0124\profiles\logs\platform.log
c:\mydownloadfiles\job\softwareag\case\casenumber1-005447235\2sr5447235sr5447235_diagnostics_rtmas0124\profiles\logs\sag-osgi.log
c:\mydownloadfiles\job\softwareag\case\casenumber1-005447235\2sr5447235sr5447235_diagnostics_rtmas0124\profiles\logs\activetransfer.log
c:\softwareag105\integrationserver\instances\default\logs\server.log
C:\SoftwareAG\IntegrationServer\instances\default\logs\server.log
g:\applicationserver\jboss\jboss-4.2.3.ga\server\default\log\server.log
g:\mydownloadfiles\from_job_to_home\log\dddbrokerlogmsgs.log
g:\mydownloadfiles\from_job_to_home\log\dddiisw3svc.log
g:\mydownloadfiles\from_job_to_home\log\dddwireshark.txt
g:\mydownloadfiles\from_job_to_home\log\logmsgs.log
g:\mydownloadfiles\from_job_to_home\log\logmsgs.mon.log
c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\1diagnostics_esbwp21.escb.eu_5001_2021022418085\logs\session.log
c:\mydownloadfiles\job\softwareag\case\casenumber1-005447566\1sr5447566diagnostics_parmanu.c\logs\session.log
c:\mydownloadfiles\job\softwareag\case\casenumber1-005447235\2sr5447235sr5447235_diagnostics_rtmas0124\logs\service.log
c:\mydownloadfiles\job\softwareag\case\casenumber1-005447566\1sr5447566diagnostics_parmanu.c\logs\security.log
c:\mydownloadfiles\job\softwareag\case\casenumber1-005447566\1sr5447566diagnostics_parmanu.c\logs\txin.log
c:\mydownloadfiles\job\softwareag\case\casenumber1-005447566\1sr5447566diagnostics_parmanu.c\logs\txout.log
g:\mydownloadfiles\from_job_to_home\log\gc.log
g:\mydownloadfiles\from_job_to_home\log\http.log
g:\utils\apache\logs\access.log
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // Data:
 //
 // Unique regular expressions to search with
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 STRING searchS[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 STRING searchFoundS[255] = ""
 INTEGER caseI = 0
 //
 INTEGER buffer2I = 0
 INTEGER buffer3I = 0
 //
 INTEGER down1B = TRUE
 INTEGER down2B = TRUE
 //
 INTEGER foundB = FALSE
 //
 INTEGER indexMinI = 1
 INTEGER indexI = indexMinI - 1
 //
 STRING caseS[255] = ""
 //
 STRING fileNameSortInputS[255] = "c:\temp\ddd1.txt" // change this
 //
 INTEGER dayI = 0
 INTEGER monthI = 0
 INTEGER yearI = 0
 //
 INTEGER fileEmptyB = FALSE
 //
 INTEGER fileExistB = FALSE
 //
 STRING fileNameS[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 // reset output
 //
 PushPosition()
 PushBlock()
 //
 IF EditFile( fileNameOutputS )
  AbandonFile()
 ENDIF
 EraseDiskFile( fileNameOutputS )
 //
 PopBlock()
 PopPosition()
 //
 PushPosition()
 PushBlock()
 //
 PushPosition()
 buffer2I = CreateTempBuffer()
 PopPosition()
 //
 // ===
 //
 // buffer1 = output of sorted on date/time stamp merged files
 //
 // buffer2 = list of regular expressions to search with in the current filename
 //
 // buffer3 = currently loaded file
 //
 // ===
 //
 // insert in a buffer a list of regular expressions to search with in the current filename
 //
 PushPosition()
 PushBlock()
 IF GotoBufferId( buffer2I )
  InsertFile( fileNameExpressionRegularS )
 ENDIF
 PopBlock()
 PopPosition()
 //
 // one by one take a filename from the list in the block
 //
 GotoBlockBegin()
 //
 WHILE ( ( IsCursorInBlock() ) AND ( down1B ) )
  //
  IF NOT LFind( "^$", "cgx" )
   //
   fileNameS = GetText( 1, MAXSTRINGLEN )
   fileNameS = Trim( fileNameS )
   fileNameS = QuotePath( fileNameS )
   //
   // Warn( fileNameS ) // debug
   //
   fileExistB = FileExists( fileNameS )
   IF ( NOT fileExistB )
    Warn( "This file", ":", " ", fileNameS, ":", " ", "does not exist or is not found. Please check if applicable" )
   ENDIF
   //
   fileEmptyB = FNFileCheckLineEmptyAllB( fileNameS )
   IF ( fileEmptyB )
    Warn( "This file", ":", " ", fileNameS, ":", " ", "is empty. Please check if applicable" )
   ENDIF
   //
   IF ( fileExistB ) AND ( NOT ( fileEmptyB ) )
    //
    PushPosition()
    PushBlock()
    //
    // delete the current file in the buffer
    //
    PushPosition()
    PushBlock()
    AbandonFile( buffer3I )
    buffer3I = CreateTempBuffer()
    PopBlock()
    PopPosition()
    //
    // load the current file in the buffer
    //
    PushPosition()
    PushBlock()
    IF GotoBufferId( buffer3I )
     InsertFile( fileNameS )
    ENDIF
    PopBlock()
    PopPosition()
    //
    // take one by one a regular search expression from the list in the buffer
    //
    GotoBufferId( buffer2I )
    MarkLine( 1, NumLines() )
    //
    GotoBlockBegin()
    //
    foundB = FALSE
    //
    WHILE ( ( IsCursorInBlock() ) AND ( down2B ) AND NOT foundB )
     //
     // get the current regular expression line
     //
     searchS = GetText( 1, MAXSTRINGLEN )
     searchS = Trim( searchS )
     //
     // Warn( CurrLine(); searchS ) // debug
     //
     PushPosition()
     PushBlock()
     //
     // goto the current loaded file in the buffer
     //
     GotoBufferId( buffer3I )
     //
     caseS = "index"
     //
     // search the current regular expression line in the currently loaded file
     //
     foundB = LFind( searchS, "gx" )
     //
     IF ( foundB )
      //
      searchFoundS = ""
      //
      caseI = 0
      //
      CASE searchS
       WHEN "\|[ ]*{[0-9][0-9][0-9][0-9]}/{[0-9][0-9]}/{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}[ ]+\|"                                                                        searchFoundS = searchS   caseI = 68    // 68  Order: s1 s2 s3 s4
       WHEN "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[T]{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}\,[0-9][0-9][0-9]"                                                                    searchFoundS = searchS   caseI = 01    // 01  Order: s1 s2 s3 s4
       WHEN "\[[A-Z][a-z][a-z][ ]+{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}[ ]+{[0-9][0-9][0-9][0-9]}\]"                                                  searchFoundS = searchS   caseI = 03    // 03  Order: s4 s1 s2 s3
       WHEN "{[0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9][0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}\.{[0-9][0-9][0-9]}"                                                                 searchFoundS = searchS   caseI = 05    // 05  Order: s3 s2 s1 s4
       WHEN "{[A-Z][a-z][a-z]}[ ]+{[0-9]?[0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}[ ]+{[0-9][0-9][0-9][0-9]}"                                                                        searchFoundS = searchS   caseI = 07    // 07  Order: s4 s1 s2 s3
       WHEN "{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}.*cs5={[0-9][0-9][0-9][0-9]}"                                                                       searchFoundS = searchS   caseI = 11    // 11  Order: s4 s1 s2 s3
       WHEN "\[[A-Z][a-z][a-z][ ]+{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}[ ]+[A-Z][A-Z][A-Z]?[A-Z]?[A-Z]?[ ]+{[0-9][0-9][0-9][0-9]}\]"                  searchFoundS = searchS   caseI = 15    // 15  Order: s4 s1 s2 s3
       WHEN "{[0-9][0-9][0-9][0-9]}/{[0-9][0-9]}/{[0-9][0-9]}[ ]+at[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"                                                                              searchFoundS = searchS   caseI = 16    // 16  Order: s1 s2 s3 s4
       WHEN "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]\.[0-9][0-9]\.[0-9][0-9]}\.{[0-9][0-9][0-9][0-9][0-9][0-9]}"                                                   searchFoundS = searchS   caseI = 17    // 17  Order: s1 s2 s3 s4
       WHEN "{[0-9][0-9]}\.{[0-9][0-9]}\.{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}\.{[0-9][0-9][0-9]}[ ]+\["                                                                   searchFoundS = searchS   caseI = 19    // 19  Order: s3 s2 s1 s4
       WHEN "\[{[0-9][0-9]}/{[A-Z][a-z][a-z]}/{[0-9][0-9][0-9][0-9]}:{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}[ ]+{[+-][0-9][0-9][0-9][0-9]}\]"                                                searchFoundS = searchS   caseI = 21    // 21  Order: s3 s2 s1 s4
       WHEN "\t?{[0-9][0-9][0-9][0-9]}[-/]{[0-9][0-9]}[-/]{[0-9][0-9]}[T ]{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"                                                                           searchFoundS = searchS   caseI = 27    // 27  Order: s1 s2 s3 s4
       WHEN "{[0-9][0-9]}/{[0-9][0-9]}/{[0-9][0-9][0-9][0-9]} {[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"                                                                                       searchFoundS = searchS   caseI = 30    // 30  Order: s3 s2 s1 s4
       WHEN "[A-Z][a-z][a-z][ ]+{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}[ ]+[A-Z][A-Z][A-Z]?[A-Z]?[A-Z]?[ ]+{[0-9][0-9][0-9][0-9]}[ ]+"                  searchFoundS = searchS   caseI = 31    // 31  Order: s4 s1 s2 s3
       WHEN "\[[A-Z][a-z][a-z][ ]+{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}\.[0-9][0-9][0-9][ ]+[A-Z][A-Z][A-Z]?[A-Z]?[A-Z]?[ ]+{[0-9][0-9][0-9][0-9]}\]" searchFoundS = searchS   caseI = 34    // 34  Order: s4 s1 s2 s3
       WHEN "{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"                                                                                                   searchFoundS = searchS   caseI = 40    // 40  Order:  ? s1 s2 s3
       WHEN "{[0-9][0-9]}{[0-9][0-9]}{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"                                                                                                searchFoundS = searchS   caseI = 48    // 48  Order: s1 s2 s3 s4
       WHEN "{[0-9][0-9]}\.{[0-9][0-9]}\.{[0-9][0-9][0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]}"                                                                                             searchFoundS = searchS   caseI = 53    // 53  Order: s3 s2 s1 s4
       WHEN "{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]}[ ]+{[0-9][0-9][0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"                                                                         searchFoundS = searchS   caseI = 58    // 58  Order: s3 s1 s2 s4
       WHEN "{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]?}\,[ ]+{[0-9][0-9][0-9][0-9]}[ ]+{[0-9][0-9]?:[0-9][0-9]?:[0-9][0-9]?}[ ]+{{AM}|{PM}}"                                                    searchFoundS = searchS   caseI = 61    // 61  Order: s3 s1 s2 s4
       WHEN "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"                                                                                    searchFoundS = searchS   caseI = 08    // 08  Order: s1 s2 s3 s4
       WHEN "{[0-9][0-9]}-{[A-Z][a-z][a-z]}-{[0-9][0-9][0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"                                                                               searchFoundS = searchS   caseI = 14    // 14  Order: s3 s2 s1 s4
      OTHERWISE
       Warn( "caseI=", caseI, ".", " ", "No applicable regular expression found in the list. Please check that list in the file and add a regular expression if applicable" )
       Warn( "Also if you add or change the regular expression in the file, you must also verbatim put it here, otherwise it will not be found." )
       B = FALSE
       RETURN( B )
      ENDCASE
      //
      // Warn( caseI ) // debug
      //
     ENDIF
     //
     PopBlock()
     PopPosition()
     //
     down2B = Down()
     //
    ENDWHILE
    //
    PopPosition()
    PopBlock()
    //
   ENDIF
   //
   PushPosition()
   PushBlock()
   //
   // Goto the current file, put the standardized date/time stamp in front of each found line and put the result in the buffer
   //
   GotoBufferId( buffer3I )
   MarkLine( 1, NumLines() )
   //
   indexI = indexI + 1
   //
   GotoBlockBegin()
   //
   // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
   //
   // Warn( searchFoundS ) // debug
   //
   WHILE ( LFind( searchFoundS, "lx" ) AND IsCursorInBlock() )
    //
    s1 = GetFoundText( 1 )
    s2 = GetFoundText( 2 )
    s3 = GetFoundText( 3 )
    s4 = GetFoundText( 4 )
    //
    s1 = FNStringGetDateChangeMonthToIntegerS( s1 )
    s2 = FNStringGetDateChangeMonthToIntegerS( s2 )
    s3 = FNStringGetDateChangeMonthToIntegerS( s3 )
    s4 = FNStringGetDateChangeMonthToIntegerS( s4 )
    //
    // keeping this same order of extracting (e.g. s1 s2 s3 s4) is mandatory in the below, because that is the order in which the standard format is created (that is first year, then month, then day, then time.
    //
    /*
    // Order: s1 s2 s3 s4  caseI = 01
    // Order: s4 s1 s2 s3  caseI = 03
    // Order: s3 s2 s1 s4  caseI = 05
    // Order: s4 s1 s2 s3  caseI = 07
    // Order s4 s1 s2 s3   caseI = 11
    // Order: s3 s2 s1 s4  caseI = 14
    // Order: s4 s1 s2 s3  caseI = 15
    // Order: s1 s2 s3 s4  caseI = 16
    // Order: s1 s2 s3 s4  caseI = 17
    // Order: s3 s2 s1 s4  caseI = 19
    // Order: s3 s2 s1 s4  caseI = 30
    // Order: s4 s1 s2 s3  caseI = 31
    // Order: s4 s1 s2 s3  caseI = 34
    // Order: ? s1 s2 s3   caseI = 40
    // Order: s1 s2 s3 s4  caseI = 48
    // Order: s3 s2 s1 s4  caseI = 53
    // Order: s3 s1 s2 s4  caseI = 58
    // Order: s3 s1 s2 s4  caseI = 61
    // Order: s1 s2 s3 s4  caseI = 08
    */
    //
    // Warn( "caseI"; caseI ) // debug
    //
    CASE caseI
     //
     WHEN 02     // Order: s1 s2 s3 s4  caseI = 01
      //
      IF Length( s1 ) == 2
       s1 = Format( "20", s1 )
      ENDIF
      //
      dayI = Val( s3 )
      monthI = Val( s2 )
      yearI = Val( s1 )
      //
      s = Format( s1, "-", Format( s2 : 2 : "0" ), "-", Format( s3 : 2 : "0" ), " ", s4 )
      //
     WHEN 03    // Order: s4 s1 s2 s3  caseI = 03
      //
      IF Length( s4 ) == 2
       s4 = Format( "20", s4 )
      ENDIF
      //
      dayI = Val( s2 )
      monthI = Val( s1 )
      yearI = Val( s4 )
      //
      s = Format( s4, "-", Format( s1 : 2 : "0" ), "-", Format( s2 : 2 : "0" ), " ", s3 )
      //
     WHEN 05    // Order: s3 s2 s1 s4  caseI = 05
      //
      IF Length( s3 ) == 2
       s3 = Format( "20", s3 )
      ENDIF
      //
      dayI = Val( s1 )
      monthI = Val( s2 )
      yearI = Val( s3 )
      //
      s = Format( s3, "-", Format( s2 : 2 : "0" ), "-", Format( s1 : 2 : "0" ), " ", s4 )
      //
     WHEN 07    // Order: s4 s1 s2 s3  caseI = 07
      //
      IF Length( s4 ) == 2
       s4 = Format( "20", s4 )
      ENDIF
      //
      dayI = Val( s2 )
      monthI = Val( s1 )
      yearI = Val( s4 )
      //
      s = Format( s4, "-", Format( s1 : 2 : "0" ), "-", Format( s2 : 2 : "0" ), " ", s3 )
      //
     WHEN 11    // Order s4 s1 s2 s3   caseI = 11
      //
      IF Length( s4 ) == 2
       s4 = Format( "20", s4 )
      ENDIF
      //
      dayI = Val( s2 )
      monthI = Val( s1 )
      yearI = Val( s4 )
      //
      s = Format( s4, "-", Format( s1 : 2 : "0" ), "-", Format( s2 : 2 : "0" ), " ", s3 )
      //
     WHEN 14    // Order: s3 s2 s1 s4  caseI = 14
      //
      IF Length( s3 ) == 2
       s3 = Format( "20", s3 )
      ENDIF
      //
      dayI = Val( s1 )
      monthI = Val( s2 )
      yearI = Val( s3 )
      //
      s = Format( s3, "-", Format( s2 : 2 : "0" ), "-", Format( s1 : 2 : "0" ), " ", s4 )
      //
     WHEN 15    // Order: s4 s1 s2 s3  caseI = 15
      //
      IF Length( s4 ) == 2
       s4 = Format( "20", s4 )
      ENDIF
      //
      dayI = Val( s2 )
      monthI = Val( s1 )
      yearI = Val( s4 )
      //
      s = Format( s4, "-", Format( s1 : 2 : "0" ), "-", Format( s2 : 2 : "0" ), " ", s3 )
      //
     WHEN 16    // Order: s1 s2 s3 s4  caseI = 16
      //
      IF Length( s1 ) == 2
       s1 = Format( "20", s1 )
      ENDIF
      //
      dayI = Val( s3 )
      monthI = Val( s2 )
      yearI = Val( s1 )
      //
      s = Format( s1, "-", Format( s2 : 2 : "0" ), "-", Format( s3 : 2 : "0" ), " ", s4 )
      //
     WHEN 17    // Order: s1 s2 s3 s4  caseI = 17
      //
      IF Length( s1 ) == 2
       s1 = Format( "20", s1 )
      ENDIF
      //
      dayI = Val( s3 )
      monthI = Val( s2 )
      yearI = Val( s1 )
      //
      s = Format( s1, "-", Format( s2 : 2 : "0" ), "-", Format( s3 : 2 : "0" ), " ", s4 )
      //
     WHEN 19    // Order: s3 s2 s1 s4  caseI = 19
      //
      IF Length( s3 ) == 2
       s3 = Format( "20", s3 )
      ENDIF
      //
      dayI = Val( s1 )
      monthI = Val( s2 )
      yearI = Val( s3 )
      //
      s = Format( s3, "-", Format( s2 : 2 : "0" ), "-", Format( s1 : 2 : "0" ), " ", s4 )
      //
     WHEN 30    // Order: s3 s2 s1 s4  caseI = 30
      //
      IF Length( s3 ) == 2
       s3 = Format( "20", s3 )
      ENDIF
      //
      dayI = Val( s1 )
      monthI = Val( s2 )
      yearI = Val( s3 )
      //
      s = Format( s3, "-", Format( s2 : 2 : "0" ), "-", Format( s1 : 2 : "0" ), " ", s4 )
      //
     WHEN 31    // Order: s4 s1 s2 s3  caseI = 31
      //
      IF Length( s4 ) == 2
       s4 = Format( "20", s4 )
      ENDIF
      //
      dayI = Val( s2 )
      monthI = Val( s1 )
      yearI = Val( s4 )
      //
      s = Format( s4, "-", Format( s1 : 2 : "0" ), "-", Format( s2 : 2 : "0" ), " ", s3 )
      //
     WHEN 34    // Order: s4 s1 s2 s3  caseI = 34
      //
      IF Length( s4 ) == 2
       s4 = Format( "20", s4 )
      ENDIF
      //
      dayI = Val( s2 )
      monthI = Val( s1 )
      yearI = Val( s4 )
      //
      s = Format( s4, "-", Format( s1 : 2 : "0" ), "-", Format( s2 : 2 : "0" ), " ", s3 )
      //
     WHEN 40    // Order: ? s1 s2 s3   caseI = 40
      //
      s4 = "2022"
      //
      IF Length( s4 ) == 2
       s4 = Format( "20", s4 )
      ENDIF
      //
      dayI = Val( s2 )
      monthI = Val( s1 )
      yearI = Val( s4 )
      //
      s = Format( s4, "-", Format( s1 : 2 : "0" ), "-", Format( s2 : 2 : "0" ), " ", s3 )
      //
     WHEN 48    // Order: s1 s2 s3 s4  caseI = 48
      //
      IF Length( s1 ) == 2
       s1 = Format( "20", s1 )
      ENDIF
      //
      dayI = Val( s3 )
      monthI = Val( s2 )
      yearI = Val( s1 )
      //
      s = Format( s1, "-", Format( s2 : 2 : "0" ), "-", Format( s3 : 2 : "0" ), " ", s4 )
      //
     WHEN 53    // Order: s3 s2 s1 s4  caseI = 53
      //
      IF Length( s3 ) == 2
       s3 = Format( "20", s3 )
      ENDIF
      //
      dayI = Val( s1 )
      monthI = Val( s2 )
      yearI = Val( s3 )
      //
      s = Format( s3, "-", Format( s2 : 2 : "0" ), "-", Format( s1 : 2 : "0" ), " ", s4 )
      //
     WHEN 58    // Order: s3 s1 s2 s4  caseI = 58
      //
      IF Length( s3 ) == 2
       s3 = Format( "20", s3 )
      ENDIF
      //
      dayI = Val( s2 )
      monthI = Val( s1 )
      yearI = Val( s3 )
      //
      s = Format( s3, "-", Format( s1 : 2 : "0" ), "-", Format( s2 : 2 : "0" ), " ", s4 )
      //
     WHEN 61    // Order: s3 s1 s2 s4  caseI = 61
      //
      IF Length( s3 ) == 2
       s3 = Format( "20", s3 )
      ENDIF
      //
      dayI = Val( s2 )
      monthI = Val( s1 )
      yearI = Val( s3 )
      //
      IF Length( s4 ) == 7
       s4 = Format( "0", s4 )
      ENDIF
      //
      s = Format( s3, "-", Format( s1 : 2 : "0" ), "-", Format( s2 : 2 : "0" ), " ", s4 )
      //
     WHEN 08    // Order: s1 s2 s3 s4  caseI = 08
      //
      IF Length( s1 ) == 2
       s1 = Format( "20", s1 )
      ENDIF
      //
      dayI = Val( s3 )
      monthI = Val( s2 )
      yearI = Val( s1 )
      //
      s = Format( s1, "-", Format( s2 : 2 : "0" ), "-", Format( s3 : 2 : "0" ), " ", s4 )
      //
     WHEN 68    // Order: s1 s2 s3 s4  caseI = 68
      //
      IF Length( s1 ) == 2
       s1 = Format( "20", s1 )
      ENDIF
      //
      dayI = Val( s3 )
      monthI = Val( s2 )
      yearI = Val( s1 )
      //
      s = Format( s1, "-", Format( s2 : 2 : "0" ), "-", Format( s3 : 2 : "0" ), " ", s4 )
      //
     WHEN 27    // Order: s1 s2 s3 s4  caseI = 27
      //
      IF Length( s1 ) == 2
       s1 = Format( "20", s1 )
      ENDIF
      //
      dayI = Val( s3 )
      monthI = Val( s2 )
      yearI = Val( s1 )
      //
      s = Format( s1, "-", Format( s2 : 2 : "0" ), "-", Format( s3 : 2 : "0" ), " ", s4 )
      //
     WHEN 21    // Order: s3 s2 s1 s4  caseI = 21
      //
      IF Length( s3 ) == 2
       s3 = Format( "20", s3 )
      ENDIF
      //
      dayI = Val( s1 )
      monthI = Val( s2 )
      yearI = Val( s3 )
      //
      s = Format( s3, "-", Format( s2 : 2 : "0" ), "-", Format( s1 : 2 : "0" ), " ", s4 )
      //
     OTHERWISE
      //
      Warn( "FNBlockSortLog?FileLogDateTimeAllMergeToBufferCanonicalFrontSimpleB(", " ", "case", " ", ":", " ", caseI, ": not found. Check the list of regular expressions in the file and add a new or the correct one." )
      //
      B = FALSE
      //
      RETURN( B )
      //
    ENDCASE
    //
    PushPosition()
    PushBlock()
    UnMarkBlock()
    BegLine()
    MarkStream()
    EndLine()
    MarkStream()
    Copy()
    PopBlock()
    PopPosition()
    //
    PushPosition()
    PushBlock()
    GotoBufferId( buffer1I )
    EndFile()
    //
    Paste()
    //
    BegLine()
    InsertText( Format( caseS, Format( indexI : 2 : "0" ), ":", " " ), _INSERT_ )
    //
    IF ( weekdayB )
     // Warn( s1; s2; s3; s4 ) // debug
     // order: day, month, year
     s5 = FNStringGetDateWeekDayNameS( dayI, monthI, yearI )
     BegLine()
     InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
    ENDIF
    //
    // format output = YYYY-MM-DD hh:mm:ss
    //
    BegLine()
    InsertText( Format( Trim( s ), " " ) )
    //
    PopBlock()
    PopPosition()
    //
    // you have to go to a position after the position of the last found, otherwise you stay on the same place and the same expression is found again and again
    //
    NextChar()
    //
   ENDWHILE
   //
   PopPosition()
   PopBlock()
   //
  ENDIF
  //
  UpDateDisplay() IF WaitForKeyPressed( 0 ) ENDIF // Activate if using a loop
  //
  down1B = Down()
  //
  // Message( "Remove the file from the ring in order to gain more memory: begin" )
  IF ( removeFileFromRingB )
   PushPosition()
   PushBlock()
   IF EditFile( fileNameS )
    AbandonFile()
   ENDIF
   PopBlock()
   PopPosition()
  ENDIF
  // Message( "Remove the file from the ring in order to gain more memory: end" )
  //
 ENDWHILE
 //
 Message( "Sort the canonical date/time chronologically: begin" )
 GotoBufferId( buffer1I )
 SaveAs( fileNameSortInputS, _OVERWRITE_ )
 Dos( Format( "g:\cygwin\bin\sort.exe", " ", QuotePath( fileNameSortInputS ), " ", ">", " ", QuotePath( fileNameOutputS ) ), _DONT_PROMPT_ )
 AbandonFile( buffer1I )
 Message( "Sort the canonical date/time chronologically: end" )
 //
 B = TRUE
 //
 // cleanup the buffers
 //
 AbandonFile( buffer2I )
 AbandonFile( buffer3I )
 //
 // run logViewPlus
 //
 IF ( runLogViewPlusB )
  //
  PROCFileRun4NtAliasCommandListUser( Format( "logviewplus", " ", QuotePath( fileNameOutputS ) ) )
  //
 ENDIF
 //
 PopPosition()
 PopBlock()
 //
 RETURN( B )
 //
END

// library: file: check: line: empty: all <description></description> <version control></version control> <version>1.0.0.0.6</version> <version control></version control> (filenamemacro=checfifr.s) [<Program>] [<Research>] [kn, ri, su, 10-04-2022 17:12:53]
INTEGER PROC FNFileCheckLineEmptyAllB( STRING fileNameS )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = CurrFilename() // change this
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "file: check: line: empty: all: fileNameS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  Warn( FNFileCheckLineEmptyAllB( s1 ) ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // Use case = Check if a block only contains empty lines
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 INTEGER B = FALSE
 //
 PushPosition()
 PushBlock()
 //
 IF NOT EditFile( fileNameS )
  //
  Warn( "Could not load the file", ":", " ", fileNameS, ":", " ", "Please check." )
  B = FALSE
  PopBlock()
  PopPosition()
  RETURN( B )
 ENDIF
 //
 MarkLine( 1, NumLines() )
 //
 B = FNBlockCheckLineEmptyAllB()
 //
 PopBlock()
 PopPosition()
 //
 RETURN( B )
 //
END

// library: string: get: date: change: month: to: integer <description></description> <version control></version control> <version>1.0.0.0.2</version> <version control></version control> (filenamemacro=getsttiu.s) [<Program>] [<Research>] [kn, ri, th, 07-04-2022 22:48:06]
STRING PROC FNStringGetDateChangeMonthToIntegerS( STRING caseS )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = "Jan"
 // e.g.  Message( FNStringGetDateChangeMonthToIntegerS( s1 ) ) // gives e.g. "01"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 STRING s[255] = caseS
 //
 INTEGER I = 0
 //
 CASE caseS
  //
  WHEN "Jan"
   //
   I = 1
   //
  WHEN "Feb"
   //
   I = 2
   //
  WHEN "Mar"
   //
   I = 3
   //
  WHEN "Apr"
   //
   I = 4
   //
  WHEN "May"
   //
   I = 5
   //
  WHEN "Jun"
   //
   I = 6
   //
  WHEN "Jul"
   //
   I = 7
   //
  WHEN "Aug"
   //
   I = 8
   //
  WHEN "Sep"
   //
   I = 9
   //
  WHEN "Oct"
   //
   I = 10
   //
  WHEN "Nov"
   //
   I = 11
   //
  WHEN "Dec"
   //
   I = 12
   //
  OTHERWISE
   //
   // do nothing
   //
 ENDCASE
 //
 IF ( I > 0 )
  //
  s = Format( I : 2 : "0" )
  //
 ENDIF
 //
 RETURN( s )
 //
END

// library: string: get: date: week: day: name <description>see also Doomsday algorithm</description> <version>1.0.0.0.33</version> <version control></version control> (filenamemacro=getstwna.s) [<Program>] [<Research>] [kn, ri, th, 25-08-2011 02:26:09]
STRING PROC FNStringGetDateWeekDayNameS( INTEGER dayI, INTEGER monthI, INTEGER yearI )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = "24"
 // e.g.  STRING s2[255] = "8"
 // e.g.  STRING s3[255] = "2011"
 // e.g.  INTEGER I = 0
 // e.g.  IF NOT Ask( "string: get: date: week: name: day = ", s1, _FIND_HISTORY_ ) ENDIF
 // e.g.  IF NOT Ask( "string: get: date: week: name: month = ", s2, _FIND_HISTORY_ ) ENDIF
 // e.g.  IF NOT Ask( "string: get: date: week: name: year = ", s3, _FIND_HISTORY_ ) ENDIF
 // e.g.  Warn( s1, " ", s2, " ", s3, " gives ", FNStringGetDateWeekDayNameS( Val( s1 ), Val( s2 ), Val( s3 ) ) )
 // e.g.  Warn( "1 January 2011 must be Saturday, and gives: ", FNStringGetDateWeekDayNameS( 1, 1, 2011 ) )
 // e.g.  Warn( "24 August 2011 must be Wednesday, and gives: ", FNStringGetDateWeekDayNameS( 24, 8, 2011 ) )
 // e.g.  Warn( "9 September 2011 must be Friday, and gives: ", FNStringGetDateWeekDayNameS( 9, 9, 2011 ) )
 // e.g.  Warn( "2 October 2011 must be Sunday, and gives: ", FNStringGetDateWeekDayNameS( 2, 10, 2011 ) )
 // e.g.  Warn( "1 November 2011 must be Tuesday, and gives: ", FNStringGetDateWeekDayNameS( 1, 11, 2011 ) )
 // e.g.  Warn( "1 September 2011 must be Thursday, and gives: ", FNStringGetDateWeekDayNameS( 1, 9, 2011 ) )
 // e.g.  FOR I = 1 TO 30
 // e.g.   Warn( I, " ", "September 2011: ", FNStringGetDateWeekDayNameS( I, 9, 2011 ) )
 // e.g.  ENDFOR
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // Idea: -From the total amount of days you can get the total amount of weeks by dividing it by 7.
 //
 //       -Dividing by 7 removes all the multiples of 7 (and then you only look at the rest of the days smaller or equal to 6)
 //
 //       -The weekday name which was originally chosen as day 1 (e.g. Sunday) will remain that.
 //
 //       -The other days keep following after that, in the original chosen order.
 //
 INTEGER dayTotalI = FNMathGetDateTodayTotalI( dayI, monthI, yearI )
 //
 INTEGER weekMultipleOf7RestI = dayTotalI MOD 7
 //
 STRING s[255] = ""
 //
 CASE weekMultipleOf7RestI
  //
  WHEN 0
   //
   s = "Saturday"
   //
  WHEN 1
   //
   s = "Sunday"
   //
  WHEN 2
   //
   s = "Monday"
  //
  WHEN 3
   //
   s = "Tuesday"
   //
  WHEN 4
   //
   s = "Wednesday"
   //
  WHEN 5
   //
   s = "Thursday"
   //
  WHEN 6
   //
   s = "Friday"
   //
  OTHERWISE
   //
   Warn( "date to week day name: unknown result", ":", " ", weekMultipleOf7RestI )
   //
   s = FNStringGetErrorS()
   //
 ENDCASE
 //
 RETURN( s )
 //
END

// library: file: run: 4: nt: alias: command: list: user <description></description> <version control></version control> <version>1.0.0.0.199</version> (filenamemacro=run4fira.s) [<Program>] [<Research>] [kn, ri, su, 01-03-2009 15:29:03]
PROC PROCFileRun4NtAliasCommandListUser( STRING s )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = FNStringGetInitializeNewStringS()
 // e.g.  INTEGER bufferI = 0
 // e.g.  INTEGER I = 0
 // e.g.  STRING fileNameS[255] = FNStringGetProgramAliasRunFilenameListS() // casealiasinputlist.txt
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  GotoBufferId( bufferI )
 // e.g.  InsertFile( fileNameS )
 // e.g.  // I = List( "alias command", 115 - 21 )
 // e.g.  I = List( "FILE: RUN: 4NT: ALIAS: COMMAND: LIST: USER", FNWindowGetScreenWidthI() )
 // e.g.  IF ( NOT ( I == 0 ) )
 // e.g.   s1 = SubStr( GetText( 1, 255 ), 1, 188 - 1 )
 // e.g.   s1 = Trim( s1 )
 // e.g.   // combobox (but switched off as this is quicker)
 // e.g.   // s1 = FNStringGetInputS( "file: run: 4nt: alias: s = ", s1 )
 // e.g.   IF FNKeyCheckPressEscapeB( s1 ) RETURN() ENDIF
 // e.g.   s1 = FNStringGetTagAngularRemoveWhileS( s1, "Please replace it by information to apply" )
 // e.g.   // do not move the runprmcn line, as it seems to work better [kn, vo, mo, 13-04-2015 19:57:52]
 // e.g.   PROCMacroRunPurgeParameter( "runprmcn", Format( FNStringGetMachineNameS(), ";", FNStringGetUserNameFirstS(), ";", FNStringGetUserNameLastS(), ";", FNStringGetPortS(), ";", "Run@3A+Alias@3A+" + s1 + "&submit01=Create" ) )
 // e.g.   PROCFileRun4NtAliasCommandListUser( s1 )
 // e.g.  ENDIF
 // e.g.  PopPosition()
 // e.g.  PushPosition()
 // e.g.  GotoBufferId( bufferI )
 // e.g.  AbandonFile( bufferI )
 // e.g.  PopPosition()
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 // e.g. <CTRL L> RepeatFind()
 //
 // PROCFileChangeEditProgramRunStringAdd( "run", "", Format( "(program: 4nt: alias: general:", " ", s, ")" ) )
 //
 // LDos( QuotePath( FNStringGetProgram4ntFilenameS() ), Format( "alias", " ", FNStringGetPathFileAlias4Dos4NtFilenameS(), " ", "&&", " ", s, " ", "&& exit && exit" ), _DONT_PROMPT_ )
 // LDos( FNStringGetProgram4ntFilenameS(), Format( "alias", " ", FNStringGetPathFileAlias4Dos4NtFilenameS(), " ", "&&", " ", s, " ", "&& exit && exit" ), _DONT_PROMPT_ )
 // LDos( FNStringGetProgram4ntFilenameS(), Format( "alias", " ", FNStringGetPathFileAlias4Dos4NtFilenameS(), " ", "&&", " ", s, " ", "&& exit" ), _DONT_PROMPT_ )
 // LDos( FNStringGetProgram4ntFilenameS(), Format( "alias", " ", "/L", " ", "&&", " ", "alias", " ", FNStringGetPathFileAlias4Dos4NtFilenameS(), " ", "&&", " ", s, " ", "&& exit" ), _DONT_PROMPT_ )
 // LDos( FNStringGetProgram4ntFilenameS(), Format( "alias", " ", FNStringGetPathFileAlias4Dos4NtFilenameS(), " ", "&&", " ", s, " ", "&& exit" ), _DONT_PROMPT_ ) // old [kn, ri, su, 25-12-2016 02:18:29]
 LDos( FNStringGetProgram4ntFilenameS(), Format( "alias", " ", FNStringGetPathFileAliasUnicode4Dos4NtFilenameS(), " ", "&&", " ", s, " ", "&& exit" ), _DONT_PROMPT_ ) // new [kn, ri, su, 25-12-2016 02:18:43]
 //
 // PROCListSaveHistoryUser( s ) // old [kn, ri, su, 10-06-2012 13:44:33]
 //
 Message( Format( s, " ", ": file: run: 4nt/4dos: alias: command: list: user" ) )
 //
 // do not enable this runprmcn line, as it is run in the run part of this macro [kn, vo, mo, 13-04-2015 19:57:46]
 // PROCMacroRunPurgeParameter( "runprmcn", Format( FNStringGetMachineNameS(), ";", FNStringGetUserNameFirstS(), ";", FNStringGetUserNameLastS(), ";", FNStringGetPortS(), ";", "Run@3A+Alias@3A+" + s + "&submit01=Create" ) )
 //
END

// library: block: check: line: empty: all <description></description> <version control></version control> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=checbleb.s) [<Program>] [<Research>] [kn, ri, su, 10-04-2022 18:48:47]
INTEGER PROC FNBlockCheckLineEmptyAllB()
 // e.g. PROC Main()
 // e.g.  Message( FNBlockCheckLineEmptyAllB() ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Use case = Check if a block only contains empty lines
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 INTEGER B = FALSE
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 PushPosition()
 PushBlock()
 //
 // if you do not find any character in the range between ASCII 0 and ASCII 255 then the file is considered empty
 //
 B = NOT LFind( "[\d000-\d255]", "glx" )
 //
 PopBlock()
 PopPosition()
 //
 RETURN( B )
 //
END

// library: math: get: date: day: to: total <description></description> <version control></version control> <version>1.0.0.0.22</version> (filenamemacro=getmadto.s) [<Program>] [<Research>] [kn, ri, su, 13-04-2008 00:10:19]
INTEGER PROC FNMathGetDateTodayTotalI( INTEGER dayI, INTEGER monthI, INTEGER yearI )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = "01"
 // e.g.  STRING s2[255] = "01"
 // e.g.  STRING s3[255] = "1970"
 // e.g.
 // e.g.  // Warn( FNMathGetDateTodayTotalI( 1, 1, 1 ) ) // gives 1 // but do not use this low dates. Keep the year range your choose from within e.g. 1900 to 2100.
 // e.g.  // Warn( FNMathGetDateTodayTotalI( 12, 1, 1989 ) ) // gives 726129
 // e.g.  // Warn( FNMathGetDateTodayTotalI( 26, 8, 1983 ) ) // gives 724163
 // e.g.  // Warn( FNMathGetDateTodayTotalI( 27, 8, 1983 ) ) // gives 724164
 // e.g.  // Warn( FNMathGetDateTodayTotalI( 1, 1, 1993 ) ) // gives 727579
 // e.g.  // Warn( FNMathGetDateTodayTotalI( 31, 12, 2007 ) ) // gives 733056
 // e.g.  // Warn( FNMathGetDateTodayTotalI( 1, 1, 2008 ) ) // gives 733057
 // e.g.
 // e.g.  IF ( NOT ( Ask( "math: get: date: day: total: dayI = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  IF ( NOT ( Ask( "math: get: date: day: total: monthI = ", s2, _EDIT_HISTORY_ ) ) AND ( Length( s2 ) > 0 ) ) RETURN() ENDIF
 // e.g.  IF ( NOT ( Ask( "math: get: date: day: total: yearI = ", s3, _EDIT_HISTORY_ ) ) AND ( Length( s3 ) > 0 ) ) RETURN() ENDIF
 // e.g.  Warn( FNMathGetDateTodayTotalI( Val( s1 ), Val( s2 ), Val( s3 ) ) )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // [book: see: Czes Kosniowski - essential maths on the bbc micro - p. 101]
 //
 // [method: Zellers formula]
 //
 //  INT( 365.25 * yearI - 395.25 ) + INT( 30.57 * monthI@ ) + dayI
 //
 // Simple idea: Basically you multiply years with 365 days, months with 30 and add the days to give the total amount of days.
 //
 // This is then adjusted with some corrections for integer instead of floating point calculation and e.g. leap year
 //
 INTEGER dayTotalI = ( ( 365 * yearI ) + ( yearI / 4 ) - 395 ) + ( 30 * monthI + ( monthI / 2 ) + ( ( 7 * monthI ) / 100 ) ) + dayI
 //
 IF ( ( yearI MOD 4 ) == 0 )
  //
  dayTotalI = dayTotalI - 1
  //
 ENDIF
 //
 IF ( ( monthI == 9 ) OR ( monthI == 11 ) )
  //
  // dayTotalI = dayTotalI - 1 // old [kn, ri, su, 02-10-2011 15:44:41]
  //
  dayTotalI = dayTotalI + 1 // new [kn, ri, su, 02-10-2011 15:44:45]
  //
 ENDIF
 //
 IF ( monthI <= 2 )
  //
  RETURN( dayTotalI )
  //
 ENDIF
 //
 IF ( FNDateCheckYearLeapB( yearI ) )
  //
  RETURN( dayTotalI - 1 )
  //
 ENDIF
 //
 RETURN( dayTotalI - 2 )
 //
END

// library: string: get: error <description>general output string to recognize an error (e.g. in another routine). Central routine, only one occurrence of this constant string</description> <version>1.0.0.0.2</version> <version control></version control> (filenamemacro=getstger.s) [<Program>] [<Research>] [kn, ri, sa, 05-12-1998 20:58:17]
STRING PROC FNStringGetErrorS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetErrorS() ) // gives e.g. "<ERROR>"
 // e.g. END
 //
 RETURN( "<ERROR>" )
 //
END

// library: string: get: program4nt <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstgps.s) [<Program>] [<Research>] [kn, am, we, 29-04-2009 18:53:22]
STRING PROC FNStringGetProgram4ntFilenameS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetProgram4ntFilenameS() ) // gives e.g. "f:\4dos\4nt.exe"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetFileIniDefaultS( "ProgramName4DosS" ) )
 //
END

// library: string: get: path: file: alias: unicode4: dos4: nt: filename <description></description> <version control></version control> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=getstnfj.s) [<Program>] [<Research>] [kn, ri, su, 25-12-2016 02:20:20]
STRING PROC FNStringGetPathFileAliasUnicode4Dos4NtFilenameS()
 // e.g. PROC Main()
 // e.g.  IF ( FNMathGetNumberInputYesNoCancelPositionDefaultI( Format( "Alias command (should be similar to computer name)", " ", "=", " ", FNStringGetPathFileAliasUnicode4Dos4NtFilenameS() ) ) == 1 ) // gives e.g. "c:\4dos\aliasUnicode.dok"
 // e.g.  ENDIF
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // do not add this, it becomes too slow [kn, ri, sa, 09-02-2013 01:49:15]
 // PROCMacroRunPurgeParameter( "runprmcn", Format( FNStringGetMachineNameS(), ";", FNStringGetUserNameFirstS(), ";", FNStringGetUserNameLastS(), ";", FNStringGetPortS(), ";", "TSE@3A+String@3A+Get@3A" + "FNStringGetPathFileAlias4Dos4NtS" + "&submit01=Create" ) )
 //
 RETURN( FNStringGetFileIniDefaultS( "FNStringGetPathFileAliasUnicode4Dos4NtS" ) )
 //
END

// library: date: check: year: leap <description></description> <version control></version control> <version>1.0.0.0.10</version> (filenamemacro=checdayl.s) [<Program>] [<Research>] [kn, ri, sa, 12-04-2008 22:55:06]
INTEGER PROC FNDateCheckYearLeapB( INTEGER yearI )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = "2008"
 // e.g.  IF ( NOT ( Ask( "date: check: year: leap: yearI = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  Message( FNDateCheckYearLeapB( Val( s1 ) ) ) // gives e.g. TRUE when that year is a leapyear
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // Method
 //
 // In the Gregorian calendar, three criteria must be taken into account to identify leap years:
 // The year can be evenly divided by 4.
 // But if the year can also be evenly divided by 100, it is NOT a leap year, unless
 // the year is also evenly divisible by 400. Then it is a leap year.
 //
 INTEGER B = FALSE
 //
 B = ( ( yearI MOD 4 == 0 ) AND ( yearI MOD 100 <> 0 ) ) OR ( yearI MOD 400 == 0 )
 //
 RETURN( B )
 //
END

// library: file: get: ini: default: central <description></description> <version control></version control> <version>1.0.0.0.6</version> (filenamemacro=getfiidf.s) [<Program>] [<Research>] [kn, ri, we, 31-12-2003 02:17:48]
STRING PROC FNStringGetFileIniDefaultS( STRING searchS )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileIniDefaultS( "path4dos" ) ) // gives e.g. "c:\4dos"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 // e.g.
 //
 // USAGE
 //
 // 1. -Choose a filename for your global variables initialization file
 //
 //    1. -E.g. default name is here
 //
 //         dddpath.ini
 //
 //    2. -You can set this name in a function in this library, if you
 //
 //        want to change the default name
 //
 // 3. -Save this file in the directory
 //
 //     (path chosen to be given by Microsoft Windows environment variable APPDATA)
 //
 //      C:\Documents and Settings\<your Microsoft Windows login name>\Application Data\
 //
 // 4. -The full path to your initialization file is thus e.g.
 //
 //      C:\Documents and Settings\Administrator\Application Data\dddpath.ini
 //
 // 5. -To keep things as simple as possible, you need to put once
 //
 //     in top of your file the word (which must start at the beginning
 //
 //     of the line). Further no more '[' characters starting at the begin of any line.
 //
 //      [default]
 //
 // 6. -This file contains 0 or more lines of the general format
 //
 //      <variable name> = <variable value>
 //
 //     1. -E.g.
 //
 //         [default]
 //
 //          path4dos = c:\4dos
 //
 //          tsevariable1 = test1
 //
 //          tsevariable2 = test2
 //
 //          tsevariable3 = test3
 //
 //          ...
 //
 //     2. -Note: you should/could put spaces before and after the '=' sign
 //
 //         (e.g. for backwards compatibility purposes)
 //
 // 7. -Using this library, you can then e.g. get the value of your global variable from this file
 //
 STRING s[255] = ""
 //
 s =FNStringGetFileGetFilenamePathDefaultS( searchS )
 //
 IF EquiStr( Trim( s ), "" )
  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default // new
  Warn( searchS, ":", " ", "Mot found (or found but the value is the empty string). Please check dddpath.ini and adapt file bibdelph.del" )
 ENDIF
 //
 RETURN( FNStringGetFileGetFilenamePathDefaultS( searchS ) )
 //
END

// library: macro: run: keep <description>macro: run a macro, then keep it</description> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=runmarke.s) [<Program>] [<Research>] [[kn, zoe, fr, 27-10-2000 15:59:33]
PROC PROCMacroRunKeep( STRING macronameS )
 // e.g. PROC Main()
 // e.g.  PROCMacroRunKeep( "mysubma1.mac myparameter11 myparameter12" )
 // e.g.  PROCMacroRunKeep( "mysubma2.mac myparameter21" )
 // e.g.  PROCMacroRunKeep( "mysubma3.mac myparameter31 myparameter32" )
 // e.g. END
 //
 IF FNMacroCheckLoadB( FNStringGetCarS( macronameS ) ) // necessary if you pass parameters in a string
  //
  PROCMacroExec( macronameS )
  //
 ENDIF
 //
END

// library: file: get: filename: path: default <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getfipde.s) [<Program>] [<Research>] [kn, ri, we, 31-12-2003 02:14:28]
STRING PROC FNStringGetFileGetFilenamePathDefaultS( STRING searchS )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileGetFilenamePathDefaultS( "path4dos" ) ) // gives e.g. "c:\4dos"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // RETURN( FNStringGetFileGetFilenamePathS( searchS, FNStringGetFilenameIniDefaultS() ) ) // [kn, ri, mo, 22-05-2006 23:59:52]
 //
 RETURN( FNStringGetInitializationGlobalS( searchS, FNStringGetSectionSeparatorS(), FNStringGetFilenameIniDefaultS() ) )
 //
END

// library: macro: check: load <description>macro: load: (Loads a Macro File From Disk Into Memory) R    LoadMacro(STRING macro_filename)*</description> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=checmacl.s) [<Program>] [<Research>] [[kn, zoe, we, 16-06-1999 01:07:06]
INTEGER PROC FNMacroCheckLoadB( STRING macronameS )
 // e.g. PROC Main()
 // e.g.  Message( FNMacroCheckLoadB( macronameS ) ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( LoadMacro( macronameS ) )
 //
END

// library: string: get: word: token: get: first: FNStringGetCarS(): Get the first word of a string (words delimited by a space " " (=space delimited list)). <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstgca.s) [<Program>] [<Research>] [kn, ni, su, 02-08-1998 15:54:17]
STRING PROC FNStringGetCarS( STRING s )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = FNStringGetInitializeNewStringS()
 // e.g.  s1 = FNStringGetInputS( "string: get: word: token: get: first: s = ", "this is a test" )
 // e.g.  IF FNKeyCheckPressEscapeB( s1 ) RETURN() ENDIF
 // e.g.  Message( FNStringGetCarS( s1 ) ) // gives e.g. "this"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // variation: RETURN( FNStringGetTokenFirstS( s, " " ) )
 //
 RETURN( GetToken( s, " ", 1 ) ) // faster, but not central
 //
END

// library: macro: exec <description>macro: (Executes the Requested Macro) O    ExecMacro([<Program>] [<Research>] [STRING macroname])*</description> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=execmame.s) [[kn, zoe, we, 16-06-1999 01:06:54]
PROC PROCMacroExec( STRING macronameS )
 // e.g. PROC Main()
 // e.g.  PROCMacroExec( "video" )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 IF FNMathCheckLogicNotB( FNMacroCheckExecB( macronameS ) )
  //
  PROCWarnCons3( "macro", macronameS, ": could not be executed" )
  //
 ENDIF
 //
END

// library: string: get: initialization: global <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstigl.s) [<Program>] [<Research>] [kn, ri, mo, 22-05-2006 23:44:33]
STRING PROC FNStringGetInitializationGlobalS( STRING searchS, STRING sectionS, STRING fileNameS )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetInitializationGlobalS( "path4dos", "default", FNStringGetFilenameIniDefaultS() ) ) // e.g. gives "c:\4dos"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( GetProfileStr( sectionS, searchS, FNStringGetEmptyS(), fileNameS ) )
 //
END

// library: string: get: section: separator <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstssh.s) [<Program>] [<Research>] [kn, ri, mo, 22-05-2006 23:43:21]
STRING PROC FNStringGetSectionSeparatorS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetSectionSeparatorS() ) // gives e.g. "default"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( "default" ) // you can not put this in the initialization file, because this actually determines the default section of that file itself. Possibly pass it as a command line parameter
 //
END

// library: filename: get: filename: ini: default <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getfiide.s) [<Program>] [<Research>] [kn, ri, we, 31-12-2003 02:15:47]
STRING PROC FNStringGetFilenameIniDefaultS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFilenameIniDefaultS() ) // gives e.g. "c:\documents and settings\administrator\application data\dddpath.ini"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // RETURN( "c:\dddpath.ini" )
 //
 RETURN( FNStringGetConcatS( FNStringGetPathUser_DataApplicationCurrentBackslashS(), FNStringGet_FilenameIniDefaultS() ) )
 //
END

// library: math: check: logic: not <description></description> <version control></version control> <version>1.0.0.0.2</version> (filenamemacro=checmaln.s) [<Program>] [<Research>] [kn, ri, tu, 15-05-2001 16:54:21]
INTEGER PROC FNMathCheckLogicNotB( INTEGER B )
 // e.g. PROC Main()
 // e.g.  STRING s[255] = FNStringGetInitializeNewStringS()
 // e.g.  s = FNStringGetInputS( "math: check: logic: not: number = ", "1" )
 // e.g.  IF FNKeyCheckPressEscapeB( s ) RETURN() ENDIF
 // e.g.  Message( FNMathCheckLogicNotB( FNStringGetToIntegerI( s ) ) )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( NOT B )
 //
END

// library: macro: check: exec <description>macro: (Executes the Requested Macro) O    ExecMacro([<Program>] [<Research>] [STRING macroname])*</description> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=checmace.s) [[kn, zoe, we, 16-06-1999 01:06:54]
INTEGER PROC FNMacroCheckExecB( STRING macronameS )
 // e.g. PROC Main()
 // e.g.  Message( FNMacroCheckExecB( macronameS ) ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( ExecMacro( macronameS ) )
 //
END

// library: warn: cons3 <description>error: warning: give a warning message via 3 strings</description> <version>1.0.0.0.2</version> <version control></version control> (filenamemacro=conswawd.s) [<Program>] [<Research>] [[kn, ri, su, 29-07-2001 18:24:52]
PROC PROCWarnCons3( STRING s1, STRING s2, STRING s3 )
 // e.g. PROC Main()
 // e.g.  PROCWarnCons3( "error", "1", "2" ) // gives e.g. "error 1 2"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 PROCWarn( FNStringGetCons3S( s1, s2, s3 ) )
 //
END

// library: string: get: empty (return an empty string) <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstgem.s) [<Program>] [<Research>] [kn, ri, sa, 20-05-2000 20:11:03]
STRING PROC FNStringGetEmptyS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetEmptyS() ) // gives e.g. ...""
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( "" )
 //
END

// library: string: get: concat <description>concatenation 2 words tot 1 word</description> <version>1.0.0.0.3</version> (filenamemacro=getstgch.s) [<Program>] [<Research>] [kn, zoe, th, 01-02-2001 19:32:49]
STRING PROC FNStringGetConcatS( STRING s1, STRING s2 )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetConcatS( "test1", "test2" ) ) // version with test if string empty ) // gives e.g. "test1test2"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetConcatSeparatorS( s1, s2, FNStringGetEmptyS() ) )
 //
END

// library: string: get: path: user: data: application: current: backslash <description></description> <version control></version control> <version>1.0.0.0.2</version> (filenamemacro=getstcbe.s) [<Program>] [<Research>] [kn, ri, sa, 21-02-2004 23:01:06]
STRING PROC FNStringGetPathUser_DataApplicationCurrentBackslashS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetPathUser_DataApplicationCurrentBackslashS() ) // gives e.g. "c:\documents and settings\administrator\application data\" (this is a hidden directory)
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetFilenameEndBackSlashNotEqualInsertEndS( FNStringGetPathUser_DataApplicationCurrentBackslashNotS() ) )
 //
END

// library: string: get: filename: ini: default <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstide.s) [<Program>] [<Research>] [kn, ri, sa, 21-02-2004 22:54:12]
STRING PROC FNStringGet_FilenameIniDefaultS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGet_FilenameIniDefaultS() ) // gives e.g. "dddpath.ini"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( "dddpath.ini" ) // you can not put this in the global initialization file, because this actually determines the name of that file itself. You could overrule this by passing the filename as a parameter on the command line. (if ( parameter is empty ) then ( defaultfilename = dddpath.ini ), else ( defaultfilename = <that command line parameter> ) )
 //
END

// library: warn <description>error: warning: give a warning message</description> <version>1.0.0.0.3</version> <version control></version control> (filenamemacro=wawarn.s)  [<Program>] [<Research>] [kn, zoe, we, 09-06-1999 22:11:07]
PROC PROCWarn( STRING s )
 // e.g. PROC Main()
 // e.g.  PROCWarn( "you have forgotten to input a value" )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default // new [kn, ri, fr, 22-05-2020 20:12:39]
 Warn( s )
 //
END

// library: string: get: cons3: string: concatenation: 3 strings <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstgcy.s) [<Program>] [<Research>] [kn, zoe, fr, 17-11-2000 13:52:07]
STRING PROC FNStringGetCons3S( STRING s1, STRING s2, STRING s3 )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetCons3S( "a", "b", "c" ) ) // gives e.g. "a b c"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetConsS( FNStringGetConsS( s1, s2 ), s3 ) )
 //
END

// library: string: get: concat: separator: string: concatenation: concatenate 2 words to 1 word, separated by separator <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstcsg.s) [<Program>] [<Research>] [kn, zoe, th, 01-07-1999 01:33:18]
STRING PROC FNStringGetConcatSeparatorS( STRING s1, STRING s2, STRING separatorS )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetConcatSeparatorS( "test1", "test2", " " ) ) // gives e.g. "tes1 test2"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 IF FNStringCheckEmptyB( s1 ) RETURN( s2 ) ENDIF
 //
 IF FNStringCheckEmptyB( s2 ) RETURN( s1 ) ENDIF
 //
 RETURN( s1 + separatorS + s2 ) // leave this like this. Do not call a function, as this is a primitive function, you will get into a recursive loop, and get stack overflow
 //
END

// library: string: get: filename: end: back: slash: not: equal: insert: end <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstiep.s) [<Program>] [<Research>] [kn, ni, su, 17-08-2003 00:24:04]
STRING PROC FNStringGetFilenameEndBackSlashNotEqualInsertEndS( STRING s )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFilenameEndBackSlashNotEqualInsertEndS( 'c:\temp\ddd' ) ) // gives e.g. a string 'c:\temp\ddd\' (so with always a string with a backslash '\' at the end)
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetCharacterEndBackSlashNotEqualInsertEndS( s ) )
 //
END

// library: string: get: path: user: data: application: current <description></description> <version control></version control> <version>1.0.0.0.2</version> (filenamemacro=getstacu.s) [<Program>] [<Research>] [kn, ri, sa, 21-02-2004 22:50:55]
STRING PROC FNStringGetPathUser_DataApplicationCurrentBackslashNotS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetPathUser_DataApplicationCurrentBackslashNotS() ) // gives e.g. "c:\documents and settings\administrator\application data" (this is a hidden directory)
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 STRING s[255] = FNStringGetEnvironmentS( "APPDATA" )
 //
 IF FNStringCheckEnvironmentFoundNotB( s )
  //
  PROCWarnCons3( "current user path to application data", s, ": not found" )
  //
  s = FNStringGetErrorS()
  //
 ENDIF
 //
 RETURN( s )
 //
END

// library: string: get: cons: string: concatenation: concatenation 2 words to 1 word (separated by a space) <description></description> <version control></version control> <version>1.0.0.0.3</version> (filenamemacro=getstgcx.s) [<Program>] [<Research>] [kn, ri, we, 25-11-1998 20:15:03]
STRING PROC FNStringGetConsS( STRING s1, STRING s2 )
 // e.g. //
 // e.g. // version with test if string empty
 // e.g. //
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetConsS( "john", "doe" ) ) // gives "john doe"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetConcatSeparatorS( s1, s2, FNStringGetCharacterSymbolSpaceS() ) )
 //
END

// library: string: check: empty <description>string: empty: is given string empty?</description> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=checstcz.s) [<Program>] [<Research>] [[kn, ri, sa, 20-05-2000 20:11:08]
INTEGER PROC FNStringCheckEmptyB( STRING s )
 // e.g. PROC Main()
 // e.g.  Message( FNStringCheckEmptyB( s ) ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringCheckEqualB( s, FNStringGetEmptyS() ) )
 //
END

// library: string: get: backslash: if last character is not equal to '\', then concatenate a backslash to the end of the given string <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstien.s) [<Program>] [<Research>] [kn, ri, sa, 24-02-2001 23:48:15]
STRING PROC FNStringGetCharacterEndBackSlashNotEqualInsertEndS( STRING s )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = FNStringGetInitializeNewStringS()
 // e.g.  s1 = FNStringGetInputS( "string: get: backslash: if: not equal insert end: string = ", "this is a string without a backslash at end" )
 // e.g.  IF FNKeyCheckPressEscapeB( s1 ) RETURN() ENDIF
 // e.g.  Message( FNStringGetCharacterEndBackSlashNotEqualInsertEndS( s1 ) ) // gives e.g. "this is a string with a backslash at end\"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetCharacterInsertEndIfEqualNotS( s, FNStringGetCharacterSymbolSlashBackwardS() ) )
 //
END

// library: environment: string: get (Searches for and Returns a Specified Environment Str) R    GetEnvStr(STRING s)* <description></description> <version control></version control> <version>1.0.0.0.4</version> (filenamemacro=getstgen.s) [<Program>] [<Research>] [kn, ri, th, 25-10-2001 01:44:48]
STRING PROC FNStringGetEnvironmentS( STRING s )
 // e.g. PROC Main()
 // e.g.  STRING s[255] = FNStringGetInputS( "value: environment variable = ", "windir" )
 // e.g.  IF FNKeyCheckPressEscapeB( s ) RETURN() ENDIF
 // e.g.  PROCMessageCons3( s, "=", FNStringGetEnvironmentS( s ) ) // gives e.g. "windir=C:\WINNT", when working on a Windows2000 machine
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 STRING valueS[255] = GetEnvStr( s )
 //
 IF FNStringCheckEmptyB( valueS )
  //
  // PROCMessageCons3( "environment variable", s, ": not found" ) // old [kn, vo, fr, 08-02-2013 10:14:48]
  //
  valueS = FNStringGetErrorS()
  //
 ENDIF
 //
 RETURN( valueS )
 //
END

// library: environment: check: found: not <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=checenfn.s) [<Program>] [<Research>] [kn, ri, sa, 27-05-2006 20:20:03]
INTEGER PROC FNStringCheckEnvironmentFoundNotB( STRING s )
 // e.g. PROC Main()
 // e.g.  Message( FNStringCheckEnvironmentFoundNotB( FNStringGetEmptyS() ) ) // gives TRUE (thus not found) because string empty (or string error string)
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringCheckEqualErrorOrEmptyB( s ) )
 //
END

// library: string: get: character: symbol: " " <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstssp.s) [<Program>] [<Research>] [kn, zoe, we, 25-10-2000 01:33:39]
STRING PROC FNStringGetCharacterSymbolSpaceS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetCharacterSymbolSpaceS() ) // gives " "
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetCharacterSymbolCentralS( 32 ) )
 //
END

// library: string: check: equal <description>string: equal: are two given strings equal? (stored in 'checstcf.s')</description> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=checstcy.s) [<Program>] [<Research>] [[kn, zoe, we, 04-10-2000 18:23:27]
INTEGER PROC FNStringCheckEqualB( STRING s1, STRING s2 )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = FNStringGetInitializeNewStringS()
 // e.g.  STRING s2[255] = FNStringGetInitializeNewStringS()
 // e.g.  s1 = FNStringGetInputS( "string: check: equal: first string = ", "a" )
 // e.g.  IF FNKeyCheckPressEscapeB( s1 ) RETURN() ENDIF
 // e.g.  s2 = FNStringGetInputS( "string: check: equal: second string = ", "a" )
 // e.g.  IF FNKeyCheckPressEscapeB( s2 ) RETURN() ENDIF
 // e.g.  Message( FNStringCheckEqualB( s1, s2 ) ) // gives e.g. TRUE when string1 is equal to string2
 // e.g.  GetKey()
 // e.g.  Message( FNStringCheckEqualB( "knud", "knud" ) ) // gives TRUE
 // e.g.  GetKey()
 // e.g.  Message( FNStringCheckEqualB( "knud", "van" ) ) // gives FALSE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( s1 == s2 )
 //
END

// library: compare if string end is equal, if not so insert that string at the end <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstenp.s) [<Program>] [<Research>] [kn, ri, sa, 24-02-2001 23:06:33]
STRING PROC FNStringGetCharacterInsertEndIfEqualNotS( STRING inS, STRING tailS )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = FNStringGetInitializeNewStringS()
 // e.g.  STRING s2[255] = FNStringGetInitializeNewStringS()
 // e.g.  s1 = FNStringGetInputS( "string: insert: insert: string = ", "c:\kee" )
 // e.g.  IF FNKeyCheckPressEscapeB( s1 ) RETURN() ENDIF
 // e.g.  s2 = FNStringGetInputS( "string: insert: insert: frontS = ", "\" )
 // e.g.  IF FNKeyCheckPressEscapeB( s2 ) RETURN() ENDIF
 // e.g.  Message( FNStringGetCharacterInsertEndIfEqualNotS( s1, s2 ) ) // gives e.g. "c:\kee\"
 // e.g.  GetKey()
 // e.g.  Message( FNStringGetCharacterInsertEndIfEqualNotS( "c", ":" ) ) // gives "c:"
 // e.g.  GetKey()
 // e.g.  Message( FNStringGetCharacterInsertEndIfEqualNotS( "c:", ":" ) ) // gives "c:"
 // e.g.  GetKey()
 // e.g.  Message( FNStringGetCharacterInsertEndIfEqualNotS( "c:\kee", FNStringGetCharacterSymbolSlashBackwardS() ) ) // gives "c:\kee\"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 STRING s[255] = inS
 //
 IF FNMathCheckLogicNotB( FNStringCheckEqualCharacterLastNB( s, tailS ) )
  //
  // s = FNStringGetConcatS( s, tailS )
  //
  s = FNStringGetConcatTailS( s, tailS )
  //
 ENDIF
 //
 RETURN( s )
 //
END

// library: string: get: character: symbol: "\" <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstsba.s) [<Program>] [<Research>] [kn, ri, su, 29-07-2001 15:41:11]
STRING PROC FNStringGetCharacterSymbolSlashBackwardS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetCharacterSymbolSlashBackwardS() ) // gives "\"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetCharacterSymbolCentralS( 92 ) )
 //
END

// library: environment: check: found: not <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=checenfn.s) [<Program>] [<Research>] [kn, ri, sa, 27-05-2006 20:20:03]
INTEGER PROC FNStringCheckEqualErrorOrEmptyB( STRING s )
 // e.g. PROC Main()
 // e.g.  Message( FNStringCheckEqualErrorOrEmptyB( FNStringGetEmptyS() ) ) // gives TRUE if string empty or string equals error string
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNMathCheckLogicOrB( FNErrorCheckSB( s ), FNStringCheckEmptyB( s ) ) )
 //
END

// library: string: get: character: symbol: central <description>string: get: character: symbol: central</description> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=getstscm.s) [<Program>] [<Research>] [[kn, ri, sa, 07-07-2001 22:35:39]
STRING PROC FNStringGetCharacterSymbolCentralS( INTEGER I )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetCharacterSymbolCentralS( I ) ) // gives e.g. ...""
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetAsciiToCharacterS( I ) )
 //
END

// library: string: word: equal: last: compare if a given string is equal at the end to another given string <description></description> <version control></version control> <version>1.0.0.0.2</version> (filenamemacro=checstln.s) [<Program>] [<Research>] [kn, zoe, we, 29-11-2000 19:08:34]
INTEGER PROC FNStringCheckEqualCharacterLastNB( STRING s, STRING tailS )
 // e.g. //
 // e.g. // version: first parameter s then endS
 // e.g. //
 // e.g. PROC Main()
 // e.g.  Message( FNStringCheckEqualCharacterLastNB( "knud", "d" ) ) //  gives TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringCheckEqualB( FNStringGetRightStringLengthEqualS( s, tailS ), tailS ) )
 //
END

// library: string: get: concat: tail: suffix <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstctb.s) [<Program>] [<Research>] [kn, ri, su, 02-09-2001 03:08:08]
STRING PROC FNStringGetConcatTailS( STRING s, STRING tailS )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetConcatTailS( "Knu", "d" ) ) // gives e.g. "Knud"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetConcatS( s, tailS ) )
 //
END

// library: math: check: logic: or: 2 arguments <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=checmalo.s) [<Program>] [<Research>] [kn, ri, tu, 15-05-2001 16:54:17]
INTEGER PROC FNMathCheckLogicOrB( INTEGER B1, INTEGER B2 )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = FNStringGetInitializeNewStringS()
 // e.g.  STRING s2[255] = FNStringGetInitializeNewStringS()
 // e.g.  s1 = FNStringGetInputS( "math: check: logic: or: number1 = ", "1" )
 // e.g.  IF FNKeyCheckPressEscapeB( s1 ) RETURN() ENDIF
 // e.g.  s2 = FNStringGetInputS( "math: check: logic: or: number2 = ", "1" )
 // e.g.  IF FNKeyCheckPressEscapeB( s2 ) RETURN() ENDIF
 // e.g.  Message( FNMathCheckLogicOrB( FNStringGetToIntegerI( s1 ), FNStringGetToIntegerI( s2 ) ) ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 IF ( B1 )
  //
  RETURN( FNMathCheckGetLogicTrueB() )
  //
 ENDIF
 //
 IF ( B2 )
  //
  RETURN( FNMathCheckGetLogicTrueB() )
  //
 ENDIF
 //
 RETURN( FNMathCheckGetLogicFalseB() )
 //
END

// library: error: check <description>error: test if an error occurred, via testing the output // version with testing local variable. Better.</description> <version>1.0.0.0.3</version> <version control></version control> (filenamemacro=checercs.s) [<Program>] [<Research>] [[kn, ni, we, 05-08-1998 20:27:34]
INTEGER PROC FNErrorCheckSB( STRING s )
 // e.g. PROC Main()
 // e.g.  Message( FNErrorCheckSB( "this is an error" ) ) // version with testing local variable. Better. ) // gives TRUE or FALSE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringCheckEqualB( s, FNStringGetErrorS() ) )
 //
END

// library: string: get: ascii: to: character (given the ASCII value, what is the corresponding character? (Get Single Character Equivalent of an Integer). Syntax: Chr(INTEGER i)*) <description></description> <version control></version control> <version>1.0.0.0.2</version> (filenamemacro=getsttch.s)  [<Program>] [<Research>] [kn, zoe, we, 16-06-1999 01:06:51]
STRING PROC FNStringGetAsciiToCharacterS( INTEGER asciiI )
 // e.g. PROC Main()
 // e.g.  Warn( FNStringGetAsciiToCharacterS( 65 ) ) // gives "A"
 // e.g.  Warn( FNStringGetAsciiToCharacterS( 66 ) ) // gives "B"
 // e.g.  Warn( FNStringGetAsciiToCharacterS( 100 ) ) // gives "d"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( Chr( asciiI ) ) // leave this keyword, otherwise possibly recursive stack overflow
 //
END

// library: STRING: get: right: string: length: equal <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstler.s) [<Program>] [<Research>] [kn, ni, su, 30-11-2003 23:32:40]
STRING PROC FNStringGetRightStringLengthEqualS( STRING s, STRING tailS )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetRightStringLengthEqualS( "Knud van Eeden", "12345" ) ) // gives e.g. "Eeden"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetRightStringS( s, FNStringGetLengthI( tailS ) ) )
 //
END

// library: math: check: get: logic: true: wrapper <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=checmalt.s) [<Program>] [<Research>] [kn, ri, su, 22-07-2001 15:43:12]
INTEGER PROC FNMathCheckGetLogicTrueB()
 // e.g. PROC Main()
 // e.g.  Message( FNMathCheckGetLogicTrueB() ) // gives TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( TRUE )
 //
END

// library: math: check: get: logic: false: wrapper <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=checmalf.s) [<Program>] [<Research>] [kn, ri, su, 22-07-2001 15:43:08]
INTEGER PROC FNMathCheckGetLogicFalseB()
 // e.g. PROC Main()
 // e.g.  Message( FNMathCheckGetLogicFalseB() ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FALSE )
 //
END

// library: string: get: word: token: last: return a given integer amount of characters from the right of a given string (=RIGHT$ in BASIC) <description></description> <version control></version control> <version>1.0.0.0.5</version> (filenamemacro=stririrs.s) [<Program>] [<Research>] [kn, ri, tu, 13-10-1998 20:05:49]
STRING PROC FNStringGetRightStringS( STRING s, INTEGER totalI )
 // e.g. PROC Main()
 // e.g.  STRING s[255] = FNStringGetInitializeNewStringS()
 // e.g.  STRING charactertotalS[255] = FNStringGetInitializeNewStringS()
 // e.g.  s = FNStringGetInputS( "string: word: token: get: right: string = ", "knud" )
 // e.g.  IF FNKeyCheckPressEscapeB( s ) RETURN() ENDIF
 // e.g.  charactertotalS = FNStringGetInputS( "string: word: token: get: right: character total = ", "2" )
 // e.g.  IF FNKeyCheckPressEscapeB( charactertotalS ) RETURN() ENDIF
 // e.g.  Message( FNStringGetRightStringS( s, FNStringGetToIntegerI( charactertotalS ) ) ) //  gives e.g. "kn"
 // e.g.  GetKey()
 // e.g.  Message( FNStringGetRightStringS( "knud", 1 ) ) // gives "d"
 // e.g.  GetKey()
 // e.g.  Message( FNStringGetRightStringS( "knud", 2 ) ) // gives "ud"
 // e.g.  GetKey()
 // e.g.  Message( FNStringGetRightStringS( "best", 3 ) ) // gives "est"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 INTEGER lengthI = FNStringGetLengthI( s )
 //
 IF FNMathCheckLogicNotB( ( ( 0 <= totalI ) AND ( totalI <= lengthI ) ) ) // if not between 0 and length( string ), return the whole given string
  //
  totalI = lengthI
  //
 ENDIF
 //
 RETURN( FNStringGetMidStringS( s, 1 + lengthI - totalI, lengthI ) )
 //
END

// library: string: line: length: what is the length <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstgle.s) [<Program>] [<Research>] [kn, ri, we, 25-11-1998 20:20:58]
INTEGER PROC FNStringGetLengthI( STRING s )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = FNStringGetInitializeNewStringS()
 // e.g.  s1 = FNStringGetInputS( "string: line: length: string = ", "this is a test" )
 // e.g.  IF FNKeyCheckPressEscapeB( s1 ) RETURN() ENDIF
 // e.g.  Message( FNStringGetLengthI( s1 ) ) // gives e.g. 14
 // e.g.  GetKey()
 // e.g.  Message( FNStringGetLengthI( "knud" ) ) // gives 4
 // e.g.  GetKey()
 // e.g.  Message( FNStringGetLengthI( "the" ) ) // gives 3
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( Length( s ) )
 //
END

// library: string: get: mid: string <description></description> <version control>string: get: word: token: middle: return a given integer amount of characters from the a given startposition</version control> <version>1.0.0.0.7</version> (=MID$ in BASIC) <version>1.0.0.0.7</version> (filenamemacro=getstmid.s) [<Program>] [<Research>] [kn, ri, tu, 13-10-1998 20:29:00]
STRING PROC FNStringGetMidStringS( STRING s, INTEGER beginI, INTEGER totalI )
 // e.g. PROC Main()
 // e.g.  STRING s[255] = FNStringGetInitializeNewStringS()
 // e.g.  STRING positionBeginS[255] = FNStringGetInitializeNewStringS()
 // e.g.  STRING characterTotalS[255] = FNStringGetInitializeNewStringS()
 // e.g.  s = FNStringGetInputS( "string: get: MIDSTRING: string = ", "testing" )
 // e.g.  IF FNKeyCheckPressEscapeB( s ) RETURN() ENDIF
 // e.g.  positionBeginS = FNStringGetInputS( "string: get: MIDSTRING: beginposition = ", "2" )
 // e.g.  IF FNKeyCheckPressEscapeB( positionBeginS ) RETURN() ENDIF
 // e.g.  characterTotalS = FNStringGetInputS( "string: get: MIDSTRING: character total = ", "3" )
 // e.g.  IF FNKeyCheckPressEscapeB( characterTotalS ) RETURN() ENDIF
 // e.g.  Message( FNStringGetMidStringS( s, FNStringGetToIntegerI( positionBeginS ), FNStringGetToIntegerI( characterTotalS ) ) )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // Message( FNStringGetMidStringS( "knud", 2, 3 ) ) // gives "nud"
 //
 // Message( FNStringGetMidStringS( "knud", 3, 2 ) ) // gives "ud"
 //
 RETURN( SubStr( s, beginI, totalI ) )
 //
END
