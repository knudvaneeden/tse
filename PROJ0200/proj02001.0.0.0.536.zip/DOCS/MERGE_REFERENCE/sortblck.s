FORWARD INTEGER PROC FNBlockChangeLineLongestToLineShorterB()
FORWARD INTEGER PROC FNBlockGetLineLongestI()
FORWARD INTEGER PROC FNBlockGetLogFileLogApacheaccesslogHttplogDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogApacheerrorlogDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogBrokerDiaglogOraclealertlogDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogBrokerlogmsgsDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogEhcacheDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogIbmdb2db2diaglogDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogJbossserverlogDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogJvmgarbagecollectiongclogDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogMicrosoftsqlserversqllogDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogMysqlservererrlogDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogSecuritySessionDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogServiceDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogStatsCsvKnudEventviewerlogIislogDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogThreaddump1DateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogThreaddump2NirvanaAccessErrorLogPluginUmclientDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogThreaddump3OpenjdkazulServerlogIntegrationserverPlatformSagosgiStatsFullIisw3svcMssqlerrorDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogThreaddump4IbmaixthreaddumpDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogTomcatcatalinalogDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogTomcatlocalhostlogDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogTomcatmanagerlogDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogTxinTxoutErrorDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogWiresharkDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockGetLogFileLogWrapperUmrealmserviceLogDateTimeAllToBufferCanonicalFrontB( STRING s1, STRING s2, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNBlockSortLogFileLogDateTimeAllMergeToBufferCanonicalFrontB( STRING s1, INTEGER i1, INTEGER i2, INTEGER i3, STRING s2, INTEGER i4, INTEGER i5, INTEGER i6 )
FORWARD INTEGER PROC FNDateCheckYearLeapB( INTEGER i1 )
FORWARD INTEGER PROC FNErrorCheckSB( STRING s1 )
FORWARD INTEGER PROC FNFileChangeLineLongestToLineShorterB()
FORWARD INTEGER PROC FNFileGetLineLongestI( STRING s1 )
FORWARD INTEGER PROC FNMacroCheckExecB( STRING s1 )
FORWARD INTEGER PROC FNMacroCheckLoadB( STRING s1 )
FORWARD INTEGER PROC FNMathCheckGetLogicFalseB()
FORWARD INTEGER PROC FNMathCheckGetLogicTrueB()
FORWARD INTEGER PROC FNMathCheckLogicNotB( INTEGER i1 )
FORWARD INTEGER PROC FNMathCheckLogicOrB( INTEGER i1, INTEGER i2 )
FORWARD INTEGER PROC FNMathGetDateTodayTotalI( INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNMathGetErrorI()
FORWARD INTEGER PROC FNMathGetIntegerMaximumAbsoluteI()
FORWARD INTEGER PROC FNMathGetIntegerMinimumAbsoluteI()
FORWARD INTEGER PROC FNStringCheckEmptyB( STRING s1 )
FORWARD INTEGER PROC FNStringCheckEnvironmentFoundNotB( STRING s1 )
FORWARD INTEGER PROC FNStringCheckEqualB( STRING s1, STRING s2 )
FORWARD INTEGER PROC FNStringCheckEqualCharacterLastNB( STRING s1, STRING s2 )
FORWARD INTEGER PROC FNStringCheckEqualErrorOrEmptyB( STRING s1 )
FORWARD INTEGER PROC FNStringGetLengthI( STRING s1 )
FORWARD PROC Main()
FORWARD PROC PROCFileRun4NtAliasCommandListUser( STRING s1 )
FORWARD PROC PROCMacroExec( STRING s1 )
FORWARD PROC PROCMacroRunKeep( STRING s1 )
FORWARD PROC PROCWarn( STRING s1 )
FORWARD PROC PROCWarnCons3( STRING s1, STRING s2, STRING s3 )
FORWARD STRING PROC FNStringGetAsciiToCharacterS( INTEGER i1 )
FORWARD STRING PROC FNStringGetCarS( STRING s1 )
FORWARD STRING PROC FNStringGetCharacterEndBackSlashNotEqualInsertEndS( STRING s1 )
FORWARD STRING PROC FNStringGetCharacterInsertEndIfEqualNotS( STRING s1, STRING s2 )
FORWARD STRING PROC FNStringGetCharacterSymbolCentralS( INTEGER i1 )
FORWARD STRING PROC FNStringGetCharacterSymbolSlashBackwardS()
FORWARD STRING PROC FNStringGetCharacterSymbolSpaceS()
FORWARD STRING PROC FNStringGetConcatS( STRING s1, STRING s2 )
FORWARD STRING PROC FNStringGetConcatSeparatorS( STRING s1, STRING s2, STRING s3 )
FORWARD STRING PROC FNStringGetConcatTailS( STRING s1, STRING s2 )
FORWARD STRING PROC FNStringGetCons3S( STRING s1, STRING s2, STRING s3 )
FORWARD STRING PROC FNStringGetConsS( STRING s1, STRING s2 )
FORWARD STRING PROC FNStringGetDateWeekDayNameS( INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD STRING PROC FNStringGetEmptyS()
FORWARD STRING PROC FNStringGetEnvironmentS( STRING s1 )
FORWARD STRING PROC FNStringGetErrorS()
FORWARD STRING PROC FNStringGetFileGetFilenamePathDefaultS( STRING s1 )
FORWARD STRING PROC FNStringGetFileIniDefaultS( STRING s1 )
FORWARD STRING PROC FNStringGetFileLogApacheaccesslogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogApacheerrorlogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogBrokerDiaglogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogBrokerLogmsgsJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogErrorJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogHttplogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogIbmdb2db2diaglogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogIntegrationServerServerLogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogJbossserverlogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogJvmgarbagecollectiongclogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogMicrosofteventviewerlogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogMicrosoftiisisslogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogMicrosoftiisw34svclogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogMicrosoftsqlservererrorlogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogMicrosoftsqlserversqllogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogMysqlservererrlogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogMywebmethodsserverFullJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogNirvanaAccessErrorJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogOraclealertlogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogPlatformJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogPluginJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogSagosgiJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogSecurityJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogServiceJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogSessionJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogStatscsvknudJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogStatslogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogTerracottaClientJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogTerracottaEhcacheJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogTerracottaServerJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogThreaddump1JobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogThreaddump2JobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogThreaddump3JobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogThreaddump4JobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogTomcatcatalinalogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogTomcatlocalhostlogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogTomcatmanagerlogJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogTxInJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogTxOutJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogUmclientJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogUmrealmserviceJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogWiresharkJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFileLogWrapperJobSoftwareAgS()
FORWARD STRING PROC FNStringGetFilenameEndBackSlashNotEqualInsertEndS( STRING s1 )
FORWARD STRING PROC FNStringGetFilenameIniDefaultS()
FORWARD STRING PROC FNStringGetInitializationGlobalS( STRING s1, STRING s2, STRING s3 )
FORWARD STRING PROC FNStringGetMidStringS( STRING s1, INTEGER i1, INTEGER i2 )
FORWARD STRING PROC FNStringGetPathFileAliasUnicode4Dos4NtFilenameS()
FORWARD STRING PROC FNStringGetPathUser_DataApplicationCurrentBackslashNotS()
FORWARD STRING PROC FNStringGetPathUser_DataApplicationCurrentBackslashS()
FORWARD STRING PROC FNStringGetProgram4ntFilenameS()
FORWARD STRING PROC FNStringGetRightStringLengthEqualS( STRING s1, STRING s2 )
FORWARD STRING PROC FNStringGetRightStringS( STRING s1, INTEGER i1 )
FORWARD STRING PROC FNStringGetSectionSeparatorS()
FORWARD STRING PROC FNStringGet_FilenameIniDefaultS()


// --- MAIN --- //

PROC Main()
 //
 STRING s1[255] = ";" // separator for comma separated value (=CSV) // change this
 STRING s2[255] = "1" // block = 0 / single line = 1 (default)
 STRING s3[255] = "1" // save to buffer = 1 / save to file (avoid out of memory) = 0
 STRING s4[255] = "1" // do not remove the files from the ring = 0 / remove the files from the ring = 1
 STRING s5[255] = "c:\temp\ddd.log" // change this
 STRING s6[255] = "0" // 0 = do not run LogViewPlus / 1 = run LogViewPlus
 STRING s7[255] = "1" // 0 = do not show weekday / 1 = show weekday
 //
 INTEGER bufferI = 0
 //
 // PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default // new
 // IF ( NOT ( Ask( "block: sort: file: name: all: log: date: time: all: merge: to: buffer1: lineSingleB = ", s2, _EDIT_HISTORY_ ) ) AND ( Length( s2 ) > 0 ) ) RETURN() ENDIF
 //
 // PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default // new
 // IF ( NOT ( Ask( "block: sort: file: name: all: log: date: time: all: merge: to: buffer1: bufferOrFileB = ", s3, _EDIT_HISTORY_ ) ) AND ( Length( s3 ) > 0 ) ) RETURN() ENDIF
 //
 // PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default // new
 // IF ( NOT ( Ask( "block: sort: file: name: all: log: date: time: all: merge: to: buffer1: removeFileFromRingB = ", s4, _EDIT_HISTORY_ ) ) AND ( Length( s4 ) > 0 ) ) RETURN() ENDIF
 //
 // PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default // new
 // IF ( NOT ( Ask( "block: sort: file: name: all: log: date: time: all: merge: to: buffer1: runLogViewPlusB = ", s6, _EDIT_HISTORY_ ) ) AND ( Length( s6 ) > 0 ) ) RETURN() ENDIF
 //
 PushPosition()
 bufferI = CreateTempBuffer()
 PopPosition()
 //
 Message( FNBlockSortLogFileLogDateTimeAllMergeToBufferCanonicalFrontB( s1, Val( s2 ), Val( s3 ), Val( s4 ), s5, Val( s6 ), Val( s7 ), bufferI ) ) // gives e.g. TRUE
 //
 EditFile( s5 )
 //
END

<F12> Main()

// --- LIBRARY --- //

// library: block: sort: log: file: log: date: time: all: merge: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.73</version> <version control></version control> (filenamemacro=sortblck.s) [<Program>] [<Research>] [kn, ri, fr, 18-03-2022 01:17:40]
INTEGER PROC FNBlockSortLogFileLogDateTimeAllMergeToBufferCanonicalFrontB( STRING separatorS, INTEGER lineSingleB, INTEGER bufferOrFileB, INTEGER removeFileFromRingB, STRING fileNameOutputS, INTEGER runLogViewPlusB, INTEGER weekDayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = ";" // separator for comma separated value (=CSV) // change this
 // e.g.  STRING s2[255] = "1" // block = 0 / single line = 1 (default)
 // e.g.  STRING s3[255] = "1" // save to buffer = 1 / save to file (avoid out of memory) = 0
 // e.g.  STRING s4[255] = "1" // do not remove the files from the ring = 0 / remove the files from the ring = 1
 // e.g.  STRING s5[255] = "c:\temp\ddd.log" // change this
 // e.g.  STRING s6[255] = "0" // 0 = do not run LogViewPlus / 1 = run LogViewPlus
 // e.g.  STRING s7[255] = "1" // 0 = do not show weekday / 1 = show weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  // PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default // new
 // e.g.  // IF ( NOT ( Ask( "block: sort: file: name: all: log: date: time: all: merge: to: buffer1: lineSingleB = ", s2, _EDIT_HISTORY_ ) ) AND ( Length( s2 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  // PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default // new
 // e.g.  // IF ( NOT ( Ask( "block: sort: file: name: all: log: date: time: all: merge: to: buffer1: bufferOrFileB = ", s3, _EDIT_HISTORY_ ) ) AND ( Length( s3 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  // PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default // new
 // e.g.  // IF ( NOT ( Ask( "block: sort: file: name: all: log: date: time: all: merge: to: buffer1: removeFileFromRingB = ", s4, _EDIT_HISTORY_ ) ) AND ( Length( s4 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  // PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default // new
 // e.g.  // IF ( NOT ( Ask( "block: sort: file: name: all: log: date: time: all: merge: to: buffer1: runLogViewPlusB = ", s6, _EDIT_HISTORY_ ) ) AND ( Length( s6 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  Message( FNBlockSortLogFileLogDateTimeAllMergeToBufferCanonicalFrontB( s1, Val( s2 ), Val( s3 ), Val( s4 ), s5, Val( s6 ), Val( s7 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  EditFile( s5 )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Overview: input given block with N filetypes + N filenames
 //
 // ===
 //
 // 1. Convert wireshark.pcap to wireshark.txt
 // 2. Convert stats.log to stats.csv
 // 3. Convert Broker logmsgs to logmsgs.log
 // 4. Convert Broker logmsgs.mon to logmsgs.mon.log
 //
 // ===
 //
 // Use case: Get all date/time occurrences in all files and concatenate these chronologically in a buffer
 //
 // ===
 //
 // Description: merging of log file
 //
 // ===
 //
 // Method: Get all filenames in the block, search all occurrences of date/time in each file and concatenate these canonical date/time in 1 buffer
 //
 // -The current method should probably only work for the extraction of single lines from the log file, not for blocks in the log files
 //
 // ===
 //
 // E.g.
 //
 // given N filetypes + N filenames in a block
 //
 // ===
 //
 //  E.g. example
 //
 /*
--- cut here: begin --------------------------------------------------
 Broker: logmsgs.log; g:\mydownloadfiles\from_job_to_home\log\dddbrokerlogmsgs.log
 Broker: logmsgs.log; g:\mydownloadfiles\from_job_to_home\log\logmsgs.log
 Broker: logmsgs.mon.log; g:\mydownloadfiles\from_job_to_home\log\logmsgs.mon.log
 Integration_Server: http.log; g:\mydownloadfiles\from_job_to_home\log\http.log
 MySQL_Server: err.log; g:\mydownloadfiles\from_job_to_home\log\dddmysqlserver.err
 JVM_Garbage_Collection: gc.log; g:\mydownloadfiles\from_job_to_home\log\gc.log
 Microsoft_Event_Viewer: eventviewer.log; g:\mydownloadfiles\from_job_to_home\log\dddwindowseventviewer.txt
 Microsoft_IIS_Format: iis.log; g:\mydownloadfiles\from_job_to_home\log\dddiis.log
 Microsoft_IIS_W3C_Format: w3svc.log; g:\mydownloadfiles\from_job_to_home\log\dddiisw3svc.log
 Oracle: alert.log; g:\mydownloadfiles\from_job_to_home\log\oracle_alert_xe.log
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 //  E.g. example
 //
 /*
--- cut here: begin --------------------------------------------------
 Network_Wireshark_Export: log; g:\mydownloadfiles\from_job_to_home\log\wireshark.txt
 Integration_Server: server.log; c:\softwareag\integrationserver\instances\default\logs\server.log
 Apache: access.log; g:\utils\apache\logs\access.log
 Apache: error.log; g:\utils\apache\logs\error.log
 JBoss: server.log; g:\applicationserver\jboss\jboss-4.2.3.ga\server\default\log\server.log
 Tomcat: catalina.log; g:\utils\tomcat\apache-tomcat-7.0.2\logs\catalina.2010-09-12.log
 Tomcat: localhost.log; g:\utils\tomcat\apache-tomcat-7.0.2\logs\localhost.2010-09-12.log
 Tomcat: manager.log; g:\utils\tomcat\apache-tomcat-7.0.2\logs\manager.2018-09-07.log
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 //  E.g. example
 //
 /*
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\12is_thread_dumps\thread_dump_1.txt
 */
 //
 //  E.g. example
 //
 /*
--- cut here: begin --------------------------------------------------
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\12is_thread_dumps\thread_dump_1.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\12is_thread_dumps\thread_dump_1.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\12is_thread_dumps\thread_dump_2.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\12is_thread_dumps\thread_dump_3.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\15lu failure\lu_thread_dump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\1diagnostics_esbwp21.escb.eu_5001_2021022418085\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\2diagnostics_exdi-gw.cz.escb.eu_5001_\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\3diagnostics_exdi-gw.cz.escb.eu_5001_2021052\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\4diagnostics_exdi-gw.cz.escb.eu_6001_2021022\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\5diagnostics_exdi-gw.ext.nbp.pl_5001_2021031\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\6diagnostics_exdi-gw.lu.escb.eu_7001_2021061\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\7diagnostics_m999exdix002p.in.bu\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\8diagnostics_m999exdix002p.in.bu\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\9diagnostics_m999exdix002p.in.bu\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\thread dump_pl_low_prod.txt
--- cut here: end ----------------------------------------------------
 */
 //
 //  E.g. example
 //
 /*
--- cut here: begin --------------------------------------------------
 Integration_Server: http.log; g:\mydownloadfiles\from_job_to_home\log\http.log
--- cut here: end ----------------------------------------------------
 */
 //
 //  E.g. example
 //
 /*
--- cut here: begin --------------------------------------------------
 Broker: logmsgs.log; g:\mydownloadfiles\from_job_to_home\log\logmsgs.log
--- cut here: end ----------------------------------------------------
 */
 //
 //  E.g. example
 //
 /*
--- cut here: begin --------------------------------------------------
 Integration_Server: http.log; g:\mydownloadfiles\from_job_to_home\log\http.log
 Broker: logmsgs.log; g:\mydownloadfiles\from_job_to_home\log\logmsgs.log
 Integration_Server: server.log; c:\softwareag\integrationserver\instances\default\logs\server.log
--- cut here: end ----------------------------------------------------
 */
 //
 //  E.g. example
 //
 /*
--- cut here: begin --------------------------------------------------
 Integration_Server: server.log; c:\softwareag\integrationserver\instances\default\logs\server.log
--- cut here: end ----------------------------------------------------
 */
 //
 //  E.g. example
 //
 /*
--- cut here: begin --------------------------------------------------
 Universal_Messaging: nirvana.log; g:\messaging\universalmessaging1030\universalmessaging\server\umserver\data\nirvana.log
--- cut here: end ----------------------------------------------------
 */
 //
 //  E.g. example
 //
 /*
--- cut here: begin --------------------------------------------------
 Integration_Server: server.log; c:\softwareag\integrationserver\instances\default\logs\server.log
 Universal_Messaging: nirvana.log; g:\messaging\universalmessaging1030\universalmessaging\server\umserver\data\nirvana.log
--- cut here: end ----------------------------------------------------
 */
 //
 //  E.g. example
 //
 /*
--- cut here: begin --------------------------------------------------
 Integration_Server: wrapper.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005444636\wrapper.log
--- cut here: end ----------------------------------------------------
 */
 //
 //  E.g. example
 //
 /*
--- cut here: begin --------------------------------------------------
 Universal_Messaging: umrealmservice.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005441113\2logsnirvana_um58152\umrealmservice.log
--- cut here: end ----------------------------------------------------
 */
 //
 //  E.g. example
 //
 /*
--- cut here: begin --------------------------------------------------
 MyWebMethodsServer: _full_.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005398522\_full_.log
--- cut here: end ----------------------------------------------------
 */
 //
 //  E.g. example
 //
 /*
--- cut here: begin --------------------------------------------------
 Broker: diag.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005415448\1brokerdatalogs\diag.log.1589281634
 Broker: diag.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005415448\1brokerdatalogs\diag.log.1588866870
 Broker: diag.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005415448\1brokerdatalogs\diag.log.1590585954
 Broker: diag.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005415448\1brokerdatalogs\diag.log.1590769499
 Broker: diag.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005415448\1brokerdatalogs\diag.log
 Broker: diag.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005415448\1brokerdatalogs\diag.log.1579613256
 Broker: diag.log; c:\softwareag\broker96\broker\data\awbrokers96\default\diag.log
 Integration_Server: server.log; c:\softwareag\integrationserver\instances\default\logs\server.log
 Universal_Messaging: nirvana.log; g:\messaging\universalmessaging1030\universalmessaging\server\umserver\data\nirvana.log
 Integration_Server: wrapper.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005444636\wrapper.log
 Universal_Messaging: umrealmservice.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005441113\2logsnirvana_um58152\umrealmservice.log
 Integration_Server: umclient.log; c:\softwareag\integrationserver\instances\default\logs\umclient.log
 MyWebMethodsServer: _full_.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005398522\_full_.log
 Integration_Server: activetransfer.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005447235\2sr5447235sr5447235_diagnostics_rtmas0124\profiles\logs\activetransfer.log
 Integration_Server: sag-osgi.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005447235\2sr5447235sr5447235_diagnostics_rtmas0124\profiles\logs\sag-osgi.log
 Integration_Server: service.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005447235\2sr5447235sr5447235_diagnostics_rtmas0124\logs\service.log
 Integration_Server: platform.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005447235\2sr5447235sr5447235_diagnostics_rtmas0124\profiles\logs\platform.log
 Integration_Server: txin.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005447566\1sr5447566diagnostics_parmanu.c\logs\txin.log
 Integration_Server: txout.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005447566\1sr5447566diagnostics_parmanu.c\logs\txout.log
 Integration_Server: stats.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\1diagnostics_esbwp21.escb.eu_5001_2021022418085\logs\stats.log
 Integration_Server: security.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005447566\1sr5447566diagnostics_parmanu.c\logs\security.log
 Integration_Server: session.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005447566\1sr5447566diagnostics_parmanu.c\logs\session.log
 Integration_Server: session.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\1diagnostics_esbwp21.escb.eu_5001_2021022418085\logs\session.log
 Integration_Server: error.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\6diagnostics_exdi-gw.lu.escb.eu_7001_2021061\logs\error.log
 Universal_Messaging: plugin.log; c:\mydownloadfiles\job\softwareag\case\casenumber1-005444369\3sr5444369esb_live_20210614151652785\universalmessaging\server\umhigh\plugins\log\plugin.log
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\12is_thread_dumps\thread_dump_1.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\12is_thread_dumps\thread_dump_1.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\12is_thread_dumps\thread_dump_2.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\12is_thread_dumps\thread_dump_3.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\15lu failure\lu_thread_dump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\1diagnostics_esbwp21.escb.eu_5001_2021022418085\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\2diagnostics_exdi-gw.cz.escb.eu_5001_\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\3diagnostics_exdi-gw.cz.escb.eu_5001_2021052\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\4diagnostics_exdi-gw.cz.escb.eu_6001_2021022\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\5diagnostics_exdi-gw.ext.nbp.pl_5001_2021031\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\6diagnostics_exdi-gw.lu.escb.eu_7001_2021061\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\7diagnostics_m999exdix002p.in.bu\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\8diagnostics_m999exdix002p.in.bu\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\9diagnostics_m999exdix002p.in.bu\runtime\threaddump.txt
 Integration_Server: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\thread dump_pl_low_prod.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\13jvm_thread_dumps\low1.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\13jvm_thread_dumps\low2.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\13jvm_thread_dumps\low3.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\13jvm_thread_dumps\low4.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\1diagnostics_esbwp21.escb.eu_5001_2021022418085\runtime\threadlist.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\1diagnostics_esbwp21.escb.eu_5001_2021022418085\runtime\threadlocal.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\2diagnostics_exdi-gw.cz.escb.eu_5001_\runtime\threadlist.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\2diagnostics_exdi-gw.cz.escb.eu_5001_\runtime\threadlocal.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\3diagnostics_exdi-gw.cz.escb.eu_5001_2021052\runtime\threadlist.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\3diagnostics_exdi-gw.cz.escb.eu_5001_2021052\runtime\threadlocal.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\4diagnostics_exdi-gw.cz.escb.eu_6001_2021022\runtime\threadlist.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\4diagnostics_exdi-gw.cz.escb.eu_6001_2021022\runtime\threadlocal.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\5diagnostics_exdi-gw.ext.nbp.pl_5001_2021031\runtime\threadlist.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\5diagnostics_exdi-gw.ext.nbp.pl_5001_2021031\runtime\threadlocal.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\6diagnostics_exdi-gw.lu.escb.eu_7001_2021061\runtime\threadlist.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\6diagnostics_exdi-gw.lu.escb.eu_7001_2021061\runtime\threadlocal.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\7diagnostics_m999exdix002p.in.bu\runtime\threadlist.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\7diagnostics_m999exdix002p.in.bu\runtime\threadlocal.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\8diagnostics_m999exdix002p.in.bu\runtime\threadlist.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\8diagnostics_m999exdix002p.in.bu\runtime\threadlocal.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\9diagnostics_m999exdix002p.in.bu\runtime\threadlist.txt
 JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump; c:\mydownloadfiles\job\softwareag\case\casenumber1-005435703\9diagnostics_m999exdix002p.in.bu\runtime\threadlocal.txt
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 //  E.g. example
 //
 /*
--- cut here: begin --------------------------------------------------
 Integration_Server: server.log; c:\softwareag\integrationserver\instances\default\logs\server.log
 Integration_Server: server.log; c:\softwareag\integrationserver\instances\default\logs\server.log
 Integration_Server: server.log; c:\softwareag\integrationserver\instances\default\logs\server.log
--- cut here: end ----------------------------------------------------
 */
 //
 // will produce this intermediate output
 //
 /*
--- cut here: begin --------------------------------------------------
 2021-04-30 15:09:55;  1; C:\SoftwareAG\IntegrationServer\instances\default\logs\server.log;  Integration_Server: server.log
 2021-04-30 15:09:55;  1; C:\SoftwareAG\IntegrationServer\instances\default\logs\server.log;  Integration_Server: server.log
 2021-04-30 15:09:55;  1; C:\SoftwareAG\IntegrationServer\instances\default\logs\server.log;  Integration_Server: server.log
 2021-04-30 15:09:55;  2; C:\SoftwareAG\IntegrationServer\instances\default\logs\server.log;  Integration_Server: server.log
 2021-04-30 15:09:55;  2; C:\SoftwareAG\IntegrationServer\instances\default\logs\server.log;  Integration_Server: server.log
 2021-04-30 15:09:55;  2; C:\SoftwareAG\IntegrationServer\instances\default\logs\server.log;  Integration_Server: server.log
 2021-04-30 15:09:55;  3; C:\SoftwareAG\IntegrationServer\instances\default\logs\server.log;  Integration_Server: server.log
 2021-04-30 15:09:55;  3; C:\SoftwareAG\IntegrationServer\instances\default\logs\server.log;  Integration_Server: server.log
 2021-04-30 15:09:55;  3; C:\SoftwareAG\IntegrationServer\instances\default\logs\server.log;  Integration_Server: server.log
 2021-04-30 15:09:55;  4; C:\SoftwareAG\IntegrationServer\instances\default\logs\server.log;  Integration_Server: server.log
 2021-04-30 15:09:55;  4; C:\SoftwareAG\IntegrationServer\instances\default\logs\server.log;  Integration_Server: server.log
 2021-04-30 15:09:55;  4; C:\SoftwareAG\IntegrationServer\instances\default\logs\server.log;  Integration_Server: server.log
 2021-04-30 15:09:55;  5; C:\SoftwareAG\IntegrationServer\instances\default\logs\server.log;  Integration_Server: server.log
 2021-04-30 15:09:55;  5; C:\SoftwareAG\IntegrationServer\instances\default\logs\server.log;  Integration_Server: server.log
 2021-04-30 15:09:55;  5; C:\SoftwareAG\IntegrationServer\instances\default\logs\server.log;  Integration_Server: server.log
--- cut here: end ----------------------------------------------------
 */
 //
 // which will give as this final output 1 merged log file with all the date/time in these files in the block chronologically ordered
 //
 /*
--- cut here: begin --------------------------------------------------
 Integration_Server: server.log: 2021-04-30 15:09:55 CEST [ISS.0025.0001I] (tid=82) Integration Server 10.3.0.0 Build 118
 Integration_Server: server.log: 2021-04-30 15:09:55 CEST [ISS.0025.0006I] (tid=82) License Manager started
 Integration_Server: server.log: 2021-04-30 15:09:55 CEST [ISS.0001.0008W] (tid=82) Microservices Functionality disabled due to license restrictions.
 Integration_Server: server.log: 2021-04-30 15:09:55 CEST [ISS.0025.0049I] (tid=82) The JCE Unlimited Strength Jurisdiction Policy File was found
 Integration_Server: server.log: 2021-04-30 15:09:55 CEST [ISS.0025.0041I] (tid=82) FIPS mode not initialized
 Integration_Server: server.log: 2021-04-30 15:09:56 CEST [ISS.0139.9999I] (tid=82) Initializing ISKeyStoreManager using watt.server.homeDir:C:\SoftwareAG\IntegrationServer\instances\default\config\security\keystore
 Integration_Server: server.log: 2021-04-30 15:09:56 CEST [ISS.0139.9999I] (tid=82) ISKeyStoreManager initialized successfully.
 Integration_Server: server.log: 2021-04-30 15:10:06 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for ActiveTransfer functional alias, check configuration.
 Integration_Server: server.log: 2021-04-30 15:10:15 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for CentralUsers functional alias, check configuration.
 Integration_Server: server.log: 2021-04-30 15:10:21 CEST [ISS.0096.0026W] (tid=82) The JDBC function "DocumentHistory", pool alias "test" has entered fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
 Integration_Server: server.log: 2021-04-30 15:10:21 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for DocumentHistory functional alias, check configuration.
 Integration_Server: server.log: 2021-04-30 15:10:29 CEST [ISS.0096.0026W] (tid=82) The JDBC function "ISCoreAudit", pool alias "test" has entered fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
 Integration_Server: server.log: 2021-04-30 15:10:29 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for ISCoreAudit functional alias, check configuration.
 Integration_Server: server.log: 2021-04-30 15:10:35 CEST [ISS.0096.0026W] (tid=82) The JDBC function "Xref", pool alias "test" has entered fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
 Integration_Server: server.log: 2021-04-30 15:10:35 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for Xref functional alias, check configuration.
 Integration_Server: server.log: 2021-04-30 15:10:44 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for ProcessAudit functional alias, check configuration.
 Integration_Server: server.log: 2021-04-30 15:10:52 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for TN functional alias, check configuration.
 Integration_Server: server.log: 2021-04-30 15:10:58 CEST [ISS.0096.0026W] (tid=82) The JDBC function "ISInternal", pool alias "test" has entered fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
 Integration_Server: server.log: 2021-04-30 15:10:58 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for ISInternal functional alias, check configuration.
 Integration_Server: server.log: 2021-04-30 15:11:06 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for ProcessEngine functional alias, check configuration.
 Integration_Server: server.log: 2021-04-30 15:11:07 CEST [ISS.0025.0024I] (tid=82) JDBC Connection Manager started
 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: The JDBC function "ISCoreAudit", pool alias "test" is in fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.main.5010E] Failed to open destination 'ErrorDBDest'; reason 'Exception trying to set the DBMS vendor: {0}'
 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: The JDBC function "ISCoreAudit", pool alias "test" is in fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.main.5010E] Failed to open destination 'apigatewayTxnJdbc'; reason 'Exception trying to set the DBMS vendor: {0}'
 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: The JDBC function "ISCoreAudit", pool alias "test" is in fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.main.5010E] Failed to open destination 'ServiceDBDest'; reason 'Exception trying to set the DBMS vendor: {0}'
 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: The JDBC function "ISCoreAudit", pool alias "test" is in fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.main.5010E] Failed to open destination 'CoreAuditDBDest'; reason 'Exception trying to set the DBMS vendor: {0}'
 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: The JDBC function "ISCoreAudit", pool alias "test" is in fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.main.5010E] Failed to open destination 'SessionDBDest'; reason 'Exception trying to set the DBMS vendor: {0}'
 Integration_Server: server.log: 2021-04-30 15:11:18 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
 Integration_Server: server.log: 2021-04-30 15:11:18 CEST [WmAuditingSC.main.5010E] Failed to open destination 'ProcessAuditDBDest'; reason 'Exception trying to set the DBMS vendor: {0}'
 Integration_Server: server.log: 2021-04-30 15:11:18 CEST [WmAuditingSC.queue.2019W] Worker thread for queue 'ProcessAuditQueue' started, but its target destination is not open
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER downB = TRUE
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING fileNameS[255] = ""
 //
 STRING fileNameSortInputS[255] = "c:\temp\ddd1.txt" // change this
 //
 STRING caseS[255] = ""
 //
 STRING searchS[255] = ""
 //
 INTEGER messageLevelOldI = 0
 //
 INTEGER indexMinI = 1
 INTEGER indexI = 0
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 messageLevelOldI = Set( MsgLevel, _NONE_ ) // do not show 'long lines split' warning message box
 //
 PushPosition()
 PushBlock()
 //
 // SetUndoOn()
 //
 PushPosition()
 PushBlock()
 IF EditFile( fileNameOutputS )
  AbandonFile()
 ENDIF
 EraseDiskFile( fileNameOutputS )
 PopBlock()
 PopPosition()
 //
 indexI = indexMinI - 1
 //
 GotoBlockBegin()
 //
 WHILE ( ( IsCursorInBlock() ) AND ( downB ) )
  //
  UpDateDisplay() IF WaitForKeyPressed( 0 ) ENDIF // new [kn, ri, tu, 15-02-2022 21:08:27]
  //
  // skip empty lines
  //
  IF NOT LFind( "^$", "cgx" ) // when no empty line at the current position
   //
   IF NOT LFind( ";", "cgi" )
    Warn( "Please add the missing type in front of this line (e.g. Integration_Server: server.log;)" )
    Halt
    PopBlock()
    PopPosition()
    B = FALSE
   ENDIF
   //
   s = GetText( 1, MAXSTRINGLEN )
   //
   fileNameS = GetToken( s, separatorS, 2 )
   fileNameS = Trim( fileNameS )
   fileNameS = QuotePath( fileNameS )
   //
   Message( fileNameS )
   //
   IF NOT FileExists( fileNameS )
    Warn( "file", ":", " ", fileNameS, " ", "does not exist or was not found. Please check." )
   ENDIF
   //
   indexI = indexI + 1
   //
   caseS = GetToken( s, separatorS, 1 )
   caseS = Trim( caseS )
   //
   PushPosition()
   PushBlock()
   //
   Message( "Getting the file type: begin" )
   //
   CASE caseS
    //
    WHEN "Integration_Server: thread_dump" // thread dump 1
     //
     searchS = FNStringGetFileLogThreaddump1JobSoftwareAgS()
     //
    WHEN "Hewlett_Packard_JVM: thread_dump" // thread dump 2
     //
     searchS = FNStringGetFileLogThreaddump2JobSoftwareAgS()
     //
    WHEN "JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump" // thread dump 3
     //
     searchS = FNStringGetFileLogThreaddump3JobSoftwareAgS()
     //
    WHEN "IBM_AIX: thread_dump" // thread dump 4
     //
     searchS = FNStringGetFileLogThreaddump4JobSoftwareAgS()
     //
    WHEN "Integration_Server: server.log"
     //
     searchS = FNStringGetFileLogIntegrationServerServerLogJobSoftwareAgS()
     //
    WHEN "Integration_Server: error.log"
     //
     searchS = FNStringGetFileLogErrorJobSoftwareAgS()
     //
    WHEN "Integration_Server: stats.log"
     //
     searchS = FNStringGetFileLogStatslogJobSoftwareAgS()
     //
    WHEN "Integration_Server: statsknud.csv"
     //
     searchS = FNStringGetFileLogStatscsvknudJobSoftwareAgS()
     //
    WHEN "Integration_Server: stats.csv"
     //
     searchS = FNStringGetFileLogStatslogJobSoftwareAgS()
     //
    WHEN "Integration_Server: txin.log"
     //
     searchS = FNStringGetFileLogTxInJobSoftwareAgS()
     //
    WHEN "Integration_Server: txout.log"
     //
     searchS = FNStringGetFileLogTxOutJobSoftwareAgS()
     //
    WHEN "Integration_Server: session.log"
     //
     searchS = FNStringGetFileLogSessionJobSoftwareAgS()
     //
    WHEN "Integration_Server: security.log"
     //
     searchS = FNStringGetFileLogSecurityJobSoftwareAgS()
     //
    WHEN "Integration_Server: platform.log"
     //
     searchS = FNStringGetFileLogPlatformJobSoftwareAgS()
     //
    WHEN "Terracotta: terracotta-server.log"
     //
     searchS = FNStringGetFileLogTerracottaServerJobSoftwareAgS()
     //
    WHEN "Terracotta: terracotta-client.log"
     //
     searchS = FNStringGetFileLogTerracottaClientJobSoftwareAgS()
     //
    WHEN "Integration_Server: ehcache.log"
     //
     searchS = FNStringGetFileLogTerracottaEhcacheJobSoftwareAgS()
     //
    WHEN "Integration_Server: service.log"
     //
     searchS = FNStringGetFileLogServiceJobSoftwareAgS()
     //
    WHEN "Integration_Server: sag-osgi.log", "Integration_Server: activetransfer.log"
     //
     searchS = FNStringGetFileLogSagosgiJobSoftwareAgS()
     //
    WHEN "Integration_Server: umclient.log"
     //
     searchS = FNStringGetFileLogUmclientJobSoftwareAgS()
     //
    WHEN "Integration_Server: wrapper.log"
     //
     searchS = FNStringGetFileLogWrapperJobSoftwareAgS()
     //
    WHEN "MyWebMethodsServer: _full_.log", "MyWebMethodsServer: _problems_.log"
     //
     searchS = FNStringGetFileLogMywebmethodsserverFullJobSoftwareAgS()
     //
    WHEN "Universal_Messaging: nirvana.log"
     //
     searchS = FNStringGetFileLogNirvanaAccessErrorJobSoftwareAgS()
     //
    WHEN "Universal_Messaging: access.log"
     //
     searchS = FNStringGetFileLogNirvanaAccessErrorJobSoftwareAgS()
     //
    WHEN "Universal_Messaging: error.log"
     //
     searchS = FNStringGetFileLogNirvanaAccessErrorJobSoftwareAgS()
     //
    WHEN "Universal_Messaging: plugin.log"
     //
     searchS = FNStringGetFileLogPluginJobSoftwareAgS()
     //
    WHEN "Universal_Messaging: umrealmservice.log"
     //
     searchS = FNStringGetFileLogUmrealmserviceJobSoftwareAgS()
     //
    WHEN "Broker: diag.log"
     //
     searchS = FNStringGetFileLogBrokerDiaglogJobSoftwareAgS()
     //
    WHEN "Network_Wireshark_Export: log"
     //
     searchS = FNStringGetFileLogWiresharkJobSoftwareAgS()
     //
    WHEN "Apache: access.log"
     //
     searchS = FNStringGetFileLogApacheaccesslogJobSoftwareAgS()
     //
    WHEN "Apache: error.log"
     //
     searchS = FNStringGetFileLogApacheerrorlogJobSoftwareAgS()
     //
    WHEN "Tomcat: catalina.log"
     //
     searchS = FNStringGetFileLogTomcatcatalinalogJobSoftwareAgS()
     //
    WHEN "Tomcat: localhost.log"
     //
     searchS = FNStringGetFileLogTomcatlocalhostlogJobSoftwareAgS()
     //
    WHEN "Tomcat: manager.log"
     //
     searchS = FNStringGetFileLogTomcatmanagerlogJobSoftwareAgS()
     //
    WHEN "Broker: logmsgs.mon.log"
     //
     searchS = FNStringGetFileLogBrokerLogmsgsJobSoftwareAgS()
     //
    WHEN "Broker: logmsgs.log"
     //
     searchS = FNStringGetFileLogBrokerLogmsgsJobSoftwareAgS()
     //
    WHEN "Integration_Server: http.log"
     //
     searchS = FNStringGetFileLogHttplogJobSoftwareAgS()
     //
    WHEN "JBoss: server.log"
     //
     searchS = FNStringGetFileLogJbossserverlogJobSoftwareAgS()
     //
    WHEN "IBM_DB2: db2diag.log"
     //
     searchS = FNStringGetFileLogIbmdb2db2diaglogJobSoftwareAgS()
     //
    WHEN "JVM_Garbage_Collection: gc.log"
     //
     searchS = FNStringGetFileLogJvmgarbagecollectiongclogJobSoftwareAgS()
     //
    WHEN "Microsoft_Event_Viewer: eventviewer.log"
     //
     searchS = FNStringGetFileLogMicrosofteventviewerlogJobSoftwareAgS()
     //
    WHEN "Microsoft_IIS_W3C_Format: w3svc.log"
     //
     searchS = FNStringGetFileLogMicrosoftiisw34svclogJobSoftwareAgS()
     //
    WHEN "Microsoft_IIS_Format: iis.log"
     //
     searchS = FNStringGetFileLogMicrosoftiisisslogJobSoftwareAgS()
     //
    WHEN "MySQL_Server: err.log"
     //
     searchS = FNStringGetFileLogMysqlservererrlogJobSoftwareAgS()
     //
    WHEN "Microsoft_SQL_Server: error.log"
     //
     searchS = FNStringGetFileLogMicrosoftsqlservererrorlogJobSoftwareAgS()
     //
    WHEN "Microsoft_SQL_Server: sql.log"
     //
     searchS = FNStringGetFileLogMicrosoftsqlserversqllogJobSoftwareAgS()
     //
    WHEN "Oracle: alert.log"
     //
     searchS = FNStringGetFileLogOraclealertlogJobSoftwareAgS()
     //
    OTHERWISE
     //
     Warn( "FNBlockSortLogFileLogDateTimeAllMergeToBufferCanonicalFrontB(", " ", "case", " ", ":", " ", caseS, ": Note: it is case sensitive. Otherwise please create the search regular expression." )
     //
     B = FALSE
     //
     RETURN( B )
     //
   ENDCASE
   //
   Message( "Getting the file type: end" )
   //
   Message( "Changing when found longest line to shorter line: begin" )
   IF FNFileGetLineLongestI( fileNameS ) > ( MAXLINELEN - 100 )
    Message( "Longest line length found greater than", ":", " ", MAXLINELEN - 100, " ", "in", " ", fileNameS )
    B = FNFileChangeLineLongestToLineShorterB()
   ENDIF
   Message( "Changing when found longest line to shorter line: end" )
   //
   Message( "Replacing date/time to canonical date/time: begin" )
   //
   IF EditFile( fileNameS )
    PushPosition()
    PushBlock()
    MarkLine( 1, NumLines() )
    //
    CASE caseS
     WHEN "Integration_Server: thread_dump" // thread dump 1
      B = FNBlockGetLogFileLogThreaddump1DateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Hewlett_Packard_JVM: thread_dump" // thread dump 2
      B = FNBlockGetLogFileLogThreaddump2NirvanaAccessErrorLogPluginUmclientDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump" // thread dump 3
      B = FNBlockGetLogFileLogThreaddump3OpenjdkazulServerlogIntegrationserverPlatformSagosgiStatsFullIisw3svcMssqlerrorDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "IBM_AIX: thread_dump" // thread dump 4
      B = FNBlockGetLogFileLogThreaddump4IbmaixthreaddumpDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Integration_Server: error.log"
      B = FNBlockGetLogFileLogTxinTxoutErrorDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Integration_Server: platform.log"
      B = FNBlockGetLogFileLogThreaddump3OpenjdkazulServerlogIntegrationserverPlatformSagosgiStatsFullIisw3svcMssqlerrorDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Integration_Server: sag-osgi.log", "Integration_Server: activetransfer.log"
      B = FNBlockGetLogFileLogThreaddump3OpenjdkazulServerlogIntegrationserverPlatformSagosgiStatsFullIisw3svcMssqlerrorDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Terracotta: terracotta-server.log"
      B = FNBlockGetLogFileLogThreaddump3OpenjdkazulServerlogIntegrationserverPlatformSagosgiStatsFullIisw3svcMssqlerrorDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Terracotta: terracotta-client.log"
      B = FNBlockGetLogFileLogThreaddump3OpenjdkazulServerlogIntegrationserverPlatformSagosgiStatsFullIisw3svcMssqlerrorDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Integration_Server: ehcache.log"
      B = FNBlockGetLogFileLogEhcacheDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Integration_Server: security.log"
      B = FNBlockGetLogFileLogSecuritySessionDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Integration_Server: server.log"
      B = FNBlockGetLogFileLogThreaddump3OpenjdkazulServerlogIntegrationserverPlatformSagosgiStatsFullIisw3svcMssqlerrorDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Integration_Server: service.log"
      B = FNBlockGetLogFileLogServiceDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Integration_Server: session.log"
      B = FNBlockGetLogFileLogSecuritySessionDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Integration_Server: stats.log"
      B = FNBlockGetLogFileLogThreaddump3OpenjdkazulServerlogIntegrationserverPlatformSagosgiStatsFullIisw3svcMssqlerrorDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Integration_Server: statsknud.csv"
      B = FNBlockGetLogFileLogStatsCsvKnudEventviewerlogIislogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Integration_Server: stats.csv"
      B = FNBlockGetLogFileLogThreaddump3OpenjdkazulServerlogIntegrationserverPlatformSagosgiStatsFullIisw3svcMssqlerrorDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Integration_Server: txin.log"
      B = FNBlockGetLogFileLogTxinTxoutErrorDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Integration_Server: txout.log"
      B = FNBlockGetLogFileLogTxinTxoutErrorDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Integration_Server: umclient.log"
      B = FNBlockGetLogFileLogThreaddump2NirvanaAccessErrorLogPluginUmclientDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Integration_Server: wrapper.log"
      B = FNBlockGetLogFileLogWrapperUmrealmserviceLogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "MyWebMethodsServer: _full_.log", "MyWebMethodsServer: _problems_.log"
      B = FNBlockGetLogFileLogThreaddump3OpenjdkazulServerlogIntegrationserverPlatformSagosgiStatsFullIisw3svcMssqlerrorDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Universal_Messaging: nirvana.log"
      B = FNBlockGetLogFileLogThreaddump2NirvanaAccessErrorLogPluginUmclientDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Universal_Messaging: access.log"
      B = FNBlockGetLogFileLogThreaddump2NirvanaAccessErrorLogPluginUmclientDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Universal_Messaging: error.log"
      B = FNBlockGetLogFileLogThreaddump2NirvanaAccessErrorLogPluginUmclientDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Universal_Messaging: plugin.log"
      B = FNBlockGetLogFileLogThreaddump2NirvanaAccessErrorLogPluginUmclientDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Universal_Messaging: umrealmservice.log"
      B = FNBlockGetLogFileLogWrapperUmrealmserviceLogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Broker: diag.log"
      B = FNBlockGetLogFileLogBrokerDiaglogOraclealertlogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Network_Wireshark_Export: log"
      B = FNBlockGetLogFileLogWiresharkDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Apache: access.log"
      B = FNBlockGetLogFileLogApacheaccesslogHttplogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Apache: error.log"
      B = FNBlockGetLogFileLogApacheerrorlogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Tomcat: catalina.log"
      B = FNBlockGetLogFileLogTomcatcatalinalogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Tomcat: localhost.log"
      B = FNBlockGetLogFileLogTomcatlocalhostlogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Tomcat: manager.log"
      B = FNBlockGetLogFileLogTomcatmanagerlogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Broker: logmsgs.mon.log"
      B = FNBlockGetLogFileLogBrokerlogmsgsDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Broker: logmsgs.log"
      B = FNBlockGetLogFileLogBrokerlogmsgsDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Integration_Server: http.log"
      B = FNBlockGetLogFileLogApacheaccesslogHttplogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "JBoss: server.log"
      B = FNBlockGetLogFileLogJBossserverlogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "IBM_DB2: db2diag.log"
      B = FNBlockGetLogFileLogIbmdb2db2diaglogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "JVM_Garbage_Collection: gc.log"
      B = FNBlockGetLogFileLogJvmgarbagecollectiongclogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Microsoft_Event_Viewer: eventviewer.log"
      B = FNBlockGetLogFileLogStatsCsvKnudEventviewerlogIislogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Microsoft_IIS_Format: iis.log"
      B = FNBlockGetLogFileLogStatsCsvKnudEventviewerlogIislogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Microsoft_IIS_W3C_Format: w3svc.log"
      B = FNBlockGetLogFileLogThreaddump3OpenjdkazulServerlogIntegrationserverPlatformSagosgiStatsFullIisw3svcMssqlerrorDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Microsoft_SQL_Server: error.log"
      B = FNBlockGetLogFileLogThreaddump3OpenjdkazulServerlogIntegrationserverPlatformSagosgiStatsFullIisw3svcMssqlerrorDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Microsoft_SQL_Server: sql.log"
      B = FNBlockGetLogFileLogMicrosoftsqlserversqllogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "MySQL_Server: err.log"
      B = FNBlockGetLogFileLogMysqlservererrlogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     WHEN "Oracle: alert.log"
      B = FNBlockGetLogFileLogBrokerDiaglogOraclealertlogDateTimeAllToBufferCanonicalFrontB( searchS, caseS, indexI, weekdayB, bufferI )
     //
    OTHERWISE
     //
     Warn( "FNBlockSortLogFileLogDateTimeAllMergeToBufferCanonicalFrontB(", " ", "case", " ", ":", " ", caseS, ": not known" )
     //
    ENDCASE
    //
    Message( "Replacing date/time to canonical date/time: end" )
    //
    Message( "Remove the file from the ring in order to gain more memory: begin" )
    IF ( removeFileFromRingB )
      PushPosition()
      PushBlock()
      IF EditFile( fileNameS )
      AbandonFile()
     ENDIF
     PopBlock()
     PopPosition()
    ENDIF
    Message( "Remove the file from the ring in order to gain more memory: end" )
    //
    PopBlock()
    PopPosition()
   ELSE
    Warn( "No filename found in current line. Please check." )
    B = FALSE
    PopBlock()
    PopPosition()
    RETURN( B )
   ENDIF
   //
   PopBlock()
   PopPosition()
   //
  ENDIF
  //
  downB = Down()
  //
 ENDWHILE
 //
 Message( "Sort the canonical date/time chronologically: begin" )
 GotoBufferId( bufferI )
 SaveAs( fileNameSortInputS, _OVERWRITE_ )
 Dos( Format( "g:\cygwin\bin\sort.exe", " ", QuotePath( fileNameSortInputS ), " ", ">", " ", QuotePath( fileNameOutputS ) ), _DONT_PROMPT_ )
 AbandonFile( bufferI )
 Message( "Sort the canonical date/time chronologically: end" )
 //
 Set( MsgLevel, messageLevelOldI )
 //
 B = TRUE
 //
 IF ( runLogViewPlusB )
  //
  PROCFileRun4NtAliasCommandListUser( Format( "logviewplus", " ", QuotePath( fileNameOutputS ) ) )
  //
 ENDIF
 //
 PopBlock()
 PopPosition()
 //
 RETURN( B )
 //
END

// library: string: get: file: log: threaddump1: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.4</version> <version control></version control> (filenamemacro=getstsac.s) [<Program>] [<Research>] [kn, ri, su, 20-06-2021 04:50:18]
STRING PROC FNStringGetFileLogThreaddump1JobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogThreaddump1JobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
              1   2  3             4
 Example: Wed May 26 10:45:46 CEST 2021; Format: Www Mmm DD HH:MM:SS ZZZ?Z?Z? YYYY; Order: s4 s1 s2 s3
 */
 //
 // "Integration_Server: thread_dump;"
 //
 // STRING s[255] = "^[ ]*[A-Z][a-z][a-z][ ]+{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}{\.[0-9][0-9][0-9]}?[ ]+[A-Z][A-Z][A-Z][A-Z]?[ ]+{[0-9][0-9][0-9][0-9]}"
 STRING s[255] = "[A-Z][a-z][a-z][ ]+{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}{\.[0-9][0-9][0-9]}?[ ]+[A-Z][A-Z][A-Z][A-Z]?[ ]+{[0-9][0-9][0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: threaddump2: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.3</version> <version control></version control> (filenamemacro=getstsae.s) [<Program>] [<Research>] [kn, ri, su, 20-06-2021 04:59:11]
STRING PROC FNStringGetFileLogThreaddump2JobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogThreaddump2JobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
               1   2  3             4
 Example: [Thu Oct 15 13:22:11 CEST 2020]; Format: Www Mmm DD HH:MM:SS ZZZ?Z?Z? YYYY; Order: s4 s1 s2 s3
 */
 //
 // ===
 //
 // "Hewlett_Packard_JVM: thread_dump;"
 //
 STRING s[255] = "\[[A-Z][a-z][a-z][ ]+{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}{\.[0-9][0-9][0-9]}?[ ]+[A-Z][A-Z][A-Z][A-Z]?[ ]+{[0-9][0-9][0-9][0-9]}\]"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: threaddump3: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.3</version> <version control></version control> (filenamemacro=getstsaf.s) [<Program>] [<Research>] [kn, ri, su, 20-06-2021 04:59:38]
STRING PROC FNStringGetFileLogThreaddump3JobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogThreaddump3JobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
 //
 // ===
 //
 Oracle JVM
 //
          1    2  3  4
 Example: 2021-05-26 11:18:52 CES; Format: YYYY-MM-DD HH:MM:SS ZZZ?Z?Z?; Order: s1 s2 s3 s4
 //
 // ===
 //
 Azul: OpenJDK: Thread: Dump: Date: Time:
 //
          1    2  3  4
 Example: 2022-02-17 19:37:44; Format: YYYY-MM-DD HH:MM:SS; Order: s1 s2 s3 s4
  */
 //
 // "JStack_Oracle_JVM_Zulu_JVM_Thread_List_Thread_Local: thread_dump;"
 //
 // STRING s[255] = "^[ ]*{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 STRING s[255] = "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: threaddump4: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.2</version> <version control></version control> (filenamemacro=getstsbp.s) [<Program>] [<Research>] [kn, ri, su, 20-06-2021 04:59:57]
STRING PROC FNStringGetFileLogThreaddump4JobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogThreaddump4JobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 /*
          1    2  3     4
 Example: 2012/03/12 at 20:52:13; Format: YYYY/MM/DD at HH:MM:SS; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "IBM_AIX: thread_dump;"
 //
 STRING s[255] = "{[0-9][0-9][0-9][0-9]}/{[0-9][0-9]}/{[0-9][0-9]}[ ]+at[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: integration: server: server: log: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.11</version> <version control></version control> (filenamemacro=getstsah.s) [<Program>] [<Research>] [kn, ri, sa, 05-06-2021 00:45:43]
STRING PROC FNStringGetFileLogIntegrationServerServerLogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogIntegrationServerServerLogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
          1    2  3  4
 Example: 2021-05-19 16:33:16; Format: YYYY-MM-DD HH:mm:SS; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "Integration_Server: server.log;"
 //
 // STRING s[255] = "^[ ]*{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 STRING s[255] = "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: error: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.4</version> <version control></version control> (filenamemacro=getstsaa.s) [<Program>] [<Research>] [kn, ri, tu, 15-06-2021 23:12:45]
STRING PROC FNStringGetFileLogErrorJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogErrorJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
          1    2  3  4
 Example: 2021-06-15T16:23:39; Format: YYYY-MM-DDT?HH:mm:SS; Order: s1 s2 s3 s4
 //
          1    2  3  4
 Example: 2022/02/10 06:23:59.672Z
 //
          1    2  3  4
 Example: 2022/02/10 06:24:00.11Z
 */
 //
 // ===
 //
 // "Integration_Server: error.log;"
 //
 STRING s[255] = "\t?{[0-9][0-9][0-9][0-9]}[-/]{[0-9][0-9]}[-/]{[0-9][0-9]}[T ]{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: statslog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.6</version> <version control></version control> (filenamemacro=getstsaz.s) [<Program>] [<Research>] [kn, ri, mo, 14-06-2021 21:09:09]
STRING PROC FNStringGetFileLogStatslogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogStatslogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
          1    2  3  4
 Example: 2021-02-24 00:01:23; Format: YYYY-MM-DD HH:mm:SS; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "Integration_Server: stats.log;"
 //
 // STRING s[255] = "^[ ]*{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 STRING s[255] = "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: statslog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.6</version> <version control></version control> (filenamemacro=getstsaz.s) [<Program>] [<Research>] [kn, ri, mo, 14-06-2021 21:09:09]
STRING PROC FNStringGetFileLogStatscsvknudJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogStatscsvknudJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
          1  2  3    4
 Example: 30/03/2022 00:00:50; Format: DD/MM/YYYY HH:mm:SS; Order: s3 s2 s1 s4
 */
 //
 // ===
 //
 // "Integration_Server: statsknud.csv;"
 //
 STRING s[255] = "{[0-9][0-9]}/{[0-9][0-9]}/{[0-9][0-9][0-9][0-9]} {[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: tx: in: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.6</version> <version control></version control> (filenamemacro=getstsax.s) [<Program>] [<Research>] [kn, ri, sa, 12-06-2021 23:58:00]
STRING PROC FNStringGetFileLogTxInJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogTxInJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
 1    2  3  4
 2021-06-07T15:21:56
 //
 1    2  3  4
 2022/02/11 09:04:37.989Z
 //
          1    2  3  4
 Example: 2022/02/11 09:04:38.69Z; Format: YYYY/MM/DD HH:mm:SSZ; Order: s1 s2 s3 s4
 */
 //
 // "Integration_Server: txin.log;"
 //
 STRING s[255] = "\t?{[0-9][0-9][0-9][0-9]}[-/]{[0-9][0-9]}[-/]{[0-9][0-9]}[T ]{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: tx: out: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.5</version> <version control></version control> (filenamemacro=getstsay.s) [<Program>] [<Research>] [kn, ri, sa, 12-06-2021 23:59:01]
STRING PROC FNStringGetFileLogTxOutJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogTxOutJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
 1    2  3  4
 2021-06-07T15:21:56
 //
 1    2  3  4
 2022/02/11 09:04:37.989Z
 //
          1    2  3  4
 Example: 2022/02/11 09:04:38.69Z; Format: YYYY/MM/DD HH:mm:SSZ; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "Integration_Server: txout.log;"
 //
 STRING s[255] = "\t?{[0-9][0-9][0-9][0-9]}[-/]{[0-9][0-9]}[-/]{[0-9][0-9]}[T ]{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: session: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.9</version> <version control></version control> (filenamemacro=getstsaw.s) [<Program>] [<Research>] [kn, ri, sa, 12-06-2021 23:56:55]
STRING PROC FNStringGetFileLogSessionJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogSessionJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
   1    2  3  4
 \t2021/02/24 11:10:05
 //
            1    2  3  4
 Example: \t2021-06-07T15:21:56; Format: \tYYYY-MM-DDT?HH:mm:SS; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "Integration_Server: session.log;"
 //
 STRING s[255] = "\t{[0-9][0-9][0-9][0-9]}[-/]{[0-9][0-9]}[-/]{[0-9][0-9]}[T ]{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: security: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.6</version> <version control></version control> (filenamemacro=getstsav.s) [<Program>] [<Research>] [kn, ri, sa, 12-06-2021 23:53:08]
STRING PROC FNStringGetFileLogSecurityJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogSecurityJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
   1    2  3  4
 \t2021/02/24 11:10:05
 //
            1    2  3  4
 Example: \t2021-06-07T15:21:56; Format: \tYYYY-MM-DDT?HH:mm:SS; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "Integration_Server: security.log;"
 //
 STRING s[255] = "\t{[0-9][0-9][0-9][0-9]}[-/]{[0-9][0-9]}[-/]{[0-9][0-9]}[T ]{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: platform: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.5</version> <version control></version control> (filenamemacro=getstsau.s) [<Program>] [<Research>] [kn, ri, sa, 12-06-2021 03:33:51]
STRING PROC FNStringGetFileLogPlatformJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogPlatformJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
          1    2  3  4
 Example: 2021-06-04 15:06:05; Format: YYYY-MM-DD HH:mm:SS; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "Integration_Server: platform.log;"
 //
 STRING s[255] = "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: terracotta: server: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.3</version> <version control></version control> (filenamemacro=getstsbq.s) [<Program>] [<Research>] [kn, ri, tu, 15-02-2022 16:28:53]
STRING PROC FNStringGetFileLogTerracottaServerJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogTerracottaServerJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
          1    2  3  4
 Example: 2021-11-29 17:22:14,184 [; Format: YYYY-MM-DD HH:mm:SS,sss; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "Terracotta server: terracotta-server.log:"
 //
 STRING s[255] = "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: terracotta: client: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.4</version> <version control></version control> (filenamemacro=getstsbs.s) [<Program>] [<Research>] [kn, ri, tu, 15-02-2022 16:31:18]
STRING PROC FNStringGetFileLogTerracottaClientJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogTerracottaClientJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
          1    2  3  4
 Example: 2022-02-14 16:52:01,587 [; Format: YYYY-MM-DD HH:mm:SS,sss [; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "Terracotta server: terracotta-client.log:"
 //
 STRING s[255] = "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: terracotta: ehcache: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.2</version> <version control></version control> (filenamemacro=getstsbt.s) [<Program>] [<Research>] [kn, ri, tu, 15-02-2022 16:33:19]
STRING PROC FNStringGetFileLogTerracottaEhcacheJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogTerracottaEhcacheJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
          1  2  3  4
 Example: 26.01.22 17:31:18.686 [; Format: DD.MM.YY HH:mm:SS.sss; Order: s3 s2 s1 s4
 */
 //
 // ===
 //
 // "Integration Server: ehcache.log:"
 //
 STRING s[255] = "{[0-9][0-9]}.{[0-9][0-9]}.{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: service: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.7</version> <version control></version control> (filenamemacro=getstsat.s) [<Program>] [<Research>] [kn, ri, sa, 12-06-2021 00:02:48]
STRING PROC FNStringGetFileLogServiceJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogServiceJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
   1    2  3  4
 \t2020/08/08 21:09:36
 //
            1    2  3  4
 Example: \t2021-06-07T15:21:52.768Z; Format: \tYYYY-MM-DDT?HH:mm:SS.sssZ; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "Integration_Server: service.log;"
 //
 STRING s[255] = "\t{[0-9][0-9][0-9][0-9]}[-/]{[0-9][0-9]}[-/]{[0-9][0-9]}[T ]{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: sagosgi: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.5</version> <version control></version control> (filenamemacro=getstsas.s) [<Program>] [<Research>] [kn, ri, fr, 11-06-2021 21:57:56]
STRING PROC FNStringGetFileLogSagosgiJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogSagosgiJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
          1    2  3  4
 Example: 2020-02-01 18:14:36,737; Format: YYYY-MM-DD HH:mm:SS,sss; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "Integration Osgi: sag-osgi.log;", "Integration_Server: activetransfer.log;"
 //
 // STRING s[255] = "^[ ]*{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 STRING s[255] = "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: umclient: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.7</version> <version control></version control> (filenamemacro=getstsaj.s) [<Program>] [<Research>] [kn, ri, sa, 05-06-2021 22:36:06]
STRING PROC FNStringGetFileLogUmclientJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogUmclientJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
      1   2  3                 4
 [Sun May 23 03:43:04.753 SAST 2021]
 //
               1   2  3                4
 Example: [Tue Feb 01 16:27:21.178 CET 2022]; Format: [Www Mmm DD HH:mm:SS.sss ZZZ?Z?Z? YYYY]; Order: s4 s1 s2 s3
 */
 //
 // ===
 //
 // "Integration_Server: umclient.log;"
 //
 STRING s[255] = "{\[[A-Z][a-z][a-z][ ]+{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}{\.[0-9][0-9][0-9]}?[ ]+[A-Z][A-Z][A-Z][A-Z]?[ ]+{[0-9][0-9][0-9][0-9]}\]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: wrapper: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.8</version> <version control></version control> (filenamemacro=getstsah.s) [<Program>] [<Research>] [kn, ri, sa, 05-06-2021 00:45:43]
STRING PROC FNStringGetFileLogWrapperJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogWrapperJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
            1    2  3  4
 Example: | 2021/05/19 16:33:16 |; Format: | YYYY/MM/DD HH:mm:SS |; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "Integration_Server: wrapper.log;"
 //
 STRING s[255] = "\|[ ]*{[0-9][0-9][0-9][0-9]}/{[0-9][0-9]}/{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: full: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.6</version> <version control></version control> (filenamemacro=getstsao.s) [<Program>] [<Research>] [kn, ri, su, 06-06-2021 02:11:50]
STRING PROC FNStringGetFileLogMywebmethodsserverFullJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogMywebmethodsserverFullJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
          1    2  3  4
 Example: 2021-05-19 16:33:16; Format: YYYY-MM-DD HH:mm:SS; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "MyWebMethodsServer: _full_.log;"
 //
 // STRING s[255] = "^[ ]*{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 STRING s[255] = "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: nirvana: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.11</version> <version control></version control> (filenamemacro=getstsag.s) [<Program>] [<Research>] [kn, ri, sa, 05-06-2021 00:37:38]
STRING PROC FNStringGetFileLogNirvanaAccessErrorJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogNirvanaAccessErrorJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
               1   2  3                 4
 Example: [Sun May 23 03:43:04.753 SAST 2021]; Format: Www Mmm DD HH:mm:SS.sss ZZZ?Z?Z? YYYY; Order: s4 s1 s2 s3
 */
 //
 // ===
 //
 // "Universal_Messaging: nirvana.log;"
 //
 STRING s[255] = "{\[[A-Z][a-z][a-z][ ]+{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}{\.[0-9][0-9][0-9]}?[ ]+[A-Z][A-Z][A-Z][A-Z]?[ ]+{[0-9][0-9][0-9][0-9]}\]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: plugin: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.2</version> <version control></version control> (filenamemacro=getstsab.s) [<Program>] [<Research>] [kn, ri, fr, 18-06-2021 14:53:51]
STRING PROC FNStringGetFileLogPluginJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogPluginJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
               1   2  3                 4
 Example: [Sun May 23 03:43:04.753 SAST 2021]; Format: Www Mmm DD HH:mm:SS.sss ZZZ?Z?Z? YYYY; Order: s4 s1 s2 s3
 */
 //
 // ===
 //
 // "Universal_Messaging: plugin.log;"
 //
 STRING s[255] = "{\[[A-Z][a-z][a-z][ ]+{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}{\.[0-9][0-9][0-9]}?[ ]+[A-Z][A-Z][A-Z][A-Z]?[ ]+{[0-9][0-9][0-9][0-9]}\]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: umrealmservice: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.8</version> <version control></version control> (filenamemacro=getstsai.s) [<Program>] [<Research>] [kn, ri, sa, 05-06-2021 00:47:05]
STRING PROC FNStringGetFileLogUmrealmserviceJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogUmrealmserviceJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
            1    2  3  4
 Example: | 2020/08/08 21:09:36 |; Format: | YYYY/MM/DD HH:mm:SS |; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "Universal_Messaging: umrealmservice.log;"
 //
 STRING s[255] = "\|[ ]*{[0-9][0-9][0-9][0-9]}/{[0-9][0-9]}/{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: broker: diaglog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.4</version> <version control></version control> (filenamemacro=getstsbu.s) [<Program>] [<Research>] [kn, ri, fr, 04-03-2022 12:54:19]
STRING PROC FNStringGetFileLogBrokerDiaglogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogBrokerDiaglogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
              1   2  3        4
 Example: Sat May 23 16:30:10 2020; Format: Www Mmm DD HH:mm:SS YYYY; Order: s4 s1 s2 s3
 */
 //
 // ===
 //
 // "Broker: Diag.log;"
 //
 STRING s[255] = "{[A-Z][a-z][a-z]}[ ]+{[0-9]?[0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}[ ]+{[0-9][0-9][0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: wireshark: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=getstsbv.s) [<Program>] [<Research>] [kn, ri, tu, 22-03-2022 12:44:55]
STRING PROC FNStringGetFileLogWiresharkJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogWiresharkJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
          1    2  3  4
 Example: 2022-03-22 12:37:52,833319; Format: YYYY-MM:DD HH:MM:SS,ssssss; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "Network_Wireshark_Export: log;"
 //
 STRING s[255] = "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: apacheaccesslog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=getstsbw.s) [<Program>] [<Research>] [kn, ri, tu, 22-03-2022 16:22:33]
STRING PROC FNStringGetFileLogApacheaccesslogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogApacheaccesslogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
   1 2   3    4
 Example: [06/Feb/2011:15:53:46 +0100]; Format: DD/Mmm/YYYY:HH:MM:SS ZZZZZ]; Order: s3 s2 s1 s4
 */
 //
 // ===
 //
 // "Apache: access.log;"
 //
 STRING s[255] = "{[0-9][0-9]}/{[A-Z][a-z][a-z]}/{[0-9][0-9][0-9][0-9]}:{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}[ ]+{.*}\]"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: apacheerrorlog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.0</version> <version control></version control> (filenamemacro=getstsbx.s) [<Program>] [<Research>] [kn, ri, tu, 22-03-2022 16:39:58]
STRING PROC FNStringGetFileLogApacheerrorlogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogApacheerrorlogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
      1   2  3        4
 Example: [Sat Apr 21 01:30:01 2012]; Format: Mmm DD HH:MM:SS YYYY; Order: s4 s1 s2 s3
 */
 //
 // ===
 //
 // "Apache: error.log;"
 //
 STRING s[255] = "\[[A-Z][a-z][a-z][ ]+{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}[ ]+{[0-9][0-9][0-9][0-9]}\]"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: Tomcat: catalinalog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=getstsbz.s) [<Program>] [<Research>] [kn, ri, tu, 22-03-2022 22:36:30]
STRING PROC FNStringGetFileLogTomcatcatalinalogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogTomcatcatalinalogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
          1   2   3    4
 Example: Sep 12, 2010 12:35:05 AM; Format: Mmm DD, YYYY HH:MM:SS [{AM}|{PM}]; Order: s3 s1 s2 s4
 */
 //
 // ===
 //
 // "Tomcat: catalina.log;"
 //
 STRING s[255] = "{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]?},[ ]+{[0-9][0-9][0-9][0-9]}[ ]+{[0-9][0-9]?}:{[0-9][0-9]?}:{[0-9][0-9]?}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: tomcatlocalhostlog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=getstscy.s) [<Program>] [<Research>] [kn, ri, tu, 22-03-2022 22:47:25]
STRING PROC FNStringGetFileLogTomcatlocalhostlogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogTomcatlocalhostlogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
          1   2   3    4
 Example: Sep 12, 2010 12:58:01 AM; Format: Mmm DD, YYYY HH:MM:SS [{AM}|{PM}]; Order: s3 s1 s2 s4
 */
 //
 // ===
 //
 // "Tomcat: localhost.log"
 //
 STRING s[255] = "{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]?},[ ]+{[0-9][0-9][0-9][0-9]}[ ]+{[0-9][0-9]?}:{[0-9][0-9]?}:{[0-9][0-9]?}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: tomcatmanagerlog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.2</version> <version control></version control> (filenamemacro=getstscz.s) [<Program>] [<Research>] [kn, ri, tu, 22-03-2022 22:49:33]
STRING PROC FNStringGetFileLogTomcatmanagerlogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogTomcatmanagerlogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
          1   2   3    4
 Example: Sep 12, 2010 12:58:01 AM; Format: Mmm DD, YYYY HH:MM:SS [{AM}|{PM}]; Order: s3 s1 s2 s4
 */
 //
 // ===
 //
 // "Tomcat: manager.log"
 //
 STRING s[255] = "{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]?},[ ]+{[0-9][0-9][0-9][0-9]}[ ]+{[0-9][0-9]?}:{[0-9][0-9]?}:{[0-9][0-9]?}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: broker: logmsgs: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=getstsel.s) [<Program>] [<Research>] [kn, ri, su, 27-03-2022 19:30:40]
STRING PROC FNStringGetFileLogBrokerLogmsgsJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogBrokerLogmsgsJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
 1    2  3  4
 Example: 2015-09-28 12:56:36 Info; Format: YYYY-MM:DD HH:MM:SS; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "Broker: logmsgs.log"
 // "Broker: logmsgs.mon.log"
 //
 STRING s[255] = "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: httplog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.2</version> <version control></version control> (filenamemacro=getstsem.s) [<Program>] [<Research>] [kn, ri, tu, 29-03-2022 12:55:37]
STRING PROC FNStringGetFileLogHttplogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogHttplogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format: the same as used in general 'common log file' and 'combined log file'. That is basically the same as used in the Apache access.log.
 //
 /*
   1 2   3    4
 Example: [06/Feb/2011:15:53:46 +0100]; Format: DD/Mmm/YYYY:HH:MM:SS ZZZZZ]; Order: s3 s2 s1 s4
 */
 //
 // ===
 //
 // "Integration_Server: http.log;"
 //
 STRING s[255] = "{[0-9][0-9]}/{[A-Z][a-z][a-z]}/{[0-9][0-9][0-9][0-9]}:{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}[ ]+{.*}\]"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: j: bossserverlog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=getstsby.s) [<Program>] [<Research>] [kn, ri, tu, 22-03-2022 22:32:50]
STRING PROC FNStringGetFileLogJbossserverlogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogJbossserverlogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
 1    2  3  4
 Example: 2016-03-16 14:32:01,627; Format: YYYY-MM-DD HH:MM:SS,sss; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "JBoss: server.log;"
 //
 STRING s[255] = "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: ibmdb2db2diaglog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.2</version> <version control></version control> (filenamemacro=getstsew.s) [<Program>] [<Research>] [kn, ri, su, 03-04-2022 19:28:10]
STRING PROC FNStringGetFileLogIbmdb2db2diaglogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogIbmdb2db2diaglogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
                                1    2  3  4
 Example: 2016-02-15-19.31.36.114000; Format: YYYY-MM-DD-HH.mm.SS.ssssss; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "IBM_DB2: db2diag.log;"
 //
 STRING s[255] = "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9].[0-9][0-9].[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: jvmgarbagecollectiongclog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.2</version> <version control></version control> (filenamemacro=getstsfz.s) [<Program>] [<Research>] [kn, ri, mo, 04-04-2022 01:28:44]
STRING PROC FNStringGetFileLogJvmgarbagecollectiongclogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogMicrosoftiisisslogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
                                                1    2  3  4
 Example: 2014-11-18T16:39:37.728-0800; Format: YYYY-MM-DDTHH:mm:SS.sss-ZZZZ; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "JVM_Garbage_Collection: gc.log;"
 //
 STRING s[255] = "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[T ]{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: microsofteventviewerlog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=getstsej.s) [<Program>] [<Research>] [kn, ri, su, 03-04-2022 19:50:06]
STRING PROC FNStringGetFileLogMicrosofteventviewerlogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogMicrosofteventviewerlogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
                                       1  2  3    4
 Example: 03/04/2022 17:19:11; Format: DD/MM/YYYY HH:mm:SS; Order: s3 s2 s1 s4
 */
 //
 // ===
 //
 // "Microsoft_Event_Viewer: eventviewer.log;"
 //
 STRING s[255] = "{[0-9][0-9]}/{[0-9][0-9]}/{[0-9][0-9][0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: microsoftiisw34svclog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=getstsfx.s) [<Program>] [<Research>] [kn, ri, su, 03-04-2022 19:54:08]
STRING PROC FNStringGetFileLogMicrosoftiisw34svclogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogMicrosoftiisw34svclogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
                                       1    2  3  4
 Example: 2004-09-29 00:13:03; Format: YYYY-MM-DD HH:mm:SS; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "Microsoft_IIS_W3C_Format: w3svc.log;"
 //
 STRING s[255] = "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: microsoftiisisslog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=getstsfy.s) [<Program>] [<Research>] [kn, ri, su, 03-04-2022 19:56:59]
STRING PROC FNStringGetFileLogMicrosoftiisisslogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogMicrosoftiisisslogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
                                          1  2  3    4
 Example: [07/28/2012 19:41:03]; Format: [DD/MM/YYYY HH:mm:SS]; Order: s3 s2 s1 s4
 */
 //
 // ===
 //
 // "Microsoft_IIS_Format: iis.log;"
 //
 STRING s[255] = "{[0-9][0-9]}/{[0-9][0-9]}/{[0-9][0-9][0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: mysqlservererrlog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.3</version> <version control></version control> (filenamemacro=getstsef.s) [<Program>] [<Research>] [kn, ri, su, 03-04-2022 19:44:58]
STRING PROC FNStringGetFileLogMysqlservererrlogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogMysqlservererrlogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
                                   1 2 3  4
 Example: 190115 23:56:11; Format: YYMMDD HH:mm:SS; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "MySQL_Server: err.log;"
 //
 STRING s[255] = "{[0-9][0-9]}{[0-9][0-9]}{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: microsoftsqlservererrorlog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=getstsed.s) [<Program>] [<Research>] [kn, ri, su, 03-04-2022 19:34:48]
STRING PROC FNStringGetFileLogMicrosoftsqlservererrorlogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogMicrosoftsqlservererrorlogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
                                           1    2  3  4
 Example: 2019-11-05 08:08:49.630; Format: YYYY-MM-DD HH:mm:SS.sss; Order: s1 s2 s3 s4
 */
 //
 // ===
 //
 // "Microsoft_SQL_Server: error.log;"
 //
 STRING s[255] = "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: microsoftsqlserversqllog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.4</version> <version control></version control> (filenamemacro=getstsfa.s) [<Program>] [<Research>] [kn, ri, mo, 09-05-2022 13:25:47]
STRING PROC FNStringGetFileLogMicrosoftsqlserversqllogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogMicrosoftsqlserversqllogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
                                       1  2  3    4
 Example: 07/28/2012 19:41:03; Format: MM/DD/YYYY HH:mm:SS; Order: s3 s1 s2 s4
 */
 /*
                                       1  2  3    4
 Example: 07/28/2012(19:41:03; Format: MM/DD/YYYY(HH:mm:SS; Order: s3 s1 s2 s4
 */
 //
 // ===
 //
 // "Microsoft_SQL_Server: sql.log;"
 //
 STRING s[255] = "{[0-9][0-9]}/{[0-9][0-9]}/{[0-9][0-9][0-9][0-9]}[ ]|({[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: string: get: file: log: oraclealertlog: job: software: ag <description></description> <version control></version control> <version>1.0.0.0.0</version> <version control></version control> (filenamemacro=getstsee.s) [<Program>] [<Research>] [kn, ri, su, 03-04-2022 19:41:05]
STRING PROC FNStringGetFileLogOraclealertlogJobSoftwareAgS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileLogOraclealertlogJobSoftwareAgS() )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // date/time format:
 //
 /*
                                                1   2  3        4
 Example: Fri Jul 16 14:00:05 2021; Format: Www Mmm DD HH:mm:SS YYYY; Order: s4 s1 s2 s3
 */
 //
 // ===
 //
 // "Oracle: alert.log;"
 //
 STRING s[255] = "{[A-Z][a-z][a-z]}[ ]+{[0-9][0-9]}[ ]+{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}[ ]+{[0-9][0-9][0-9][0-9]}"
 //
 RETURN( s )
 //
END

// library: file: get: line: longest <description></description> <version control></version control> <version>1.0.0.0.4</version> <version control></version control> (filenamemacro=getfillq.s) [<Program>] [<Research>] [kn, ri, mo, 14-03-2022 23:26:22]
INTEGER PROC FNFileGetLineLongestI( STRING fileNameS )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = "c:\temp\ddd.txt" // change this
 // e.g.  Message( FNFileGetLineLongestI( s1 ) ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 INTEGER I = 0
 //
 PushPosition()
 PushBlock()
 //
 IF NOT EditFile( fileNameS )
  //
  Warn( fileNameS, ":", " ", "Could not be loaded. Please check." )
  //
  PopBlock()
  //
  PopPosition()
  //
  I = FNMathGetErrorI()
  //
  RETURN( I )
  //
 ENDIF
 //
 MarkLine( 1, NumLines() )
 //
 I = FNBlockGetLineLongestI()
 //
 PopBlock()
 PopPosition()
 //
 RETURN( I )
 //
END

// library: file: change: line: longest: to: line: shorter <description></description> <version control></version control> <version>1.0.0.0.2</version> <version control></version control> (filenamemacro=chanfilt.s) [<Program>] [<Research>] [kn, ri, mo, 14-03-2022 23:42:35]
INTEGER PROC FNFileChangeLineLongestToLineShorterB()
 // e.g. PROC Main()
 // e.g.  Message( FNFileChangeLineLongestToLineShorterB() ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 INTEGER B = FALSE
 //
 PushPosition()
 PushBlock()
 //
 MarkLine( 1, NumLines() )
 //
 B = FNBlockChangeLineLongestToLineShorterB()
 //
 PopBlock()
 PopPosition()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: threaddump1: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.13</version> <version control></version control> (filenamemacro=getblcfv.s) [<Program>] [<Research>] [kn, ri, fr, 18-03-2022 14:52:18]
INTEGER PROC FNBlockGetLogFileLogThreaddump1DateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogThreaddump1JobSoftwareAgS()
 // e.g.  STRING s2[255] = "Integration_Server: thread_dump"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogThreaddump1DateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 //  // Note: The date/time format of the Integration Server threaddump is the same as the date/time format of the Universal Messaging umclient.log, so combining it into one.
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
Wed May 26 10:45:46 CEST 2021
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
2021-05-26 10:45:46 Integration_Server: thread_dump0: Wed May 26 10:45:46 CEST 2021
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 STRING s6[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // format input: YYYY/MM/DD HH:MM:SS (e.g. 2021/06/07 08:30:02.90)
  //
  s1 = GetFoundText( 1 ) // month name, e.g. "May" (=MM)
  s2 = GetFoundText( 2 ) // day number in the month, e.g. 27 (=DD)
  s3 = GetFoundText( 3 ) // time (=hh:mm:ss, 05:37:22)
  s4 = GetFoundText( 4 ) // year, e.g. 2021 (=YYYY)
  s5 = GetFoundText( 5 ) // year, e.g. 2021 (=YYYY)
  //
  // Warn( "s1"; s1; "s2"; s2; "s3"; s3; "s4"; s4; "s5"; s5 ) Halt // debug
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  IF NOT ( Pos( ".", s4 ) == 0 ) OR ( EquiStr( "", Trim( s4 ) ) )
   s4 = s5
  ENDIF
  //
  // Warn( "month"; s1; "day"; s2; "time"; s3; "year"; s4 ) // debug
  //
  CASE s1
   //
   WHEN "Jan"
    s1 = "01"
   WHEN "Feb"
    s1 = "02"
   WHEN "Mar"
    s1 = "03"
   WHEN "Apr"
    s1 = "04"
   WHEN "May"
    s1 = "05"
   WHEN "Jun"
    s1 = "06"
   WHEN "Jul"
    s1 = "07"
   WHEN "Aug"
    s1 = "08"
   WHEN "Sep"
    s1 = "09"
   WHEN "Oct"
    s1 = "10"
   WHEN "Nov"
    s1 = "11"
   WHEN "Dec"
    s1 = "12"
    //
   OTHERWISE
    //
    Warn( "FNBlockGetLogFileLogThreaddump1DateTimeAllToBufferCanonicalFrontB(", " ", "case", " ", ":", " ", s1, ": not known" )
    //
  ENDCASE
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s6 = FNStringGetDateWeekDayNameS( Val( s2 ), Val( s1 ), Val( s4 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s6, 1 ) ), SubStr( s6, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s4, "-", s1, "-", s2, " ", s3 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: nirvana: log: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.3</version> <version control></version control> (filenamemacro=getblcfs.s) [<Program>] [<Research>] [kn, ri, fr, 18-03-2022 02:27:27]
INTEGER PROC FNBlockGetLogFileLogThreaddump2NirvanaAccessErrorLogPluginUmclientDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogNirvanaAccessErrorJobSoftwareAgS()
 // e.g.  STRING s2[255] = "Universal_Messaging: nirvana.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogThreaddump2NirvanaAccessErrorLogPluginUmclientDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 //  // Note: The date/time format of the Universal Messaging nirvana.log is the same as the date/time format of the Universal Messaging umclient.log, so combining it into one.
 //
 // ===
 //
 // Overview: input ( given block date/time 1 ) -> output sorted canonical format YYYY-MM-DD hh:mm:ss ( block date/time 2 )
 //
 // ===
 //
 // Description: Convert a block of (already earlier extracted, existing) nirvana.log date/time first to a block of canonical log date/time, then sort that canonical log block chronologically (because now converted to YYYY-MM-DD format, so sorting correctly out of the box is possible).
 //
 // ===
 //
 // Use case: You want to sort a list of nirvana log files in chronological order, e.g. for merging purposes
 //
 // ===
 //
 // Method: Get a block of nirvana.log date/time, optionally put it somewhere, run the program, then the nirvana.log date/time are (searched using a regular expression) converted to canonical log date/time and chronologically sorted.
 //
 // ===
 //
 // Format: Nirvana.log date/time format (first 3 characters for the dayname, then 3 characters for the monthname, then 2 digits for the monthnumber, then 2 digits for the hour, a colon, then 2 digits for the minutes, a colon, then 2 digits for the seconds, then 3 or 4 characters for the timezone, then 4 digits for the year.
 //
 //  [Thu May 27 18:17:21 CEST 2021]
 //
 // to
 //
 // Canonical date/time format in log
 //
 //  2021-05-27 18:17:21
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 [Sun May 23 03:43:42.123 SAST 2021] [MemoryManagement] MemoryManager: Monitor: Memory Free, Before 797.93 MB, After 797.93 MB
 [Sun May 23 03:43:39.234 SAST 2021] [UM Server Status Generator] ServerStatusLog> Memory=798, Direct=2041, EventMemory=0, Disk=73934, CPU=0.5, Scheduled=927, Queued=0, Connections=8, BytesIn=3208162, BytesOut=30558526028, Published=7451129, Consumed=20521967, QueueSize=0, ClientsSize=0, CommQueueSize=0
 [Sun May 23 03:43:44.567 SAST 2021] [UM Server Status Generator] ServerStatusLog> Memory=797, Direct=2041, EventMemory=0, Disk=73934, CPU=0.5, Scheduled=928, Queued=0, Connections=8, BytesIn=3208162, BytesOut=30558636356, Published=7451146, Consumed=20521978, QueueSize=0, ClientsSize=0, CommQueueSize=0
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
2021-05-23 03:43:39  [Sun May 23 03:43:39.814 SAST 2021] [UM Server Status Generator] ServerStatusLog> Memory=798, Direct=2041, EventMemory=0, Disk=73934, CPU=0.5, Scheduled=927, Queued=0, Connections=8, BytesIn=3208162, BytesOut=30558526028, Published=7451129, Consumed=20521967, QueueSize=0, ClientsSize=0, CommQueueSize=0
2021-05-23 03:43:42  [Sun May 23 03:43:42.362 SAST 2021] [MemoryManagement] MemoryManager: Monitor: Memory Free, Before 797.93 MB, After 797.93 MB
2021-05-23 03:43:44  [Sun May 23 03:43:44.825 SAST 2021] [UM Server Status Generator] ServerStatusLog> Memory=797, Direct=2041, EventMemory=0, Disk=73934, CPU=0.5, Scheduled=928, Queued=0, Connections=8, BytesIn=3208162, BytesOut=30558636356, Published=7451146, Consumed=20521978, QueueSize=0, ClientsSize=0, CommQueueSize=0
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 STRING s6[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // format input: WWW MMM DD HH:MM:SS ZZZZ YYYY  (e.g. Fri Mar 18 02:36:00 CET 2022)
  //
  s1 = GetFoundText( 2 ) // month name, e.g. "May" (=MM)
  s2 = GetFoundText( 3 ) // day number in the month, e.g. 27 (=DD)
  s3 = GetFoundText( 4 ) // time (=hh:mm:ss, 05:37:22)
  s4 = GetFoundText( 5 ) // time zone {ZZZ?Z?Z?)
  s5 = GetFoundText( 6 ) // year, e.g. 2021 (=YYYY)
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  IF NOT ( Pos( ".", s4 ) == 0 ) OR ( EquiStr( "", Trim( s4 ) ) )
   s4 = s5
  ENDIF
  //
  // Warn( "month"; s1; "day"; s2; "time"; s3; "year"; s4 ) // debug
  //
  CASE s1
   //
   WHEN "Jan"
    s1 = "01"
   WHEN "Feb"
    s1 = "02"
   WHEN "Mar"
    s1 = "03"
   WHEN "Apr"
    s1 = "04"
   WHEN "May"
    s1 = "05"
   WHEN "Jun"
    s1 = "06"
   WHEN "Jul"
    s1 = "07"
   WHEN "Aug"
    s1 = "08"
   WHEN "Sep"
    s1 = "09"
   WHEN "Oct"
    s1 = "10"
   WHEN "Nov"
    s1 = "11"
   WHEN "Dec"
    s1 = "12"
    //
   OTHERWISE
    //
    Warn( "FNBlockGetLogFileLogThreaddump2NirvanaAccessErrorLogPluginUmclientDateTimeAllToBufferCanonicalFrontB(", " ", "case", " ", ":", " ", s1, ": not known" )
    //
  ENDCASE
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s6 = FNStringGetDateWeekDayNameS( Val( s2 ), Val( s1 ), Val( s4 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s6, 1 ) ), SubStr( s6, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s4, "-", s1, "-", s2, " ", s3 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: serverlog: integrationserver: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.6</version> <version control></version control> (filenamemacro=getblcfr.s) [<Program>] [<Research>] [kn, ri, th, 17-03-2022 22:07:09]
INTEGER PROC FNBlockGetLogFileLogThreaddump3OpenjdkazulServerlogIntegrationserverPlatformSagosgiStatsFullIisw3svcMssqlerrorDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogIntegrationServerServerLogJobSoftwareAgS()
 // e.g.  STRING s2[255] = "Integration_Server: server.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: merge: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogThreaddump3OpenjdkazulServerlogIntegrationserverPlatformSagosgiStatsFullIisw3svcMssqlerrorDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
2021-04-30 15:09:55 CEST [ISS.0025.0001I] (tid=82) Integration Server 10.3.0.0 Build 118
2021-04-30 15:09:55 CEST [ISS.0025.0006I] (tid=82) License Manager started
2021-04-30 15:09:55 CEST [ISS.0001.0008W] (tid=82) Microservices Functionality disabled due to license restrictions.
2021-04-30 15:09:55 CEST [ISS.0025.0049I] (tid=82) The JCE Unlimited Strength Jurisdiction Policy File was found
2021-04-30 15:09:55 CEST [ISS.0025.0041I] (tid=82) FIPS mode not initialized
2021-04-30 15:09:56 CEST [ISS.0139.9999I] (tid=82) Initializing ISKeyStoreManager using watt.server.homeDir:C:\SoftwareAG\IntegrationServer\instances\default\config\security\keystore
2021-04-30 15:09:56 CEST [ISS.0139.9999I] (tid=82) ISKeyStoreManager initialized successfully.
2021-04-30 15:10:06 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for ActiveTransfer functional alias, check configuration.
2021-04-30 15:10:15 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for CentralUsers functional alias, check configuration.
2021-04-30 15:10:21 CEST [ISS.0096.0026W] (tid=82) The JDBC function "DocumentHistory", pool alias "test" has entered fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:10:21 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for DocumentHistory functional alias, check configuration.
2021-04-30 15:10:29 CEST [ISS.0096.0026W] (tid=82) The JDBC function "ISCoreAudit", pool alias "test" has entered fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:10:29 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for ISCoreAudit functional alias, check configuration.
2021-04-30 15:10:35 CEST [ISS.0096.0026W] (tid=82) The JDBC function "Xref", pool alias "test" has entered fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:10:35 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for Xref functional alias, check configuration.
2021-04-30 15:10:44 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for ProcessAudit functional alias, check configuration.
2021-04-30 15:10:52 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for TN functional alias, check configuration.
2021-04-30 15:10:58 CEST [ISS.0096.0026W] (tid=82) The JDBC function "ISInternal", pool alias "test" has entered fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:10:58 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for ISInternal functional alias, check configuration.
2021-04-30 15:11:06 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for ProcessEngine functional alias, check configuration.
2021-04-30 15:11:07 CEST [ISS.0025.0024I] (tid=82) JDBC Connection Manager started
2021-04-30 15:11:10 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: The JDBC function "ISCoreAudit", pool alias "test" is in fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:11:10 CEST [WmAuditingSC.main.5010E] Failed to open destination 'ErrorDBDest'; reason 'Exception trying to set the DBMS vendor: {0}'
2021-04-30 15:11:10 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: The JDBC function "ISCoreAudit", pool alias "test" is in fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:11:10 CEST [WmAuditingSC.main.5010E] Failed to open destination 'apigatewayTxnJdbc'; reason 'Exception trying to set the DBMS vendor: {0}'
2021-04-30 15:11:10 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: The JDBC function "ISCoreAudit", pool alias "test" is in fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:11:10 CEST [WmAuditingSC.main.5010E] Failed to open destination 'ServiceDBDest'; reason 'Exception trying to set the DBMS vendor: {0}'
2021-04-30 15:11:10 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: The JDBC function "ISCoreAudit", pool alias "test" is in fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:11:10 CEST [WmAuditingSC.main.5010E] Failed to open destination 'CoreAuditDBDest'; reason 'Exception trying to set the DBMS vendor: {0}'
2021-04-30 15:11:10 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: The JDBC function "ISCoreAudit", pool alias "test" is in fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:11:10 CEST [WmAuditingSC.main.5010E] Failed to open destination 'SessionDBDest'; reason 'Exception trying to set the DBMS vendor: {0}'
2021-04-30 15:11:18 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:11:18 CEST [WmAuditingSC.main.5010E] Failed to open destination 'ProcessAuditDBDest'; reason 'Exception trying to set the DBMS vendor: {0}'
2021-04-30 15:11:18 CEST [WmAuditingSC.queue.2019W] Worker thread for queue 'ProcessAuditQueue' started, but its target destination is not open
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
2021-04-30 15:09:55 Integration_Server: server.log: 2021-04-30 15:09:55 CEST [ISS.0025.0001I] (tid=82) Integration Server 10.3.0.0 Build 118
2021-04-30 15:09:55 Integration_Server: server.log: 2021-04-30 15:09:55 CEST [ISS.0025.0006I] (tid=82) License Manager started
2021-04-30 15:09:55 Integration_Server: server.log: 2021-04-30 15:09:55 CEST [ISS.0001.0008W] (tid=82) Microservices Functionality disabled due to license restrictions.
2021-04-30 15:09:55 Integration_Server: server.log: 2021-04-30 15:09:55 CEST [ISS.0025.0049I] (tid=82) The JCE Unlimited Strength Jurisdiction Policy File was found
2021-04-30 15:09:55 Integration_Server: server.log: 2021-04-30 15:09:55 CEST [ISS.0025.0041I] (tid=82) FIPS mode not initialized
2021-04-30 15:09:56 Integration_Server: server.log: 2021-04-30 15:09:56 CEST [ISS.0139.9999I] (tid=82) Initializing ISKeyStoreManager using watt.server.homeDir:C:\SoftwareAG\IntegrationServer\instances\default\config\security\keystore
2021-04-30 15:09:56 Integration_Server: server.log: 2021-04-30 15:09:56 CEST [ISS.0139.9999I] (tid=82) ISKeyStoreManager initialized successfully.
2021-04-30 15:10:06 Integration_Server: server.log: 2021-04-30 15:10:06 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for ActiveTransfer functional alias, check configuration.
2021-04-30 15:10:15 Integration_Server: server.log: 2021-04-30 15:10:15 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for CentralUsers functional alias, check configuration.
2021-04-30 15:10:21 Integration_Server: server.log: 2021-04-30 15:10:21 CEST [ISS.0096.0026W] (tid=82) The JDBC function "DocumentHistory", pool alias "test" has entered fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:10:21 Integration_Server: server.log: 2021-04-30 15:10:21 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for DocumentHistory functional alias, check configuration.
2021-04-30 15:10:29 Integration_Server: server.log: 2021-04-30 15:10:29 CEST [ISS.0096.0026W] (tid=82) The JDBC function "ISCoreAudit", pool alias "test" has entered fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:10:29 Integration_Server: server.log: 2021-04-30 15:10:29 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for ISCoreAudit functional alias, check configuration.
2021-04-30 15:10:35 Integration_Server: server.log: 2021-04-30 15:10:35 CEST [ISS.0096.0026W] (tid=82) The JDBC function "Xref", pool alias "test" has entered fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:10:35 Integration_Server: server.log: 2021-04-30 15:10:35 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for Xref functional alias, check configuration.
2021-04-30 15:10:44 Integration_Server: server.log: 2021-04-30 15:10:44 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for ProcessAudit functional alias, check configuration.
2021-04-30 15:10:52 Integration_Server: server.log: 2021-04-30 15:10:52 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for TN functional alias, check configuration.
2021-04-30 15:10:58 Integration_Server: server.log: 2021-04-30 15:10:58 CEST [ISS.0096.0026W] (tid=82) The JDBC function "ISInternal", pool alias "test" has entered fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:10:58 Integration_Server: server.log: 2021-04-30 15:10:58 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for ISInternal functional alias, check configuration.
2021-04-30 15:11:06 Integration_Server: server.log: 2021-04-30 15:11:06 CEST [ISS.0096.0001C] (tid=82) JDBCConnectionManager: initialization failed for ProcessEngine functional alias, check configuration.
2021-04-30 15:11:07 Integration_Server: server.log: 2021-04-30 15:11:07 CEST [ISS.0025.0024I] (tid=82) JDBC Connection Manager started
2021-04-30 15:11:10 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: The JDBC function "ISCoreAudit", pool alias "test" is in fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:11:10 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.main.5010E] Failed to open destination 'ErrorDBDest'; reason 'Exception trying to set the DBMS vendor: {0}'
2021-04-30 15:11:10 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: The JDBC function "ISCoreAudit", pool alias "test" is in fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:11:10 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.main.5010E] Failed to open destination 'apigatewayTxnJdbc'; reason 'Exception trying to set the DBMS vendor: {0}'
2021-04-30 15:11:10 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: The JDBC function "ISCoreAudit", pool alias "test" is in fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:11:10 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.main.5010E] Failed to open destination 'ServiceDBDest'; reason 'Exception trying to set the DBMS vendor: {0}'
2021-04-30 15:11:10 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: The JDBC function "ISCoreAudit", pool alias "test" is in fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:11:10 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.main.5010E] Failed to open destination 'CoreAuditDBDest'; reason 'Exception trying to set the DBMS vendor: {0}'
2021-04-30 15:11:10 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: The JDBC function "ISCoreAudit", pool alias "test" is in fail-fast mode. The exception message is: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:11:10 Integration_Server: server.log: 2021-04-30 15:11:10 CEST [WmAuditingSC.main.5010E] Failed to open destination 'SessionDBDest'; reason 'Exception trying to set the DBMS vendor: {0}'
2021-04-30 15:11:18 Integration_Server: server.log: 2021-04-30 15:11:18 CEST [WmAuditingSC.destination.1130E] Exception trying to set the DBMS vendor: [SoftwareAG][Oracle JDBC Driver]SAG-9Y4HHC2
2021-04-30 15:11:18 Integration_Server: server.log: 2021-04-30 15:11:18 CEST [WmAuditingSC.main.5010E] Failed to open destination 'ProcessAuditDBDest'; reason 'Exception trying to set the DBMS vendor: {0}'
2021-04-30 15:11:18 Integration_Server: server.log: 2021-04-30 15:11:18 CEST [WmAuditingSC.queue.2019W] Worker thread for queue 'ProcessAuditQueue' started, but its target destination is not open
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // format input: YYYY-MM-DD HH:MM:SS ZZZ?Z?Z? (e.g. 2022-03-18 00:50:00 CET)
  //
  s1 = GetFoundText( 1 ) // year, e.g. 2022 (=YYYY)
  s2 = GetFoundText( 2 ) // month number, e.g. 03 (=MM)
  s3 = GetFoundText( 3 ) // day number, e.g. 18 (=DD)
  s4 = GetFoundText( 4 ) // time (=hh:mm:ss, e.g. 00:50:00)
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s3 ), Val( s2 ), Val( s1 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s1, "-", s2, "-", s3, " ", s4 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: serverlog: integrationserver: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.8</version> <version control></version control> (filenamemacro=getblcfr.s) [<Program>] [<Research>] [kn, ri, th, 17-03-2022 22:07:09]
INTEGER PROC FNBlockGetLogFileLogThreaddump4IbmaixthreaddumpDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogThreaddump4JobSoftwareAgS()
 // e.g.  STRING s2[255] = "IBM_AIX: thread_dump"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: merge: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogThreaddump4IbmaixthreaddumpDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 Example: 2012/06/01 at 09:52:12; Format: (YYYY/MM/DD at HH:MM:SS; Order: s1 s2 s3 s4
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
 2012-06-01 09:52:12 IBM_AIX: thread_dump: Example: 2012/06/01 at 09:52:12 / Format: (YYYY/MM/DD at HH:MM:SS / Order: s1, s2, s3, s4
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // Example: 2012/06/01 at 09:52:12 / Format: (YYYY/MM/DD at HH:MM:SS / Order: s1, s2, s3, s4
  //
  s1 = GetFoundText( 1 ) // year, e.g. 2022 (=YYYY)
  s2 = GetFoundText( 2 ) // month number, e.g. 03 (=MM)
  s3 = GetFoundText( 3 ) // day number, e.g. 18 (=DD)
  s4 = GetFoundText( 4 ) // time (=hh:mm:ss, e.g. 00:50:00)
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s3 ), Val( s2 ), Val( s1 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s1, "-", s2, "-", s3, " ", s4 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: txin: txout: error: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.6</version> <version control></version control> (filenamemacro=getblcfu.s) [<Program>] [<Research>] [kn, ri, fr, 18-03-2022 12:47:03]
INTEGER PROC FNBlockGetLogFileLogTxinTxoutErrorDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogErrorJobSoftwareAgS()
 // e.g.  STRING s2[255] = "Integration_Server: error.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogTxinTxoutErrorDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Note: The date/time format of the Integration Server TxIn.log is the same as the date/time format of the Integration Server TxOut.log and Integration Server server.log, so combining it into one.
 //
 // ===
 //
 // Overview: input ( given block date/time 1 ) -> output sorted canonical format YYYY-MM-DD hh:mm:ss ( block date/time 2 )
 //
 // ===
 //
 // Description: Convert a block of (already earlier extracted, existing) wrapper.log date/time first to a block of canonicl log date/time, then sort that canonical log block chronologically (because now converted to YYYY-MM-DD format, so sorting correctly out of the box is possible).
 //
 // ===
 //
 // Use case: You want to sort a list of wrapper log files in chronological order, e.g. for merging purposes
 //
 // ===
 //
 // Method: Get a block of wrapper.log date/time, optionally put it somewhere, run the program, then the wrapper.log date/time are (searched using a regular expression) converted to canonical log date/time and chronologically sorted.
 //
 // ===
 //
 // Format: wrapper.log date/time format (first 3 characters for the dayname, then 3 characters for the monthname, then 2 digits for the monthnumber, then 2 digits for the hour, a colon, then 2 digits for the minutes, a colon, then 2 digits for the seconds, then 3 or 4 characters for the timezone, then 4 digits for the year.
 //
 //  | 2021-04-30 15:09:55 |
 //
 // to
 //
 // Canonical date/time format in log
 //
 //   2021-04-30 15:09:55
 //
 // ===
 //
 // Input:
 //
 /*
 0122fe20-88a1-10b3-8f22-ffffff76735c	0122fe20-88a1-10b3-8f22-ffffff76735c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:30:02.90Z	2021/06/07 08:30:02.27Z	Administrator	false	0	Mtn_Pro_OPTIMA_CampaignMgmt.instorePPEFeed.V01.services.priv:subscribeZipFolder	Started	NULL	0	0
 0122fe20-88a1-10b3-8f22-ffffff76735c	0122fe20-88a1-10b3-8f22-ffffff76735c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:30:09.233Z	2021/06/07 08:30:09.140Z	Administrator	false	7142	Mtn_Pro_OPTIMA_CampaignMgmt.instorePPEFeed.V01.services.priv:subscribeZipFolder	Ended	NULL	0	0
 182e8000-2de4-1751-92ee-ffffff760a83	182e8000-2de4-1751-92ee-ffffff760a83	3b2634a0-9d66-1d21-b3e6-ffffff760a81	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:38:01.777Z	2021/06/07 08:38:01.727Z	e_m	false	0	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:invokeCustBulkExtract	Started	NULL	0	0
 182e8000-2de4-1751-92ee-ffffff760a83	182e8000-2de4-1751-92ee-ffffff760a83	3b2634a0-9d66-1d21-b3e6-ffffff760a81	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:38:02.03Z	2021/06/07 08:38:01.913Z	e_m	false	225	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:invokeCustBulkExtract	Ended	NULL	0	0
 c3516b30-76b2-15a4-a76c-ffffff7606c7	c3516b30-76b2-15a4-a76c-ffffff7606c7	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:23.957Z	2021/06/07 08:39:23.923Z	Administrator	false	0	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeGzipLocation	Started	NULL	0	0
 c3516b30-76b2-15a4-a76c-ffffff7606c7	c3516b30-76b2-15a4-a76c-ffffff7606c7	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:55.760Z	2021/06/07 08:39:55.677Z	Administrator	false	31802	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeGzipLocation	Ended	NULL	0	0
 13da8e30-b26a-1742-8e03-ffffff76062c	13da8e30-b26a-1742-8e03-ffffff76062c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:55.777Z	2021/06/07 08:39:55.753Z	Administrator	false	0	Mtn_Cmr_ESBDB_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeJsonLocDetails	Started	NULL	0	0
 13da8e30-b26a-1742-8e03-ffffff76062c	13da8e30-b26a-1742-8e03-ffffff76062c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:40:03.480Z	2021/06/07 08:40:03.380Z	Administrator	false	7704	Mtn_Cmr_ESBDB_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeJsonLocDetails	Ended	NULL	0	0
 a4835030-59dc-1a5a-ba4e-ffffff7532b5	a4835030-59dc-1a5a-ba4e-ffffff7532b5	RTMAS0124.Matalan.co.uk:19000	2021/06/07 09:11:29.200Z	2021/06/07 09:11:29.140Z	Administrator	false	0	Mtn_Cmr_ESBDB_ProductMgmt.productFeed.V01.services.priv:subscribeProductFeed	Started	NULL	0	0
 a4835030-59dc-1a5a-ba4e-ffffff7532b5	a4835030-59dc-1a5a-ba4e-ffffff7532b5	RTMAS0124.Matalan.co.uk:19000	2021/06/07 09:15:04.747Z	2021/06/07 09:15:04.693Z	Administrator	false	215547	Mtn_Cmr_ESBDB_ProductMgmt.productFeed.V01.services.priv:subscribeProductFeed	Ended	NULL	0	0
 */
 //
 // Output:
 //
 /*
2021-06-07 08:30:02 Integration_Server: error.log:  0122fe20-88a1-10b3-8f22-ffffff76735c	0122fe20-88a1-10b3-8f22-ffffff76735c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:30:02.90Z	2021/06/07 08:30:02.27Z	Administrator	false	0	Mtn_Pro_OPTIMA_CampaignMgmt.instorePPEFeed.V01.services.priv:subscribeZipFolder	Started	NULL	0	0
2021-06-07 08:30:09 Integration_Server: error.log:  0122fe20-88a1-10b3-8f22-ffffff76735c	0122fe20-88a1-10b3-8f22-ffffff76735c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:30:09.233Z	2021/06/07 08:30:09.140Z	Administrator	false	7142	Mtn_Pro_OPTIMA_CampaignMgmt.instorePPEFeed.V01.services.priv:subscribeZipFolder	Ended	NULL	0	0
2021-06-07 08:38:01 Integration_Server: error.log:  182e8000-2de4-1751-92ee-ffffff760a83	182e8000-2de4-1751-92ee-ffffff760a83	3b2634a0-9d66-1d21-b3e6-ffffff760a81	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:38:01.777Z	2021/06/07 08:38:01.727Z	e_m	false	0	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:invokeCustBulkExtract	Started	NULL	0	0
2021-06-07 08:38:02 Integration_Server: error.log:  182e8000-2de4-1751-92ee-ffffff760a83	182e8000-2de4-1751-92ee-ffffff760a83	3b2634a0-9d66-1d21-b3e6-ffffff760a81	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:38:02.03Z	2021/06/07 08:38:01.913Z	e_m	false	225	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:invokeCustBulkExtract	Ended	NULL	0	0
2021-06-07 08:39:23 Integration_Server: error.log:  c3516b30-76b2-15a4-a76c-ffffff7606c7	c3516b30-76b2-15a4-a76c-ffffff7606c7	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:23.957Z	2021/06/07 08:39:23.923Z	Administrator	false	0	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeGzipLocation	Started	NULL	0	0
2021-06-07 08:39:55 Integration_Server: error.log:  c3516b30-76b2-15a4-a76c-ffffff7606c7	c3516b30-76b2-15a4-a76c-ffffff7606c7	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:55.760Z	2021/06/07 08:39:55.677Z	Administrator	false	31802	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeGzipLocation	Ended	NULL	0	0
2021-06-07 08:39:55 Integration_Server: error.log:  13da8e30-b26a-1742-8e03-ffffff76062c	13da8e30-b26a-1742-8e03-ffffff76062c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:55.777Z	2021/06/07 08:39:55.753Z	Administrator	false	0	Mtn_Cmr_ESBDB_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeJsonLocDetails	Started	NULL	0	0
2021-06-07 08:40:03 Integration_Server: error.log:  13da8e30-b26a-1742-8e03-ffffff76062c	13da8e30-b26a-1742-8e03-ffffff76062c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:40:03.480Z	2021/06/07 08:40:03.380Z	Administrator	false	7704	Mtn_Cmr_ESBDB_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeJsonLocDetails	Ended	NULL	0	0
2021-06-07 09:11:29 Integration_Server: error.log:  a4835030-59dc-1a5a-ba4e-ffffff7532b5	a4835030-59dc-1a5a-ba4e-ffffff7532b5	RTMAS0124.Matalan.co.uk:19000	2021/06/07 09:11:29.200Z	2021/06/07 09:11:29.140Z	Administrator	false	0	Mtn_Cmr_ESBDB_ProductMgmt.productFeed.V01.services.priv:subscribeProductFeed	Started	NULL	0	0
2021-06-07 09:15:04 Integration_Server: error.log:  a4835030-59dc-1a5a-ba4e-ffffff7532b5	a4835030-59dc-1a5a-ba4e-ffffff7532b5	RTMAS0124.Matalan.co.uk:19000	2021/06/07 09:15:04.747Z	2021/06/07 09:15:04.693Z	Administrator	false	215547	Mtn_Cmr_ESBDB_ProductMgmt.productFeed.V01.services.priv:subscribeProductFeed	Ended	NULL	0	0
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // format input: YYYY/MM/DD HH:MM:SS (e.g. 2021/06/07 08:30:02.90)
  //
  s1 = GetFoundText( 1 ) // year, e.g. 2021 (=YYYY)
  s2 = GetFoundText( 2 ) // month name, e.g. "May" (=MM)
  s3 = GetFoundText( 3 ) // day number in the month, e.g. 27 (=DD)
  s4 = GetFoundText( 4 ) // time (=hh:mm:ss, 05:37:22)
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s3 ), Val( s2 ), Val( s1 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s1, "-", s2, "-", s3, " ", s4 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: ehcache: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.5</version> <version control></version control> (filenamemacro=getblcfy.s) [<Program>] [<Research>] [kn, ri, fr, 18-03-2022 15:16:55]
INTEGER PROC FNBlockGetLogFileLogEhcacheDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogTerracottaEhcacheJobSoftwareAgS()
 // e.g.  STRING s2[255] = "Integration_Server: ehcache.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogEhcacheDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
26.01.22 17:31:18.686 [WARN] | Another CacheManager already instantiated the Ehcache Management rest agent, reachable through the TSA agent, the configuration will not be changed for SoftwareAG.IS.PE.IntegrationServerCluster
26.01.22 17:31:18.718 [WARN] | Cache: oauthTokens has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
26.01.22 17:31:20.255 [WARN] | Cache: stockInformationCache has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
26.01.22 17:31:20.379 [WARN] | Cache: stockInformationCacheV3 has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
26.01.22 17:31:20.422 [WARN] | Cache: solarDataCache has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
26.01.22 17:31:20.453 [WARN] | Cache: articleMasterDataCache has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
26.01.22 17:31:20.482 [WARN] | Cache: weatherForecastV2Cache has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
26.01.22 17:31:20.535 [WARN] | Another CacheManager already instantiated the Ehcache Management rest agent, reachable through the TSA agent, the configuration will not be changed for CM.KL_EnterpriseServicesClustered
26.01.22 17:31:26.518 [WARN] | Another CacheManager already instantiated the Ehcache Management rest agent, reachable through the TSA agent, the configuration will not be changed for SoftwareAG.IS.ART.IntegrationServerCluster
26.01.22 17:31:26.536 [WARN] | Cache: storeMasterdataCache has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
26.01.22 17:31:28.299 [WARN] | Another CacheManager already instantiated the Ehcache Management rest agent, reachable through the TSA agent, the configuration will not be changed for SoftwareAG.IS.Core.IntegrationServerCluster
26.01.22 17:31:28.342 [WARN] | Cache: weatherForecastCache has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
26.01.22 17:31:28.348 [WARN] | Cache: checkHistory has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
2022-01-26 17:31:18 Integration_Server: ehcache.log: 26.01.22 17:31:18.686 [WARN] | Another CacheManager already instantiated the Ehcache Management rest agent, reachable through the TSA agent, the configuration will not be changed for SoftwareAG.IS.PE.IntegrationServerCluster
2022-01-26 17:31:18 Integration_Server: ehcache.log: 26.01.22 17:31:18.718 [WARN] | Cache: oauthTokens has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
2022-01-26 17:31:20 Integration_Server: ehcache.log: 26.01.22 17:31:20.255 [WARN] | Cache: stockInformationCache has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
2022-01-26 17:31:20 Integration_Server: ehcache.log: 26.01.22 17:31:20.379 [WARN] | Cache: stockInformationCacheV3 has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
2022-01-26 17:31:20 Integration_Server: ehcache.log: 26.01.22 17:31:20.422 [WARN] | Cache: solarDataCache has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
2022-01-26 17:31:20 Integration_Server: ehcache.log: 26.01.22 17:31:20.453 [WARN] | Cache: articleMasterDataCache has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
2022-01-26 17:31:20 Integration_Server: ehcache.log: 26.01.22 17:31:20.482 [WARN] | Cache: weatherForecastV2Cache has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
2022-01-26 17:31:20 Integration_Server: ehcache.log: 26.01.22 17:31:20.535 [WARN] | Another CacheManager already instantiated the Ehcache Management rest agent, reachable through the TSA agent, the configuration will not be changed for CM.KL_EnterpriseServicesClustered
2022-01-26 17:31:26 Integration_Server: ehcache.log: 26.01.22 17:31:26.518 [WARN] | Another CacheManager already instantiated the Ehcache Management rest agent, reachable through the TSA agent, the configuration will not be changed for SoftwareAG.IS.ART.IntegrationServerCluster
2022-01-26 17:31:26 Integration_Server: ehcache.log: 26.01.22 17:31:26.536 [WARN] | Cache: storeMasterdataCache has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
2022-01-26 17:31:28 Integration_Server: ehcache.log: 26.01.22 17:31:28.299 [WARN] | Another CacheManager already instantiated the Ehcache Management rest agent, reachable through the TSA agent, the configuration will not be changed for SoftwareAG.IS.Core.IntegrationServerCluster
2022-01-26 17:31:28 Integration_Server: ehcache.log: 26.01.22 17:31:28.342 [WARN] | Cache: weatherForecastCache has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
2022-01-26 17:31:28 Integration_Server: ehcache.log: 26.01.22 17:31:28.348 [WARN] | Cache: checkHistory has a maxElementsInMemory of 0. This might lead to performance degradation or OutOfMemoryError at Terracotta client.From Ehcache 2.0 onwards this has been changed to mean a store with no capacity limit. Set it to 1 if you want no elements cached in memory
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // format input: DD.MM.YY HH:MM:SS (e.g. 26.01.22 17:31:18.686)
  //
  s1 = GetFoundText( 1 ) // day number in the month: 01, 02, ..., 31, e.g. 27 (=DD)
  s2 = GetFoundText( 2 ) // month number: 01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 11, 12, e.g. 2 (=MM)
  s3 = GetFoundText( 3 ) // year: ..., 19, 20, 21, 22, ..., e.g. 22 (=YY)
  s4 = GetFoundText( 4 ) // time, e.g. 05:37:22 (=HH:MM:SS)
  //
  s3 = Format( "20", s3 ) // make a 4 digit year YYYY from the 2 digit year YY (20YY)
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s1 ), Val( s2 ), Val( s3 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s3, "-", s2, "-", s1, " ", s4 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: security: session: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.5</version> <version control></version control> (filenamemacro=getblcfx.s) [<Program>] [<Research>] [kn, ri, fr, 18-03-2022 15:11:11]
INTEGER PROC FNBlockGetLogFileLogSecuritySessionDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogSecurityJobSoftwareAgS()
 // e.g.  STRING s2[255] = "Integration_Server: security.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogSecuritySessionDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Note: The date/time format of the Integration Server security.log is the same as the date/time format of the Integration Server session.log and Integration Server service.log, so combining it into one.
 //
 // ===
 //
 // Overview: input ( given block date/time 1 ) -> output sorted canonical format YYYY-MM-DD hh:mm:ss ( block date/time 2 )
 //
 // ===
 //
 // Description: Convert a block of (already earlier extracted, existing) wrapper.log date/time first to a block of canonicl log date/time, then sort that canonical log block chronologically (because now converted to YYYY-MM-DD format, so sorting correctly out of the box is possible).
 //
 // ===
 //
 // Use case: You want to sort a list of wrapper log files in chronological order, e.g. for merging purposes
 //
 // ===
 //
 // Method: Get a block of wrapper.log date/time, optionally put it somewhere, run the program, then the wrapper.log date/time are (searched using a regular expression) converted to canonical log date/time and chronologically sorted.
 //
 // ===
 //
 // Format: wrapper.log date/time format (first 3 characters for the dayname, then 3 characters for the monthname, then 2 digits for the monthnumber, then 2 digits for the hour, a colon, then 2 digits for the minutes, a colon, then 2 digits for the seconds, then 3 or 4 characters for the timezone, then 4 digits for the year.
 //
 //  | 2021-04-30 15:09:55 |
 //
 // to
 //
 // Canonical date/time format in log
 //
 //   2021-04-30 15:09:55
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 0122fe20-88a1-10b3-8f22-ffffff76735c	0122fe20-88a1-10b3-8f22-ffffff76735c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:30:02.90Z	2021/06/07 08:30:02.27Z	Administrator	false	0	Mtn_Pro_OPTIMA_CampaignMgmt.instorePPEFeed.V01.services.priv:subscribeZipFolder	Started	NULL	0	0
 0122fe20-88a1-10b3-8f22-ffffff76735c	0122fe20-88a1-10b3-8f22-ffffff76735c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:30:09.233Z	2021/06/07 08:30:09.140Z	Administrator	false	7142	Mtn_Pro_OPTIMA_CampaignMgmt.instorePPEFeed.V01.services.priv:subscribeZipFolder	Ended	NULL	0	0
 182e8000-2de4-1751-92ee-ffffff760a83	182e8000-2de4-1751-92ee-ffffff760a83	3b2634a0-9d66-1d21-b3e6-ffffff760a81	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:38:01.777Z	2021/06/07 08:38:01.727Z	e_m	false	0	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:invokeCustBulkExtract	Started	NULL	0	0
 182e8000-2de4-1751-92ee-ffffff760a83	182e8000-2de4-1751-92ee-ffffff760a83	3b2634a0-9d66-1d21-b3e6-ffffff760a81	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:38:02.03Z	2021/06/07 08:38:01.913Z	e_m	false	225	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:invokeCustBulkExtract	Ended	NULL	0	0
 c3516b30-76b2-15a4-a76c-ffffff7606c7	c3516b30-76b2-15a4-a76c-ffffff7606c7	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:23.957Z	2021/06/07 08:39:23.923Z	Administrator	false	0	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeGzipLocation	Started	NULL	0	0
 c3516b30-76b2-15a4-a76c-ffffff7606c7	c3516b30-76b2-15a4-a76c-ffffff7606c7	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:55.760Z	2021/06/07 08:39:55.677Z	Administrator	false	31802	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeGzipLocation	Ended	NULL	0	0
 13da8e30-b26a-1742-8e03-ffffff76062c	13da8e30-b26a-1742-8e03-ffffff76062c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:55.777Z	2021/06/07 08:39:55.753Z	Administrator	false	0	Mtn_Cmr_ESBDB_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeJsonLocDetails	Started	NULL	0	0
 13da8e30-b26a-1742-8e03-ffffff76062c	13da8e30-b26a-1742-8e03-ffffff76062c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:40:03.480Z	2021/06/07 08:40:03.380Z	Administrator	false	7704	Mtn_Cmr_ESBDB_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeJsonLocDetails	Ended	NULL	0	0
 a4835030-59dc-1a5a-ba4e-ffffff7532b5	a4835030-59dc-1a5a-ba4e-ffffff7532b5	RTMAS0124.Matalan.co.uk:19000	2021/06/07 09:11:29.200Z	2021/06/07 09:11:29.140Z	Administrator	false	0	Mtn_Cmr_ESBDB_ProductMgmt.productFeed.V01.services.priv:subscribeProductFeed	Started	NULL	0	0
 a4835030-59dc-1a5a-ba4e-ffffff7532b5	a4835030-59dc-1a5a-ba4e-ffffff7532b5	RTMAS0124.Matalan.co.uk:19000	2021/06/07 09:15:04.747Z	2021/06/07 09:15:04.693Z	Administrator	false	215547	Mtn_Cmr_ESBDB_ProductMgmt.productFeed.V01.services.priv:subscribeProductFeed	Ended	NULL	0	0
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
2021-06-07 08:30:02 Integration_Server: security.log:  0122fe20-88a1-10b3-8f22-ffffff76735c	0122fe20-88a1-10b3-8f22-ffffff76735c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:30:02.90Z	2021/06/07 08:30:02.27Z	Administrator	false	0	Mtn_Pro_OPTIMA_CampaignMgmt.instorePPEFeed.V01.services.priv:subscribeZipFolder	Started	NULL	0	0
2021-06-07 08:30:09 Integration_Server: security.log:  0122fe20-88a1-10b3-8f22-ffffff76735c	0122fe20-88a1-10b3-8f22-ffffff76735c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:30:09.233Z	2021/06/07 08:30:09.140Z	Administrator	false	7142	Mtn_Pro_OPTIMA_CampaignMgmt.instorePPEFeed.V01.services.priv:subscribeZipFolder	Ended	NULL	0	0
2021-06-07 08:38:01 Integration_Server: security.log:  182e8000-2de4-1751-92ee-ffffff760a83	182e8000-2de4-1751-92ee-ffffff760a83	3b2634a0-9d66-1d21-b3e6-ffffff760a81	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:38:01.777Z	2021/06/07 08:38:01.727Z	e_m	false	0	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:invokeCustBulkExtract	Started	NULL	0	0
2021-06-07 08:38:02 Integration_Server: security.log:  182e8000-2de4-1751-92ee-ffffff760a83	182e8000-2de4-1751-92ee-ffffff760a83	3b2634a0-9d66-1d21-b3e6-ffffff760a81	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:38:02.03Z	2021/06/07 08:38:01.913Z	e_m	false	225	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:invokeCustBulkExtract	Ended	NULL	0	0
2021-06-07 08:39:23 Integration_Server: security.log:  c3516b30-76b2-15a4-a76c-ffffff7606c7	c3516b30-76b2-15a4-a76c-ffffff7606c7	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:23.957Z	2021/06/07 08:39:23.923Z	Administrator	false	0	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeGzipLocation	Started	NULL	0	0
2021-06-07 08:39:55 Integration_Server: security.log:  c3516b30-76b2-15a4-a76c-ffffff7606c7	c3516b30-76b2-15a4-a76c-ffffff7606c7	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:55.760Z	2021/06/07 08:39:55.677Z	Administrator	false	31802	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeGzipLocation	Ended	NULL	0	0
2021-06-07 08:39:55 Integration_Server: security.log:  13da8e30-b26a-1742-8e03-ffffff76062c	13da8e30-b26a-1742-8e03-ffffff76062c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:55.777Z	2021/06/07 08:39:55.753Z	Administrator	false	0	Mtn_Cmr_ESBDB_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeJsonLocDetails	Started	NULL	0	0
2021-06-07 08:40:03 Integration_Server: security.log:  13da8e30-b26a-1742-8e03-ffffff76062c	13da8e30-b26a-1742-8e03-ffffff76062c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:40:03.480Z	2021/06/07 08:40:03.380Z	Administrator	false	7704	Mtn_Cmr_ESBDB_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeJsonLocDetails	Ended	NULL	0	0
2021-06-07 09:11:29 Integration_Server: security.log:  a4835030-59dc-1a5a-ba4e-ffffff7532b5	a4835030-59dc-1a5a-ba4e-ffffff7532b5	RTMAS0124.Matalan.co.uk:19000	2021/06/07 09:11:29.200Z	2021/06/07 09:11:29.140Z	Administrator	false	0	Mtn_Cmr_ESBDB_ProductMgmt.productFeed.V01.services.priv:subscribeProductFeed	Started	NULL	0	0
2021-06-07 09:15:04 Integration_Server: security.log:  a4835030-59dc-1a5a-ba4e-ffffff7532b5	a4835030-59dc-1a5a-ba4e-ffffff7532b5	RTMAS0124.Matalan.co.uk:19000	2021/06/07 09:15:04.747Z	2021/06/07 09:15:04.693Z	Administrator	false	215547	Mtn_Cmr_ESBDB_ProductMgmt.productFeed.V01.services.priv:subscribeProductFeed	Ended	NULL	0	0
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // format input: YYYY/MM/DD HH:MM:SS (e.g. 2021/06/07 08:30:02.90)
  //
  s1 = GetFoundText( 1 ) // year: ..., 2020, 2021, ... (=YYYY)
  s2 = GetFoundText( 2 ) // month: 01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 11, 12 (=MM)
  s3 = GetFoundText( 3 ) // day: 01, 02, ..., 31 (=DD)
  s4 = GetFoundText( 4 ) // time (=hh:mm:ss)
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s3 ), Val( s2 ), Val( s1 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s1, "-", s2, "-", s3, " ", s4 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: service: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.5</version> <version control></version control> (filenamemacro=getblcfw.s) [<Program>] [<Research>] [kn, ri, fr, 18-03-2022 15:04:25]
INTEGER PROC FNBlockGetLogFileLogServiceDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogServiceJobSoftwareAgS()
 // e.g.  STRING s2[255] = "Integration_Server: service.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogServiceDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Note: The date/time format of the Integration Server service.log is not the same as other .log date/time formats
 //
 // ===
 //
 // Overview: input ( given block date/time 1 ) -> output sorted canonical format YYYY-MM-DD hh:mm:ss ( block date/time 2 )
 //
 // ===
 //
 // Description: Convert a block of (already earlier extracted, existing) wrapper.log date/time first to a block of canonicl log date/time, then sort that canonical log block chronologically (because now converted to YYYY-MM-DD format, so sorting correctly out of the box is possible).
 //
 // ===
 //
 // Use case: You want to sort a list of wrapper log files in chronological order, e.g. for merging purposes
 //
 // ===
 //
 // Method: Get a block of wrapper.log date/time, optionally put it somewhere, run the program, then the wrapper.log date/time are (searched using a regular expression) converted to canonical log date/time and chronologically sorted.
 //
 // ===
 //
 // Format: wrapper.log date/time format (first 3 characters for the dayname, then 3 characters for the monthname, then 2 digits for the monthnumber, then 2 digits for the hour, a colon, then 2 digits for the minutes, a colon, then 2 digits for the seconds, then 3 or 4 characters for the timezone, then 4 digits for the year.
 //
 //  | 2021-04-30 15:09:55 |
 //
 // to
 //
 // Canonical date/time format in log
 //
 //   2021-04-30 15:09:55
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 0122fe20-88a1-10b3-8f22-ffffff76735c	0122fe20-88a1-10b3-8f22-ffffff76735c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:30:02.90Z	2021/06/07 08:30:02.27Z	Administrator	false	0	Mtn_Pro_OPTIMA_CampaignMgmt.instorePPEFeed.V01.services.priv:subscribeZipFolder	Started	NULL	0	0
 0122fe20-88a1-10b3-8f22-ffffff76735c	0122fe20-88a1-10b3-8f22-ffffff76735c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:30:09.233Z	2021/06/07 08:30:09.140Z	Administrator	false	7142	Mtn_Pro_OPTIMA_CampaignMgmt.instorePPEFeed.V01.services.priv:subscribeZipFolder	Ended	NULL	0	0
 182e8000-2de4-1751-92ee-ffffff760a83	182e8000-2de4-1751-92ee-ffffff760a83	3b2634a0-9d66-1d21-b3e6-ffffff760a81	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:38:01.777Z	2021/06/07 08:38:01.727Z	e_m	false	0	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:invokeCustBulkExtract	Started	NULL	0	0
 182e8000-2de4-1751-92ee-ffffff760a83	182e8000-2de4-1751-92ee-ffffff760a83	3b2634a0-9d66-1d21-b3e6-ffffff760a81	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:38:02.03Z	2021/06/07 08:38:01.913Z	e_m	false	225	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:invokeCustBulkExtract	Ended	NULL	0	0
 c3516b30-76b2-15a4-a76c-ffffff7606c7	c3516b30-76b2-15a4-a76c-ffffff7606c7	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:23.957Z	2021/06/07 08:39:23.923Z	Administrator	false	0	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeGzipLocation	Started	NULL	0	0
 c3516b30-76b2-15a4-a76c-ffffff7606c7	c3516b30-76b2-15a4-a76c-ffffff7606c7	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:55.760Z	2021/06/07 08:39:55.677Z	Administrator	false	31802	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeGzipLocation	Ended	NULL	0	0
 13da8e30-b26a-1742-8e03-ffffff76062c	13da8e30-b26a-1742-8e03-ffffff76062c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:55.777Z	2021/06/07 08:39:55.753Z	Administrator	false	0	Mtn_Cmr_ESBDB_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeJsonLocDetails	Started	NULL	0	0
 13da8e30-b26a-1742-8e03-ffffff76062c	13da8e30-b26a-1742-8e03-ffffff76062c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:40:03.480Z	2021/06/07 08:40:03.380Z	Administrator	false	7704	Mtn_Cmr_ESBDB_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeJsonLocDetails	Ended	NULL	0	0
 a4835030-59dc-1a5a-ba4e-ffffff7532b5	a4835030-59dc-1a5a-ba4e-ffffff7532b5	RTMAS0124.Matalan.co.uk:19000	2021/06/07 09:11:29.200Z	2021/06/07 09:11:29.140Z	Administrator	false	0	Mtn_Cmr_ESBDB_ProductMgmt.productFeed.V01.services.priv:subscribeProductFeed	Started	NULL	0	0
 a4835030-59dc-1a5a-ba4e-ffffff7532b5	a4835030-59dc-1a5a-ba4e-ffffff7532b5	RTMAS0124.Matalan.co.uk:19000	2021/06/07 09:15:04.747Z	2021/06/07 09:15:04.693Z	Administrator	false	215547	Mtn_Cmr_ESBDB_ProductMgmt.productFeed.V01.services.priv:subscribeProductFeed	Ended	NULL	0	0
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
2021-06-07 08:30:02 Integration_Server: service.log:  0122fe20-88a1-10b3-8f22-ffffff76735c	0122fe20-88a1-10b3-8f22-ffffff76735c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:30:02.90Z	2021/06/07 08:30:02.27Z	Administrator	false	0	Mtn_Pro_OPTIMA_CampaignMgmt.instorePPEFeed.V01.services.priv:subscribeZipFolder	Started	NULL	0	0
2021-06-07 08:30:09 Integration_Server: service.log:  0122fe20-88a1-10b3-8f22-ffffff76735c	0122fe20-88a1-10b3-8f22-ffffff76735c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:30:09.233Z	2021/06/07 08:30:09.140Z	Administrator	false	7142	Mtn_Pro_OPTIMA_CampaignMgmt.instorePPEFeed.V01.services.priv:subscribeZipFolder	Ended	NULL	0	0
2021-06-07 08:38:01 Integration_Server: service.log:  182e8000-2de4-1751-92ee-ffffff760a83	182e8000-2de4-1751-92ee-ffffff760a83	3b2634a0-9d66-1d21-b3e6-ffffff760a81	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:38:01.777Z	2021/06/07 08:38:01.727Z	e_m	false	0	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:invokeCustBulkExtract	Started	NULL	0	0
2021-06-07 08:38:02 Integration_Server: service.log:  182e8000-2de4-1751-92ee-ffffff760a83	182e8000-2de4-1751-92ee-ffffff760a83	3b2634a0-9d66-1d21-b3e6-ffffff760a81	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:38:02.03Z	2021/06/07 08:38:01.913Z	e_m	false	225	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:invokeCustBulkExtract	Ended	NULL	0	0
2021-06-07 08:39:23 Integration_Server: service.log:  c3516b30-76b2-15a4-a76c-ffffff7606c7	c3516b30-76b2-15a4-a76c-ffffff7606c7	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:23.957Z	2021/06/07 08:39:23.923Z	Administrator	false	0	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeGzipLocation	Started	NULL	0	0
2021-06-07 08:39:55 Integration_Server: service.log:  c3516b30-76b2-15a4-a76c-ffffff7606c7	c3516b30-76b2-15a4-a76c-ffffff7606c7	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:55.760Z	2021/06/07 08:39:55.677Z	Administrator	false	31802	Mtn_Pro_FLEX_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeGzipLocation	Ended	NULL	0	0
2021-06-07 08:39:55 Integration_Server: service.log:  13da8e30-b26a-1742-8e03-ffffff76062c	13da8e30-b26a-1742-8e03-ffffff76062c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:39:55.777Z	2021/06/07 08:39:55.753Z	Administrator	false	0	Mtn_Cmr_ESBDB_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeJsonLocDetails	Started	NULL	0	0
2021-06-07 08:40:03 Integration_Server: service.log:  13da8e30-b26a-1742-8e03-ffffff76062c	13da8e30-b26a-1742-8e03-ffffff76062c	RTMAS0124.Matalan.co.uk:19000	2021/06/07 08:40:03.480Z	2021/06/07 08:40:03.380Z	Administrator	false	7704	Mtn_Cmr_ESBDB_StaffDiscountMgmt.staffDiscInbound.V01.services.priv:subscribeJsonLocDetails	Ended	NULL	0	0
2021-06-07 09:11:29 Integration_Server: service.log:  a4835030-59dc-1a5a-ba4e-ffffff7532b5	a4835030-59dc-1a5a-ba4e-ffffff7532b5	RTMAS0124.Matalan.co.uk:19000	2021/06/07 09:11:29.200Z	2021/06/07 09:11:29.140Z	Administrator	false	0	Mtn_Cmr_ESBDB_ProductMgmt.productFeed.V01.services.priv:subscribeProductFeed	Started	NULL	0	0
2021-06-07 09:15:04 Integration_Server: service.log:  a4835030-59dc-1a5a-ba4e-ffffff7532b5	a4835030-59dc-1a5a-ba4e-ffffff7532b5	RTMAS0124.Matalan.co.uk:19000	2021/06/07 09:15:04.747Z	2021/06/07 09:15:04.693Z	Administrator	false	215547	Mtn_Cmr_ESBDB_ProductMgmt.productFeed.V01.services.priv:subscribeProductFeed	Ended	NULL	0	0
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // format input: YYYY/MM/DD HH:MM:SS (e.g. 2021/06/07 08:30:02.90)
  //
  s1 = GetFoundText( 1 ) // year, e.g. 2021 (=YYYY)
  s2 = GetFoundText( 2 ) // month name, e.g. "May" (=MM)
  s3 = GetFoundText( 3 ) // day number in the month, e.g. 27 (=DD)
  s4 = GetFoundText( 4 ) // time (=hh:mm:ss, 05:37:22)
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s3 ), Val( s2 ), Val( s1 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s1, "-", s2, "-", s3, " ", s4 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: statscsvknud: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.3</version> <version control></version control> (filenamemacro=getblcfi.s) [<Program>] [<Research>] [kn, ri, fr, 01-04-2022 00:47:17]
INTEGER PROC FNBlockGetLogFileLogStatsCsvKnudEventviewerlogIislogDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogStatscsvknudJobSoftwareAgS()
 // e.g.  STRING s2[255] = "Integration_Server: stats.csv"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: merge: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogStatsCsvKnudEventviewerlogIislogDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // format input: YYYY-MM-DD HH:MM:SS ZZZ?Z?Z? (e.g. 2022-03-18 00:50:00 CET)
  //
  s1 = GetFoundText( 1 ) // day number, e.g. 18 (=DD)
  s2 = GetFoundText( 2 ) // month number, e.g. 03 (=MM)
  s3 = GetFoundText( 3 ) // year, e.g. 2022 (=YYYY)
  s4 = GetFoundText( 4 ) // time (=hh:mm:ss, e.g. 00:50:00)
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s1 ), Val( s2 ), Val( s3 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s3, "-", s2, "-", s1, " ", s4 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: wrapper: umrealmservice: log: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.5</version> <version control></version control> (filenamemacro=getblcft.s) [<Program>] [<Research>] [kn, ri, fr, 18-03-2022 11:09:53]
INTEGER PROC FNBlockGetLogFileLogWrapperUmrealmserviceLogDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogWrapperJobSoftwareAgS()
 // e.g.  STRING s2[255] = "Integration_Server: wrapper.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogWrapperUmrealmserviceLogDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Note: The date/time format of the Integration Server wrapper.log is the same as the date/time format of the Universal Messaging UMRealmService.log, so combining it into one.
 //
 // ===
 //
 // Overview: input ( given block date/time 1 ) -> output sorted canonical format YYYY-MM-DD hh:mm:ss ( block date/time 2 )
 //
 // ===
 //
 // Description: Convert a block of (already earlier extracted, existing) wrapper.log date/time first to a block of canonicl log date/time, then sort that canonical log block chronologically (because now converted to YYYY-MM-DD format, so sorting correctly out of the box is possible).
 //
 // ===
 //
 // Use case: You want to sort a list of wrapper log files in chronological order, e.g. for merging purposes
 //
 // ===
 //
 // Method: Get a block of wrapper.log date/time, optionally put it somewhere, run the program, then the wrapper.log date/time are (searched using a regular expression) converted to canonical log date/time and chronologically sorted.
 //
 // ===
 //
 // Format: wrapper.log date/time format (first 3 characters for the dayname, then 3 characters for the monthname, then 2 digits for the monthnumber, then 2 digits for the hour, a colon, then 2 digits for the minutes, a colon, then 2 digits for the seconds, then 3 or 4 characters for the timezone, then 4 digits for the year.
 //
 //  | 2021-04-30 15:09:55 |
 //
 // to
 //
 // Canonical date/time format in log
 //
 //   2021-04-30 15:09:55
 //
 // ===
 //
 // Input:
 //
 /*
  INFO   | jvm 1    | 2021/05/19 16:33:16 | HTTP Handler 127.0.0.1, READ: TLSv1.2 Handshake, length = 70
  INFO   | jvm 1    | 2021/05/19 16:33:16 | check handshake state: client_key_exchange[16]
  INFO   | jvm 1    | 2021/05/19 16:33:16 | update handshake state: client_key_exchange[16]
  INFO   | jvm 1    | 2021/05/19 16:33:16 | upcoming handshake states: certificate_verify[15](optional)
  INFO   | jvm 1    | 2021/05/19 16:33:16 | upcoming handshake states: client change_cipher_spec[-1]
  INFO   | jvm 1    | 2021/05/19 16:33:16 | upcoming handshake states: client finished[20]
  INFO   | jvm 1    | 2021/05/19 16:33:16 | upcoming handshake states: server change_cipher_spec[-1]
  INFO   | jvm 1    | 2021/05/19 16:33:16 | upcoming handshake states: server finished[20]
 */
 //
 // Output:
 //
 /*
2021-05-19 16:33:16 Integration_Server: wrapper.log:   INFO   | jvm 1    | 2021/05/19 16:33:16 | HTTP Handler 127.0.0.1, READ: TLSv1.2 Handshake, length = 70
2021-05-19 16:33:16 Integration_Server: wrapper.log:   INFO   | jvm 1    | 2021/05/19 16:33:16 | check handshake state: client_key_exchange[16]
2021-05-19 16:33:16 Integration_Server: wrapper.log:   INFO   | jvm 1    | 2021/05/19 16:33:16 | update handshake state: client_key_exchange[16]
2021-05-19 16:33:16 Integration_Server: wrapper.log:   INFO   | jvm 1    | 2021/05/19 16:33:16 | upcoming handshake states: certificate_verify[15](optional)
2021-05-19 16:33:16 Integration_Server: wrapper.log:   INFO   | jvm 1    | 2021/05/19 16:33:16 | upcoming handshake states: client change_cipher_spec[-1]
2021-05-19 16:33:16 Integration_Server: wrapper.log:   INFO   | jvm 1    | 2021/05/19 16:33:16 | upcoming handshake states: client finished[20]
2021-05-19 16:33:16 Integration_Server: wrapper.log:   INFO   | jvm 1    | 2021/05/19 16:33:16 | upcoming handshake states: server change_cipher_spec[-1]
2021-05-19 16:33:16 Integration_Server: wrapper.log:   INFO   | jvm 1    | 2021/05/19 16:33:16 | upcoming handshake states: server finished[20]
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // format input: YYYY/MM/DD HH:MM:SS (e.g. 2021/05/19 16:33:16)
  //
  s1 = GetFoundText( 1 ) // year, e.g. 2021 (=YYYY)
  s2 = GetFoundText( 2 ) // month number (e.g. 05 (=MM)
  s3 = GetFoundText( 3 ) // day number in the month, e.g. 19 (=DD)
  s4 = GetFoundText( 4 ) // time (=hh:mm:ss, 05:37:22)
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s3 ), Val( s2 ), Val( s1 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s1, "-", s2, "-", s3, " ", s4 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: broker: diaglog: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.4</version> <version control></version control> (filenamemacro=getblcfz.s) [<Program>] [<Research>] [kn, ri, fr, 18-03-2022 15:22:20]
INTEGER PROC FNBlockGetLogFileLogBrokerDiaglogOraclealertlogDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogBrokerDiaglogJobSoftwareAgS()
 // e.g.  STRING s2[255] = "Broker: diag.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: merge: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogBrokerDiaglogOraclealertlogDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 Thu May  7 12:07:19 2020 ASSERT: In function "void RemoteBroker::M1_events(Args&, unsigned int, int&, RequestEnv&)"(), file "rbroker.cc":3178, non-fatal check (false) fails, with message:
 events aligned, alignment: 1
 0x7604d3 0x75ff71 0x759488 0x431b59 0x5902cc 0x53a5df 0x53ae80 0x53cd32 0x619511 0x61bc52 0x608888 0x6089c1 0x763ac8 0x7f6972738dd5 0x7f6971836ead
 Sat May 23 16:30:10 2020 ASSERT: In function "virtual int NoOrderUnackdMgr::doAck(unsigned int, rseqn_t, Queue::QueueCursor&, RequestEnv&, bool)"(), file "ackmgr.cc":295, non-fatal check (rc) fails, with message:
 [69255] cursor reset, rseqn=870644
 0x7604d3 0x75ff71 0x759488 0x431b59 0x440fcf 0x442d05 0x424e94 0x4a79b4 0x551e5a 0x5640ed 0x547d16 0x55aceb 0x6199be 0x61c497 0x608888 0x6089c1 0x763ac8 0x7f18a17feea5 0x7f18a08fc8cd
 Sun May 24 05:46:02 2020 ASSERT: In function "virtual int NoOrderUnackdMgr::doAck(unsigned int, rseqn_t, Queue::QueueCursor&, RequestEnv&, bool)"(), file "ackmgr.cc":295, non-fatal check (rc) fails, with message:
 [69385] cursor reset, rseqn=698151
 0x7604d3 0x75ff71 0x759488 0x431b59 0x440fcf 0x442d05 0x424e94 0x4a79b4 0x551e5a 0x5640ed 0x547d16 0x55aceb 0x6199be 0x61c497 0x608888 0x6089c1 0x763ac8 0x7f18a17feea5 0x7f18a08fc8cd
 Mon May 25 04:38:09 2020 ASSERT: In function "virtual int NoOrderUnackdMgr::doAck(unsigned int, rseqn_t, Queue::QueueCursor&, RequestEnv&, bool)"(), file "ackmgr.cc":295, non-fatal check (rc) fails, with message:
 [69385] cursor reset, rseqn=1014840
 0x7604d3 0x75ff71 0x759488 0x431b59 0x440fcf 0x442d05 0x424e94 0x4a79b4 0x551e5a 0x5640ed 0x547d16 0x55aceb 0x6199be 0x61c497 0x608888 0x6089c1 0x763ac8 0x7f18a17feea5 0x7f18a08fc8cd
 Wed May 27 07:03:35 2020 ASSERT: In function "virtual int NoOrderUnackdMgr::doAck(unsigned int, rseqn_t, Queue::QueueCursor&, RequestEnv&, bool)"(), file "ackmgr.cc":295, non-fatal check (rc) fails, with message:
 [69385] cursor reset, rseqn=2376991
 0x7604d3 0x75ff71 0x759488 0x431b59 0x440fcf 0x442d05 0x424e94 0x4a79b4 0x551e5a 0x5640ed 0x547d16 0x55aceb 0x6199be 0x61c497 0x608888 0x6089c1 0x763ac8 0x7f18a17feea5 0x7f18a08fc8cd
 Tue Jan 21 10:08:51 2020 ASSERT: In function "void RemoteBroker::M1_events(Args&, unsigned int, int&, RequestEnv&)"(), file "rbroker.cc":3178, non-fatal check (false) fails, with message:
 events aligned, alignment: 1
 0x7604d3 0x75ff71 0x759488 0x431b59 0x5902cc 0x53a5df 0x53ae80 0x53cd32 0x619511 0x61bc52 0x608888 0x6089c1 0x763ac8 0x7fe3988fcdd5 0x7fe3979faead
 Fri Apr 10 05:36:03 2020 ASSERT: In function "int EventType::_set_infosets(Args&, int, int, int, char*&, RequestEnv&)"(), file "eventtype.cc":1596, non-fatal check (strncmp(argv[arg], name, namelen) != 0) fails, with message:
 Attempting to set infoset entry is with different name in event type wm::is::Adapter::error
 0x7604d3 0x75ff71 0x759488 0x431b59 0x4eddd2 0x4ee8e2 0x560e67 0x5631f0 0x553662 0x55acae 0x6199be 0x61c497 0x608888 0x6089c1 0x763ac8 0x7fe3988fcdd5 0x7fe3979faead
 Fri Apr 10 05:54:33 2020 last message repeated 2 time(s)
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
 2020-05-07 12:07:19 Broker: diag.log:  Thu May  7 12:07:19 2020 ASSERT: In function "void RemoteBroker::M1_events(Args&, unsigned int, int&, RequestEnv&)"(), file "rbroker.cc":3178, non-fatal check (false) fails, with message:
 2020-05-23 16:30:10 Broker: diag.log:  Sat May 23 16:30:10 2020 ASSERT: In function "virtual int NoOrderUnackdMgr::doAck(unsigned int, rseqn_t, Queue::QueueCursor&, RequestEnv&, bool)"(), file "ackmgr.cc":295, non-fatal check (rc) fails, with message:
 2020-05-24 05:46:02 Broker: diag.log:  Sun May 24 05:46:02 2020 ASSERT: In function "virtual int NoOrderUnackdMgr::doAck(unsigned int, rseqn_t, Queue::QueueCursor&, RequestEnv&, bool)"(), file "ackmgr.cc":295, non-fatal check (rc) fails, with message:
 2020-05-25 04:38:09 Broker: diag.log:  Mon May 25 04:38:09 2020 ASSERT: In function "virtual int NoOrderUnackdMgr::doAck(unsigned int, rseqn_t, Queue::QueueCursor&, RequestEnv&, bool)"(), file "ackmgr.cc":295, non-fatal check (rc) fails, with message:
 2020-05-27 07:03:35 Broker: diag.log:  Wed May 27 07:03:35 2020 ASSERT: In function "virtual int NoOrderUnackdMgr::doAck(unsigned int, rseqn_t, Queue::QueueCursor&, RequestEnv&, bool)"(), file "ackmgr.cc":295, non-fatal check (rc) fails, with message:
 2020-01-21 10:08:51 Broker: diag.log:  Tue Jan 21 10:08:51 2020 ASSERT: In function "void RemoteBroker::M1_events(Args&, unsigned int, int&, RequestEnv&)"(), file "rbroker.cc":3178, non-fatal check (false) fails, with message:
 2020-04-10 05:36:03 Broker: diag.log:  Fri Apr 10 05:36:03 2020 ASSERT: In function "int EventType::_set_infosets(Args&, int, int, int, char*&, RequestEnv&)"(), file "eventtype.cc":1596, non-fatal check (strncmp(argv[arg], name, namelen) != 0) fails, with message:
 2020-04-10 05:54:33 Broker: diag.log:  Fri Apr 10 05:54:33 2020 last message repeated 2 time(s)
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // format input: WWW MMM DD HH:MM:SS YYYY (e.g. Thu May  7 12:07:19 2020)
  //
  s1 = GetFoundText( 1 ) // month (Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec) (=MMM)
  s2 = GetFoundText( 2 ) // day number in the month, e.g. 27 (=DD?)
  s3 = GetFoundText( 3 ) // time, e.g. 05:37:22 (=HH:MM:SS)
  s4 = GetFoundText( 4 ) // year, e.g. 2020, 2021, 2022, ... (=YYYY)
  //
  CASE s1
   //
   WHEN "Jan"
    s1 = "01"
   WHEN "Feb"
    s1 = "02"
   WHEN "Mar"
    s1 = "03"
   WHEN "Apr"
    s1 = "04"
   WHEN "May"
    s1 = "05"
   WHEN "Jun"
    s1 = "06"
   WHEN "Jul"
    s1 = "07"
   WHEN "Aug"
    s1 = "08"
   WHEN "Sep"
    s1 = "09"
   WHEN "Oct"
    s1 = "10"
   WHEN "Nov"
    s1 = "11"
   WHEN "Dec"
    s1 = "12"
    //
   OTHERWISE
    //
    Warn( "FNBlockSortChangeLogDateTime_BrokerDiagLogOraclealertlogToFormatCanonicalB(", " ", "case", " ", ":", " ", s1, ": not known" )
    //
  ENDCASE
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s2 ), Val( s1 ), Val( s4 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s4, "-", s1, "-", Format( s2 : 2 : "0" ), " ", s3 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: wireshark: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.4</version> <version control></version control> (filenamemacro=getblcfa.s) [<Program>] [<Research>] [kn, ri, tu, 22-03-2022 23:09:31]
INTEGER PROC FNBlockGetLogFileLogWiresharkDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogWiresharkJobSoftwareAgS()
 // e.g.  STRING s2[255] = "Network_Wireshark_Export: log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: merge: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogWiresharkDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 No.     Time                          Source                Destination           Protocol Length Info
       1 2022-03-22 23:19:10,706033    192.168.86.113        255.255.255.255       UDP      230    49156 → 6667 Len=188
 Frame 1: 230 bytes on wire (1840 bits), 230 bytes captured (1840 bits) on interface \Device\NPF_{932E8DCB-03CE-4156-8498-C53BE8A1F998}, id 0
 Ethernet II, Src: Espressi_e8:d2:88 (68:c6:3a:e8:d2:88), Dst: Broadcast (ff:ff:ff:ff:ff:ff)
 Internet Protocol Version 4, Src: 192.168.86.113, Dst: 255.255.255.255
 User Datagram Protocol, Src Port: 49156, Dst Port: 6667
 Data (188 bytes)
 0000  00 00 55 aa 00 00 00 00 00 00 00 13 00 00 00 ac   ..U.............
 0010  00 00 00 00 f4 ac 6f d3 f5 e5 16 01 43 0e e9 7c   ......o.....C..|
 0020  fe 73 6a 90 c0 ea 7e ca c4 3a 62 da 29 88 45 15   .sj...~..:b.).E.
 0030  dc d2 8a 60 52 22 ce 50 d2 7a 3f 0e 1b d4 77 cc   ...`R".P.z?...w.
 0040  ea 5f e1 9a a6 67 7e 42 d9 08 16 11 dd 66 3d 9a   ._...g~B.....f=.
 0050  53 f5 be c2 5c 90 75 65 b3 23 a3 46 d0 de 78 c2   S...\.ue.#.F..x.
 0060  2f 1f da ba 1a e7 c6 13 c2 ca e0 04 e5 4a 47 45   /............JGE
 0070  61 36 77 14 37 9e 7d 68 a0 24 56 26 9f 46 16 38   a6w.7.}h.$V&.F.8
 0080  8e 2a a0 4e 8f e0 28 47 20 ce 69 ea c4 0a 6b f1   .*.N..(G .i...k.
 0090  2a 67 6a 0d 0f 85 2c 0c f0 80 ba 37 53 36 11 c7   *gj...,....7S6..
 00a0  01 64 56 f4 38 43 63 dc d0 f0 70 5a e4 ca c5 95   .dV.8Cc...pZ....
 00b0  bb f4 96 25 b7 00 4e b6 00 00 aa 55               ...%..N....U
 No.     Time                          Source                Destination           Protocol Length Info
       2 2022-03-22 23:19:10,706374    fe80::16c1:4eff:fe0b:6fec ff02::c               SSDP     176    M-SEARCH * HTTP/1.1
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
 2022-03-22 23:19:10 Network_Wireshark_Export: log:       1 2022-03-22 23:19:10,706033    192.168.86.113        255.255.255.255       UDP      230    49156 → 6667 Len=188
 2022-03-22 23:19:10 Network_Wireshark_Export: log:       2 2022-03-22 23:19:10,706374    fe80::16c1:4eff:fe0b:6fec ff02::c               SSDP     176    M-SEARCH * HTTP/1.1
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // Example: 2022-03-22 12:37:52,833319 / Format: YYYY-MM:DD HH:MM:SS,ssssss / Order: s1 s2 s3 s4
  //
  s1 = GetFoundText( 1 ) // year: ..., 2020, 2021, ... (=YYYY)
  s2 = GetFoundText( 2 ) // month: 01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 11, 12 (=MM)
  s3 = GetFoundText( 3 ) // day: 01, 02, ..., 31 (=DD)
  s4 = GetFoundText( 4 ) // time (=hh:mm:ss)
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s3 ), Val( s2 ), Val( s1 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s1, "-", s2, "-", s3, " ", s4 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: apacheaccesslog: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.8</version> <version control></version control> (filenamemacro=getblcfg.s) [<Program>] [<Research>] [kn, ri, we, 23-03-2022 00:25:22]
INTEGER PROC FNBlockGetLogFileLogApacheaccesslogHttplogDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogApacheaccesslogJobSoftwareAgS()
 // e.g.  STRING s2[255] = "Apache: access.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: merge: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogApacheaccesslogHttplogDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 Example: [06/Feb/2011:15:53:46 +0100]; Format: DD/Mmm/YYYY:HH:MM:SS; Order: s3 s2 s1 s4
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
Sun 2011-02-06 15:53:46 Apache: access.log0:  Example: [06/Feb/2011:15:53:46 +0100]; Format: DD/Mmm/YYYY:HH:MM:SS; Order: s3 s2 s1 s4
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // Example: [06/Feb/2011:15:53:46 +0100] / Format: DD/Mmm/YYYY:HH:MM:SS / Order: s3 s2 s1 s4)
  //
  s1 = GetFoundText( 1 ) // day number in the month, e.g. 27 (=DD)
  s2 = GetFoundText( 2 ) // month name, e.g. "May" (=MM)
  s3 = GetFoundText( 3 ) // year, e.g. 2021 (=YYYY)
  s4 = GetFoundText( 4 ) // time (HH:MM:SS)
  //
  CASE s2
   //
   WHEN "Jan"
    s2 = "01"
   WHEN "Feb"
    s2 = "02"
   WHEN "Mar"
    s2 = "03"
   WHEN "Apr"
    s2 = "04"
   WHEN "May"
    s2 = "05"
   WHEN "Jun"
    s2 = "06"
   WHEN "Jul"
    s2 = "07"
   WHEN "Aug"
    s2 = "08"
   WHEN "Sep"
    s2 = "09"
   WHEN "Oct"
    s2 = "10"
   WHEN "Nov"
    s2 = "11"
   WHEN "Dec"
    s2 = "12"
    //
   OTHERWISE
    //
    Warn( "FNBlockGetLogFileLogApacheaccesslogHttplogDateTimeAllToBufferCanonicalFrontB(", " ", "case", " ", ":", " ", s1, ": not known" )
    //
  ENDCASE
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s1 ), Val( s2 ), Val( s3 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s3, "-", s2, "-", s1, " ", s4 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: apacheerrorlog: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.4</version> <version control></version control> (filenamemacro=getblcff.s) [<Program>] [<Research>] [kn, ri, we, 23-03-2022 00:19:37]
INTEGER PROC FNBlockGetLogFileLogApacheerrorlogDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogApacheerrorlogJobSoftwareAgS()
 // e.g.  STRING s2[255] = "Apache: error.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: merge: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogApacheerrorlogDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 Example: [Sat Apr 21 01:30:01 2012]; Format: Mmm DD HH:MM:SS YYYY; Order: s4 s1 s2 s3
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
 2012-04-21 01:30:01 Apache: error.log: Example: [Sat Apr 21 01:30:01 2012] / Format: Mmm DD HH:MM:SS YYYY / Order: s4 s1 s2 s3
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // Example: [Sat Apr 21 01:30:01 2012] / Format: Mmm DD HH:MM:SS YYYY / Order: s4 s1 s2 s3
  //
  s1 = GetFoundText( 1 ) // month name, e.g. "May" (=MM)
  s2 = GetFoundText( 2 ) // day number in the month, e.g. 27 (=DD)
  s3 = GetFoundText( 3 ) // time (HH:MM:SS)
  s4 = GetFoundText( 4 ) // year, e.g. 2021 (=YYYY)
  //
  CASE s1
   //
   WHEN "Jan"
    s1 = "01"
   WHEN "Feb"
    s1 = "02"
   WHEN "Mar"
    s1 = "03"
   WHEN "Apr"
    s1 = "04"
   WHEN "May"
    s1 = "05"
   WHEN "Jun"
    s1 = "06"
   WHEN "Jul"
    s1 = "07"
   WHEN "Aug"
    s1 = "08"
   WHEN "Sep"
    s1 = "09"
   WHEN "Oct"
    s1 = "10"
   WHEN "Nov"
    s1 = "11"
   WHEN "Dec"
    s1 = "12"
    //
   OTHERWISE
    //
    Warn( "FNBlockGetLogFileLogApacheerrorlogDateTimeAllToBufferCanonicalFrontB(", " ", "case", " ", ":", " ", s1, ": not known" )
    //
  ENDCASE
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s2 ), Val( s1 ), Val( s4 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s4, "-", s1, "-", s2, " ", s3 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: tomcatcatalinalog: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=getblcfd.s) [<Program>] [<Research>] [kn, ri, tu, 22-03-2022 23:59:23]
INTEGER PROC FNBlockGetLogFileLogTomcatcatalinalogDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogTomcatcatalinalogJobSoftwareAgS()
 // e.g.  STRING s2[255] = "Tomcat: catalina.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: merge: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogTomcatcatalinalogDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 Example: Sep 12, 2010 12:35:05 AM; Format: Mmm DD, YYYY HH:MM:SS [{AM}|{PM}]; Order: s3 s1 s2 s4
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
 2010-09-12 12-58-00 Tomcat: catalina.log: / Example: Sep 12, 2010 12:58:01 AM / Format: Mmm DD, YYYY HH:MM:SS [{AM}|{PM}] / Order: s3 s1 s2 s4
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 STRING s6[255] = ""
 STRING s7[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // Example: Oct 11, 2010 2:52:47 PM / Format: Mmm DD, YYYY HH:MM:SS [{AM}|{PM}] / Order: s3 s1 s2 s4)
  //
  s1 = GetFoundText( 1 ) // month name, e.g. "May" (=MM)
  s2 = GetFoundText( 2 ) // day number in the month, e.g. 27 (=DD)
  s3 = GetFoundText( 3 ) // year, e.g. 2021 (=YYYY)
  s4 = GetFoundText( 4 ) // time (HH)
  s5 = GetFoundText( 5 ) // time (MM)
  s6 = GetFoundText( 6 ) // time (SS)
  //
  CASE s1
   //
   WHEN "Jan"
    s1 = "01"
   WHEN "Feb"
    s1 = "02"
   WHEN "Mar"
    s1 = "03"
   WHEN "Apr"
    s1 = "04"
   WHEN "May"
    s1 = "05"
   WHEN "Jun"
    s1 = "06"
   WHEN "Jul"
    s1 = "07"
   WHEN "Aug"
    s1 = "08"
   WHEN "Sep"
    s1 = "09"
   WHEN "Oct"
    s1 = "10"
   WHEN "Nov"
    s1 = "11"
   WHEN "Dec"
    s1 = "12"
    //
   OTHERWISE
    //
    Warn( "FNBlockGetLogFileLogTomcatcatalinalogDateTimeAllToBufferCanonicalFrontB(", " ", "case", " ", ":", " ", s1, ": not known" )
    //
  ENDCASE
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s7 = FNStringGetDateWeekDayNameS( Val( s2 ), Val( s1 ), Val( s3 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s7, 1 ) ), SubStr( s7, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s3, "-", s1, "-", Format( s2 : 2 : "0" ), " ", Format( s4 : 2 : "0" ), ":", Format( s5 : 2 : "0" ), ":", Format( s6 : 2 : "0" ) )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: tomcatlocalhostlog: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.2</version> <version control></version control> (filenamemacro=getblcfc.s) [<Program>] [<Research>] [kn, ri, tu, 22-03-2022 23:55:44]
INTEGER PROC FNBlockGetLogFileLogTomcatlocalhostlogDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogTomcatlocalhostlogJobSoftwareAgS()
 // e.g.  STRING s2[255] = "Tomcat: localhost.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: merge: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogTomcatlocalhostlogDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 Example: Sep 12, 2010 12:58:01 AM; Format: Mmm DD, YYYY HH:MM:SS [{AM}|{PM}]; Order: s3 s1 s2 s4
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
 2010-09-12 12-58-00 Tomcat: localhost.log: / Example: Sep 12, 2010 12:58:01 AM / Format: Mmm DD, YYYY HH:MM:SS [{AM}|{PM}] / Order: s3 s1 s2 s4
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 STRING s6[255] = ""
 STRING s7[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // Example: Oct 11, 2010 2:52:47 PM / Format: Mmm DD, YYYY HH:MM:SS [{AM}|{PM}] / Order: s3 s1 s2 s4
  //
  s1 = GetFoundText( 1 ) // month name, e.g. "May" (=MM)
  s2 = GetFoundText( 2 ) // day number in the month, e.g. 27 (=DD)
  s3 = GetFoundText( 3 ) // year, e.g. 2021 (=YYYY)
  s4 = GetFoundText( 4 ) // time (HH)
  s5 = GetFoundText( 5 ) // time (MM)
  s6 = GetFoundText( 6 ) // time (SS)
  //
  CASE s1
   //
   WHEN "Jan"
    s1 = "01"
   WHEN "Feb"
    s1 = "02"
   WHEN "Mar"
    s1 = "03"
   WHEN "Apr"
    s1 = "04"
   WHEN "May"
    s1 = "05"
   WHEN "Jun"
    s1 = "06"
   WHEN "Jul"
    s1 = "07"
   WHEN "Aug"
    s1 = "08"
   WHEN "Sep"
    s1 = "09"
   WHEN "Oct"
    s1 = "10"
   WHEN "Nov"
    s1 = "11"
   WHEN "Dec"
    s1 = "12"
    //
   OTHERWISE
    //
    Warn( "FNBlockGetLogFileLogTomcatlocalhostlogDateTimeAllToBufferCanonicalFrontB(", " ", "case", " ", ":", " ", s1, ": not known" )
    //
  ENDCASE
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s7 = FNStringGetDateWeekDayNameS( Val( s2 ), Val( s1 ), Val( s3 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s7, 1 ) ), SubStr( s7, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s3, "-", s1, "-", Format( s2 : 2 : "0" ), " ", Format( s4 : 2 : "0" ), ":", Format( s5 : 2 : "0" ), ":", Format( s6 : 2 : "0" ) )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: tomcatmanagerlog: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.3</version> <version control></version control> (filenamemacro=getblcfb.s) [<Program>] [<Research>] [kn, ri, tu, 22-03-2022 23:44:48]
INTEGER PROC FNBlockGetLogFileLogTomcatmanagerlogDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogTomcatmanagerlogJobSoftwareAgS()
 // e.g.  STRING s2[255] = "Tomcat: manager.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: merge: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogTomcatmanagerlogDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 Example: Oct 11, 2010 2:52:47 PM; Format: Mmm DD, YYYY HH:MM:SS [{AM}|{PM}]; Order: s3 s1 s2 s4
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
 2010-10-11 02-52-04 Tomcat: manager.log: Example: Oct 11, 2010 2:52:47 PM / Format: Mmm DD, YYYY HH:MM:SS [{AM}|{PM}] / Order: s3 s1 s2 s4
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 STRING s6[255] = ""
 STRING s7[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // Example: Oct 11, 2010 2:52:47 PM / Format: Mmm DD, YYYY HH:MM:SS [{AM}|{PM}] / Order: s3 s1 s2 s4
  //
  s1 = GetFoundText( 1 ) // month name, e.g. "May" (=MM)
  s2 = GetFoundText( 2 ) // day number in the month, e.g. 27 (=DD)
  s3 = GetFoundText( 3 ) // year, e.g. 2021 (=YYYY)
  s4 = GetFoundText( 4 ) // time (HH)
  s5 = GetFoundText( 5 ) // time (MM)
  s6 = GetFoundText( 6 ) // time (SS)
  //
  CASE s1
   //
   WHEN "Jan"
    s1 = "01"
   WHEN "Feb"
    s1 = "02"
   WHEN "Mar"
    s1 = "03"
   WHEN "Apr"
    s1 = "04"
   WHEN "May"
    s1 = "05"
   WHEN "Jun"
    s1 = "06"
   WHEN "Jul"
    s1 = "07"
   WHEN "Aug"
    s1 = "08"
   WHEN "Sep"
    s1 = "09"
   WHEN "Oct"
    s1 = "10"
   WHEN "Nov"
    s1 = "11"
   WHEN "Dec"
    s1 = "12"
    //
   OTHERWISE
    //
    Warn( "FNBlockGetLogFileLogTomcatmanagerlogDateTimeAllToBufferCanonicalFrontB(", " ", "case", " ", ":", " ", s1, ": not known" )
    //
  ENDCASE
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s7 = FNStringGetDateWeekDayNameS( Val( s2 ), Val( s1 ), Val( s3 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s7, 1 ) ), SubStr( s7, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s3, "-", s1, "-", Format( s2 : 2 : "0" ), " ", Format( s4 : 2 : "0" ), ":", Format( s5 : 2 : "0" ), ":", Format( s6 : 2 : "0" ) )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: brokerlogmsgs: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.4</version> <version control></version control> (filenamemacro=getblcfh.s) [<Program>] [<Research>] [kn, ri, su, 27-03-2022 20:02:08]
INTEGER PROC FNBlockGetLogFileLogBrokerlogmsgsDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogBrokerlogmsgsJobSoftwareAgS()
 // e.g.  // STRING s2[255] = "Broker: logmsgs.mon.log"
 // e.g.  STRING s2[255] = "Broker: logmsgs.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: merge: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogBrokerlogmsgsDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 2015-09-28 12:56:36 Info    1287 Failed to create audit log file. Audit logging will be disabled.
 2015-09-28 12:56:36 Info    1318 TTL Cleanup disabled.
 2015-09-28 12:56:36 Info    1324 FIPS mode initialization failed.
 2015-09-28 12:56:36 Info    1350 Broker Server's filter collation locale is {English_United  States.1252}
 2015-09-28 12:56:36 Alert   1331 Unable to initialize basic authentication module. Verify the contents of basic authentication config file.
 2015-09-28 12:56:36 Info    1333 Basic Authentication disabled.
 2015-09-28 12:56:36 Info    1344 Remote Broker Parallel channel disabled.
 2015-09-28 12:56:36 Info    1338 Streaming is disabled.
 2015-09-28 12:56:40 Info    1000 Broker Server ready, process id 2004   {Version 9.6.0.0.210 021114}
 2015-10-09 18:12:11 Info    1001 Broker Server exiting, process id 2004
 2015-10-10 19:57:01 Info    1287 Failed to create audit log file. Audit logging will be disabled.
 2015-10-10 19:57:01 Info    1318 TTL Cleanup disabled.
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
2015-09-28 12:56:36 Broker: logmsgs.log:  2015-09-28 12:56:36 Info    1287 Failed to create audit log file. Audit logging will be disabled.
2015-09-28 12:56:36 Broker: logmsgs.log:  2015-09-28 12:56:36 Info    1318 TTL Cleanup disabled.
2015-09-28 12:56:36 Broker: logmsgs.log:  2015-09-28 12:56:36 Info    1324 FIPS mode initialization failed.
2015-09-28 12:56:36 Broker: logmsgs.log:  2015-09-28 12:56:36 Info    1350 Broker Server's filter collation locale is {English_United  States.1252}
2015-09-28 12:56:36 Broker: logmsgs.log:  2015-09-28 12:56:36 Alert   1331 Unable to initialize basic authentication module. Verify the contents of basic authentication config file.
2015-09-28 12:56:36 Broker: logmsgs.log:  2015-09-28 12:56:36 Info    1333 Basic Authentication disabled.
2015-09-28 12:56:36 Broker: logmsgs.log:  2015-09-28 12:56:36 Info    1344 Remote Broker Parallel channel disabled.
2015-09-28 12:56:36 Broker: logmsgs.log:  2015-09-28 12:56:36 Info    1338 Streaming is disabled.
2015-09-28 12:56:40 Broker: logmsgs.log:  2015-09-28 12:56:40 Info    1000 Broker Server ready, process id 2004   {Version 9.6.0.0.210 021114}
2015-10-09 18:12:11 Broker: logmsgs.log:  2015-10-09 18:12:11 Info    1001 Broker Server exiting, process id 2004
2015-10-10 19:57:01 Broker: logmsgs.log:  2015-10-10 19:57:01 Info    1287 Failed to create audit log file. Audit logging will be disabled.
2015-10-10 19:57:01 Broker: logmsgs.log:  2015-10-10 19:57:01 Info    1318 TTL Cleanup disabled.
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // format input: YYYY-MM:DD HH:MM:SS, s1 s2 s3 s4
  //
  s1 = GetFoundText( 1 ) // year, e.g. 2021 (=YYYY)
  s2 = GetFoundText( 2 ) // month number, e.g. 03 (=MM)
  s3 = GetFoundText( 3 ) // day number in the month, e.g. 27 (=DD)
  s4 = GetFoundText( 4 ) // time (=hh:mm:ss, 05:37:22)
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s3 ), Val( s2 ), Val( s1 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s1, "-", s2, "-", s3, " ", s4 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: jbossserverlog: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.4</version> <version control></version control> (filenamemacro=getblcfe.s) [<Program>] [<Research>] [kn, ri, we, 23-03-2022 00:03:10]
INTEGER PROC FNBlockGetLogFileLogJbossserverlogDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogJbossserverlogJobSoftwareAgS()
 // e.g.  STRING s2[255] = "JBoss: server.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: merge: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogJbossserverlogDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 Example: 2016-03-16 14:32:01,627; Format: YYYY-MM-DD HH:MM:SS,sss; Order: s1 s2 s3 s4
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
 2014-06-16 11:22:09 JBoss: server.log: / Example: 2014-06-16 11:22:09,460 / Format: YYYY-MM-DD HH:MM:SS,sss / Order: s1 s2 s3 s4
--- cut here: end ----------------------------------------------------
 /*
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // Example: 2014-06-16 11:22:09,460 / Format: YYYY-MM-DD HH:MM:SS,sss / Order s1 s2 s3 s4
  //
  s1 = GetFoundText( 1 ) // year: ..., 2020, 2021, ... (=YYYY)
  s2 = GetFoundText( 2 ) // month: 01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 11, 12 (=MM)
  s3 = GetFoundText( 3 ) // day: 01, 02, ..., 31 (=DD)
  s4 = GetFoundText( 4 ) // time (=hh:mm:ss)
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s3 ), Val( s2 ), Val( s1 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s1, "-", s2, "-", s3, " ", s4 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.3</version> <version control></version control> (filenamemacro=timedacf.s) [<Program>] [<Research>] [kn, ri, su, 03-04-2022 20:38:50]
INTEGER PROC FNBlockGetLogFileLogIbmdb2db2diaglogDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogIbmdb2db2diaglogJobSoftwareAgS()
 // e.g.  STRING s2[255] = "IBM_DB2: db2diag.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: merge: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogIbmdb2db2diaglogDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 Example: 2016-02-15-19.31.36.114000; Format: YYYY-MM-DD-HH.mm.SS.ssssss; Order: s1 s2 s3 s4
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
2016-02-15 19:31:36 IBM_DB2: db2diag.log0:  Example: 2016-02-15-19.31.36.114000; Format: YYYY-MM-DD-HH.mm.SS.ssssss; Order: s1 s2 s3 s4
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // Example: [Sat Apr 21 01:30:01 2012] / Format: Mmm DD HH:MM:SS YYYY / Order: s4 s1 s2 s3
  //
  s1 = GetFoundText( 1 ) // year, e.g. 2021 (=YYYY)
  s2 = GetFoundText( 2 ) // month name, e.g. "May" (=MM)
  s3 = GetFoundText( 3 ) // day number in the month, e.g. 27 (=DD)
  s4 = GetFoundText( 4 ) // time (HH.MM.SS)
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  s4 = StrReplace( ".", s4, ":", "" ) // tags {} are not possible
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s3 ), Val( s2 ), Val( s1 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s1, "-", s2, "-", s3, " ", s4 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: jvmgarbagecollectiongclog: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.2</version> <version control></version control> (filenamemacro=getblcfk.s) [<Program>] [<Research>] [kn, ri, mo, 04-04-2022 01:31:09]
INTEGER PROC FNBlockGetLogFileLogJvmgarbagecollectiongclogDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogJvmgarbagecollectiongclogJobSoftwareAgS()
 // e.g.  STRING s2[255] = "JVM_Garbage_Collection; gc.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: merge: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogJvmgarbagecollectiongclogDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 Example: 2014-11-18T16:39:37.728-0800; Format: YYYY-MM-DDTHH:mm:SS.sss-ZZZZ; Order: s1 s2 s3 s4; "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[T ]{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
2014-11-18 16:39:37 JVM_Garbage_Collection; gc.log0:  Example: 2014-11-18T16:39:37.728-0800; Format: YYYY-MM-DDTHH:mm:SS.sss-ZZZZ; Order: s1 s2 s3 s4; "{[0-9][0-9][0-9][0-9]}-{[0-9][0-9]}-{[0-9][0-9]}[T ]{[0-9][0-9]:[0-9][0-9]:[0-9][0-9]}"
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  s1 = GetFoundText( 1 ) // year, e.g. 22 (=YY)
  s2 = GetFoundText( 2 ) // month name, e.g. 03 (=MM)
  s3 = GetFoundText( 3 ) // day number in the month, e.g. 27 (=DD)
  s4 = GetFoundText( 4 ) // time (HH:MM:SS)
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s3 ), Val( s2 ), Val( s1 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s1, "-", s2, "-", s3, " ", s4 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: microsoftsqlserversqllog: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=getblcfl.s) [<Program>] [<Research>] [kn, ri, mo, 09-05-2022 14:51:00]
INTEGER PROC FNBlockGetLogFileLogMicrosoftsqlserversqllogDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogMicrosoftsqlserversqllogJobSoftwareAgS()
 // e.g.  STRING s2[255] = "Microsoft_SQL_Server: sql.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: merge: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogMicrosoftsqlserversqllogDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 Example: 07/28/2012 19:41:03; Format: MM/DD/YYYY HH:mm:SS; Order: s3 s1 s2 s4
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
2012-07-28 19:41:03 Thu Microsoft_SQL_Server: sql.log0:  Example: 07/28/2012 19:41:03; Format: MM/DD/YYYY HH:mm:SS; Order: s3 s1 s2 s4
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  // format input: YYYY-MM-DD HH:MM:SS ZZZ?Z?Z? (e.g. 2022-03-18 00:50:00 CET)
  //
  s1 = GetFoundText( 1 ) // month number, e.g. 03 (=MM)
  s2 = GetFoundText( 2 ) // day number, e.g. 18 (=DD)
  s3 = GetFoundText( 3 ) // year, e.g. 2022 (=YYYY)
  s4 = GetFoundText( 4 ) // time (=hh:mm:ss, e.g. 00:50:00)
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s1 ), Val( s2 ), Val( s3 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s3, "-", s1, "-", s2, " ", s4 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: block: get: log: file: log: mysqlservererrlog: date: time: all: to: buffer: canonical: front <description></description> <version control></version control> <version>1.0.0.0.2</version> <version control></version control> (filenamemacro=getblcfj.s) [<Program>] [<Research>] [kn, ri, su, 03-04-2022 21:16:15]
INTEGER PROC FNBlockGetLogFileLogMysqlservererrlogDateTimeAllToBufferCanonicalFrontB( STRING searchS, STRING caseS, INTEGER indexI, INTEGER weekdayB, INTEGER bufferI )
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = FNStringGetFileLogMysqlservererrlogJobSoftwareAgS()
 // e.g.  STRING s2[255] = "MySQL_Server: err.log"
 // e.g.  STRING s3[255] = "0" // index
 // e.g.  STRING s4[255] = "1" // weekday
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default
 // e.g.  IF ( NOT ( Ask( "block: get: log: date: time: all: merge: to: buffer: canonical: front: searchS = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  //
 // e.g.  Message( FNBlockGetLogFileLogMysqlservererrlogDateTimeAllToBufferCanonicalFrontB( s1, s2, Val( s3 ), Val( s4 ), bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 Example: 190115 23:56:11; Format: YYMMDD HH:mm:SS; Order: s1 s2 s3 s4
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 STRING s3[255] = ""
 STRING s4[255] = ""
 STRING s5[255] = ""
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 Set( BREAK, ON )
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 // do use local seach only (not a "lg" search, or else you will continuously be checking in the same block, because at each start of the while loop, because of the 'g' you start again at the beginning of the block)
 //
 WHILE ( LFind( searchS, "lx" ) AND IsCursorInBlock() )
  //
  s1 = GetFoundText( 1 ) // year, e.g. 22 (=YY)
  s2 = GetFoundText( 2 ) // month name, e.g. 03 (=MM)
  s3 = GetFoundText( 3 ) // day number in the month, e.g. 27 (=DD)
  s4 = GetFoundText( 4 ) // time (HH:MM:SS)
  //
  PushPosition()
  PushBlock()
  UnMarkBlock()
  BegLine()
  MarkStream()
  EndLine()
  MarkStream()
  Copy()
  PopBlock()
  PopPosition()
  //
  PushPosition()
  PushBlock()
  GotoBufferId( bufferI )
  EndFile()
  //
  Paste()
  //
  BegLine()
  InsertText( Format( caseS, indexI, ":", " " ), _INSERT_ )
  //
  s1 = Format( "20", s1 ) // make a 4 digit year YYYY from the 2 digit year YY (20YY)
  //
  IF ( weekdayB )
   // order: day, month, year
   s5 = FNStringGetDateWeekDayNameS( Val( s3 ), Val( s2 ), Val( s1 ) )
   BegLine()
   InsertText( Format( Upper( LeftStr( s5, 1 ) ), SubStr( s5, 2, 2 ), " " ) ) // gives e.g. 'Sat ' after the standard date/timestamp
  ENDIF
  //
  // format output = YYYY-MM-DD hh:mm:ss
  //
  s = Format( s1, "-", s2, "-", s3, " ", s4 )
  //
  BegLine()
  InsertText( Format( Trim( s ), " " ) )
  //
  PopBlock()
  PopPosition()
  //
  // NextChar() // old [kn, ri, su, 20-03-2022 23:08:27]
  EndLine() // new (to avoid duplication of the line because more than 1 date/time found) [kn, ri, su, 20-03-2022 23:08:36]
  //
 ENDWHILE
 //
 PopPosition()
 PopBlock()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: file: run: 4: nt: alias: command: list: user <description></description> <version control></version control> <version>1.0.0.0.199</version> (filenamemacro=run4fira.s) [<Program>] [<Research>] [kn, ri, su, 01-03-2009 15:29:03]
PROC PROCFileRun4NtAliasCommandListUser( STRING s )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = FNStringGetInitializeNewStringS()
 // e.g.  INTEGER bufferI = 0
 // e.g.  INTEGER I = 0
 // e.g.  STRING fileNameS[255] = FNStringGetProgramAliasRunFilenameListS() // casealiasinputlist.txt
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  GotoBufferId( bufferI )
 // e.g.  InsertFile( fileNameS )
 // e.g.  // I = List( "alias command", 115 - 21 )
 // e.g.  I = List( "FILE: RUN: 4NT: ALIAS: COMMAND: LIST: USER", FNWindowGetScreenWidthI() )
 // e.g.  IF ( NOT ( I == 0 ) )
 // e.g.   s1 = SubStr( GetText( 1, 255 ), 1, 188 - 1 )
 // e.g.   s1 = Trim( s1 )
 // e.g.   // combobox (but switched off as this is quicker)
 // e.g.   // s1 = FNStringGetInputS( "file: run: 4nt: alias: s = ", s1 )
 // e.g.   IF FNKeyCheckPressEscapeB( s1 ) RETURN() ENDIF
 // e.g.   s1 = FNStringGetTagAngularRemoveWhileS( s1, "Please replace it by information to apply" )
 // e.g.   // do not move the runprmcn line, as it seems to work better [kn, vo, mo, 13-04-2015 19:57:52]
 // e.g.   PROCMacroRunPurgeParameter( "runprmcn", Format( FNStringGetMachineNameS(), ";", FNStringGetUserNameFirstS(), ";", FNStringGetUserNameLastS(), ";", FNStringGetPortS(), ";", "Run%3A+Alias%3A+" + s1 + "&submit01=Create" ) )
 // e.g.   PROCFileRun4NtAliasCommandListUser( s1 )
 // e.g.  ENDIF
 // e.g.  PopPosition()
 // e.g.  PushPosition()
 // e.g.  GotoBufferId( bufferI )
 // e.g.  AbandonFile( bufferI )
 // e.g.  PopPosition()
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 // e.g. <CTRL L> RepeatFind()
 //
 // PROCFileChangeEditProgramRunStringAdd( "run", "", Format( "(program: 4nt: alias: general:", " ", s, ")" ) )
 //
 // LDos( QuotePath( FNStringGetProgram4ntFilenameS() ), Format( "alias", " ", FNStringGetPathFileAlias4Dos4NtFilenameS(), " ", "&&", " ", s, " ", "&& exit && exit" ), _DONT_PROMPT_ )
 // LDos( FNStringGetProgram4ntFilenameS(), Format( "alias", " ", FNStringGetPathFileAlias4Dos4NtFilenameS(), " ", "&&", " ", s, " ", "&& exit && exit" ), _DONT_PROMPT_ )
 // LDos( FNStringGetProgram4ntFilenameS(), Format( "alias", " ", FNStringGetPathFileAlias4Dos4NtFilenameS(), " ", "&&", " ", s, " ", "&& exit" ), _DONT_PROMPT_ )
 // LDos( FNStringGetProgram4ntFilenameS(), Format( "alias", " ", "/L", " ", "&&", " ", "alias", " ", FNStringGetPathFileAlias4Dos4NtFilenameS(), " ", "&&", " ", s, " ", "&& exit" ), _DONT_PROMPT_ )
 // LDos( FNStringGetProgram4ntFilenameS(), Format( "alias", " ", FNStringGetPathFileAlias4Dos4NtFilenameS(), " ", "&&", " ", s, " ", "&& exit" ), _DONT_PROMPT_ ) // old [kn, ri, su, 25-12-2016 02:18:29]
 LDos( FNStringGetProgram4ntFilenameS(), Format( "alias", " ", FNStringGetPathFileAliasUnicode4Dos4NtFilenameS(), " ", "&&", " ", s, " ", "&& exit" ), _DONT_PROMPT_ ) // new [kn, ri, su, 25-12-2016 02:18:43]
 //
 // PROCListSaveHistoryUser( s ) // old [kn, ri, su, 10-06-2012 13:44:33]
 //
 Message( Format( s, " ", ": file: run: 4nt/4dos: alias: command: list: user" ) )
 //
 // do not enable this runprmcn line, as it is run in the run part of this macro [kn, vo, mo, 13-04-2015 19:57:46]
 // PROCMacroRunPurgeParameter( "runprmcn", Format( FNStringGetMachineNameS(), ";", FNStringGetUserNameFirstS(), ";", FNStringGetUserNameLastS(), ";", FNStringGetPortS(), ";", "Run%3A+Alias%3A+" + s + "&submit01=Create" ) )
 //
END

// library: math: get: error <description>indicate, via the returned number, that an error occurred</description> <version>1.0.0.0.3</version> <version control></version control> (filenamemacro=getmager.s) [<Program>] [<Research>] [kn, ri, th, 29-04-1999 21:19:56]
INTEGER PROC FNMathGetErrorI()
 // e.g. PROC Main()
 // e.g.  Message( FNMathGetErrorI() ) // gives e.g. -( 2^31 - 1 ) = -2147483647
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNMathGetIntegerMinimumAbsoluteI() )
 //
END

// library: block: get: line: longest <description></description> <version control></version control> <version>1.0.0.0.4</version> <version control></version control> (filenamemacro=getblllp.s) [<Program>] [<Research>] [kn, ri, mo, 14-03-2022 23:18:00]
INTEGER PROC FNBlockGetLineLongestI()
 // e.g. PROC Main()
 // e.g.  Message( FNBlockGetLineLongestI() ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 INTEGER Marking = Set( MARKING, Off ) // turn off marking (=do not show the highlighted marked block visually)
 //
 INTEGER maxLengthI = 0
 //
 INTEGER lastLineI = 0
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) RETURN( FNMathGetErrorI() ) ENDIF // return from the current procedure if no block is marked
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 lastLineI = Query( BlockEndLine )
 //
 maxLengthI = CurrLineLen()
 //
 WHILE ( ( Down() ) AND  ( CurrLine() <= lastLineI ) )
  //
  IF ( CurrLineLen() > maxLengthI )
   //
   maxLengthI = CurrLineLen()
   //
  ENDIF
  //
 ENDWHILE
 //
 PopBlock()
 PopPosition()
 //
 RETURN( maxLengthI )
 //
END

// library: block: change: line: longest: to: line: shorter <description></description> <version control></version control> <version>1.0.0.0.5</version> <version control></version control> (filenamemacro=chanbluu.s) [<Program>] [<Research>] [kn, ri, mo, 14-03-2022 23:33:04]
INTEGER PROC FNBlockChangeLineLongestToLineShorterB()
 // e.g. PROC Main()
 // e.g.  Message( FNBlockChangeLineLongestToLineShorterB() ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 INTEGER B = FALSE
 //
 INTEGER lastLineI = 0
 //
 IF ( NOT ( IsBlockInCurrFile() ) ) Warn( "Please mark a block" ) B = FALSE RETURN( B ) ENDIF // return from the current procedure if no block is marked
 //
 PushPosition()
 PushBlock()
 //
 GotoBlockBegin()
 //
 lastLineI = Query( BlockEndLine )
 //
 WHILE ( ( Down() ) AND  ( CurrLine() <= lastLineI ) )
  //
  IF ( CurrLineLen() > ( MAXLINELEN - 100 ) )
   //
   GotoColumn( MAXLINELEN - 100 )
   //
   LReplace( ".", "\n", "cnx1" ) // split the line in 2 parts starting from that position.
   //
  ENDIF
  //
 ENDWHILE
 //
 PopBlock()
 PopPosition()
 //
 RETURN( B )
 //
END

// library: string: get: date: week: day: name <description>see also Doomsday algorithm</description> <version>1.0.0.0.33</version> <version control></version control> (filenamemacro=getstwna.s) [<Program>] [<Research>] [kn, ri, th, 25-08-2011 02:26:09]
STRING PROC FNStringGetDateWeekDayNameS( INTEGER dayI, INTEGER monthI, INTEGER yearI )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = "24"
 // e.g.  STRING s2[255] = "8"
 // e.g.  STRING s3[255] = "2011"
 // e.g.  INTEGER I = 0
 // e.g.  IF NOT Ask( "string: get: date: week: name: day = ", s1, _FIND_HISTORY_ ) ENDIF
 // e.g.  IF NOT Ask( "string: get: date: week: name: month = ", s2, _FIND_HISTORY_ ) ENDIF
 // e.g.  IF NOT Ask( "string: get: date: week: name: year = ", s3, _FIND_HISTORY_ ) ENDIF
 // e.g.  Warn( s1, " ", s2, " ", s3, " gives ", FNStringGetDateWeekDayNameS( Val( s1 ), Val( s2 ), Val( s3 ) ) )
 // e.g.  Warn( "1 January 2011 must be Saturday, and gives: ", FNStringGetDateWeekDayNameS( 1, 1, 2011 ) )
 // e.g.  Warn( "24 August 2011 must be Wednesday, and gives: ", FNStringGetDateWeekDayNameS( 24, 8, 2011 ) )
 // e.g.  Warn( "9 September 2011 must be Friday, and gives: ", FNStringGetDateWeekDayNameS( 9, 9, 2011 ) )
 // e.g.  Warn( "2 October 2011 must be Sunday, and gives: ", FNStringGetDateWeekDayNameS( 2, 10, 2011 ) )
 // e.g.  Warn( "1 November 2011 must be Tuesday, and gives: ", FNStringGetDateWeekDayNameS( 1, 11, 2011 ) )
 // e.g.  Warn( "1 September 2011 must be Thursday, and gives: ", FNStringGetDateWeekDayNameS( 1, 9, 2011 ) )
 // e.g.  FOR I = 1 TO 30
 // e.g.   Warn( I, " ", "September 2011: ", FNStringGetDateWeekDayNameS( I, 9, 2011 ) )
 // e.g.  ENDFOR
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // Idea: -From the total amount of days you can get the total amount of weeks by dividing it by 7.
 //
 //       -Dividing by 7 removes all the multiples of 7 (and then you only look at the rest of the days smaller or equal to 6)
 //
 //       -The weekday name which was originally chosen as day 1 (e.g. Sunday) will remain that.
 //
 //       -The other days keep following after that, in the original chosen order.
 //
 INTEGER dayTotalI = FNMathGetDateTodayTotalI( dayI, monthI, yearI )
 //
 INTEGER weekMultipleOf7RestI = dayTotalI MOD 7
 //
 STRING s[255] = ""
 //
 CASE weekMultipleOf7RestI
  //
  WHEN 0
   //
   s = "Saturday"
   //
  WHEN 1
   //
   s = "Sunday"
   //
  WHEN 2
   //
   s = "Monday"
  //
  WHEN 3
   //
   s = "Tuesday"
   //
  WHEN 4
   //
   s = "Wednesday"
   //
  WHEN 5
   //
   s = "Thursday"
   //
  WHEN 6
   //
   s = "Friday"
   //
  OTHERWISE
   //
   Warn( "date to week day name: unknown result", ":", " ", weekMultipleOf7RestI )
   //
   s = FNStringGetErrorS()
   //
 ENDCASE
 //
 RETURN( s )
 //
END

// library: string: get: program4nt <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstgps.s) [<Program>] [<Research>] [kn, am, we, 29-04-2009 18:53:22]
STRING PROC FNStringGetProgram4ntFilenameS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetProgram4ntFilenameS() ) // gives e.g. "f:\4dos\4nt.exe"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetFileIniDefaultS( "ProgramName4DosS" ) )
 //
END

// library: string: get: path: file: alias: unicode4: dos4: nt: filename <description></description> <version control></version control> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=getstnfj.s) [<Program>] [<Research>] [kn, ri, su, 25-12-2016 02:20:20]
STRING PROC FNStringGetPathFileAliasUnicode4Dos4NtFilenameS()
 // e.g. PROC Main()
 // e.g.  IF ( FNMathGetNumberInputYesNoCancelPositionDefaultI( Format( "Alias command (should be similar to computer name)", " ", "=", " ", FNStringGetPathFileAliasUnicode4Dos4NtFilenameS() ) ) == 1 ) // gives e.g. "c:\4dos\aliasUnicode.dok"
 // e.g.  ENDIF
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // do not add this, it becomes too slow [kn, ri, sa, 09-02-2013 01:49:15]
 // PROCMacroRunPurgeParameter( "runprmcn", Format( FNStringGetMachineNameS(), ";", FNStringGetUserNameFirstS(), ";", FNStringGetUserNameLastS(), ";", FNStringGetPortS(), ";", "TSE%3A+String%3A+Get%3A" + "FNStringGetPathFileAlias4Dos4NtS" + "&submit01=Create" ) )
 //
 RETURN( FNStringGetFileIniDefaultS( "FNStringGetPathFileAliasUnicode4Dos4NtS" ) )
 //
END

// library: math: get: integer: minimum: absolute <description></description> <version control></version control> <version>1.0.0.0.2</version> (filenamemacro=getmamab.s) [<Program>] [<Research>] [kn, noot, mo, 09-07-2001 11:51:54]
INTEGER PROC FNMathGetIntegerMinimumAbsoluteI()
 // e.g. PROC Main()
 // e.g.  Message( FNMathGetIntegerMinimumAbsoluteI() ) // gives always a negative integer. E.g. -4
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( - FNMathGetIntegerMaximumAbsoluteI() )
 //
END

// library: math: get: date: day: to: total <description></description> <version control></version control> <version>1.0.0.0.22</version> (filenamemacro=getmadto.s) [<Program>] [<Research>] [kn, ri, su, 13-04-2008 00:10:19]
INTEGER PROC FNMathGetDateTodayTotalI( INTEGER dayI, INTEGER monthI, INTEGER yearI )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = "01"
 // e.g.  STRING s2[255] = "01"
 // e.g.  STRING s3[255] = "1970"
 // e.g.
 // e.g.  // Warn( FNMathGetDateTodayTotalI( 1, 1, 1 ) ) // gives 1 // but do not use this low dates. Keep the year range your choose from within e.g. 1900 to 2100.
 // e.g.  // Warn( FNMathGetDateTodayTotalI( 12, 1, 1989 ) ) // gives 726129
 // e.g.  // Warn( FNMathGetDateTodayTotalI( 26, 8, 1983 ) ) // gives 724163
 // e.g.  // Warn( FNMathGetDateTodayTotalI( 27, 8, 1983 ) ) // gives 724164
 // e.g.  // Warn( FNMathGetDateTodayTotalI( 1, 1, 1993 ) ) // gives 727579
 // e.g.  // Warn( FNMathGetDateTodayTotalI( 31, 12, 2007 ) ) // gives 733056
 // e.g.  // Warn( FNMathGetDateTodayTotalI( 1, 1, 2008 ) ) // gives 733057
 // e.g.
 // e.g.  IF ( NOT ( Ask( "math: get: date: day: total: dayI = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  IF ( NOT ( Ask( "math: get: date: day: total: monthI = ", s2, _EDIT_HISTORY_ ) ) AND ( Length( s2 ) > 0 ) ) RETURN() ENDIF
 // e.g.  IF ( NOT ( Ask( "math: get: date: day: total: yearI = ", s3, _EDIT_HISTORY_ ) ) AND ( Length( s3 ) > 0 ) ) RETURN() ENDIF
 // e.g.  Warn( FNMathGetDateTodayTotalI( Val( s1 ), Val( s2 ), Val( s3 ) ) )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // ===
 //
 // [book: see: Czes Kosniowski - essential maths on the bbc micro - p. 101]
 //
 // [method: Zellers formula]
 //
 //  INT( 365.25 * yearI - 395.25 ) + INT( 30.57 * monthI% ) + dayI
 //
 // Simple idea: Basically you multiply years with 365 days, months with 30 and add the days to give the total amount of days.
 //
 // This is then adjusted with some corrections for integer instead of floating point calculation and e.g. leap year
 //
 INTEGER dayTotalI = ( ( 365 * yearI ) + ( yearI / 4 ) - 395 ) + ( 30 * monthI + ( monthI / 2 ) + ( ( 7 * monthI ) / 100 ) ) + dayI
 //
 IF ( ( yearI MOD 4 ) == 0 )
  //
  dayTotalI = dayTotalI - 1
  //
 ENDIF
 //
 IF ( ( monthI == 9 ) OR ( monthI == 11 ) )
  //
  // dayTotalI = dayTotalI - 1 // old [kn, ri, su, 02-10-2011 15:44:41]
  //
  dayTotalI = dayTotalI + 1 // new [kn, ri, su, 02-10-2011 15:44:45]
  //
 ENDIF
 //
 IF ( monthI <= 2 )
  //
  RETURN( dayTotalI )
  //
 ENDIF
 //
 IF ( FNDateCheckYearLeapB( yearI ) )
  //
  RETURN( dayTotalI - 1 )
  //
 ENDIF
 //
 RETURN( dayTotalI - 2 )
 //
END

// library: string: get: error <description>general output string to recognize an error (e.g. in another routine). Central routine, only one occurrence of this constant string</description> <version>1.0.0.0.2</version> <version control></version control> (filenamemacro=getstger.s) [<Program>] [<Research>] [kn, ri, sa, 05-12-1998 20:58:17]
STRING PROC FNStringGetErrorS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetErrorS() ) // gives e.g. "<ERROR>"
 // e.g. END
 //
 RETURN( "<ERROR>" )
 //
END

// library: file: get: ini: default: central <description></description> <version control></version control> <version>1.0.0.0.6</version> (filenamemacro=getfiidf.s) [<Program>] [<Research>] [kn, ri, we, 31-12-2003 02:17:48]
STRING PROC FNStringGetFileIniDefaultS( STRING searchS )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileIniDefaultS( "path4dos" ) ) // gives e.g. "c:\4dos"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 // e.g.
 //
 // USAGE
 //
 // 1. -Choose a filename for your global variables initialization file
 //
 //    1. -E.g. default name is here
 //
 //         dddpath.ini
 //
 //    2. -You can set this name in a function in this library, if you
 //
 //        want to change the default name
 //
 // 3. -Save this file in the directory
 //
 //     (path chosen to be given by Microsoft Windows environment variable APPDATA)
 //
 //      C:\Documents and Settings\<your Microsoft Windows login name>\Application Data\
 //
 // 4. -The full path to your initialization file is thus e.g.
 //
 //      C:\Documents and Settings\Administrator\Application Data\dddpath.ini
 //
 // 5. -To keep things as simple as possible, you need to put once
 //
 //     in top of your file the word (which must start at the beginning
 //
 //     of the line). Further no more '[' characters starting at the begin of any line.
 //
 //      [default]
 //
 // 6. -This file contains 0 or more lines of the general format
 //
 //      <variable name> = <variable value>
 //
 //     1. -E.g.
 //
 //         [default]
 //
 //          path4dos = c:\4dos
 //
 //          tsevariable1 = test1
 //
 //          tsevariable2 = test2
 //
 //          tsevariable3 = test3
 //
 //          ...
 //
 //     2. -Note: you should/could put spaces before and after the '=' sign
 //
 //         (e.g. for backwards compatibility purposes)
 //
 // 7. -Using this library, you can then e.g. get the value of your global variable from this file
 //
 STRING s[255] = ""
 //
 s =FNStringGetFileGetFilenamePathDefaultS( searchS )
 //
 IF EquiStr( Trim( s ), "" )
  PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default // new
  Warn( searchS, ":", " ", "Mot found (or found but the value is the empty string). Please check dddpath.ini and adapt file bibdelphi.del" )
 ENDIF
 //
 RETURN( FNStringGetFileGetFilenamePathDefaultS( searchS ) )
 //
END

// library: math: get: integer: maximum: absolute <description></description> <version control></version control> <version>1.0.0.0.4</version> (filenamemacro=getmamac.s) [<Program>] [<Research>] [kn, noot, mo, 09-07-2001 11:51:54]
INTEGER PROC FNMathGetIntegerMaximumAbsoluteI()
 // e.g. PROC Main()
 // e.g.  Message( FNMathGetIntegerMaximumAbsoluteI() ) // gives the maximum value of an integer possible in TSE. This is currently 2147483647 (= 2^31 - 1. Note this is not 2^32 - 1 even if 32 bits, because 1 bit is reserved for the sign (thus '+' or '-'), as it are signed integers by design in TSE).
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( MAXINT )
 //
END

// library: date: check: year: leap <description></description> <version control></version control> <version>1.0.0.0.10</version> (filenamemacro=checdayl.s) [<Program>] [<Research>] [kn, ri, sa, 12-04-2008 22:55:06]
INTEGER PROC FNDateCheckYearLeapB( INTEGER yearI )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = "2008"
 // e.g.  IF ( NOT ( Ask( "date: check: year: leap: yearI = ", s1, _EDIT_HISTORY_ ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  Message( FNDateCheckYearLeapB( Val( s1 ) ) ) // gives e.g. TRUE when that year is a leapyear
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // Method
 //
 // In the Gregorian calendar, three criteria must be taken into account to identify leap years:
 // The year can be evenly divided by 4.
 // But if the year can also be evenly divided by 100, it is NOT a leap year, unless
 // the year is also evenly divisible by 400. Then it is a leap year.
 //
 INTEGER B = FALSE
 //
 B = ( ( yearI MOD 4 == 0 ) AND ( yearI MOD 100 <> 0 ) ) OR ( yearI MOD 400 == 0 )
 //
 RETURN( B )
 //
END

// library: macro: run: keep <description>macro: run a macro, then keep it</description> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=runmarke.s) [<Program>] [<Research>] [[kn, zoe, fr, 27-10-2000 15:59:33]
PROC PROCMacroRunKeep( STRING macronameS )
 // e.g. PROC Main()
 // e.g.  PROCMacroRunKeep( "mysubma1.mac myparameter11 myparameter12" )
 // e.g.  PROCMacroRunKeep( "mysubma2.mac myparameter21" )
 // e.g.  PROCMacroRunKeep( "mysubma3.mac myparameter31 myparameter32" )
 // e.g. END
 //
 IF FNMacroCheckLoadB( FNStringGetCarS( macronameS ) ) // necessary if you pass parameters in a string
  //
  PROCMacroExec( macronameS )
  //
 ENDIF
 //
END

// library: file: get: filename: path: default <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getfipde.s) [<Program>] [<Research>] [kn, ri, we, 31-12-2003 02:14:28]
STRING PROC FNStringGetFileGetFilenamePathDefaultS( STRING searchS )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFileGetFilenamePathDefaultS( "path4dos" ) ) // gives e.g. "c:\4dos"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // RETURN( FNStringGetFileGetFilenamePathS( searchS, FNStringGetFilenameIniDefaultS() ) ) // [kn, ri, mo, 22-05-2006 23:59:52]
 //
 RETURN( FNStringGetInitializationGlobalS( searchS, FNStringGetSectionSeparatorS(), FNStringGetFilenameIniDefaultS() ) )
 //
END

// library: macro: check: load <description>macro: load: (Loads a Macro File From Disk Into Memory) R    LoadMacro(STRING macro_filename)*</description> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=checmacl.s) [<Program>] [<Research>] [[kn, zoe, we, 16-06-1999 01:07:06]
INTEGER PROC FNMacroCheckLoadB( STRING macronameS )
 // e.g. PROC Main()
 // e.g.  Message( FNMacroCheckLoadB( macronameS ) ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( LoadMacro( macronameS ) )
 //
END

// library: string: get: word: token: get: first: FNStringGetCarS(): Get the first word of a string (words delimited by a space " " (=space delimited list)). <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstgca.s) [<Program>] [<Research>] [kn, ni, su, 02-08-1998 15:54:17]
STRING PROC FNStringGetCarS( STRING s )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = FNStringGetInitializeNewStringS()
 // e.g.  s1 = FNStringGetInputS( "string: get: word: token: get: first: s = ", "this is a test" )
 // e.g.  IF FNKeyCheckPressEscapeB( s1 ) RETURN() ENDIF
 // e.g.  Message( FNStringGetCarS( s1 ) ) // gives e.g. "this"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // variation: RETURN( FNStringGetTokenFirstS( s, " " ) )
 //
 RETURN( GetToken( s, " ", 1 ) ) // faster, but not central
 //
END

// library: macro: exec <description>macro: (Executes the Requested Macro) O    ExecMacro([<Program>] [<Research>] [STRING macroname])*</description> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=execmame.s) [[kn, zoe, we, 16-06-1999 01:06:54]
PROC PROCMacroExec( STRING macronameS )
 // e.g. PROC Main()
 // e.g.  PROCMacroExec( "video" )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 IF FNMathCheckLogicNotB( FNMacroCheckExecB( macronameS ) )
  //
  PROCWarnCons3( "macro", macronameS, ": could not be executed" )
  //
 ENDIF
 //
END

// library: string: get: initialization: global <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstigl.s) [<Program>] [<Research>] [kn, ri, mo, 22-05-2006 23:44:33]
STRING PROC FNStringGetInitializationGlobalS( STRING searchS, STRING sectionS, STRING fileNameS )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetInitializationGlobalS( "path4dos", "default", FNStringGetFilenameIniDefaultS() ) ) // e.g. gives "c:\4dos"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( GetProfileStr( sectionS, searchS, FNStringGetEmptyS(), fileNameS ) )
 //
END

// library: string: get: section: separator <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstssh.s) [<Program>] [<Research>] [kn, ri, mo, 22-05-2006 23:43:21]
STRING PROC FNStringGetSectionSeparatorS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetSectionSeparatorS() ) // gives e.g. "default"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( "default" ) // you can not put this in the initialization file, because this actually determines the default section of that file itself. Possibly pass it as a command line parameter
 //
END

// library: filename: get: filename: ini: default <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getfiide.s) [<Program>] [<Research>] [kn, ri, we, 31-12-2003 02:15:47]
STRING PROC FNStringGetFilenameIniDefaultS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFilenameIniDefaultS() ) // gives e.g. "c:\documents and settings\administrator\application data\dddpath.ini"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // RETURN( "c:\dddpath.ini" )
 //
 RETURN( FNStringGetConcatS( FNStringGetPathUser_DataApplicationCurrentBackslashS(), FNStringGet_FilenameIniDefaultS() ) )
 //
END

// library: math: check: logic: not <description></description> <version control></version control> <version>1.0.0.0.2</version> (filenamemacro=checmaln.s) [<Program>] [<Research>] [kn, ri, tu, 15-05-2001 16:54:21]
INTEGER PROC FNMathCheckLogicNotB( INTEGER B )
 // e.g. PROC Main()
 // e.g.  STRING s[255] = FNStringGetInitializeNewStringS()
 // e.g.  s = FNStringGetInputS( "math: check: logic: not: number = ", "1" )
 // e.g.  IF FNKeyCheckPressEscapeB( s ) RETURN() ENDIF
 // e.g.  Message( FNMathCheckLogicNotB( FNStringGetToIntegerI( s ) ) )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( NOT B )
 //
END

// library: macro: check: exec <description>macro: (Executes the Requested Macro) O    ExecMacro([<Program>] [<Research>] [STRING macroname])*</description> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=checmace.s) [[kn, zoe, we, 16-06-1999 01:06:54]
INTEGER PROC FNMacroCheckExecB( STRING macronameS )
 // e.g. PROC Main()
 // e.g.  Message( FNMacroCheckExecB( macronameS ) ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( ExecMacro( macronameS ) )
 //
END

// library: warn: cons3 <description>error: warning: give a warning message via 3 strings</description> <version>1.0.0.0.2</version> <version control></version control> (filenamemacro=conswawd.s) [<Program>] [<Research>] [[kn, ri, su, 29-07-2001 18:24:52]
PROC PROCWarnCons3( STRING s1, STRING s2, STRING s3 )
 // e.g. PROC Main()
 // e.g.  PROCWarnCons3( "error", "1", "2" ) // gives e.g. "error 1 2"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 PROCWarn( FNStringGetCons3S( s1, s2, s3 ) )
 //
END

// library: string: get: empty (return an empty string) <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstgem.s) [<Program>] [<Research>] [kn, ri, sa, 20-05-2000 20:11:03]
STRING PROC FNStringGetEmptyS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetEmptyS() ) // gives e.g. ...""
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( "" )
 //
END

// library: string: get: concat <description>concatenation 2 words tot 1 word</description> <version>1.0.0.0.3</version> (filenamemacro=getstgch.s) [<Program>] [<Research>] [kn, zoe, th, 01-02-2001 19:32:49]
STRING PROC FNStringGetConcatS( STRING s1, STRING s2 )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetConcatS( "test1", "test2" ) ) // version with test if string empty ) // gives e.g. "test1test2"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetConcatSeparatorS( s1, s2, FNStringGetEmptyS() ) )
 //
END

// library: string: get: path: user: data: application: current: backslash <description></description> <version control></version control> <version>1.0.0.0.2</version> (filenamemacro=getstcbe.s) [<Program>] [<Research>] [kn, ri, sa, 21-02-2004 23:01:06]
STRING PROC FNStringGetPathUser_DataApplicationCurrentBackslashS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetPathUser_DataApplicationCurrentBackslashS() ) // gives e.g. "c:\documents and settings\administrator\application data\" (this is a hidden directory)
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetFilenameEndBackSlashNotEqualInsertEndS( FNStringGetPathUser_DataApplicationCurrentBackslashNotS() ) )
 //
END

// library: string: get: filename: ini: default <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstide.s) [<Program>] [<Research>] [kn, ri, sa, 21-02-2004 22:54:12]
STRING PROC FNStringGet_FilenameIniDefaultS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGet_FilenameIniDefaultS() ) // gives e.g. "dddpath.ini"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( "dddpath.ini" ) // you can not put this in the global initialization file, because this actually determines the name of that file itself. You could overrule this by passing the filename as a parameter on the command line. (if ( parameter is empty ) then ( defaultfilename = dddpath.ini ), else ( defaultfilename = <that command line parameter> ) )
 //
END

// library: warn <description>error: warning: give a warning message</description> <version>1.0.0.0.3</version> <version control></version control> (filenamemacro=wawarn.s)  [<Program>] [<Research>] [kn, zoe, we, 09-06-1999 22:11:07]
PROC PROCWarn( STRING s )
 // e.g. PROC Main()
 // e.g.  PROCWarn( "you have forgotten to input a value" )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default // new [kn, ri, fr, 22-05-2020 20:12:39]
 Warn( s )
 //
END

// library: string: get: cons3: string: concatenation: 3 strings <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstgcy.s) [<Program>] [<Research>] [kn, zoe, fr, 17-11-2000 13:52:07]
STRING PROC FNStringGetCons3S( STRING s1, STRING s2, STRING s3 )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetCons3S( "a", "b", "c" ) ) // gives e.g. "a b c"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetConsS( FNStringGetConsS( s1, s2 ), s3 ) )
 //
END

// library: string: get: concat: separator: string: concatenation: concatenate 2 words to 1 word, separated by separator <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstcsg.s) [<Program>] [<Research>] [kn, zoe, th, 01-07-1999 01:33:18]
STRING PROC FNStringGetConcatSeparatorS( STRING s1, STRING s2, STRING separatorS )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetConcatSeparatorS( "test1", "test2", " " ) ) // gives e.g. "tes1 test2"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 IF FNStringCheckEmptyB( s1 ) RETURN( s2 ) ENDIF
 //
 IF FNStringCheckEmptyB( s2 ) RETURN( s1 ) ENDIF
 //
 RETURN( s1 + separatorS + s2 ) // leave this like this. Do not call a function, as this is a primitive function, you will get into a recursive loop, and get stack overflow
 //
END

// library: string: get: filename: end: back: slash: not: equal: insert: end <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstiep.s) [<Program>] [<Research>] [kn, ni, su, 17-08-2003 00:24:04]
STRING PROC FNStringGetFilenameEndBackSlashNotEqualInsertEndS( STRING s )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetFilenameEndBackSlashNotEqualInsertEndS( 'c:\temp\ddd' ) ) // gives e.g. a string 'c:\temp\ddd\' (so with always a string with a backslash '\' at the end)
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetCharacterEndBackSlashNotEqualInsertEndS( s ) )
 //
END

// library: string: get: path: user: data: application: current <description></description> <version control></version control> <version>1.0.0.0.2</version> (filenamemacro=getstacu.s) [<Program>] [<Research>] [kn, ri, sa, 21-02-2004 22:50:55]
STRING PROC FNStringGetPathUser_DataApplicationCurrentBackslashNotS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetPathUser_DataApplicationCurrentBackslashNotS() ) // gives e.g. "c:\documents and settings\administrator\application data" (this is a hidden directory)
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 STRING s[255] = FNStringGetEnvironmentS( "APPDATA" )
 //
 IF FNStringCheckEnvironmentFoundNotB( s )
  //
  PROCWarnCons3( "current user path to application data", s, ": not found" )
  //
  s = FNStringGetErrorS()
  //
 ENDIF
 //
 RETURN( s )
 //
END

// library: string: get: cons: string: concatenation: concatenation 2 words to 1 word (separated by a space) <description></description> <version control></version control> <version>1.0.0.0.3</version> (filenamemacro=getstgcx.s) [<Program>] [<Research>] [kn, ri, we, 25-11-1998 20:15:03]
STRING PROC FNStringGetConsS( STRING s1, STRING s2 )
 // e.g. //
 // e.g. // version with test if string empty
 // e.g. //
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetConsS( "john", "doe" ) ) // gives "john doe"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetConcatSeparatorS( s1, s2, FNStringGetCharacterSymbolSpaceS() ) )
 //
END

// library: string: check: empty <description>string: empty: is given string empty?</description> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=checstcz.s) [<Program>] [<Research>] [[kn, ri, sa, 20-05-2000 20:11:08]
INTEGER PROC FNStringCheckEmptyB( STRING s )
 // e.g. PROC Main()
 // e.g.  Message( FNStringCheckEmptyB( s ) ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringCheckEqualB( s, FNStringGetEmptyS() ) )
 //
END

// library: string: get: backslash: if last character is not equal to '\', then concatenate a backslash to the end of the given string <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstien.s) [<Program>] [<Research>] [kn, ri, sa, 24-02-2001 23:48:15]
STRING PROC FNStringGetCharacterEndBackSlashNotEqualInsertEndS( STRING s )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = FNStringGetInitializeNewStringS()
 // e.g.  s1 = FNStringGetInputS( "string: get: backslash: if: not equal insert end: string = ", "this is a string without a backslash at end" )
 // e.g.  IF FNKeyCheckPressEscapeB( s1 ) RETURN() ENDIF
 // e.g.  Message( FNStringGetCharacterEndBackSlashNotEqualInsertEndS( s1 ) ) // gives e.g. "this is a string with a backslash at end\"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetCharacterInsertEndIfEqualNotS( s, FNStringGetCharacterSymbolSlashBackwardS() ) )
 //
END

// library: environment: string: get (Searches for and Returns a Specified Environment Str) R    GetEnvStr(STRING s)* <description></description> <version control></version control> <version>1.0.0.0.4</version> (filenamemacro=getstgen.s) [<Program>] [<Research>] [kn, ri, th, 25-10-2001 01:44:48]
STRING PROC FNStringGetEnvironmentS( STRING s )
 // e.g. PROC Main()
 // e.g.  STRING s[255] = FNStringGetInputS( "value: environment variable = ", "windir" )
 // e.g.  IF FNKeyCheckPressEscapeB( s ) RETURN() ENDIF
 // e.g.  PROCMessageCons3( s, "=", FNStringGetEnvironmentS( s ) ) // gives e.g. "windir=C:\WINNT", when working on a Windows2000 machine
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 STRING valueS[255] = GetEnvStr( s )
 //
 IF FNStringCheckEmptyB( valueS )
  //
  // PROCMessageCons3( "environment variable", s, ": not found" ) // old [kn, vo, fr, 08-02-2013 10:14:48]
  //
  valueS = FNStringGetErrorS()
  //
 ENDIF
 //
 RETURN( valueS )
 //
END

// library: environment: check: found: not <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=checenfn.s) [<Program>] [<Research>] [kn, ri, sa, 27-05-2006 20:20:03]
INTEGER PROC FNStringCheckEnvironmentFoundNotB( STRING s )
 // e.g. PROC Main()
 // e.g.  Message( FNStringCheckEnvironmentFoundNotB( FNStringGetEmptyS() ) ) // gives TRUE (thus not found) because string empty (or string error string)
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringCheckEqualErrorOrEmptyB( s ) )
 //
END

// library: string: get: character: symbol: " " <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstssp.s) [<Program>] [<Research>] [kn, zoe, we, 25-10-2000 01:33:39]
STRING PROC FNStringGetCharacterSymbolSpaceS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetCharacterSymbolSpaceS() ) // gives " "
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetCharacterSymbolCentralS( 32 ) )
 //
END

// library: string: check: equal <description>string: equal: are two given strings equal? (stored in 'checstcf.s')</description> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=checstcy.s) [<Program>] [<Research>] [[kn, zoe, we, 04-10-2000 18:23:27]
INTEGER PROC FNStringCheckEqualB( STRING s1, STRING s2 )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = FNStringGetInitializeNewStringS()
 // e.g.  STRING s2[255] = FNStringGetInitializeNewStringS()
 // e.g.  s1 = FNStringGetInputS( "string: check: equal: first string = ", "a" )
 // e.g.  IF FNKeyCheckPressEscapeB( s1 ) RETURN() ENDIF
 // e.g.  s2 = FNStringGetInputS( "string: check: equal: second string = ", "a" )
 // e.g.  IF FNKeyCheckPressEscapeB( s2 ) RETURN() ENDIF
 // e.g.  Message( FNStringCheckEqualB( s1, s2 ) ) // gives e.g. TRUE when string1 is equal to string2
 // e.g.  GetKey()
 // e.g.  Message( FNStringCheckEqualB( "knud", "knud" ) ) // gives TRUE
 // e.g.  GetKey()
 // e.g.  Message( FNStringCheckEqualB( "knud", "van" ) ) // gives FALSE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( s1 == s2 )
 //
END

// library: compare if string end is equal, if not so insert that string at the end <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstenp.s) [<Program>] [<Research>] [kn, ri, sa, 24-02-2001 23:06:33]
STRING PROC FNStringGetCharacterInsertEndIfEqualNotS( STRING inS, STRING tailS )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = FNStringGetInitializeNewStringS()
 // e.g.  STRING s2[255] = FNStringGetInitializeNewStringS()
 // e.g.  s1 = FNStringGetInputS( "string: insert: insert: string = ", "c:\kee" )
 // e.g.  IF FNKeyCheckPressEscapeB( s1 ) RETURN() ENDIF
 // e.g.  s2 = FNStringGetInputS( "string: insert: insert: frontS = ", "\" )
 // e.g.  IF FNKeyCheckPressEscapeB( s2 ) RETURN() ENDIF
 // e.g.  Message( FNStringGetCharacterInsertEndIfEqualNotS( s1, s2 ) ) // gives e.g. "c:\kee\"
 // e.g.  GetKey()
 // e.g.  Message( FNStringGetCharacterInsertEndIfEqualNotS( "c", ":" ) ) // gives "c:"
 // e.g.  GetKey()
 // e.g.  Message( FNStringGetCharacterInsertEndIfEqualNotS( "c:", ":" ) ) // gives "c:"
 // e.g.  GetKey()
 // e.g.  Message( FNStringGetCharacterInsertEndIfEqualNotS( "c:\kee", FNStringGetCharacterSymbolSlashBackwardS() ) ) // gives "c:\kee\"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 STRING s[255] = inS
 //
 IF FNMathCheckLogicNotB( FNStringCheckEqualCharacterLastNB( s, tailS ) )
  //
  // s = FNStringGetConcatS( s, tailS )
  //
  s = FNStringGetConcatTailS( s, tailS )
  //
 ENDIF
 //
 RETURN( s )
 //
END

// library: string: get: character: symbol: "\" <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstsba.s) [<Program>] [<Research>] [kn, ri, su, 29-07-2001 15:41:11]
STRING PROC FNStringGetCharacterSymbolSlashBackwardS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetCharacterSymbolSlashBackwardS() ) // gives "\"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetCharacterSymbolCentralS( 92 ) )
 //
END

// library: environment: check: found: not <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=checenfn.s) [<Program>] [<Research>] [kn, ri, sa, 27-05-2006 20:20:03]
INTEGER PROC FNStringCheckEqualErrorOrEmptyB( STRING s )
 // e.g. PROC Main()
 // e.g.  Message( FNStringCheckEqualErrorOrEmptyB( FNStringGetEmptyS() ) ) // gives TRUE if string empty or string equals error string
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNMathCheckLogicOrB( FNErrorCheckSB( s ), FNStringCheckEmptyB( s ) ) )
 //
END

// library: string: get: character: symbol: central <description>string: get: character: symbol: central</description> <version>1.0.0.0.1</version> <version control></version control> (filenamemacro=getstscm.s) [<Program>] [<Research>] [[kn, ri, sa, 07-07-2001 22:35:39]
STRING PROC FNStringGetCharacterSymbolCentralS( INTEGER I )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetCharacterSymbolCentralS( I ) ) // gives e.g. ...""
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetAsciiToCharacterS( I ) )
 //
END

// library: string: word: equal: last: compare if a given string is equal at the end to another given string <description></description> <version control></version control> <version>1.0.0.0.2</version> (filenamemacro=checstln.s) [<Program>] [<Research>] [kn, zoe, we, 29-11-2000 19:08:34]
INTEGER PROC FNStringCheckEqualCharacterLastNB( STRING s, STRING tailS )
 // e.g. //
 // e.g. // version: first parameter s then endS
 // e.g. //
 // e.g. PROC Main()
 // e.g.  Message( FNStringCheckEqualCharacterLastNB( "knud", "d" ) ) //  gives TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringCheckEqualB( FNStringGetRightStringLengthEqualS( s, tailS ), tailS ) )
 //
END

// library: string: get: concat: tail: suffix <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstctb.s) [<Program>] [<Research>] [kn, ri, su, 02-09-2001 03:08:08]
STRING PROC FNStringGetConcatTailS( STRING s, STRING tailS )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetConcatTailS( "Knu", "d" ) ) // gives e.g. "Knud"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetConcatS( s, tailS ) )
 //
END

// library: math: check: logic: or: 2 arguments <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=checmalo.s) [<Program>] [<Research>] [kn, ri, tu, 15-05-2001 16:54:17]
INTEGER PROC FNMathCheckLogicOrB( INTEGER B1, INTEGER B2 )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = FNStringGetInitializeNewStringS()
 // e.g.  STRING s2[255] = FNStringGetInitializeNewStringS()
 // e.g.  s1 = FNStringGetInputS( "math: check: logic: or: number1 = ", "1" )
 // e.g.  IF FNKeyCheckPressEscapeB( s1 ) RETURN() ENDIF
 // e.g.  s2 = FNStringGetInputS( "math: check: logic: or: number2 = ", "1" )
 // e.g.  IF FNKeyCheckPressEscapeB( s2 ) RETURN() ENDIF
 // e.g.  Message( FNMathCheckLogicOrB( FNStringGetToIntegerI( s1 ), FNStringGetToIntegerI( s2 ) ) ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 IF ( B1 )
  //
  RETURN( FNMathCheckGetLogicTrueB() )
  //
 ENDIF
 //
 IF ( B2 )
  //
  RETURN( FNMathCheckGetLogicTrueB() )
  //
 ENDIF
 //
 RETURN( FNMathCheckGetLogicFalseB() )
 //
END

// library: error: check <description>error: test if an error occurred, via testing the output // version with testing local variable. Better.</description> <version>1.0.0.0.3</version> <version control></version control> (filenamemacro=checercs.s) [<Program>] [<Research>] [[kn, ni, we, 05-08-1998 20:27:34]
INTEGER PROC FNErrorCheckSB( STRING s )
 // e.g. PROC Main()
 // e.g.  Message( FNErrorCheckSB( "this is an error" ) ) // version with testing local variable. Better. ) // gives TRUE or FALSE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringCheckEqualB( s, FNStringGetErrorS() ) )
 //
END

// library: string: get: ascii: to: character (given the ASCII value, what is the corresponding character? (Get Single Character Equivalent of an Integer). Syntax: Chr(INTEGER i)*) <description></description> <version control></version control> <version>1.0.0.0.2</version> (filenamemacro=getsttch.s)  [<Program>] [<Research>] [kn, zoe, we, 16-06-1999 01:06:51]
STRING PROC FNStringGetAsciiToCharacterS( INTEGER asciiI )
 // e.g. PROC Main()
 // e.g.  Warn( FNStringGetAsciiToCharacterS( 65 ) ) // gives "A"
 // e.g.  Warn( FNStringGetAsciiToCharacterS( 66 ) ) // gives "B"
 // e.g.  Warn( FNStringGetAsciiToCharacterS( 100 ) ) // gives "d"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( Chr( asciiI ) ) // leave this keyword, otherwise possibly recursive stack overflow
 //
END

// library: STRING: get: right: string: length: equal <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstler.s) [<Program>] [<Research>] [kn, ni, su, 30-11-2003 23:32:40]
STRING PROC FNStringGetRightStringLengthEqualS( STRING s, STRING tailS )
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetRightStringLengthEqualS( "Knud van Eeden", "12345" ) ) // gives e.g. "Eeden"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNStringGetRightStringS( s, FNStringGetLengthI( tailS ) ) )
 //
END

// library: math: check: get: logic: true: wrapper <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=checmalt.s) [<Program>] [<Research>] [kn, ri, su, 22-07-2001 15:43:12]
INTEGER PROC FNMathCheckGetLogicTrueB()
 // e.g. PROC Main()
 // e.g.  Message( FNMathCheckGetLogicTrueB() ) // gives TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( TRUE )
 //
END

// library: math: check: get: logic: false: wrapper <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=checmalf.s) [<Program>] [<Research>] [kn, ri, su, 22-07-2001 15:43:08]
INTEGER PROC FNMathCheckGetLogicFalseB()
 // e.g. PROC Main()
 // e.g.  Message( FNMathCheckGetLogicFalseB() ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FALSE )
 //
END

// library: string: get: word: token: last: return a given integer amount of characters from the right of a given string (=RIGHT$ in BASIC) <description></description> <version control></version control> <version>1.0.0.0.5</version> (filenamemacro=stririrs.s) [<Program>] [<Research>] [kn, ri, tu, 13-10-1998 20:05:49]
STRING PROC FNStringGetRightStringS( STRING s, INTEGER totalI )
 // e.g. PROC Main()
 // e.g.  STRING s[255] = FNStringGetInitializeNewStringS()
 // e.g.  STRING charactertotalS[255] = FNStringGetInitializeNewStringS()
 // e.g.  s = FNStringGetInputS( "string: word: token: get: right: string = ", "knud" )
 // e.g.  IF FNKeyCheckPressEscapeB( s ) RETURN() ENDIF
 // e.g.  charactertotalS = FNStringGetInputS( "string: word: token: get: right: character total = ", "2" )
 // e.g.  IF FNKeyCheckPressEscapeB( charactertotalS ) RETURN() ENDIF
 // e.g.  Message( FNStringGetRightStringS( s, FNStringGetToIntegerI( charactertotalS ) ) ) //  gives e.g. "kn"
 // e.g.  GetKey()
 // e.g.  Message( FNStringGetRightStringS( "knud", 1 ) ) // gives "d"
 // e.g.  GetKey()
 // e.g.  Message( FNStringGetRightStringS( "knud", 2 ) ) // gives "ud"
 // e.g.  GetKey()
 // e.g.  Message( FNStringGetRightStringS( "best", 3 ) ) // gives "est"
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 INTEGER lengthI = FNStringGetLengthI( s )
 //
 IF FNMathCheckLogicNotB( ( ( 0 <= totalI ) AND ( totalI <= lengthI ) ) ) // if not between 0 and length( string ), return the whole given string
  //
  totalI = lengthI
  //
 ENDIF
 //
 RETURN( FNStringGetMidStringS( s, 1 + lengthI - totalI, lengthI ) )
 //
END

// library: string: line: length: what is the length <description></description> <version control></version control> <version>1.0.0.0.1</version> (filenamemacro=getstgle.s) [<Program>] [<Research>] [kn, ri, we, 25-11-1998 20:20:58]
INTEGER PROC FNStringGetLengthI( STRING s )
 // e.g. PROC Main()
 // e.g.  STRING s1[255] = FNStringGetInitializeNewStringS()
 // e.g.  s1 = FNStringGetInputS( "string: line: length: string = ", "this is a test" )
 // e.g.  IF FNKeyCheckPressEscapeB( s1 ) RETURN() ENDIF
 // e.g.  Message( FNStringGetLengthI( s1 ) ) // gives e.g. 14
 // e.g.  GetKey()
 // e.g.  Message( FNStringGetLengthI( "knud" ) ) // gives 4
 // e.g.  GetKey()
 // e.g.  Message( FNStringGetLengthI( "the" ) ) // gives 3
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( Length( s ) )
 //
END

// library: string: get: mid: string <description></description> <version control>string: get: word: token: middle: return a given integer amount of characters from the a given startposition</version control> <version>1.0.0.0.7</version> (=MID$ in BASIC) <version>1.0.0.0.7</version> (filenamemacro=getstmid.s) [<Program>] [<Research>] [kn, ri, tu, 13-10-1998 20:29:00]
STRING PROC FNStringGetMidStringS( STRING s, INTEGER beginI, INTEGER totalI )
 // e.g. PROC Main()
 // e.g.  STRING s[255] = FNStringGetInitializeNewStringS()
 // e.g.  STRING positionBeginS[255] = FNStringGetInitializeNewStringS()
 // e.g.  STRING characterTotalS[255] = FNStringGetInitializeNewStringS()
 // e.g.  s = FNStringGetInputS( "string: get: MIDSTRING: string = ", "testing" )
 // e.g.  IF FNKeyCheckPressEscapeB( s ) RETURN() ENDIF
 // e.g.  positionBeginS = FNStringGetInputS( "string: get: MIDSTRING: beginposition = ", "2" )
 // e.g.  IF FNKeyCheckPressEscapeB( positionBeginS ) RETURN() ENDIF
 // e.g.  characterTotalS = FNStringGetInputS( "string: get: MIDSTRING: character total = ", "3" )
 // e.g.  IF FNKeyCheckPressEscapeB( characterTotalS ) RETURN() ENDIF
 // e.g.  Message( FNStringGetMidStringS( s, FNStringGetToIntegerI( positionBeginS ), FNStringGetToIntegerI( characterTotalS ) ) )
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 // Message( FNStringGetMidStringS( "knud", 2, 3 ) ) // gives "nud"
 //
 // Message( FNStringGetMidStringS( "knud", 3, 2 ) ) // gives "ud"
 //
 RETURN( SubStr( s, beginI, totalI ) )
 //
END
