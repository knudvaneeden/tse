# Search in templates

Choose **Search projects > N: Search in templates...**, directly below
**Search in compiler options file**.

This integrates the supplied SEARCHTEMPLATE 1.0.0.0.5. It searches template
abbreviations in TSE's template.dat format and displays each matching template,
its extension and its body. It retains the original extension matching:
templates for the entered extension and templates with a blank/global extension
are included. It does not search inside template bodies.

The four prompts ask for the abbreviation search, options, extension and full
path to template.dat. Each prompt remembers its own last accepted value.
Escape cancels the search. The default file is LoadDir() + "template.dat".

Initial proposals are configurable in **proj0200.ini > [SearchTemplates]**:

| Key | Default | Meaning |
| --- | --- | --- |
| template | empty | Use TSE's load-directory template.dat |
| searchstring | sh | Abbreviation pattern |
| searchfileextension | .java | Extension filter; a missing dot is added |
| searchoption | ix | i ignores case; x enables TSE regex; w matches whole words |

Central settings override the bundled standalone searchtemplate.ini defaults.
Previously accepted prompt histories override those initial proposals.
The supplied original files and README are retained in SEARCH_TOOLS_REFERENCE.

The result buffer is selected after menu cleanup, so the main menu does not
cover it. The result count, cancellation or failure is recorded in
proj0200_activity.log. This macro is compiled and copied by build.bat.
