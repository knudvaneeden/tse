# PROJ0200 1.0.0.0.536 - isolated Windows test, no TSE/compiler installation required.
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$testRoot=Join-Path ([IO.Path]::GetTempPath()) ('proj0200 logs test '+[Guid]::NewGuid().ToString('N'))
$exe=Join-Path $PSHOME 'powershell.exe'
if (-not [IO.File]::Exists($exe)) { throw 'Run this test with Windows PowerShell.' }
function Assert-Test([bool]$Condition,[string]$Message) { if (-not $Condition) { throw $Message } }
[void][IO.Directory]::CreateDirectory($testRoot)
try {
    foreach ($name in @('proj0200_logs.ps1','proj0200_compile_capture.bat','proj0200_merge_helper.ps1',
        'proj0200_merge_formats.json','proj0200_merge_exclude.txt','proj0200_merge_types.txt')) {
        Copy-Item -LiteralPath (Join-Path $root $name) -Destination $testRoot
    }
    $compilerDir=Join-Path $testRoot 'PROJ0200COMPILERS'
    [void][IO.Directory]::CreateDirectory($compilerDir)
    $original=Get-ChildItem -LiteralPath (Join-Path $root 'PROJ0200COMPILERS') -Filter 'COM*.BAT' | Select-Object -First 1
    $guard=@(Get-Content -LiteralPath $original.FullName -TotalCount 6)
    $fake=Join-Path $compilerDir 'COMTEST.BAT'
    $body=@('@echo off','echo sample.c(2,3): error: test error>"%~6"','exit /b 7')
    [IO.File]::WriteAllLines($fake,[string[]]($guard+$body),[Text.Encoding]::Default)
    $source=Join-Path $testRoot 'sample with spaces.c'
    [IO.File]::WriteAllText($source,'int main(){}')
    $diagnostics=Join-Path $testRoot 'diagnostics with spaces.err'
    for ($run=0;$run -lt 2;$run++) {
        & $fake 'sample' 'unused' $source 'C' 'unused' $diagnostics
        Assert-Test ($LASTEXITCODE -eq 7) 'Compiler exit code changed by logging.'
        Assert-Test ([IO.File]::ReadAllText($diagnostics).Trim() -eq 'sample.c(2,3): error: test error') 'Original diagnostics changed.'
    }
    $saved=@(Get-ChildItem -LiteralPath $testRoot -Filter 'compiler*.log')
    Assert-Test ($saved.Count -eq 2) 'Expected two distinct compiler logs.'
    foreach ($file in $saved) {
        $text=[IO.File]::ReadAllText($file.FullName)
        Assert-Test ($text -match '\d{4}-\d\d-\d\d \d\d:\d\d:\d\d ERROR sample.c') 'Missing timestamped compiler error.'
    }
    [IO.File]::WriteAllText((Join-Path $testRoot 'proj0200_backup_log.txt'),'old undated backup detail')
    [IO.File]::WriteAllText((Join-Path $testRoot 'merged_previous.log'),'should not be collected')
    $ini=''
    foreach ($line in [IO.File]::ReadAllLines((Join-Path $root 'proj0200.ini'))) {
        if ($line -match '^mergesortexe=') { $ini=$line; break }
    }
    [IO.File]::WriteAllText((Join-Path $testRoot 'proj0200.ini'),$ini+"`r`nsingleline=true`r`n")
    $manifest=Join-Path $testRoot 'manifest.txt'
    & $exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $testRoot 'proj0200_logs.ps1') -Action Catalog -Output $manifest -ForMerge
    Assert-Test ($LASTEXITCODE -eq 0) 'Catalog failed.'
    $catalog=[IO.File]::ReadAllText($manifest)
    Assert-Test ($catalog.Contains('proj0200_backup_log.txt')) 'Backup log missing from catalog.'
    Assert-Test (-not $catalog.Contains('merged_previous.log')) 'Prior merged output was collected.'
    $sort=$ini -replace '^mergesortexe=',''
    if ($sort -and [IO.File]::Exists($sort)) {
        $output=Join-Path $testRoot 'merged_new.log'; $status=Join-Path $testRoot 'status.txt'
        & $exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $testRoot 'proj0200_merge_helper.ps1') -Request $manifest -Output $output -Status $status -PackageLogs
        Assert-Test ($LASTEXITCODE -eq 0) 'Merge failed.'
        $text=[IO.File]::ReadAllText($output)
        Assert-Test ($text.Contains('timestamp=file-modification; event time unknown')) 'Undated fallback was not labelled.'
        Assert-Test ($text.Contains('test error')) 'Compiler diagnostics missing from merged output.'
    } else { Write-Warning 'Merge test skipped: configured mergesortexe not found. Compiler capture/catalog tests still ran.' }
    Write-Host 'PASS: compiler capture, unchanged diagnostics, exit code, unique names and catalog checks.'
} finally {
    Remove-Item -LiteralPath $testRoot -Recurse -Force -ErrorAction SilentlyContinue
}
