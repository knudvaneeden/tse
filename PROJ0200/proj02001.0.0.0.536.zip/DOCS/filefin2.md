# FILEFIN2 archive filename search

PROJ0200 integration: 1.0.0.0.536

Choose **Search projects > U: FILEFIN2 filename search (including archives)...**.
Enter a filename mask, then one or more top directories separated by semicolons.
Choose Yes to search archive member names as well as physical filenames.
The directory search is recursive. This is a separate directory-based search;
the three project-scoped filename options continue to search physical filenames.

FILEFIN2 is based on upstream **1.0.0.0.40**. The freshly supplied
32-bit ff.dll and zip.dll builds are installed in the package root beside
zip_nested.ps1 and filefin2.ini. The updated C sources avoid context cleanup
inside the Windows DLL detach entry point. This is the upstream mitigation;
it does not establish that every possible editor crash has been resolved.

## Build and installation

1. Close TSE and extract the complete PROJ0200 package. This includes both DLLs.
2. Compile SAL with the normal `build.bat`; it now also compiles filefin2.s
   and copies filefin2.mac to the package root. No C compiler is needed.
3. Restart TSE after replacing DLLs, then choose the FILEFIN2 search entry.
   The launcher temporarily uses the package directory to help Windows locate
   the DLLs, then restores the previous working directory.

For users who want to rebuild the DLLs, the original C sources and optional
Borland C++ 5.5 build task remain included:

```bat
build_filefin2_dlls.bat "G:\LANGUAGE\COMPUTER\CPP\EMBARCADERO\BORLAND\BCC55\Bin\bcc32.exe"
```

Adjust the compiler path and its include/library configuration to your system.
The script builds both DLLs before installing them in the package root.
The normal SAL build also accepts this compiler as an optional second argument.
The supplied binaries have been checked as x86 PE DLLs; Windows SAL compilation
and runtime testing are still required.

## Archive formats and results

The supplied FILEFIN2 engine supports ZIP/JAR directly, plus TAR, TGZ and
mixed/nested ZIP/JAR/TAR/TGZ/RAR/7Z through zip_nested.ps1 and PowerShell.
RAR/7Z require compatible external tools. Configure `SevenZipExe` and `RarExe`
in the root filefin2.ini `[ArchiveTools]` section when automatic discovery does
not find them. These are FILEFIN2's own settings, separate from PROJ0200's
archive-content search settings. Nesting is limited to 8 levels; the helper
also applies per-member and total expansion limits (256 MiB and 512 MiB).

Matching uses FILEFIN2's original case-insensitive DOS-style wildcards, not
TSE regular expressions. The adapter retains the source's DLL API and search
engine. Filename and directory prompts now have separate persistent histories.
Escape/right-click cancels either prompt; cancelling the archive-choice menu
also stops the search. The original global Ctrl+Alt+Shift+F shortcut is omitted
to avoid changing the user's editor key bindings.

Results are displayed in the original FILEFIN2 text buffer with sizes, dates,
times, member names and archive provenance. This text buffer does not provide
PROJ0200's clickable-result navigation or archive-member extraction on click.

## Exclusions

Use Search projects > E: Edit search exclusions > for shared and FILEFIN2-only
rules. Save the file before searching. See [search_exclusions.md](search_exclusions.md).
Both the SAL adapter and nested-archive helper apply the rules; DLLs are unchanged.

## Simple Windows test

Create a directory containing an ordinary file named needle.txt and a ZIP with
another needle.txt member. Add a ZIP nested inside that ZIP containing a third
needle.txt. Search `needle.txt` in that directory and choose Yes for archives.
Expect the ordinary hit and member hits with their archive provenance. Repeat
with No: expect only the ordinary hit. Repeat with `NEEDLE.TXT` to check case
insensitivity, then test Escape at both prompts and at the archive-choice menu.

Unmodified uploaded sources, build script and original README are retained in
FILEFIN2/. The executable SAL adapter is SRC/MAC/filefin2.s (mirrored at root).
