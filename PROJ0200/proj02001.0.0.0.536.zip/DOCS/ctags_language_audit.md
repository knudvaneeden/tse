# PROJ0200 1.0.0.0.536 Ctags audit

The supplied compiler settings contain **88 rule files**, including duplicate
extensions and database dialects. **87 rule entries have a Ctags mapping**.
BrainF (`.b`) has no named procedures, variables or types, so no symbol parser
is claimed for it. A Hello World program without declarations can legitimately
produce no tags in any language.

Tested with Linux Exuberant Ctags 5.9~svn20110310 and Universal Ctags 5.9.0
(Debian 2021 snapshot): **85 symbol fixtures passed on each**, including the
61 older example rows and 24 new regression fixtures. No Ctags warnings/errors
were emitted. This tests tag generation; it does not test SAL compilation or
F12 interaction on Windows. The user's existing Windows Ctags executable is
retained via `ctags=` in `proj0200.ini`; no executable is replaced or bundled.
Exuberant 5.8 compatibility uses the existing langdef/langmap/regex syntax,
but this exact Windows version was not run here.

The active file is `proj0200_ctags_languages.conf` beside projstart.mac.
After installing, regenerate the tags through the Ctags menu. Merely replacing
the options file does not rebuild an existing tags database.

## Additions and fixes

21 declaration-oriented parsers were added. These are line-based POSIX regular
expressions, not complete language grammars: comments, multiline declarations,
quoted names, scopes and dialect-specific constructs may be missed or generate
false positives. Native parsers continue to cover the earlier languages.

- **ProjZig**: .zig. Declaration-oriented regex parser; not a complete grammar.
- **ProjClojure**: .clj, .cljs, .cljc, .edn. Declaration-oriented regex parser; not a complete grammar.
- **ProjElixir**: .ex, .exs. Declaration-oriented regex parser; not a complete grammar.
- **ProjJulia**: .jl. Declaration-oriented regex parser; not a complete grammar.
- **ProjAutoHotkey**: .ahk. Declaration-oriented regex parser; not a complete grammar.
- **ProjGroovy**: .groovy, .gvy, .gy, .gsh. Declaration-oriented regex parser; not a complete grammar.
- **ProjLean**: .lean. Declaration-oriented regex parser; not a complete grammar.
- **ProjForth**: .fth, .forth, .fs. Declaration-oriented regex parser; not a complete grammar.
- **ProjLogo**: .logo. Declaration-oriented regex parser; not a complete grammar.
- **ProjAPL**: .apl. UTF-8 simple niladic traditional functions and left-side assignments; dyadic signatures not covered.
- **ProjGraphviz**: .dot, .gv. Declaration-oriented regex parser; not a complete grammar.
- **ProjMermaid**: .mmd, .mermaid. Declaration-oriented regex parser; not a complete grammar.
- **ProjJSON**: .json, .jsonc. Declaration-oriented regex parser; not a complete grammar.
- **ProjXML**: .xml, .xsd, .xslt, .xsl. Named/id XML elements, schemas and XSLT templates; anonymous elements do not define symbols.
- **ProjDTD**: .dtd. Declaration-oriented regex parser; not a complete grammar.
- **ProjYAML**: .yaml, .yml. Declaration-oriented regex parser; not a complete grammar.
- **ProjBison**: .y, .yy, .yacc. Declaration-oriented regex parser; not a complete grammar.
- **ProjLex**: .l, .lex, .flex. Named scanner definitions only; use separate C source for full C implementation tags.
- **ProjSlickC**: .sli. Declaration-oriented regex parser; not a complete grammar.
- **ProjOctave**: .oct, .octave. Declaration-oriented regex parser; not a complete grammar.
- **ProjVBScript**: .vbs. Declaration-oriented regex parser; not a complete grammar.

Mappings added/repaired: NASM `.nasm`, Make `.mk`, Ant `.ant`, JavaScript
`.jsx`/`.mongodb`, MatLab `.m`, and SAL `.inc`/`.ui`. SAL procedure matching is
anchored, ignores commented-out PROC text, and does not double-tag typed PROC
names. Rust trait/type kind letters no longer conflict in Universal Ctags.
SQL now recognizes simple CREATE DATABASE/TABLE/VIEW/PROCEDURE/FUNCTION etc.,
including TEMPORARY and IF NOT EXISTS. BBC BASIC DEF PROC/FN and common Rocq
Definition/Theorem/Lemma constructs augment Basic and Verilog respectively.

Shared extensions keep deterministic behavior: `.v` uses Verilog plus the
Rocq patterns; `.bas` uses Basic plus BBC patterns; `.m` uses MatLab (also
appropriate for ordinary Octave functions). `.s`/`.si`/`.inc`/`.ui` select SAL;
use `.nasm`/`.asm` for assembly. `.xml` is generic named XML, while `.ant` or
`*.build.xml` selects Ant. `.ex` is Elixir; Slick-C uses `.sli`. No interactive
language chooser was added. A BASIC identifier's `$` remains part of its tag;
the old example inventory now correctly expects `Greet$`.

Named XML elements/templates, JSON/YAML keys, Graphviz/Mermaid nodes and Bison/Lex
rules are navigation targets rather than functions. APL patterns cover UTF-8
simple niladic traditional functions and assignments; general dyadic signatures
and other encodings are not promised. BrainF remains explicitly not applicable.

## Complete compiler-rule coverage

The parser column reports actual --list-maps output from Exuberant Ctags with
the package configuration. Mapping coverage does not prove full grammar support
or successful symbol extraction for every dialect.

| Compiler-rule file | Extension | Parser |
| --- | --- | --- |
| `comadabatcompilersetting_adb.txt` | `.adb` | ProjAda |
| `comantbatcompilersetting_ant.txt` | `.ant` | Ant |
| `comaplbatcompilersetting_apl.txt` | `.apl` | ProjAPL |
| `comaspbatcompilersetting_asp.txt` | `.asp` | Asp |
| `comassemblernasmbatcompilersetting_nasm.txt` | `.nasm` | Asm |
| `comautohotkeybatcompilersetting_ahk.txt` | `.ahk` | ProjAutoHotkey |
| `comawkbatcompilersetting_awk.txt` | `.awk` | Awk |
| `combbcbasicconsole_rules.txt` | `.bas` | Basic |
| `combbcbasicconsolebatcompilersetting_bas.txt` | `.bas` | Basic |
| `combisonbatcompilersetting_y.txt` | `.y` | ProjBison |
| `combrainfbatcompilersetting_b.txt` | `.b` | Not applicable: BrainF has no named symbols |
| `comcbatcompilersetting_c.txt` | `.c` | C |
| `comclojurebatcompilersetting_clj.txt` | `.clj` | ProjClojure |
| `comcmdbatcompilersetting_bat.txt` | `.bat` | DosBatch |
| `comcobolbatcompilersetting_cob.txt` | `.cob` | Cobol |
| `comcppbatcompilersetting_cpp.txt` | `.cpp` | C++ |
| `comcsharpbatcompilersetting_cs.txt` | `.cs` | C# |
| `comdartbatcompilersetting_dart.txt` | `.dart` | ProjDart |
| `comdatabaseaccessbatcompilersetting_sql.txt` | `.sql` | SQL |
| `comdatabaseinterbasebatcompilersetting_sql.txt` | `.sql` | SQL |
| `comdatabasemongodbbatcompilersetting_mongodb.txt` | `.mongodb` | JavaScript |
| `comdatabasemysqlbatcompilersetting_sql.txt` | `.sql` | SQL |
| `comdatabaseoraclebatcompilersetting_sql.txt` | `.sql` | SQL |
| `comdatabasepostgresqlbatcompilersetting_sql.txt` | `.sql` | SQL |
| `comdatabasesqlitebatcompilersetting_sql.txt` | `.sql` | SQL |
| `comdatabasetransactbatcompilersetting_sql.txt` | `.sql` | SQL |
| `comdelphibatcompilersetting_pas.txt` | `.pas` | Pascal |
| `comdtdbatcompilersetting_dtd.txt` | `.dtd` | ProjDTD |
| `comeiffelbatcompilersetting_e.txt` | `.e` | Eiffel |
| `comelixirbatcompilersetting_ex.txt` | `.ex` | ProjElixir |
| `comemacslispbatcompilersetting_el.txt` | `.el` | Lisp |
| `comerlangbatcompilersetting_erl.txt` | `.erl` | Erlang |
| `comflexbatcompilersetting_l.txt` | `.l` | ProjLex |
| `comforthbatcompilersetting_fth.txt` | `.fth` | ProjForth |
| `comfortranbatcompilersetting_f90.txt` | `.f90` | Fortran |
| `comfortranbatcompilersetting_for.txt` | `.for` | Fortran |
| `comgobatcompilersetting_go.txt` | `.go` | ProjGo |
| `comgraphvizbatcompilersetting_dot.txt` | `.dot` | ProjGraphviz |
| `comgroovybatcompilersetting_groovy.txt` | `.groovy` | ProjGroovy |
| `comhaskellbatcompilersetting_hs.txt` | `.hs` | ProjHaskell |
| `comhtmlbatcompilersetting_htm.txt` | `.html` | HTML |
| `comhtmlbatcompilersetting_html.txt` | `.htm` | HTML |
| `comjavabatcompilersetting_java.txt` | `.java` | Java |
| `comjavascriptbatcompilersetting_js.txt` | `.js` | JavaScript |
| `comjsonbatcompilersetting_json.txt` | `.json` | ProjJSON |
| `comjuliabatcompilersetting_jl.txt` | `.jl` | ProjJulia |
| `comkotlinbatcompilersetting_kt.txt` | `.kt` | ProjKotlin |
| `comlatexmiktexbatcompilersetting_tex.txt` | `.tex` | Tex |
| `comleanbatcompilersetting_lean.txt` | `.lean` | ProjLean |
| `comlispbatcompilersetting_lisp.txt` | `.lisp` | Lisp |
| `comlogobatcompilersetting_logo.txt` | `.logo` | ProjLogo |
| `comluabatcompilersetting_lua.txt` | `.lua` | Lua |
| `commakebatcompilersetting_mk.txt` | `.mk` | Make |
| `commaplebatcompilersetting_mpl.txt` | `.mpl` | ProjMaple |
| `commarkdownbatcompilersetting_md.txt` | `.md` | ProjMarkdown |
| `commathematicabatcompilersetting_wl.txt` | `.wl` | ProjMathematica |
| `commatlabbatcompilersetting_m.txt` | `.m` | MatLab, ObjectiveC |
| `commermaidbatcompilersetting_mmd.txt` | `.mmd` | ProjMermaid |
| `comnodejsbatcompilersetting_js.txt` | `.js` | JavaScript |
| `comocamlbatcompilersetting_ml.txt` | `.ml` | OCaml |
| `comoctavebatcompilersetting_oct.txt` | `.oct` | ProjOctave |
| `comperlbatcompilersetting_pl.txt` | `.pl` | Perl |
| `comphpbatcompilersetting_php.txt` | `.php` | PHP |
| `compowershellbatcompilersetting_ps1.txt` | `.ps1` | ProjPowerShell |
| `compythonbatcompilersetting_py.txt` | `.py` | Python |
| `comrbatcompilersetting_r.txt` | `.r` | ProjR |
| `comreactbatcompilersetting_jsx.txt` | `.jsx` | JavaScript |
| `comrocqbatcompilersetting_v.txt` | `.v` | Verilog |
| `comrubybatcompilersetting_rb.txt` | `.rb` | Ruby |
| `comrustbatcompilersetting_rs.txt` | `.rs` | ProjRust |
| `comscalabatcompilersetting_scala.txt` | `.scala` | ProjScala |
| `comschemebatcompilersetting_scm.txt` | `.scm` | Scheme |
| `comslickcbatcompilersetting_sli.txt` | `.sli` | ProjSlickC |
| `comswiftbatcompilersetting_swift.txt` | `.swift` | ProjSwift |
| `comtccbatcompilersetting_bat.txt` | `.bat` | DosBatch |
| `comtclbatcompilersetting_tcl.txt` | `.tcl` | Tcl |
| `comtsebatcompilersetting_s.txt` | `.s` | TSESal |
| `comtypescriptbatcompilersetting_ts.txt` | `.ts` | ProjTypeScript |
| `comvbscriptbatcompilersetting_vbs.txt` | `.vbs` | ProjVBScript |
| `comverilogbatcompilersetting_v.txt` | `.v` | Verilog |
| `comvhdlbatcompilersetting_vhd.txt` | `.vhd` | VHDL |
| `comvimscriptbatcompilersetting_vim.txt` | `.vim` | Vim |
| `comvisualbasicbatcompilersetting_bas.txt` | `.bas` | Basic |
| `comxmlbatcompilersetting_xml.txt` | `.xml` | ProjXML |
| `comxsdbatcompilersetting_xsd.txt` | `.xsd` | ProjXML |
| `comxsltbatcompilersetting_xslt.txt` | `.xslt` | ProjXML |
| `comyamlbatcompilersetting_yaml.txt` | `.yaml` | ProjYAML |
| `comzigbatcompilersetting_zig.txt` | `.zig` | ProjZig |

## Repeat the audit

From the PROJ0200 directory, using Python and your installed Ctags:

```text
python TOOLS/check_ctags_languages.py --ctags "C:\path\to\ctags.exe"
```

The tool checks every rule extension and each fixture's expected symbol, rejects
Ctags errors/warnings, and checks the SAL comment/duplicate regression. JSON
reports for both tested engines are in DOCS. New fixture cases are listed in
CTAGSEXAMPLES/ctags_audit_cases.json. The older F12-verified labels in the example
README remain historical user tests, not new runtime claims.

References: [Universal Ctags optlib documentation](https://docs.ctags.io/en/stable/optlib.html)
and [Ctags options](https://docs.ctags.io/en/stable/man/ctags.1.html).
