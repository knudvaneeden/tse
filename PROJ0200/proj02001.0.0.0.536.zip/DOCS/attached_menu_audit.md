# Attached-menu audit

The audit covers the current SAL menu definitions and their launch paths.
This is a source audit; native TSE layout and key handling require runtime testing.

Updated action-menu paths:

- Projects > Project, Search, Utility and Configure.
- Search projects > Find / replace in current file and Find across open files.
- Load projects > Load logs.
- Simple utility options > Compare now opens the attached comparison-method submenu.
- Merge action selection keeps parent menus visible; test/log/edit actions defer until the menu chain closes.
- The syntax conversion submenu is attached as implemented in the preceding update.

Existing attached project groups and their direct child menus retain their launch behavior.
Settings and project settings retain their existing stateful editing workflows.
List() file/project/language pickers, input/confirmation dialogs, and full tool/editor interfaces
(such as CmpFiles, mapping-set editing, Git/SVN browsers and AI choice lists) retain their own layouts.
They are not ordinary action submenus and may need a standalone view to show or edit their content.

Menu inventory (portable package sources; alternate TSE 2.6 definitions excluded):

| Source | Menu | Audit result |
| --- | --- | --- |
| `clip.si` | `ClipboardMenu` | Existing project submenu / local action chooser |
| `clipview.s` | `mYesNoMenu` | Tool/editor dialog or context menu; own layout retained |
| `clipview.s` | `PROJ_ClipboardViewerMenu` | Tool/editor dialog or context menu; own layout retained |
| `cmp2bkupreplacement.s` | `PROJ_CompareMethodMenu` | Attached comparison submenu; action deferred |
| `cmpfiles.s` | `FileMenu` | Attached worker submenu; action deferred |
| `cmpfiles.s` | `EditMenu` | Tool/editor dialog or context menu; own layout retained |
| `cmpfiles.s` | `ViewMenu` | Tool/editor dialog or context menu; own layout retained |
| `cmpfiles.s` | `SearchMenu` | Attached worker submenu; action deferred |
| `cmpfiles.s` | `HelpMenu` | Tool/editor dialog or context menu; own layout retained |
| `commands.si` | `OpenWith` | Tool/editor dialog or context menu; own layout retained |
| `ctags.si` | `ClassOrConst` | Existing project submenu / local action chooser |
| `ctags.si` | `ECTagMenu` | Existing project submenu / local action chooser |
| `ctags.si` | `BSCTagMenu` | Existing project submenu / local action chooser |
| `edtassoc.si` | `PROJ_AssocMouseMenu` | Tool/editor dialog or context menu; own layout retained |
| `filefin2.s` | `ZipSearch` | Tool/editor dialog or context menu; own layout retained |
| `filetypes.si` | `PROJ_TypeMouseMenu` | Tool/editor dialog or context menu; own layout retained |
| `flatfile.si` | `PromptMenu` | Tool/editor dialog or context menu; own layout retained |
| `gethelp.si` | `HelpStyleMenu` | Tool/editor dialog or context menu; own layout retained |
| `gethelp.si` | `HelpStyleMenu` | Tool/editor dialog or context menu; own layout retained |
| `gethelp.si` | `HelpFileEntryMenu` | Tool/editor dialog or context menu; own layout retained |
| `gethelp.si` | `SectionOptions` | Tool/editor dialog or context menu; own layout retained |
| `gethelp.si` | `EditingCommands` | Tool/editor dialog or context menu; own layout retained |
| `menus28.si` | `PROJ_CopyProjectMenu` | Existing project submenu / local action chooser |
| `menus28.si` | `PROJ_OpenProjectMenu` | Existing project submenu / local action chooser |
| `menus28.si` | `PROJ_ViewProjectMenu` | Existing project submenu / local action chooser |
| `menus28.si` | `PROJ_CloseProjectMenu` | Existing project submenu / local action chooser |
| `menus28.si` | `PROJ_ImportProjectMenu` | Existing project submenu / local action chooser |
| `menus28.si` | `PROJ_ExportProjectMenu` | Existing project submenu / local action chooser |
| `menus28.si` | `PROJ_CalculateProjectsMenu` | Existing project submenu / local action chooser |
| `menus28.si` | `PROJ_HelpMenu` | Existing project submenu / local action chooser |
| `menus28.si` | `PROJ_LoadProjectsMenu` | Existing project submenu / local action chooser |
| `menus28.si` | `PROJ_DeleteProjectsMenu` | Existing project submenu / local action chooser |
| `menus28.si` | `PROJ_ChangeProjectsMenu` | Existing project submenu / local action chooser |
| `menus28.si` | `PROJ_GetProjectsMenu` | Existing project submenu / local action chooser |
| `menus28.si` | `PROJ_SaveProjectsMenu` | Existing project submenu / local action chooser |
| `menus28.si` | `PROJ_ProjectsMenu` | Existing project submenu / local action chooser |
| `menus28.si` | `ProjectMenu` | Existing project submenu / local action chooser |
| `nameclip.s` | `clipboardmenu` | Tool/editor dialog or context menu; own layout retained |
| `nameclip.s` | `clipboard_other_menu` | Tool/editor dialog or context menu; own layout retained |
| `nameclip.s` | `clipboard_global_menu` | Tool/editor dialog or context menu; own layout retained |
| `nameclip.s` | `clipboard_settings_menu` | Tool/editor dialog or context menu; own layout retained |
| `pjfile.si` | `ProjectSettings` | Stateful project settings or picker/context menu |
| `pjfile.si` | `OptionsMenu` | Stateful project settings or picker/context menu |
| `pjfile.si` | `PROJ_PathMouseMenu` | Stateful project settings or picker/context menu |
| `pjfile.si` | `Retry` | Stateful project settings or picker/context menu |
| `pjfile.si` | `PROJ_ProjectListMouseMenu` | Stateful project settings or picker/context menu |
| `pjfile.si` | `OverwriteCancel` | Stateful project settings or picker/context menu |
| `pjfile.si` | `NoDebug` | Stateful project settings or picker/context menu |
| `pjfile.si` | `YesNoOnly` | Stateful project settings or picker/context menu |
| `pjfile.si` | `PROJ_AutoloadMouseMenu` | Stateful project settings or picker/context menu |
| `projcreate.s` | `PROJ_CreateMenu` | Existing project submenu / local action chooser |
| `projdialogsimpl.si` | `PROJ_InputMouseMenu` | Tool/editor dialog or context menu; own layout retained |
| `projdraw.s` | `PROJ_DiagramTypeMenu` | Existing project submenu / local action chooser |
| `projdraw.s` | `PROJ_DrawWorkerMenu` | Existing project submenu / local action chooser |
| `projfilenames.si` | `PROJ_SearchExclusionsMenu` | Existing project submenu / local action chooser |
| `projfilenames.si` | `PROJ_FilenameSearchMenu` | Existing project submenu / local action chooser |
| `projlogs.s` | `PROJ_LogMenu` | Attached worker submenu; action deferred |
| `projmerge.s` | `PROJ_MergeOptions` | Attached merge submenu; edit/test actions deferred |
| `projreadme.s` | `PROJ_ReadmeMouseMenu` | Tool/editor dialog or context menu; own layout retained |
| `projsession.s` | `PROJ_SessionListMouseMenu` | Tool/editor dialog or context menu; own layout retained |
| `projsession.s` | `PROJ_SearchChoiceMouseMenu` | Tool/editor dialog or context menu; own layout retained |
| `projsession.s` | `FileMenu` | Attached worker submenu; action deferred |
| `projsession.s` | `SearchMenu` | Attached worker submenu; action deferred |
| `projsession.s` | `PROJ_CurrentFileSearchMenu` | Attached worker submenu; action deferred |
| `projsession.s` | `PROJ_OpenFilesSearchMenu` | Attached worker submenu; action deferred |
| `projsession.s` | `UtilityMenu` | Attached worker submenu; action deferred |
| `projsession.s` | `PROJ_SimpleStartupMenu` | Attached worker submenu; action deferred |
| `projsession.s` | `ConfigMenu` | Tool/editor dialog or context menu; own layout retained |
| `projsession.s` | `HelpMenu` | Tool/editor dialog or context menu; own layout retained |
| `projsyncfg.s` | `PROJ_SyntaxConversionMenu` | Attached conversion submenu; action deferred |
| `scopeops.si` | `PROJ_RefreshMenu` | Existing project submenu / local action chooser |
| `searchcompile.s` | `SearchFieldMenu` | Tool/editor dialog or context menu; own layout retained |
| `seartekb.s` | `PROJ_AliasScope` | Tool/editor dialog or context menu; own layout retained |
| `syncfg.si` | `remove_dupe_menu` | Tool/editor dialog or context menu; own layout retained |
| `syncfg.si` | `dupe_word_prompt` | Tool/editor dialog or context menu; own layout retained |
| `syncfg.si` | `ConfigDelimetersMenu` | Tool/editor dialog or context menu; own layout retained |
| `syncfg.si` | `ConfigDirectiveMenu` | Tool/editor dialog or context menu; own layout retained |
| `syncfg.si` | `ConfigKeywordsMenu` | Tool/editor dialog or context menu; own layout retained |
| `syncfg.si` | `NumericFlagMenu` | Tool/editor dialog or context menu; own layout retained |
| `syncfg.si` | `NumericMenu` | Tool/editor dialog or context menu; own layout retained |
| `syncfg.si` | `PickOptMenu` | Tool/editor dialog or context menu; own layout retained |
| `syncfg.si` | `CursorLineMenu` | Tool/editor dialog or context menu; own layout retained |
| `syncfg.si` | `GetDirMenu` | Tool/editor dialog or context menu; own layout retained |
| `syncfg.si` | `WhichExtMenu` | Tool/editor dialog or context menu; own layout retained |
| `syncfg.si` | `OverWriteFile` | Tool/editor dialog or context menu; own layout retained |
| `syncfg.si` | `OpeningMenu` | Tool/editor dialog or context menu; own layout retained |
| `transfermenus.si` | `PROJ_SVNMenu` | Existing project submenu / local action chooser |
| `transfermenus.si` | `PROJ_GitMenu` | Existing project submenu / local action chooser |
| `transfermenus.si` | `PROJ_VersionControlMenu` | Existing project submenu / local action chooser |
| `transfermenus.si` | `PROJ_BackupMenu` | Existing project submenu / local action chooser |
| `transfermenus.si` | `PROJ_CompareProjectsMenu` | Existing project submenu / local action chooser |
| `transfermenus.si` | `PROJ_RunFilesMenu` | Existing project submenu / local action chooser |
| `transfermenus.si` | `PROJ_RunScriptsMenu` | Existing project submenu / local action chooser |
| `transfermenus.si` | `PROJ_RunMenu` | Existing project submenu / local action chooser |
