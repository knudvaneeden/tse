## Optional command-line script startup

1. Build the complete package with build.bat and restart TSE.
2. In PROJ0200 choose **Settings > Install command-line parameter capture...**.
   This calls AddAutoLoadMacro with the full package path to CmdLineParameter.mac
   and opens TSE's AutoLoad list for inspection. It uses isAutoLoaded()
   to skip existing registrations and to report the final state after editing. No copy to the TSE mac folder
   is required for the capture macro.
3. Verify the entry and place it before any PROJ startup entry if necessary.
   Accept the AutoLoad list, then close TSE completely.
4. Start a new editor process for testing. The capture macro must execute
   during AutoLoad, before TSE processes command-line macros and file arguments.

The same installation action can be run via Macro > Execute:

```text
F:\BBC\TAAL\PROJ0200\projstart.mac -InstallCmdLineParameter
```

For the independent test below, copy the compiled CmdLineParameterTest.mac
from PROJ0200 into TSE's mac folder (the capture macro is already registered
by its full path). Alternatively retain the original manual installation
instructions in CmdLineParameter.s.

First test the supplied macro independently:

```bat
g32.exe -eCmdLineParameterTest -p "Hello World!"
```

It should display Hello World! as a parameter, without opening -p or the text
as editor files. Then test PROJ0200 using your actual package path:

```bat
g32.exe -eF:\BBC\TAAL\PROJ0200\projstart.mac -p "F:\BBC\TAAL\PROJ0200\ddd.pjl"
```

If projstart.mac is installed in TSE's mac search path, the shorter form is:

```bat
g32.exe -eprojstart -p "F:\BBC\TAAL\PROJ0200\ddd.pjl"
```

The first captured parameter is the PJL script filename. The launcher and
proj.mac read the supplied CmdLineParameter:<macro>:1 global and consume it
once, so reopening the menu does not rerun the startup script. The original
-e macro spelling, optional .mac suffix and full path are respected. The
unscoped CmdLineParameter::1 form is supported too. Extra globals remain
available to other macros; PROJ0200 currently uses only parameter 1.
Explicit Macro > Execute arguments retain precedence. Relative script names
continue to resolve in the PROJ0200 directory. Existing in-editor use remains:

```text
projstart.mac ddd.pjl
```

The explicit installation action updates TSE's AutoLoad list. Ordinary PROJ
startup does not register macros. Without AutoLoad installation, -p interception
is not active. Command-line interception
and script execution still require confirmation in Windows TSE; start with
the independent test above.


Command-line diagnostics are appended to **proj0200_cmdline.log** in PROJ0200.
Entries have timestamps and INFO, WARN or ERROR severity. They record
AutoLoad registration, visible command-line text, global keys checked, captured
script filenames and launcher/PJL dispatch. A registration entry does not prove
that the capture macro executed during startup. PJL execution outcomes remain
in the separate timestamped pjlYYYYMMDDHHMMSS.log files.

Each trace entry identifies the receiving macro in brackets, for example
[projstart]. Global lookup lines include the exact macro-scoped key, such as
CmdLineParameter:projstart:1. With a full-path -e invocation, the exact supplied
macro path is part of the key, following the capture macro's documented format.

The supplied **ddd.pjl** is included in the PROJ0200 root. Its command-line
execution was confirmed in user testing. It opens and views projects, runs
timelog commands, uploads files in the TSE ring to Subversion automatically,
and pauses. Adapt its project directory and repository settings to your setup.
