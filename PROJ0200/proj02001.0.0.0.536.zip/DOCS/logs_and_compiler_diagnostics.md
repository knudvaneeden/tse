# Operation logs and compiler diagnostics

PROJ0200 1.0.0.0.536

Choose **Load projects > G: Load logs >**. The submenu includes PJL, SVN, GIT,
command-line, merge UI, merge engine, backup, Visustin, drawing ZIP, project
timelog and calculator logs, plus latest/browse/preserve compiler diagnostics.
**Browse all PROJ0200 logs...** lists root logs newest modification time first.
Opening any log closes the project menu, keeps the log selected and refreshes
the display after menu cleanup. Fixed-name logs open directly without running
the catalog command.

An absent log gives a message; using a feature creates its corresponding log.

| Category | File in the main PROJ0200 directory |
| --- | --- |
| Menu activity | proj0200_activity.log |
| PJL | pjlYYYYMMDDHHMMSS.log |
| SVN / GIT | proj0200_svn_log.txt / proj0200_git_log.txt |
| Command line | proj0200_cmdline.log |
| Merge UI | proj0200_merge_ui.log |
| Merge engine | mergeYYYYMMDDHHMMSS_identifier.log |
| Backup | proj0200_backup_log.txt |
| Visustin | proj0200_visustin_log.txt |
| Drawing ZIP | proj0200_draw_zip_log.txt |
| Timelog | projectname.LOG (recognized by its Project History header) |
| Calculator failures | proj0200_calculator_number.log |
| Preserved compiler diagnostics | compilerYYYYMMDDHHMMSS_unique-id.log |

## Automatic compiler preservation

The 62 bundled COM*.BAT files now have a small entry guard. When the batch file
is run from PROJ0200COMPILERS with the package helper in its parent directory,
it calls proj0200_compile_capture.bat. That dispatcher invokes the original
batch code with the same TSE arguments, then preserves parameter 6 (TSE's
&output& diagnostics file) through proj0200_logs.ps1. The original compiler
settings remain below the guard and can be edited as before. There is no
compiler executable change and no need to change the six-parameter rule syntax.

The preserved log is created with a unique name and CreateNew semantics. It
contains source/compiler information, the original batch return code and each
diagnostic line. Original ISO date/time prefixes are retained. Otherwise the
line gets capture completion time and INFO/WARN/ERROR based on its text.
This timestamp is explicitly labelled as capture time, not the time the
compiler originally emitted that diagnostic. The start time is recorded too.
Capture occurs after the original batch returns, including any pause or program
execution it normally performs. The batch return code is preserved even if
logging fails; text-based severity detection is only a convenience.

The file passed as &output& is never edited, deleted or timestamp-prefixed, so
TSE's error navigation continues to use its original diagnostics. A SHA256
comparison warns if its content did not change during invocation (possibly
stale output, or simply identical output). If the file is absent, the saved
log explains that rather than claiming no errors occurred. Collection streams
file contents and does not load all output into memory.

This applies only when TSE actually runs the **bundled guarded COM*.BAT**.
External older BAT copies, native compiler calls and SemWare's original SAL
rule are not automatically intercepted. Configure those rules to use the
bundled BAT where appropriate, or use **Preserve an existing compiler
diagnostics file...**. One-argument standalone BAT usage still runs, but may
not supply parameter 6; in that case there may be no diagnostics to preserve.
The guard falls back to the original code if the capture helper is unavailable.
No private compiler-setting or compiled compile.dat file is rewritten.

## Existing diagnostics outside PROJ0200

The [Logging] section of proj0200.ini has **compilerdiagnosticpaths**. Supply
semicolon-separated exact existing paths, for example:

```ini
[Logging]
compilerdiagnosticpaths=C:\TEMP\dddoutput.txt;C:\TEMP\TseGitTree.log
```

These files become visible in the compiler/all log browser and are included in
the all-logs merge. No external folders are scanned automatically. Environment
variables and package-relative paths are accepted. Missing optional files are
ignored. This makes a file available; use Preserve to retain an immutable
snapshot before the external tool overwrites it.

## Merge all PROJ0200 logs

**Merge projects > P: Merge all PROJ0200 logs** uses the same discovery:
root *.log, *.err, proj0200_*log*.txt, and configured external diagnostics.
The active merge journal, the chosen output and normal merge exclusions still
apply. Previously merged outputs named merged_* are excluded to avoid feeding
merged results back into another merge.

New backup, Visustin and drawing-ZIP diagnostics have complete date/time and
severity prefixes. New calculator PowerShell errors also have timestamps.
The existing SVN/GIT/PJL/command-line/merge timestamp formats remain supported.
There are five additional named timestamp formats for compiler, backup,
Visustin, drawing ZIP and calculator logs (76 total format definitions).

Some historical operation logs and native timelog summaries lack a complete
date and time per record. **Only the all-logs merge** supplies their file's last
modification time for otherwise undated leading lines. Those rows explicitly
say **[timestamp=file-modification; event time unknown]**. Once a native record
format is recognized, normal block handling resumes. Entirely undated files
get one labelled row per line, preserving them even with singleline=true.
The source file itself is not rewritten. Other merge scopes keep the previous
behavior of requiring recognizable timestamps.

No automatic date conversion can recover the actual event time from an
undated compiler message or a cumulative timelog duration. Treat fallback
rows as inspection data rather than historically exact event chronology.
For timestamped multiline blocks, singleline=true still keeps only their
first line; set singleline=false for the complete block.

## Windows checks

1. Rebuild and restart TSE. Open each available log through Load logs and check
   the missing-log message for a category not used yet.
2. Point a compiler rule at the package's COM*.BAT. Compile a known error test
   twice. Confirm two different compiler*.log files and unchanged error jumping.
3. Compare &output& with the saved copy's messages. Check paths containing spaces,
   an unchanged diagnostics file, a missing diagnostics file and a failed helper.
4. Use Preserve on a known external diagnostics file. Confirm it opens the new
   snapshot. Add that external path to compilerdiagnosticpaths and browse again.
5. Run backup, Visustin/drawing ZIP (where installed) and a calculator error;
   inspect their timestamps and severities.
6. Merge all logs to a new output with configured Cygwin sort.exe. Confirm
   compiler and operation records, explicitly marked undated rows, and exclusion
   of the active journal and prior merged_* outputs. Repeat the bundled merge
   test; it should retain its 43-record baseline.

Windows SAL, cmd.exe, PowerShell and compiler integration require runtime
verification on the user's system; this release has source/package checks.

An isolated Windows test is provided as DOCS/test_logging.ps1. Run it with
Windows PowerShell (`powershell.exe -NoProfile -ExecutionPolicy Bypass -File
DOCS\test_logging.ps1`). It uses a fake compiler in a temporary folder, checks
exit-code and raw-output preservation, unique snapshots and discovery, then
tests the merge if your configured Cygwin sort.exe exists. It does not invoke
TSE or a real compiler and deletes its temporary files afterward.
