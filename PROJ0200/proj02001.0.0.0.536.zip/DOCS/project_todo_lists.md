# Project todo lists

Choose **Create projects > Create a todo list for the current project**.
Open and save a project first. The filename prompt defaults to `<projectname>.tdl`
in the general project folder (beside its `.pj` file). You can choose another
folder and filename. The `.tdl` extension is added when necessary.

The selected location is stored in the project's `[PROJ0200Todo]` section.
The next invocation suggests that project's saved location. Existing files are
opened without replacing their contents, and an already open buffer keeps its
unsaved changes. A new list contains a project heading and an editable `[ ]`
task. Change `[ ]` to `[x]` when a task is complete, using normal TSE editing.
Save your todo edits before exporting or importing: transfer copies the saved
file on disk.

Project export and import include the referenced `.tdl` file. They copy it beside
the destination `.pj` with the destination project basename and store a relative
reference there. For example, `Books.pj` travels with `Books.tdl`. Keep these files
together when moving an exported project. Existing destination todo files require
confirmation before replacement. A missing or uncopyable referenced todo file
cancels that project's transfer and displays a warning. Other project file members
retain the existing export/import behavior.

This follows the original PROJECTS `ToDoList()` approach of opening a `.tdl` in
TSE, replacing its hard-coded filename with a configurable per-project location.
