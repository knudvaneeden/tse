# Search components upgrade

PROJ0200 1.0.0.0.536

| Component | Upstream version | Integration |
| --- | --- | --- |
| FILEFIN2 | 1.0.0.0.40 | Search projects > FILEFIN2 filename search; latest DLL sources and the user's new x86 binaries; named filename/directory histories; Yes/No archive results indicator. |
| GREPZIP | 1.0.0.0.27 | Existing current/project/all-project archive-aware searches retain the PROJ0200 scope protocol, with updated traversal, archive switch, completion marker and enumeration/error counts. |

FILEFIN2/ and GREPZIP/ contain unmodified upstream reference files. The active
root and SRC/MAC sources include the PROJ0200 exclusions, dialogs and history
integration. The standalone GREPZIP macro can also be run through Execute macro
as `grepzip`; build.bat compiles it and installs it beside grepzip_helper.ps1
and grepzip.ini. It retains its dedicated named histories and clickable results.
Choose **Search projects > &W: GREPZIP text search on disk (+ archives)...**
directly below FILEFIN2 to launch the full directory/file-specification search.
Its PJL equivalent is `file search text grepzip`. On completion the menus close
to show the results; cancelling an input returns to the menu.

## Install

1. Close all TSE instances before replacing ff.dll and zip.dll. DLLs already
   loaded into another process cannot be upgraded by merely purging a macro.
2. Extract the complete package, preserving your personal project/INI data as
   usual. Merge the new [GREPZIP] searcharchives setting if retaining an old INI.
3. Run build.bat with the sc32.exe matching your editor. Rebuild all workers.
4. Restart TSE and launch projstart. The marked-block preservation fix remains.

No C compiler is needed for the supplied binaries. Optional
build_filefin2_dlls.bat accepts the full path to Borland bcc32.exe and uses its
sibling include/lib folders. Standalone grepzip.ini controls the standalone
macro; scoped project searches use proj0200.ini and their own named histories.
The project scan paths/known extensions continue to define project membership.

## Behavior retained and updated

- Physical-file filename matching uses DOS wildcards, ignoring case.
- Archive text searches still use TSE regex flags, including i and x.
- Shared and engine-specific exclusion files still apply.
- New archive Yes/No input uses a separate history. No skips archive contents;
  physical files continue to be searched. Ring-buffer searches keep their
  existing buffer-based behavior so unsaved text remains searchable.
- A stale or incomplete scoped-search manifest is rejected. Completed manifests
  include enumerated file count, emitted entry count, error count and first error.
- Extracted archive traversal avoids directory reparse-point loops, retaining
  the PROJ0200 exclusion pruning and additional gzip/bz2/xz handling.
- Search result header rows have matching empty navigation records, so clicking
  a result still opens the corresponding file at its line and column.

## Dedicated input histories

All active native Ask and AskFilename call sites were audited. Remaining shared
or omitted histories in named clipboards, CmpFiles, keyboard search, syntax
configuration, project descriptions and command editing now use distinct stable
GetFreeHistory names. Generic syntax-item prompts additionally key by field/tag.
Existing PROJ_HistoryAsk and PROJ_HistoryAskFilename call sites keep their named
histories and persistent last-accepted defaults. A failed allocation is reported
instead of falling back to the shared _EDIT_HISTORY_. The dialog worker forwards
the dedicated history supplied by its caller. Upstream reference files remain
unchanged and are not the active integrated sources.

## Validation and Windows test checklist

Static checks cover x86 DLL exports, supplied-binary hashes, source mirrors,
search dependencies/build entries, named histories, fresh-manifest checks,
result-header mappings, menu help and PJL routes. SAL compilation and execution
of Windows PowerShell/DLLs must be verified in TSE on Windows.

- Search an ordinary directory, then a nested ZIP/TAR/JAR archive, with archive
  search Yes and No. Check displayed counts and exclusions.
- Repeat with different search/filename/directory inputs; reopen each prompt
  and confirm its own prior inputs are available. Cancel prompts with Escape.
- Search a project and an unsaved ring buffer; click hits and use CtrlAltShift G
  to return. Check a header click does not jump to an unrelated result.
- Repeat the Subversion upload test with a marked block through projstart.

## Shared history worker

Named-history lookups and prompt persistence now execute in projdialog.mac,
through the compact projhistory.si client. The backend is projhistoryimpl.si.
The history names, saved profile section, accepted values and cancellation flag
are unchanged. Rebuild the complete package so the client and worker match.

## Scoped filename searches

The current-project, all-projects and combined project/ring filename searches
include nested archive members (up to the existing 32-level limit). Archive
containers themselves can also match. They use FILEFIN2/shared exclusions and
case-insensitive DOS wildcards, preserving project membership rules for disk
files. Matching archive members remain in temporary buffers for clickable
navigation after extraction cleanup. The same external tools as scoped text
searches are required for archive formats beyond built-in ZIP/JAR support.
