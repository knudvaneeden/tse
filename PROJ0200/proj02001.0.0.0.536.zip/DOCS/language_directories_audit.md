# PROJ0200 1.0.0.0.536: five-directory audit

## Result and limits

88 compiler-rule files and 1,129 example-loader rows now resolve to existing
files. Every extension in the supplied computerlanguages.txt has a syntax text
through the supplied listsynext.txt. These two uploaded lists are preserved
byte-for-byte. All explicitly local BAT helper references resolve with Windows
case-insensitive path rules, and static GOTO targets exist.

34 execution/format checks passed on Linux, plus Node's syntax check of
comjavascript_check.cjs. No Windows BAT, PowerShell COM/Access execution, SAL
compilation, TSE regex-rule jumping or live syntax highlighting was run here.
No claim is made that all 88 compiler rules have been executed. Most external
compilers and databases are not installed in this environment. The installed
command named go is not a Go compiler (it rejects `run`), so Go was marked
unavailable rather than counting its failure as a source-code error.

## Fixes

- Preserved the newly supplied listsynext.txt and computerlanguages.txt.
- Added 114 explicit command/rule aliases to proj0200_examples.txt, providing
  the previously unregistered dialect-specific Hello World/settings/error links.
  Existing ambiguous-extension defaults remain in place.
- Restored the missing original comdatabaseaccess.ps1 from the user's saved file.
  It accepts the Source, OutputFile and Database parameters used by the BAT.
  Access itself still requires Windows/COM testing.
- Pointed COMPOWERSHELL.BAT self-test defaults at the bundled powershell examples
  in the sibling Hello World/error directories.
- Changed the C++ Hello World entry point to standard `int main()` returning 0;
  it now compiles and runs with g++.
- Corrected the swapped Extension values in the two HTML/HTM rule files.
- Corrected the YAML error example's comment: duplicate keys occur at lines
  7, 9 and 12. The payload reports these as errors even though ordinary
  yaml.safe_load accepts duplicate keys.
- Supplied mapped syntax aliases aspx.txt (from asp.txt), basicbbc.txt (from
  basicbbcc.txt), and ml.txt (from ocaml.txt). Added initial forth.txt, latex.txt,
  r.txt and ruby.txt definitions. The user's authoritative mapping is unchanged.
  The new definitions are basic keyword/comment/string configurations; their
  rendering has not been tested in TSE. pjl.txt is unchanged.

## Syntax compilation still required

All seven previously missing binaries have now been supplied by the user and included:

| Syntax text | Source |
| --- | --- |
| aspx.txt | Copy of bundled asp.txt |
| basicbbc.txt | Copy of bundled basicbbcc.txt |
| forth.txt | New initial definition |
| latex.txt | New initial definition |
| ml.txt | Copy of bundled ocaml.txt |
| r.txt | New initial definition |
| ruby.txt | New initial definition |

The supplied `aspx(1).syn` is installed as `aspx.syn`. All 88 syntax text files
now have corresponding SYN files, with no orphan binaries. The supplied binaries
were copied byte-for-byte. This verifies presence and identity, not binary format
validity, equivalence to the bundled text, or live rendering in TSE. In particular,
the newly supplied binaries may originate from different syntax text versions;
the initial text definitions are retained for editing and have not been proven
equivalent. No compiled SYN files were fabricated here.

## What was executed

| Tests | Count | Result |
| --- | ---: | --- |
| C and C++ Hello World compile/run, intentional error rejection | 6 | Passed |
| Python, JavaScript, Perl and Tcl Hello World/error pairs | 8 | Passed; error source locations observed |
| JSON, XML, DTD, XSD and XSLT valid/invalid format pairs | 10 | Passed; valid DTD/XSD instance validation and XSLT transformation also checked |
| Actual Python payloads extracted from COMDTD/COMXML/COMXSD/COMXSLT/COMYAML, valid/error pairs | 10 | Passed, exit codes 0/1 as expected |
| comjavascript_check.cjs syntax | 1 additional check | Passed with node --check |

Payload tests exercise the bundled Python implementation but bypass the Windows
BAT launch and path handling. This distinction is important for jump-to-error
and console behavior. Most error fixtures intentionally reveal one error at a
time; a single diagnostic is not evidence that the remaining errors are missing.

## Complete rule links

The matrix validates presence and dispatch links, not every language grammar.
SAL retains SemWare's original compiler command and rule as requested.

| Rule | Extension | Compiler | Hello World | Errors | Syntax text |
| --- | --- | --- | --- | --- | --- |
| comadabatcompilersetting_adb.txt | .adb | COMADA.BAT | helloworldada.adb | errorstestada.adb | ada.txt |
| comantbatcompilersetting_ant.txt | .ant | COMANT.BAT | helloworldant.ant | errorstestant.ant | ant.txt |
| comaplbatcompilersetting_apl.txt | .apl | COMAPL.BAT | helloworldapl.apl | errorstestapl.apl | apl.txt |
| comaspbatcompilersetting_asp.txt | .asp | COMASP.BAT | helloworldasp.asp | errorstestasp.asp | aspx.txt |
| comassemblernasmbatcompilersetting_nasm.txt | .nasm | COMASSEMBLERNASM.BAT | helloworldassemblernasm.nasm | errorstestassemblernasm.nasm | nasm.txt |
| comautohotkeybatcompilersetting_ahk.txt | .ahk | COMAUTOHOTKEY.BAT | helloworldautohotkey.ahk | errorstestautohotkey.ahk | ahk.txt |
| comawkbatcompilersetting_awk.txt | .awk | COMAWK.BAT | helloworldawk.awk | errorstestawk.awk | awk.txt |
| combbcbasicconsole_rules.txt | .bas | COMBBCBASICCONSOLE.BAT | helloworld.basicbbcc | errorstestbbcbasic.bas | basicbbc.txt |
| combbcbasicconsolebatcompilersetting_bas.txt | .bas | COMBBCBASICCONSOLE.BAT | helloworld.basicbbcc | errorstestbbcbasic.bas | basicbbc.txt |
| combisonbatcompilersetting_y.txt | .y | COMBISON.BAT | helloworldbison.y | errorstestbison.y | bison.txt |
| combrainfbatcompilersetting_b.txt | .b | COMBRAINF.BAT | helloworldbrainf.b | errorstestbrainf.b | brainf.txt |
| comcbatcompilersetting_c.txt | .c | COMC.BAT | helloworldc.c | errorstestc.c | c.txt |
| comclojurebatcompilersetting_clj.txt | .clj | COMCLOJURE.BAT | helloworldclojure.clj | errorstestclojure.clj | clojure.txt |
| comcmdbatcompilersetting_bat.txt | .bat | COMCMD.BAT | helloworldcmd.bat | errorstestcmd.bat | bat.txt |
| comcobolbatcompilersetting_cob.txt | .cob | COMCOBOL.BAT | helloworldcobol.cob | errorstestcobol.cob | cobol.txt |
| comcppbatcompilersetting_cpp.txt | .cpp | COMCPP.BAT | helloworldcpp.cpp | errorstestcpp.cpp | cpp.txt |
| comcsharpbatcompilersetting_cs.txt | .cs | COMCSHARP.BAT | helloworldcsharp.cs | errorstestcsharp.cs | cs.txt |
| comdartbatcompilersetting_dart.txt | .dart | COMDART.BAT | helloworlddart.dart | errorstestdart.dart | dart.txt |
| comdatabaseaccessbatcompilersetting_sql.txt | .sql | COMDATABASEACCESS.BAT | helloworlddatabaseaccess.sql | errorstestdatabaseaccess.sql | sql.txt |
| comdatabaseinterbasebatcompilersetting_sql.txt | .sql | COMDATABASEINTERBASE.BAT | helloworlddatabaseinterbase.sql | errorstestdatabaseinterbase.sql | sql.txt |
| comdatabasemongodbbatcompilersetting_mongodb.txt | .mongodb | COMDATABASEMONGODB.BAT | helloworlddatabasemongodb.mongodb | errorstestdatabasemongodb.mongodb | mongodb.txt |
| comdatabasemysqlbatcompilersetting_sql.txt | .sql | COMDATABASEMYSQL.BAT | helloworld.sqlmysql | errorstestdatabasemysql.sql | sql.txt |
| comdatabaseoraclebatcompilersetting_sql.txt | .sql | COMDATABASEORACLE.BAT | helloworlddatabaseoracle.sql | errorstestdatabaseoracle.sql | sql.txt |
| comdatabasepostgresqlbatcompilersetting_sql.txt | .sql | COMDATABASEPOSTGRESQL.BAT | helloworlddatabasepostgresql.sql | errorstestdatabasepostgresql.sql | sql.txt |
| comdatabasesqlitebatcompilersetting_sql.txt | .sql | COMDATABASESQLITE.BAT | helloworlddatabasesqlite.sql | errorstestdatabasesqlite.sql | sql.txt |
| comdatabasetransactbatcompilersetting_sql.txt | .sql | COMDATABASETRANSACT.BAT | helloworlddatabasetransact.sql | errorstestdatabasetransact.sql | sql.txt |
| comdelphibatcompilersetting_pas.txt | .pas | COMDELPHI.BAT | helloworlddelphi.pas | errorstestdelphi.pas | pas.txt |
| comdtdbatcompilersetting_dtd.txt | .dtd | COMDTD.BAT | helloworlddtd.dtd | errorstestdtd.dtd | dtd.txt |
| comeiffelbatcompilersetting_e.txt | .e | COMEIFFEL.BAT | helloworldeiffel.e | errorstesteiffel.e | eiffel.txt |
| comelixirbatcompilersetting_ex.txt | .ex | COMELIXIR.BAT | helloworld.exs | errorstestelixir.ex | elixir.txt |
| comemacslispbatcompilersetting_el.txt | .el | COMEMACSLISP.BAT | helloworldemacslisp.el | errorstestemacslisp.el | lispemacs.txt |
| comerlangbatcompilersetting_erl.txt | .erl | COMERLANG.BAT | helloworlderlang.erl | errorstesterlang.erl | erlang.txt |
| comflexbatcompilersetting_l.txt | .l | COMFLEX.BAT | helloworldflex.l | errorstestflex.l | flex.txt |
| comforthbatcompilersetting_fth.txt | .fth | COMFORTH.BAT | helloworldforth.fth | errorstestforth.fth | forth.txt |
| comfortranbatcompilersetting_f90.txt | .f90 | COMFORTRAN.BAT | helloworldfortran.f90 | errorstestfortran.f90 | for.txt |
| comfortranbatcompilersetting_for.txt | .for | COMFORTRAN.BAT | helloworldfortran.for | errorstestfortran.for | for.txt |
| comgobatcompilersetting_go.txt | .go | COMGO.BAT | helloworldgo.go | errorstestgo.go | go.txt |
| comgraphvizbatcompilersetting_dot.txt | .dot | COMGRAPHVIZ.BAT | helloworldgraphviz.dot | errorstestgraphviz.dot | dot.txt |
| comgroovybatcompilersetting_groovy.txt | .groovy | COMGROOVY.BAT | helloworldgroovy.groovy | errorstestgroovy.groovy | groovy.txt |
| comhaskellbatcompilersetting_hs.txt | .hs | COMHASKELL.BAT | helloworldhaskell.hs | errorstesthaskell.hs | haskell.txt |
| comhtmlbatcompilersetting_htm.txt | .htm | COMHTML.BAT | helloworldhtml.html | errorstesthtml.html | html.txt |
| comhtmlbatcompilersetting_html.txt | .html | COMHTML.BAT | helloworldhtml.html | errorstesthtml.html | html.txt |
| comjavabatcompilersetting_java.txt | .java | COMJAVA.BAT | helloworldjava.java | errorstestjava.java | java.txt |
| comjavascriptbatcompilersetting_js.txt | .js | COMJAVASCRIPT.BAT | helloworldjavascript.js | errorstestjavascript.js | js.txt |
| comjsonbatcompilersetting_json.txt | .json | COMJSON.BAT | helloworldjson.json | errorstestjson.json | json.txt |
| comjuliabatcompilersetting_jl.txt | .jl | COMJULIA.BAT | helloworldjulia.jl | errorstestjulia.jl | julia.txt |
| comkotlinbatcompilersetting_kt.txt | .kt | COMKOTLIN.BAT | helloworldkotlin.kt | errorstestkotlin.kt | kotlin.txt |
| comlatexmiktexbatcompilersetting_tex.txt | .tex | COMLATEXMIKTEX.BAT | helloworldlatexmiktex.tex | errorstestlatexmiktex.tex | latex.txt |
| comleanbatcompilersetting_lean.txt | .lean | COMLEAN.BAT | helloworldlean.lean | errorstestlean.lean | lean.txt |
| comlispbatcompilersetting_lisp.txt | .lisp | COMLISP.BAT | helloworldlisp.lisp | errorstestlisp.lisp | lisp.txt |
| comlogobatcompilersetting_logo.txt | .logo | COMLOGO.BAT | helloworldlogo.logo | errorstestlogo.logo | logo.txt |
| comluabatcompilersetting_lua.txt | .lua | COMLUA.BAT | helloworldlua.lua | errorstestlua.lua | lua.txt |
| commakebatcompilersetting_mk.txt | .mk | COMMAKE.BAT | helloworldmake.mk | errorstestmake.mk | make.txt |
| commaplebatcompilersetting_mpl.txt | .mpl | COMMAPLE.BAT | helloworldmaple.mpl | errorstestmaple.mpl | maple.txt |
| commarkdownbatcompilersetting_md.txt | .md | COMMARKDOWN.BAT | helloworldmarkdown.md | errorstestmarkdown.md | markdown.txt |
| commathematicabatcompilersetting_wl.txt | .wl | COMMATHEMATICA.BAT | helloworldmathematica.wl | errorstestmathematica.wl | mathematica.txt |
| commatlabbatcompilersetting_m.txt | .m | COMMATLAB.BAT | helloworldmatlab.m | errorstestmatlab.m | matlab.txt |
| commermaidbatcompilersetting_mmd.txt | .mmd | COMMERMAID.BAT | helloworldmermaid.mmd | errorstestmermaid.mmd | mermaid.txt |
| comnodejsbatcompilersetting_js.txt | .js | COMNODEJS.BAT | helloworldnodejs.js | errorstestnodejs.js | js.txt |
| comocamlbatcompilersetting_ml.txt | .ml | COMOCAML.BAT | helloworldocaml.ml | errorstestocaml.ml | ml.txt |
| comoctavebatcompilersetting_oct.txt | .oct | COMOCTAVE.BAT | helloworldoctave.oct | errorstestoctave.oct | octave.txt |
| comperlbatcompilersetting_pl.txt | .pl | COMPERL.BAT | helloworldperl.pl | errorstestperl.pl | perl.txt |
| comphpbatcompilersetting_php.txt | .php | COMPHP.BAT | helloworldphp.php | errorstestphp.php | php.txt |
| compowershellbatcompilersetting_ps1.txt | .ps1 | COMPOWERSHELL.BAT | helloworldpowershell.ps1 | errorstestpowershell.ps1 | powershell.txt |
| compythonbatcompilersetting_py.txt | .py | COMPYTHON.BAT | helloworldpython.py | errorstestpython.py | python.txt |
| comrbatcompilersetting_r.txt | .r | COMR.BAT | helloworldr.r | errorstestr.r | r.txt |
| comreactbatcompilersetting_jsx.txt | .jsx | COMREACT.BAT | helloworldreact.jsx | errorstestreact.jsx | react.txt |
| comrocqbatcompilersetting_v.txt | .v | COMROCQ.BAT | helloworldverilog.v | errorstestverilog.v | rocq.txt |
| comrubybatcompilersetting_rb.txt | .rb | COMRUBY.BAT | helloworldruby.rb | errorstestruby.rb | ruby.txt |
| comrustbatcompilersetting_rs.txt | .rs | COMRUST.BAT | helloworldrust.rs | errorstestrust.rs | rust.txt |
| comscalabatcompilersetting_scala.txt | .scala | COMSCALA.BAT | helloworldscala.scala | errorstestscala.scala | scala.txt |
| comschemebatcompilersetting_scm.txt | .scm | COMSCHEME.BAT | helloworldscheme.scm | errorstestscheme.scm | scheme.txt |
| comslickcbatcompilersetting_sli.txt | .sli | COMSLICKC.BAT | helloworldslickc.sli | errorstestslickc.sli | slickc.txt |
| comswiftbatcompilersetting_swift.txt | .swift | COMSWIFT.BAT | helloworldswift.swift | errorstestswift.swift | swift.txt |
| comtccbatcompilersetting_bat.txt | .bat | COMTCC.BAT | helloworldtcc.bat | errorstesttcc.bat | bat.txt |
| comtclbatcompilersetting_tcl.txt | .tcl | COMTCL.BAT | helloworldtcl.tcl | errorstesttcl.tcl | tcl.txt |
| comtsebatcompilersetting_s.txt | .s | SemWare compiler via &SCPath&&scfn& (original SAL rule) | helloworldtsesal.s | errorstesttsesal.s | sal.txt |
| comtypescriptbatcompilersetting_ts.txt | .ts | COMTYPESCRIPT.BAT | helloworldtypescript.ts | errorstesttypescript.ts | typescript.txt |
| comvbscriptbatcompilersetting_vbs.txt | .vbs | COMVBSCRIPT.BAT | helloworldvbscript.vbs | errorstestvbscript.vbs | vbs.txt |
| comverilogbatcompilersetting_v.txt | .v | COMVERILOG.BAT | helloworldverilog.v | errorstestverilog.v | rocq.txt |
| comvhdlbatcompilersetting_vhd.txt | .vhd | COMVHDL.BAT | helloworldvhdl.vhd | errorstestvhdl.vhd | vhd.txt |
| comvimscriptbatcompilersetting_vim.txt | .vim | COMVIMSCRIPT.BAT | helloworldvimscript.vim | errorstestvimscript.vim | vimscript.txt |
| comvisualbasicbatcompilersetting_bas.txt | .bas | COMVISUALBASIC.BAT | helloworld.basicbbcc | errorstestvisualbasic.bas | basicbbc.txt |
| comxmlbatcompilersetting_xml.txt | .xml | COMXML.BAT | helloworldxml.xml | errorstestxml.xml | xml.txt |
| comxsdbatcompilersetting_xsd.txt | .xsd | COMXSD.BAT | helloworldxsd.xsd | errorstestxsd.xsd | xsd.txt |
| comxsltbatcompilersetting_xslt.txt | .xslt | COMXSLT.BAT | helloworldxslt.xslt | errorstestxslt.xslt | xslt.txt |
| comyamlbatcompilersetting_yaml.txt | .yaml | COMYAML.BAT | helloworldyaml.yaml | errorstestyaml.yaml | yaml.txt |
| comzigbatcompilersetting_zig.txt | .zig | COMZIG.BAT | helloworldzig.zig | errorstestzig.zig | zig.txt |

## Repeat static checks

```text
python TOOLS/check_language_directories.py --report language_audit.json
```

Execution records and diagnostic excerpts are in language_examples_execution.json.
Directory counts after the fixes: 355 Hello World files, 88 compiler settings,
93 compiler/helper files, 89 intentional-error files and 176 syntax files.
