# Menu activity log

Every selectable option in PROJ0200's static popup menus has a shared audit
handler. The journal is **proj0200_activity.log** in the main package directory.
It appends records; it does not overwrite previous entries. The logger writes
directly to disk without creating editor buffers or opening a console.

Open it with **Load projects > Load logs > D: Load menu activity log**.
It is also included automatically in **Merge all PROJ0200 logs** and the log
browser. Its ISO date/time format is already supported by the merge engine.

Records contain the local date/time, INFO/WARN/ERROR, a session-local event
number, the source macro, the menu identifier and the selected option label.
Nested actions have their own event numbers. Example (illustrative):

```
2026-10-21 16:00:01 INFO [menu 12] Selected projsession: FileMenu > &S: Save
2026-10-21 16:00:01 INFO [menu 12] Handler returned: projsession: FileMenu > &S: Save
```

- INFO records selections and handler returns. Returning does not certify that
  an external operation succeeded: some handlers queue a worker or display a
  dialog. Deferred session/search execution receives a separate event.
- WARN records file operations returning false (which can mean cancellation)
  and warning dialogs without a recognized failure or informational message.
- ERROR records failed macro invocation and warning dialogs containing an
  explicit failure such as "cannot", "could not", "failed", "error:" or
  "not found". Informational saved/created/opened/added/removed/completed
  messages are recorded as INFO. A nested reported warning/error is reflected
  in its parent handler's return record.

This is activity tracing, not an exception detector: a native/editor/external
operation that silently fails cannot be assigned ERROR without a status from
that operation. Native TSE prompts, third-party menus outside the package,
and List() result rows do not become new audited menu options. Closing a menu
without selecting an option does not produce a selection record. Exiting TSE
or aborting a macro can leave a selection without a return record.

Records obey SAL's 255-character string limit; long messages can be truncated.
Dialog line breaks are replaced by spaces. The currently displayed journal
buffer may need reloading to see entries appended after it was opened.

## Build and check in TSE

1. Run build.bat with your SAL compiler. It builds projmenulog.mac before proj.
2. Choose a main-menu submenu, then a file/search/clipboard option; inspect the
   journal for selection and handler-return entries with the relevant label.
3. Cancel Open/Save As: the known file-operation callback should record WARN,
   not a claim of success.
4. Select a missing log or temporarily unavailable companion macro: inspect
   the warning/error entry. Restore any temporarily renamed macro afterwards.
5. Open the activity log using Load logs and merge all PROJ0200 logs. Confirm
   the activity records are present in chronological order.

No logging dialog is shown on normal menu selection. A logging failure is
reported on the message line and does not prevent the selected action.

## Main macro size

The main project module uses one compact action dispatcher, with contiguous
action codes. Descriptive labels are compiled into projmenulog.mac via
projmenunames.si. This avoids repeating logging entry/return code for each
main-module submenu. State-sensitive actions still execute in proj.mac; the
logging worker only resolves labels and appends records. Both generated
includes are supplied in SRC/MAC and mirrored at the package root.

Shared dialog and prompt implementations are compiled in projdialog.mac; the
public helper names remain available through projdialogs.si. The original
mouse hooks and return values are retained in projdialogsimpl.si. Command-line
reading and its trace writer live in projcmdworker.mac, with the caller's
macro filename and MacroCmdLine supplied explicitly. First-run setup executes
in pjfile.mac against the same shared project database. These workers are
built by build.bat and require no AutoLoad entries.

The main module now delegates shared status rendering, saved-window capture
and restoration, package INI lookup, environment expansion, path searching
token capitalization and function-regex lookup data to projcommon.mac. The original implementations
are retained there; other modules continue using their existing common.si
implementations. The new worker is built before proj.mac and copied by the
normal build. No AutoLoad entry is required.
