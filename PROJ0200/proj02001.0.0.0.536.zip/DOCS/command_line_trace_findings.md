# Command-line startup trace findings

The three supplied screenshots show the Settings installation action, the
AutoLoad list containing KeepBlinking followed by the full PROJ0200 path to
CmdLineParameter, and a successful isAutoLoaded confirmation. Registration
succeeded. They do not show the actual shell command or its startup result.
The screenshot timestamps were 20261020-021059, 021113 and 021132.

The supplied capture macro runs WhenLoaded, stores globals under its own
basename plus the original command-line -e token, removes -p arguments from
DosCmdLine, then purges itself. That early interception is required.

Our original reader reconstructed the named key exclusively from DosCmdLine.
If -e has already been consumed by TSE when projstart executes, the named key
was never tried; only CmdLineParameter::1 was checked. This is a possible
failure path identified by source inspection, not a confirmed runtime cause.
The updated reader keeps exact -e lookup first, then checks the running macro
name with/without .mac, its full path with/without .mac, and finally unscoped
parameter 1. Values are consumed only once. Explicit MacroCmdLine arguments
continue to override globals. Carlo Hogeveen's capture macro is unchanged.

Next Windows tests, after rebuilding and closing TSE completely:

1. Copy CmdLineParameterTest.mac into the TSE mac folder and run:
   g32.exe -eCmdLineParameterTest -p "Hello World!"
   Expect a Hello World! parameter dialog, with no -p/parameter file buffers.
2. Test the full launcher path:
   g32.exe -eF:\BBC\TAAL\PROJ0200\projstart.mac -p "F:\BBC\TAAL\PROJ0200\newscript.pjl"
   Use an existing simple script, for example containing pause "Startup test".
3. Reopen projstart from TSE without arguments. It must show the menu rather
   than execute the script again.

If step 1 fails, investigate AutoLoad execution/capture before PROJ integration.
If step 1 succeeds but step 2 fails, retain the exact shell command, the startup
screen and the relevant named global values for the next investigation.
Registration in AutoLoad alone does not prove the macro ran in a fresh process.

## Supplied startup log: 2026-10-20

At 04:21:57, DosCmdLine contained -eknudstar and no matching PROJ parameter
was found. This is consistent with ordinary startup without a PROJ script.
At 04:23:37, DosCmdLine contained -eknudstar followed by the full-path -e
invocation of projstart.mac. The corresponding full-path global contained
F:\BBC\TAAL\PROJ0200\newscript.pjl. The launcher logged that same filename
as the argument passed to proj. It logged proj.mac returning at 04:24:43.
Thus capture and launcher handoff succeeded in this run. The log contains no
[proj] Dispatching PJL entry, so it does not confirm interpreter dispatch or
script success. Check the loaded proj.mac version and the timestamped PJL log
in the next test before attributing any remaining issue to parameter capture.

Inspect this trace from Load projects > Load command-line log.
Settings > I: Install command-line parameter capture... registers the macro.
All Settings action labels now use unique leading &X: shortcut notation.

## Confirmed follow-up

User testing confirmed the missing-file warning for newscript.pjl, followed
by successful execution of ddd.pjl using the command-line launcher. The
supplied script is now included as ddd.pjl at the package root.
