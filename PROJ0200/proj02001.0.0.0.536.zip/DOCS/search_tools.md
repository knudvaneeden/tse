# Compiler, keyboard and alias searches

PROJ0200 integration 1.0.0.0.536

Under **Search projects >**:

- **O: Search in compiler options file** runs searchcompile.mac.
- **K: Search for keyboard assignments** runs keyassgn.mac.
- **L: Search in TSE alias file** runs seartekb.mac.

The normal build.bat compiles and installs these macros. They run in separate
macros to keep the main project macro below SAL's size limit.

## Compiler options

The supplied SEARCHCOMPILE searches the selected field of SemWare compile.dat
records. Choose the search expression, options (i=ignore case, x=regular
expression), extension filter (blank=all), compile.dat path and field.
A blank compile_dat setting defaults to LoadDir() + compile.dat. Editable initial
proposals are in proj0200.ini [SearchCompile], which overrides the legacy
searchcompile.ini keys when present. Each prompt has a separate
persistent history, which takes priority over its initial proposal. Escape
cancels prompts or field selection. Results show the matched compiler records.
This searches definitions in compile.dat; it does not recursively search BAT
files in PROJ0200COMPILERS.

## Keyboard assignments

The supplied KEYASSGN asks for the editor UI source and additional macro source
directories. The proj0200.ini [SearchKeyboardAssignments] section provides ui_source,
macro_directories and show_search_paths settings. A blank ui_source uses
a TSEPath lookup for tse.ui as a portable initial proposal;
the hardcoded personal Windows/Linux paths were removed. Additional source
directories initially point at the PROJ0200 macro directory. Both inputs have
separate persistent histories. Loaded macro source definitions take priority
over the selected UI fallback, as in the uploaded version.

Press a key or a two-key sequence to view its command, comment and definition
file. Escape or right-click exits the key-description popup. The utility needs
the relevant on-disk SAL/UI source files; it cannot recover arbitrary compiled
macro definitions when their source is unavailable. The original companion
KEYFIND and KEYTABLE files are retained in the package.

## TSE aliases

The uploaded seartekb.s searches a personal alias block in a configured job
file. Its original is preserved under SEARCH_TOOLS_REFERENCE/seartekb.s.
The portable adapter retains the full-file / alias-block choice but asks for
an existing alias file instead of using personal INI/global variables. It
remembers the path, expression and search options separately. The
[SearchTSEAliases] section of proj0200.ini sets alias_file, search_string,
search_options (default ix), scope (fullfile or aliasonly), begin_marker and
end_marker. Remembered prompt values take priority over INI proposals.
For an alias-block search it also asks for the begin and end marker expressions,
remembering each. The begin marker, end marker and all text outside that block
are excluded. A successful search displays the first matching position; no
match or missing markers produce a warning. Escape cancels input or scope
selection. This only searches text; it does not install or execute aliases.

The adapter removes the dependency on the local recogont helper and does not
install a global Ctrl+F12 binding. Per the user's instruction, searteka.s is
not included or invoked. All three search entries now use bundled macros.

## Validation

Packaging verifies menu accelerators, action routing, build entries, source
mirrors and include availability. Compile with Windows SAL and check each
utility against your own compile.dat, UI/macro source and alias file. In the
alias search, also test a bounded block, missing markers and an empty block.
