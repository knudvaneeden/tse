# Comparison of the supplied PROJECTS variants

The two supplied files are variants of **Ian Campbell's PROJECTS** session
manager. They are distinct from Chris Antos's PROJ v2.00, which underlies
PROJ0200. The package already integrates Campbell's session functionality as
`projsession.s`. Jose Baltieri's file was given priority in this comparison.
Original reference copies are retained in `PROJECTS_REFERENCE`; they are not
compiled or installed as competing startup macros.

| Significant Jose change | PROJ0200 disposition |
| --- | --- |
| Save/close selected file from the open-buffer list, then keep browsing | Added F2 Save and Del Close to View projects > List open files; ordinary unsaved-file confirmation retained. |
| Sort modified/unmodified files | Added Alt+C modified first and Ctrl+C modified last; retained a consistent `*` marker, correcting the variant's marker mismatch. |
| Initial buffer order and wider list | Buffer order is now initial default; list uses screen width and shows modified counts. Existing name/path/extension/reverse/recent sorts remain. |
| Date/time sorting in session snapshot picker | Added the variant's `DTn` order only while the picker is open; original TSE preference restored afterward. |
| Insert in snapshot picker to create a snapshot seeded by a file | Added Ins/GreyIns to ask for an existing file and save a session snapshot; it leaves TSE running. Existing ring files are also part of the snapshot. |
| Per-session recent files `.rec` | Added persistence of the package's own recent-files list with named and last-session snapshots; restored when reopening a snapshot; removed on confirmed snapshot deletion. No external `recent_files` global or clipboard copying required. |
| Public `mListOpenFiles` | Existing package menu and `projsession.mac -listopen` entry are retained. |
| `GPROJECTNAME` compatibility global | Added when the session worker publishes its snapshot identity. It names the current session snapshot; it does not replace the active Antos `.pj` project identity. |
| Save project / switch / save and exit; clipboard; search; audit bookmarks | Already exposed through corresponding PROJ0200 menus. |
| Additional warning messages when snapshot saving fails | Existing checked saves and visible error dialogs retained; added warning on failure to save recent-file sidecars. |
| Different personal hotkeys, eight-character name limit, PRJ-only startup trigger | Retained current PROJ0200 menus, long names and working startup/PJL behavior rather than replacing them with personal defaults. |
| Force history restoration despite editor-version mismatch (`ALLOW_CRASH=TRUE`) | Kept the existing compatibility check. |
| Disable editor settings restoration, remove timelog, remove append-project command | Kept the current features, which are already integrated. |
| Personal REP.MAC exclusion and EDITING/EXITING globals | Not adopted: these rely on another installation, and the variant sets EXITING=N immediately before checking whether it is Y. |
| Cosmetic identifier case / comments / menu reorganization | No functional differences to import. |

The macro-size correction moves active-project presentation and filename
completion into existing workers, and detailed PJL startup dispatch into
`projlaunchpjl.mac`. `build.bat` compiles and copies the new worker. This
reduces code and strings in `proj.mac`; SAL compilation and Windows runtime
verification must still be done with the user's compiler.

## Suggested checks

1. Build the complete package; confirm `proj.si` no longer reports Macro too long.
2. Open several buffers, modify one, then use View projects > List open files.
   Test Alt+C/Ctrl+C, F2 Save, Del Close with an unsaved-file prompt, Enter,
   and Escape. Cancelling the close must leave the buffer available.
3. Save a session snapshot. A `.rec` sidecar should appear in `PRJ` beside
   its `.PRJ` file, including `!!LAST!!.rec`. Restore the snapshot and test
   recent-file cycling with Alt+0/Ctrl+0 in the file list.
4. In the session snapshot picker, test Insert and cancel as well as create;
   TSE must stay open. Confirm the editor's normal PickFile sort is restored.
5. Re-test project filename completion, active-project view, and command-line
   PJL execution after the worker split.
