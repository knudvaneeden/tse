# PJL menu commands

Commands are case insensitive. These commands accept no extra arguments and use the same prompts and confirmations as their menu action. Existing parameterized PJL commands remain available. Completion means the action returned; review the activity log for its actual outcome. Save/exit actions can terminate TSE. Toggle commands invert the existing setting. Nested script execution is rejected; run another PJL script separately.

| Command | Menu action |
| --- | --- |
| `ai run` | PROJ_RunMenu > &A: Run AI... |
| `alias search tse` | Search in TSE alias file |
| `autoload add proj0200` | Add PROJ0200 to AutoLoad list |
| `autoload edit list` | View/edit TSE AutoLoad list... |
| `autoload remove proj0200` | Remove PROJ0200 from AutoLoad list |
| `bookmark audit forward` | Audit bookmarks - forward |
| `bookmark audit reverse` | Audit bookmarks - reverse |
| `bookmark view next` | Audit bookmarks forward |
| `bookmark view previous` | Audit bookmarks backward |
| `bsc find definition` | BSCTagMenu > Look up &Definition |
| `bsc find references` | BSCTagMenu > Look up &References |
| `bsc view bases` | BSCTagMenu > Bases... |
| `bsc view definition window` | BSCTagMenu >   in separate &window |
| `bsc view derivations` | BSCTagMenu > Derivations... |
| `bsc view members` | BSCTagMenu > Members... |
| `bsc view usedby` | BSCTagMenu > Used &by... |
| `bsc view uses` | BSCTagMenu > &Uses... |
| `calculator open` | PROJ_CalculateProjectsMenu > &C: Floating point calculator ... |
| `clipboard configure named` | ClipboardMenu > &N: Named TSE clipboards |
| `clipboard load tse` | ClipboardMenu > &L: Load TSE clipboard content from a file |
| `clipboard open menu` | ProjectMenu > &K: Clipboards |
| `clipboard save tse` | ClipboardMenu > &S: Save TSE current clipboard content to a file |
| `clipboard view named` | ClipboardMenu > &B: View named TSE clipboards |
| `clipboard view tse` | ClipboardMenu > &V: View the current TSE clipboard content |
| `clipboard view windows` | ClipboardMenu > &W: View the current Microsoft Windows clipboard content |
| `compiler search options` | Search in compiler options file |
| `ctags clear cache` | ECTagMenu > &Purge all CTags files from memory |
| `ctags find definition` | ECTagMenu > Goto &CTags definition |
| `ctags find definition cursor` | ECTagMenu > &Goto CTags definition at cursor |
| `ctags generate` | ECTagMenu > Ge&nerate CTags file |
| `ctags open menu` | ProjectMenu > &T: Ctags |
| `ctags toggle ignorecase` | ECTagMenu > &Ignore Case |
| `ctags view definition window` | ECTagMenu > &Display CTags definition in separate window |
| `diagram create file` | Create a Mermaid diagram of the current file (this needs ChatGPT AI) |
| `diagram create project` | Create a Mermaid diagram of the current project (this needs ChatGPT AI) |
| `diagram draw block visustin` | Draw a Visustin flow chart diagram of the current block |
| `diagram draw file visustin` | Draw a Visustin flow chart diagram of the current file |
| `diagram save clipboard` | Save returned Mermaid script from Windows clipboard... |
| `file backup current` | PROJ_BackupMenu > &C: Backup current file |
| `file backup ring` | PROJ_BackupMenu > &R: Backup all files in the TSE ring |
| `file close current` | PROJ_CloseProjectMenu > &F: Close current file |
| `file compare backup` | PROJ_CompareProjectsMenu > &2: Compare 2 FILES (current file and backup)... |
| `file delete saved ring` | PROJ_DeleteProjectsMenu > &N: Delete all saved files in the TSE ring without asking |
| `file find current` | Find... |
| `file find dialog current` | Find... |
| `file find dialog open` | Find... |
| `file find open` | Find... |
| `file find repeat current forward` | Repeat find - forward |
| `file find repeat current reverse` | Repeat find - reverse |
| `file find repeat dialog current forward` | Repeat find forward |
| `file find repeat dialog current reverse` | Repeat find reverse |
| `file find repeat open` | Repeat find forward |
| `file find repeat open forward` | Repeat find - forward |
| `file find repeat open reverse` | Repeat find - reverse |
| `file find reverse open` | Repeat find reverse |
| `file find word current forward` | Find word at cursor - forward |
| `file find word current reverse` | Find word at cursor - reverse |
| `file find word dialog current forward` | Find word at cursor forward |
| `file find word dialog current reverse` | Find word at cursor reverse |
| `file find word open` | Find word at cursor forward |
| `file find word open forward` | Find word at cursor - forward |
| `file find word open reverse` | Find word at cursor - reverse |
| `file find word reverse open` | Find word at cursor reverse |
| `file get filenames ring` | PROJ_GetProjectsMenu > &N: Get all filenames in the TSE ring |
| `file get name current` | PROJ_GetProjectsMenu > &C: Get current filename |
| `file load directory nonbinary` | PROJ_LoadProjectsMenu > &N: Load all non-binary files from a given directory into the TSE ring |
| `file load example bat` | PROJ_LoadProjectsMenu > &C: Load a compiler .BAT example for the current computer language |
| `file load example ctags` | PROJ_LoadProjectsMenu > &T: Load a ctags file example for the current computer language |
| `file load example errorstest` | PROJ_LoadProjectsMenu > &E: Load a error file example for the current computer language |
| `file load example helloworld` | PROJ_LoadProjectsMenu > &H: Load a helloworld file example for the current computer language |
| `file load example rule` | PROJ_LoadProjectsMenu > &R: Load a compiler rule example for the current computer language |
| `file load example syntaxhighlight` | PROJ_LoadProjectsMenu > &S: Load a syntax highlight file example for the current computer language |
| `file load filenames ring` | PROJ_LoadProjectsMenu > &O: Load all filenames in the file into the TSE ring |
| `file merge ring` | Merge all files in the TSE ring |
| `file open` | PROJ_LoadProjectsMenu > &D: Open a file... |
| `file reload current automatic` | PROJ_RefreshMenu > &C: Refresh current file without asking |
| `file reload current withprompt` | PROJ_RefreshMenu > &Q: Refresh current file with asking... |
| `file replace current` | Replace... |
| `file replace current dialog` | Current file: Replace ... |
| `file replace dialog current` | Replace... |
| `file replace multifile` | Replace... |
| `file replace open` | Replace across open files |
| `file run block nopause` | PROJ_RunFilesMenu > &D: Run block in current file - without pause ... |
| `file run block pause` | PROJ_RunFilesMenu > &B: Run block in current file - with pause ... |
| `file run current nopause` | PROJ_RunFilesMenu > &F: Run current file - without pause ... |
| `file run current pause` | PROJ_RunFilesMenu > &C: Run current file - with pause ... |
| `file run ring nopause` | PROJ_RunFilesMenu > &U: Run all files in TSE ring - without pause ... |
| `file run ring pause` | PROJ_RunFilesMenu > &T: Run all files in TSE ring - with pause ... |
| `file save as` | PROJ_SaveProjectsMenu > &A: Save current file as... |
| `file save close current` | PROJ_CloseProjectMenu > &S: Save and close current file |
| `file save current` | PROJ_SaveProjectsMenu > &F: Save current file |
| `file search current` | Current file: Find ... |
| `file search current archives` | GREPZIP Search in current file only (+ archives)... |
| `file search current dbrecord` | Search in current file... |
| `file search current grepziptse` | GREPZIPTSE search in current file (+ archives)... |
| `file search current multiline` | MULTIREGEX multi-line regular expression search in the current file... |
| `file search current regexengine` | Search in current file... |
| `file search current repeat forward` | Current file: Repeat find forward |
| `file search current repeat reverse` | Current file: Repeat find backward |
| `file search current word forward` | Current file: Find word at cursor forward |
| `file search current word reverse` | Current file: Find word at cursor backward |
| `file search disk multiline` | MULTIREGEX multi-line regular expression search on disk... |
| `file search filenames filefin2` | FILEFIN2 filename search on disk (+ archives)... |
| `file search filenames filefin2tse` | FILEFIN2TSE filename search on disk (+ archives)... |
| `file search open` | Open files: Across: Find ... |
| `file search open repeat forward` | Open files: Across: Repeat find forward |
| `file search open repeat reverse` | Open files: Across: Repeat find backward |
| `file search open word forward` | Open files: Across: Repeat find word at cursor forward |
| `file search open word reverse` | Open files: Across: Repeat find word at cursor backward |
| `file search ring` | Open files: Across: Search in all files in the TSE ring |
| `file search ring multiline` | MULTIREGEX multi-line regular expression search in all files in the TSE ring... |
| `file search text grepzip` | GREPZIP text search on disk (+ archives)... |
| `file search text grepziptse` | GREPZIPTSE text search on disk (+ archives)... |
| `file toggle previous` | PROJ_ViewProjectMenu > &T: Toggle to previous file |
| `file toggle recent` | Toggle to previous file |
| `file view next` | PROJ_ViewProjectMenu > &N: Next file |
| `file view previous` | PROJ_ViewProjectMenu > &B: Previous file |
| `file view recent` | PROJ_ViewProjectMenu > &L: List open / recent files... |
| `file view ring pause` | PROJ_ViewProjectMenu > &R: View all files in the TSE ring - with pause |
| `fileversioncontrol browse git` | PROJ_GitMenu > &R: Browse Git repository... |
| `fileversioncontrol browse subversion` | PROJ_SVNMenu > &R: Browse Subversion repository... |
| `fileversioncontrol open menu` | ProjectMenu > &F: File Version Control of projects |
| `help open` | ProjectMenu > &H: Help  <F1> |
| `help view about` | PROJ_HelpMenu > &A: About PROJ0200... |
| `help view browser` | PROJ_HelpMenu > &B: Read package help in browser... |
| `help view editor` | PROJ_HelpMenu > &R: Read package help in TSE... |
| `help view integration` | PROJ_HelpMenu > &I: Integration information |
| `help view original` | PROJ_HelpMenu > &H: Existing project help... |
| `keyboard search assignments` | Search for keyboard assignments |
| `language view loaded` | ProjectMenu > &U: Loaded computer languages... |
| `log browse all` | Browse all PROJ0200 logs... |
| `log browse compiler` | Browse saved compiler diagnostics... |
| `log browse timelog` | Browse project timelogs... |
| `log load activity` | Load menu activity log |
| `log load backup` | Load backup log |
| `log load commandline` | Load command-line log |
| `log load drawing zip` | Load drawing ZIP log |
| `log load git` | Load GIT log |
| `log load latest calculator` | Load latest calculator diagnostics |
| `log load latest compiler` | Load latest compiler diagnostics |
| `log load latest merge engine` | Load latest merge engine log |
| `log load latest pjl` | Load latest PJL log |
| `log load merge ui` | Load merge UI log |
| `log load search` | Load search diagnostics log |
| `log load svn` | Load SVN log |
| `log load visustin` | Load Visustin log |
| `log merge all` | Merge all PROJ0200 logs |
| `log merge tests` | Merge the 2 bundled test logs... |
| `log preserve compiler` | Preserve an existing compiler diagnostics file... |
| `log view timelog menu` | PROJ_ViewProjectMenu > &G: View timelog... |
| `merge edit exclusions` | Edit merge filename exclusions... |
| `merge edit formats` | Edit merge timestamp formats... |
| `merge edit types` | Edit merge log type overrides... |
| `project add files` | Add files or scan directories... |
| `project backup files all` | PROJ_BackupMenu > &A: Backup all files in all projects |
| `project backup files all ring` | PROJ_BackupMenu > &B: Backup all files in all projects + all files in the TSE ring |
| `project backup files current` | PROJ_BackupMenu > &P: Backup all files in current project |
| `project change interactive` | PROJ_ChangeProjectsMenu > &C: Change project... |
| `project close all` | PROJ_CloseProjectMenu > &A: Close all projects |
| `project close current` | PROJ_CloseProjectMenu > &C: Close project |
| `project close files saved all` | PROJ_CloseProjectMenu > &W: Close saved files from all projects... |
| `project close files saved current` | PROJ_CloseProjectMenu > &K: Close saved files in current project... |
| `project configure autoload directories` | PROJ_ChangeProjectsMenu > &P: Configure directory AutoLoad... |
| `project configure settings` | ProjectMenu > &Y: Project settings |
| `project copy` | Copy projects > &C: Copy project... |
| `project create interactive` | Create project... |
| `project create todo` | Create a todo list for the current project |
| `project delete` | PROJ_DeleteProjectsMenu > &D: Delete project... |
| `project edit associated extensions` | Associated extensions... |
| `project edit bsc database` | BSC database file... |
| `project edit ctags location` | CTags file location |
| `project edit ctags otherfiles` | Other CTags files... |
| `project edit description` | PROJ_ChangeProjectsMenu > &D: Edit project description... |
| `project edit known types` | Known file types... |
| `project edit openpath` | Open path... |
| `project export all` | PROJ_ExportProjectMenu > &A: Export All projects... |
| `project export current` | PROJ_ExportProjectMenu > &E: Export project... |
| `project get filenames all` | PROJ_GetProjectsMenu > &A: Get all filenames in all projects |
| `project get filenames current` | PROJ_GetProjectsMenu > &P: Get all filenames in current project |
| `project get names all interactive` | PROJ_GetProjectsMenu > &R: Get all project names |
| `project import all` | PROJ_ImportProjectMenu > &A: Import all projects... |
| `project import current` | PROJ_ImportProjectMenu > Import project... |
| `project load filenames current` | PROJ_LoadProjectsMenu > &F: Load all filenames in the file into current project |
| `project load files current` | PROJ_LoadProjectsMenu > &L: Load all files in current project |
| `project merge files all` | Merge all files in all projects |
| `project merge files all ring` | Merge all files in all projects + the TSE ring |
| `project merge files current` | Merge all files in the current project |
| `project open file` | PROJ_LoadProjectsMenu > &B: Open a project file by name... |
| `project open interactive` | Open projects > &O: Open project... |
| `project reload filelist` | PROJ_RefreshMenu > &F: Reload file list |
| `project reload files all automatic` | PROJ_RefreshMenu > &A: Refresh all files in all projects without asking |
| `project reload files all withprompt` | PROJ_RefreshMenu > &Y: Refresh all files in all projects with asking... |
| `project reload files current automatic` | PROJ_RefreshMenu > &N: Refresh all files in current project without asking |
| `project reload files current withprompt` | PROJ_RefreshMenu > &P: Refresh all files in current project with asking... |
| `project rename` | PROJ_ChangeProjectsMenu > &R: Rename project... |
| `project run files all nopause` | PROJ_RunFilesMenu > &G: Run all files in all projects - without pause ... |
| `project run files all pause` | PROJ_RunFilesMenu > &A: Run all files in all projects - with pause ... |
| `project run files current nopause` | PROJ_RunFilesMenu > &Q: Run all files in current project - without pause ... |
| `project run files current pause` | PROJ_RunFilesMenu > &P: Run all files in current project - with pause ... |
| `project save context switch` | PROJ_ChangeProjectsMenu > &G: Save context and switch project... |
| `project save interactive` | PROJ_SaveProjectsMenu > &P: Save current project |
| `project search filenames all` | FILEFIN2 Search filenames in all projects (+ archives)... |
| `project search filenames all filefin2tse` | FILEFIN2TSE search filenames in all projects (+ archives)... |
| `project search filenames all ring` | FILEFIN2 Search filenames in all projects + the TSE ring (+ archives)... |
| `project search filenames all ring filefin2tse` | FILEFIN2TSE search filenames in all projects + the TSE ring (+ archives)... |
| `project search filenames current` | FILEFIN2 Search filenames in current project (+ archives)... |
| `project search filenames current filefin2tse` | FILEFIN2TSE search filenames in current project (+ archives)... |
| `project search files all archives` | GREPZIP Search in all files in all projects (+ archives)... |
| `project search files all dbrecord` | Search in all files in all projects... |
| `project search files all grepziptse` | GREPZIPTSE search in all projects (+ archives)... |
| `project search files all multiline` | MULTIREGEX multi-line regular expression search in all files in all projects... |
| `project search files all regexengine` | Search in all files in all projects... |
| `project search files all ring archives` | GREPZIP Search in all files in all projects + the TSE ring (+ archives) |
| `project search files all ring dbrecord` | Search in all files in all projects + the TSE ring... |
| `project search files all ring grepziptse` | GREPZIPTSE search in all projects + the TSE ring (+ archives)... |
| `project search files all ring multiline` | MULTIREGEX multi-line regular expression search in all files in all projects + all files in the TSE ring... |
| `project search files all ring regexengine` | Search in all files in all projects + the TSE ring... |
| `project search files current archives` | GREPZIP Search in all files in current project (+ archives)... |
| `project search files current dbrecord` | Search in all files in current project... |
| `project search files current grepziptse` | GREPZIPTSE search in current project (+ archives)... |
| `project search files current multiline` | MULTIREGEX multi-line regular expression search in all files in the current project... |
| `project search files current regexengine` | Search in all files in current project... |
| `project search files current ring dbrecord` | Search in all files in current project + the TSE ring... |
| `project search files current ring regexengine` | Search in all files in current project + the TSE ring... |
| `project toggle ctags wholeproject` | CTags for whole project |
| `project view active` | PROJ_ViewProjectMenu > &V: View current active project... |
| `project view assigned paths` | View assigned directories or files to current project... |
| `project view files all pause` | PROJ_ViewProjectMenu > &P: View all files in all projects - with pause |
| `project view files current pause` | PROJ_ViewProjectMenu > &C: View all files in the current project - with pause |
| `project view list` | PROJ_ViewProjectMenu > &A: View all projects... |
| `script create` | Create script... |
| `script insert keyword` | PROJ_RunScriptsMenu > &K: Insert PJL keyword... |
| `script run interactive` | PROJ_RunScriptsMenu > &R: Run Project Language script (.pjl)... |
| `search configure exclusions dbrecord` | DATABASERECORDHEADERBODYSEARCH exclusions... |
| `search configure exclusions filefin2` | FILEFIN2 exclusions... |
| `search configure exclusions filefin2tse` | FILEFIN2TSE exclusions... |
| `search configure exclusions grepzip` | GREPZIP exclusions... |
| `search configure exclusions grepzipc` | GREPZIPC exclusions... |
| `search configure exclusions grepziptse` | GREPZIPTSE exclusions... |
| `search configure exclusions multiregex` | MULTIREGEX exclusions... |
| `search configure exclusions regexengine` | REGEXENGINE exclusions... |
| `search configure exclusions shared` | Shared search exclusions... |
| `search edit exclusions filefin2` | FILEFIN2 exclusions... |
| `search edit exclusions grepzip` | GREPZIP exclusions... |
| `search edit exclusions shared` | Shared search exclusions... |
| `search edit inclusions dbrecord` | DATABASERECORDHEADERBODYSEARCH inclusions... |
| `search edit inclusions filefin2` | FILEFIN2 inclusions... |
| `search edit inclusions filefin2tse` | FILEFIN2TSE inclusions... |
| `search edit inclusions grepzip` | GREPZIP inclusions... |
| `search edit inclusions grepzipc` | GREPZIPC inclusions... |
| `search edit inclusions grepziptse` | GREPZIPTSE inclusions... |
| `search edit inclusions multiregex` | MULTIREGEX inclusions... |
| `search edit inclusions regexengine` | REGEXENGINE inclusions... |
| `search edit inclusions shared` | Shared search inclusions... |
| `session append` | PROJ_LoadProjectsMenu > &A: Add another session snapshot's files... |
| `session append project` | Add another project's files... |
| `session close file` | Quit |
| `session compare backup` | Compare two files to backup |
| `session open configure menu` | Projects > &9: Configure |
| `session open file` | Open... |
| `session open project menu` | Projects > &6: Project |
| `session open search menu` | Projects > &7: Search |
| `session open utility menu` | Projects > &8: Utility |
| `session restore` | PROJ_LoadProjectsMenu > &S: Restore session snapshot... |
| `session save` | PROJ_SaveProjectsMenu > &S: Save session snapshot... |
| `session save close file` | Save and quit |
| `session save exit` | PROJ_SaveProjectsMenu > &E: Save session snapshot and exit TSE... |
| `session save file` | Save |
| `session save file as` | Save as... |
| `session save load project` | Save and load new project... |
| `session save project` | Save project... |
| `session save project exit` | Save project and exit... |
| `session save switch` | PROJ_LoadProjectsMenu > &W: Save and switch session... |
| `session view clipboard` | View clipboard... |
| `session view file next` | Next |
| `session view file previous` | Previous |
| `session view files open` | List open files... |
| `session view timelog` | View timelog... |
| `settings configure autoload paths` | AutoLoad project paths... |
| `settings edit associated extensions default` | Associated extensions... |
| `settings edit known types default` | Known file types... |
| `settings edit projectdirectory` | PROJ subdirectory |
| `settings install commandline` | Install command-line parameter capture... |
| `settings open` | ProjectMenu > &Q: Settings |
| `settings toggle autoload` | AutoLoad project |
| `settings toggle autosave` | AutoSave project |
| `settings toggle localprojects` | Local projects |
| `settings toggle openlast` | Open last project |
| `settings toggle promptempty` | Prompt to open project if empty command line |
| `settings toggle restoredirectories` | Restore working directories |
| `syntax configure mappings` | PROJ_ChangeProjectsMenu > &H: Configure syntax highlight mapping sets |
| `syntax convert current binarytotext` | binarytotext - current loaded file |
| `syntax convert current texttobinary` | texttobinary - current loaded file |
| `syntax convert directory binarytotext` | directorybinarytotext - .syn to .txt |
| `syntax convert directory texttobinary` | directorytexttobinary - .txt to .syn |
| `syntax convert file binarytotext` | filebinarytotext - .syn to .txt |
| `syntax convert file texttobinary` | filetexttobinary - .txt to .syn |
| `syntax convert interactive` | PROJ_ChangeProjectsMenu > &S: Convert syntax highlight .txt to .syn or .syn to .txt |
| `template search` | Search in templates... |
