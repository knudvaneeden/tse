## Save context and switch project

Use **Change projects > G: Save context and switch project...**, or press
**Ctrl+K then G**. A context is a saved `.PRJ` session snapshot under `PRJ`,
independent of computer language. Create destination contexts first with
**Save projects > Save session snapshot...**.

The action selects and validates the destination before saving. It requires
an existing destination snapshot with the same TSE version, existing listed
files, and its `.CLP` clipboard/history sidecar. It then saves any modified
buffers (asking for filenames for unnamed buffers), asks for the outgoing
snapshot name, saves its state, and closes the saved outgoing buffers before
restoring the destination. A cancelled or failed save stops the switch.
The outgoing name must differ from the destination. Select a named destination;
`!!LAST!!` is updated by saving the outgoing context and cannot be the target.

Restored state uses the original session implementation: open files and
positions, bookmarks/selections, native TSE histories, the main TSE clipboard
and legacy A-Z clipboards, recent-file tracking, editor settings and recorded
keyboard macros. Outgoing keyboard macros are saved through the native checked
`SaveKeyMacro` call. Keyboard macros and clipboard contents are cleared before
destination restoration, so absent destination entries do not retain outgoing
contents. The Windows clipboard and separate NAMECLIP arbitrary named
clipboards are outside this exchange. Package INI/profile defaults remain
shared settings. The action does not change the active Antos `.PJ` database
record; **Change project...** remains the separate `.PJ` membership operation.

If restoration reports failure after closure, the coordinator attempts to
restore the saved outgoing snapshot. This is a recovery attempt, not an atomic
filesystem transaction; already completed source-file saves are retained.
TCC console/directory/history integration is not included.

## PROJECTS keyboard compatibility

The requested original and Jose aliases are active after running
`projstart.mac`. Normal direct `proj.mac` startup also initializes the shortcut
worker. The resident `projcontextkeys.mac` can be executed again after INI edits.
No personal startup macro or separate AutoLoad entry is required.

| Keys | Action |
| --- | --- |
| Ctrl+K then M | Open the PROJ0200 main menu |
| Ctrl+K then P | Save session context (original PROJECTS binding) |
| Ctrl+K then A | Save session context and exit TSE (original binding) |
| Ctrl+K then J | Save session context (Jose alias) |
| Ctrl+K then Z | Save session context and exit TSE (Jose alias) |
| Ctrl+K then G | Save context and switch project |
| Ctrl+keypad Plus / Minus | Next / previous audit bookmark (Jose) |
| Ctrl+keypad Multiply | Toggle previous buffer (Jose) |
| Ctrl+K then F1 | View the native history system buffer (Jose) |

`projectcontextkeys=true` enables the original keys and Jose aliases by default.
Set it to `false` to retain your own bindings. `contextswitchkey=true` separately
enables Ctrl+K then G; set it to `false` to use only the menu action. These two-key
sequences mean press Ctrl+K, release, then press the indicated letter.
Commented example bindings in the supplied sources remain examples; they are
not activated. Ctrl+K,G was commented as an append action in the original;
its active Jose meaning and the requested switch action take priority here.

The open-file list preserves **Alt+N/P/E/B** for ascending name/path/extension/
buffer sorts, **Ctrl+N/P/E/B** for reverse sorts, **Alt+0/Ctrl+0** for recent
cycling, and **F1** for help. Alt+P has been corrected from the integration's
accidental Alt+[ binding. Jose's **Alt+C/Ctrl+C**, **F2**, and **Del** additions
remain available. The session picker retains Del/GreyDel deletion and Jose's
Ins/GreyIns creation. Enter/Escape retain their usual list/picker behavior.

## Context-switch checks on Windows

1. Rebuild the full package and restart TSE through `projstart.mac`.
2. Create two named contexts, A and B, using different files, cursor positions,
   clipboard text and recorded keyboard macros. Save both snapshots.
3. Switch from A to B using the new menu action; save outgoing as A. Verify
   B's files, positions, clipboard, histories, recent cycle and key macros.
4. Switch back with Ctrl+K,G. Verify A's state returns and B files are closed.
5. Cancel the destination picker and the outgoing save prompt. Try a missing
   sidecar and a different-version snapshot. No destination should be loaded.
6. Exercise an unnamed modified buffer, a cancelled Save As, and a read-only
   save failure. Confirm the switch stops and edited text remains available.
7. Test the original M/P/A bindings and Jose J/Z/keypad aliases. Verify
   Alt+P and Ctrl+P sort the open-file list by path in opposite directions.
8. Test with no recorded keyboard macros as well as with multiple macros;
   native keyboard save failure must stop the switch visibly.

Source/dispatch/key-coverage checks are performed during packaging. SAL
compilation and these runtime checks still require the Windows TSE installation.

