// helloworldreact.jsx - version 1.0.0.0.8 - 2026-11-06
// Save anywhere; COMREACT checks this file before copying to src/App.js.
export default function App() {
  console.log("Hello world from React!");
  return <h1>Hello world from React!</h1>;
}
