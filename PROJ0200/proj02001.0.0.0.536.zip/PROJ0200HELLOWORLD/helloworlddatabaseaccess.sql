-- helloworlddatabaseaccess.sql version 1.0.0.0.8
-- The helper removes comment lines before sending SQL to Access.
SELECT "Hello world!" AS Greeting;
