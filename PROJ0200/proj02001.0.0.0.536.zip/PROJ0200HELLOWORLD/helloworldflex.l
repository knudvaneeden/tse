n/* helloworld.l version 1.0.0.0.8 - OpenAI ChatGPT GPT-6 */
%option noyywrap nounistd never-interactive
%{
#include <stdio.h>
%}
%%
hello       { puts("Hello world from FLEX!"); }
[ \t\r\n]+  ;
.           ;
%%
int main(void)
{
    YY_BUFFER_STATE buffer = yy_scan_string("hello\n");
    yylex();
    yy_delete_buffer(buffer);
    return 0;
}
