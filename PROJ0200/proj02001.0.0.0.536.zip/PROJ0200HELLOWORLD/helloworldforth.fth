\ helloworldforth.fth - version 1.0.0.0.8
\ Date: 2026-11-05
\ COMFORTH.BAT adds -e bye after this file.
: hello ( -- )
  ." Hello world from Gforth!" cr
;
hello
