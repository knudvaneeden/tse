BEGIN {
 print "Hello world"
}
