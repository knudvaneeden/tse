-- helloworlddatabasetransact.sql version 1.0.0.0.13
-- Prepared with OpenAI ChatGPT GPT-6.1 Sol.
-- One batch; no database objects or data are changed.
SET NOCOUNT ON;
PRINT 'Hello world from Transact-SQL!';
SELECT 'Hello world from SQL Server!' AS Greeting;
