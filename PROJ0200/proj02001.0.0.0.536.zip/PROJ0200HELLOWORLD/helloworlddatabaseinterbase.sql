/* helloworlddatabaseinterbase.sql version 1.0.0.0.11 */
/* Requires a connection to an existing InterBase database. */
SELECT 'Hello world from InterBase!' AS greeting FROM RDB$DATABASE;
