# helloworldapl.apl version 1.0.0.0.10
'Hello World from APL!'
)OFF
