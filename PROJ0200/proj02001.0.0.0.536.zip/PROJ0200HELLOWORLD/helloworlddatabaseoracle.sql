-- helloworlddatabaseoracle.sql version 1.0.0.0.9
-- Knud van Eeden / OpenAI ChatGPT GPT-6
BEGIN
    DBMS_OUTPUT.PUT_LINE('Hello from Oracle PL/SQL');
END;
/
