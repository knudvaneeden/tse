// helloworldnodejs.js - version 1.0.0.0.9 - 2026-11-02
// Save in f:\bbc\taal\proj0200\helloworldnodejs.js
// Expected: Hello world! once, no errors, exit code 0.
"use strict";
console.log("Hello world!");
