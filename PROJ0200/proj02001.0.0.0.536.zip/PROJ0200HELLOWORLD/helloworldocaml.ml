(* helloworld.ml version 1.0.0.0.7 - OpenAI GPT-6 *)
let () = print_endline "Hello from OCaml!"
