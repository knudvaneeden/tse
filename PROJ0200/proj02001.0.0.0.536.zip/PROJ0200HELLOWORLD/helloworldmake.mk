# helloworldmake.mk version 1.0.0.0.8 - OpenAI ChatGPT / Codex
# Borland MAKE; run: COMMAKE.BAT "helloworldmake.mk"
# Recipe begins with a real TAB. No C/C++ compiler is needed.
all:
	@echo Hello World from Borland MAKE!
