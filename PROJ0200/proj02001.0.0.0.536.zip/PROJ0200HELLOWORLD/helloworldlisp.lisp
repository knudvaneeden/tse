; helloworld.lisp version 1.0.0.0.7 - OpenAI GPT-6
; Install: F:\BBC\TAAL\PROJ0200HELLOWORLD\helloworld.lisp
(format t "Hello from Common Lisp!~%")
