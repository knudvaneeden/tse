-- helloworldDATABASEPOSTGRESQL.sql version 1.0.0.0.8
-- OpenAI ChatGPT GPT-6.1
SELECT 'Hello, world!' AS message;
