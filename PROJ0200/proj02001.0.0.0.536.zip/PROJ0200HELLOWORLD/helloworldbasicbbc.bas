PRINT "Hello world"
