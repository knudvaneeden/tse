param(
    [string]$Specification = '',
    [string]$Manifest = (Join-Path $env:TEMP 'grepzip_manifest.txt'),
    [string]$SearchArchives = 'yes',
    [switch]$Cleanup
)

$searchArchivesEnabled = @('yes', 'y', 'true', '1', 'on') -contains `
                         $SearchArchives.ToLowerInvariant()

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$sevenZipConfigured = ''
$rarConfigured = ''
$archiveIniSection = ''
$sevenZipRead = $false
$rarRead = $false
$iniPath = Join-Path $PSScriptRoot 'grepzip.ini'
if (Test-Path -LiteralPath $iniPath -PathType Leaf) {
    foreach ($iniLine in [IO.File]::ReadAllLines($iniPath)) {
        $trimmed = $iniLine.Trim()
        if ($trimmed -match '^\[([^]]+)\]$') {
            $archiveIniSection = $Matches[1].ToLowerInvariant()
        } elseif (($archiveIniSection -eq 'archivetools') -and
                  (-not $sevenZipRead) -and
                  ($trimmed -match '^SevenZipExecutable\s*=\s*(.*)$')) {
            $sevenZipConfigured = [Environment]::ExpandEnvironmentVariables(
                $Matches[1].Trim().Trim('"'))
            $sevenZipRead = $true
        } elseif (($archiveIniSection -eq 'archivetools') -and
                  (-not $rarRead) -and
                  ($trimmed -match '^RarExecutable\s*=\s*(.*)$')) {
            $rarConfigured = [Environment]::ExpandEnvironmentVariables(
                $Matches[1].Trim().Trim('"'))
            $rarRead = $true
        }
    }
}

if (Test-Path -LiteralPath $Manifest) {
    $first = [IO.File]::ReadLines($Manifest) | Select-Object -First 1
    if ($first -and $first.StartsWith('#WORK=')) {
        $oldWork = $first.Substring(6)
        if ($oldWork -and (Test-Path -LiteralPath $oldWork)) {
            Remove-Item -LiteralPath $oldWork -Recurse -Force `
                        -ErrorAction SilentlyContinue
        }
    }
    Remove-Item -LiteralPath $Manifest -Force -ErrorAction SilentlyContinue
}
if ($Cleanup) {
    exit 0
}

$work = Join-Path $env:TEMP ('grepzip_' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work | Out-Null
$writer = New-Object IO.StreamWriter($Manifest, $false, [Text.Encoding]::Default)
$writer.WriteLine('#WORK=' + $work)
$sourceFilesEnumerated = 0
$manifestEntriesWritten = 0
$helperErrorCount = 0
$firstHelperError = ''

function Record-HelperError([string]$message) {
    $script:helperErrorCount++
    if ([string]::IsNullOrEmpty($script:firstHelperError)) {
        $clean = $message.Replace("`r", ' ').Replace("`n", ' ').Replace("`t", ' ')
        if ($clean.Length -gt 160) { $clean = $clean.Substring(0, 160) }
        $script:firstHelperError = $clean
    }
}

function Add-SearchFile([string]$disk, [string]$display) {
    if ($display.IndexOf("`t") -ge 0) { $display = $display.Replace("`t", ' ') }
    $writer.WriteLine($disk + "`t" + $display)
    $script:manifestEntriesWritten++
}

function Get-ArchiveKind([string]$name) {
    $lower = $name.ToLowerInvariant()
    if ($lower.EndsWith('.zip') -or $lower.EndsWith('.jar')) { return 'zip' }
    if ($lower.EndsWith('.tgz') -or $lower.EndsWith('.tar.gz')) { return 'tgz' }
    if ($lower.EndsWith('.tar')) { return 'tar' }
    if ($lower.EndsWith('.7z')) { return '7z' }
    if ($lower.EndsWith('.rar')) { return 'rar' }
    return ''
}

function Get-SevenZipCommand() {
    if ($sevenZipConfigured -and
        (Test-Path -LiteralPath $sevenZipConfigured -PathType Leaf)) {
        return $sevenZipConfigured
    }
    $command = Get-Command 7z.exe -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    if ($env:ProgramFiles) {
        $candidate = Join-Path $env:ProgramFiles '7-Zip\7z.exe'
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }
    $programFilesX86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
    if ($programFilesX86) {
        $candidate = Join-Path $programFilesX86 '7-Zip\7z.exe'
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }
    return ''
}

function Get-RarCommand() {
    if ($rarConfigured -and
        (Test-Path -LiteralPath $rarConfigured -PathType Leaf)) {
        return $rarConfigured
    }
    $command = Get-Command rar.exe -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    if ($env:ProgramFiles) {
        $candidate = Join-Path $env:ProgramFiles 'WinRAR\Rar.exe'
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }
    $programFilesX86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
    if ($programFilesX86) {
        $candidate = Join-Path $programFilesX86 'WinRAR\Rar.exe'
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }
    return ''
}

function Test-Mask([string]$name, [string]$mask) {
    if ([string]::IsNullOrEmpty($mask)) { return $true }
    if ($mask -eq '*' -or $mask -eq '*.*') { return $true }
    return $name -like $mask
}

function Get-RecursiveFiles([string]$root) {
    $pending = New-Object 'Collections.Generic.Stack[string]'
    $pending.Push($root)
    while ($pending.Count -gt 0) {
        $directory = $pending.Pop()
        $files = @(Get-ChildItem -LiteralPath $directory -File -Force `
                                 -ErrorAction SilentlyContinue)
        foreach ($file in $files) {
            Write-Output $file
        }
        $directories = @(Get-ChildItem -LiteralPath $directory -Directory `
                                       -Force -ErrorAction SilentlyContinue)
        foreach ($child in $directories) {
            if (-not ($child.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
                $pending.Push($child.FullName)
            }
        }
    }
}

function Expand-ZipArchive([string]$archivePath, [string]$display,
                           [string]$mask, [int]$depth) {
    $stream = [IO.File]::Open($archivePath, [IO.FileMode]::Open,
                              [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
    try {
        $archive = New-Object IO.Compression.ZipArchive(
            $stream, [IO.Compression.ZipArchiveMode]::Read)
        try {
            foreach ($entry in $archive.Entries) {
                if ([string]::IsNullOrEmpty($entry.Name)) { continue }
                $safeName = [IO.Path]::GetFileName($entry.Name)
                if ([string]::IsNullOrEmpty($safeName)) { continue }
                $target = Join-Path $work (
                    [Guid]::NewGuid().ToString('N') + '_' + $safeName)
                $input = $entry.Open()
                try {
                    $output = [IO.File]::Create($target)
                    try { $input.CopyTo($output) } finally { $output.Dispose() }
                } finally { $input.Dispose() }
                Process-File $target ($display + '::' + $entry.FullName) `
                             $mask ($depth + 1) $false
            }
        } finally { $archive.Dispose() }
    } finally { $stream.Dispose() }
}

function Expand-TarArchive([string]$archivePath, [string]$display,
                           [string]$mask, [int]$depth) {
    # Use only Windows' native tar.exe. A tar.exe found through PATH may be
    # Cygwin tar; it interprets "F:\..." as host "F" plus a remote path.
    # If native tar is unavailable, use the configured 7-Zip fallback.
    $tarCommand = ''
    if ($env:SystemRoot) {
        $nativeTar = Join-Path $env:SystemRoot 'System32\tar.exe'
        if (Test-Path -LiteralPath $nativeTar -PathType Leaf) {
            $tarCommand = $nativeTar
        }
    }
    if ([string]::IsNullOrEmpty($tarCommand)) {
        # 7-Zip can extract TAR directly. For TGZ/TAR.GZ it first produces
        # the contained TAR, which Process-File then recognizes recursively.
        Expand-SevenZipArchive $archivePath $display $mask $depth
        return
    }
    $extractRoot = Join-Path $work ([Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $extractRoot | Out-Null
    & $tarCommand -xf $archivePath -C $extractRoot 2>$null
    if ($LASTEXITCODE -ne 0) { return }
    $members = Get-RecursiveFiles $extractRoot
    foreach ($member in $members) {
        $relative = $member.FullName.Substring($extractRoot.Length).TrimStart('\')
        $relative = $relative.Replace('\', '/')
        Process-File $member.FullName ($display + '::' + $relative) `
                     $mask ($depth + 1) $false
    }
}

function Expand-SevenZipArchive([string]$archivePath, [string]$display,
                                [string]$mask, [int]$depth) {
    $sevenZip = Get-SevenZipCommand
    if ([string]::IsNullOrEmpty($sevenZip)) { return }
    $extractRoot = Join-Path $work ([Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $extractRoot | Out-Null
    $outputOption = '-o' + $extractRoot
    & $sevenZip x -y $outputOption -- $archivePath *> $null
    if ($LASTEXITCODE -ne 0) { return }
    $members = Get-RecursiveFiles $extractRoot
    foreach ($member in $members) {
        $relative = $member.FullName.Substring($extractRoot.Length).TrimStart('\')
        $relative = $relative.Replace('\', '/')
        Process-File $member.FullName ($display + '::' + $relative) `
                     $mask ($depth + 1) $false
    }
}

function Expand-RarArchive([string]$archivePath, [string]$display,
                           [string]$mask, [int]$depth) {
    $rarCommand = Get-RarCommand
    if ([string]::IsNullOrEmpty($rarCommand)) {
        Expand-SevenZipArchive $archivePath $display $mask $depth
        return
    }
    $extractRoot = Join-Path $work ([Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $extractRoot | Out-Null
    $destination = $extractRoot + '\'
    & $rarCommand x -o+ -inul $archivePath $destination *> $null
    if ($LASTEXITCODE -ne 0) { return }
    $members = Get-RecursiveFiles $extractRoot
    foreach ($member in $members) {
        $relative = $member.FullName.Substring($extractRoot.Length).TrimStart('\')
        $relative = $relative.Replace('\', '/')
        Process-File $member.FullName ($display + '::' + $relative) `
                     $mask ($depth + 1) $false
    }
}

function Process-File([string]$disk, [string]$display, [string]$mask,
                      [int]$depth, [bool]$forceSearch) {
    if ($depth -gt 32) { return }
    $kind = Get-ArchiveKind $display
    if ($kind -and (-not $searchArchivesEnabled)) { return }
    try {
        if ($kind -eq 'zip') {
            Expand-ZipArchive $disk $display $mask $depth
        } elseif ($kind -eq 'tar' -or $kind -eq 'tgz') {
            Expand-TarArchive $disk $display $mask $depth
        } elseif ($kind -eq '7z') {
            Expand-SevenZipArchive $disk $display $mask $depth
        } elseif ($kind -eq 'rar') {
            Expand-RarArchive $disk $display $mask $depth
        } elseif ($forceSearch -or (Test-Mask ([IO.Path]::GetFileName($display)) $mask)) {
            Add-SearchFile $disk $display
        }
    } catch {
        # Damaged, encrypted and unsupported archives are skipped.
        Record-HelperError $_.Exception.Message
    }
}

function Process-Specification([string]$oneSpecification) {
    $expanded = [Environment]::ExpandEnvironmentVariables(
        $oneSpecification.Trim().Trim('"'))
    if ([string]::IsNullOrWhiteSpace($expanded)) { return }
    if ($expanded -match '^=([A-Za-z]:[\\/].*)$') {
        $expanded = $Matches[1]
    }
    try {
        $mask = '*'
        $forceSingle = $false
        if (Test-Path -LiteralPath $expanded -PathType Container) {
            $root = (Resolve-Path -LiteralPath $expanded).Path
            $files = Get-RecursiveFiles $root
        } elseif (Test-Path -LiteralPath $expanded -PathType Leaf) {
            $files = @(Get-Item -LiteralPath $expanded)
            $forceSingle = $true
        } else {
            $parent = Split-Path -Parent $expanded
            $mask = Split-Path -Leaf $expanded
            if ([string]::IsNullOrEmpty($parent)) { $parent = (Get-Location).Path }
            $files = Get-RecursiveFiles $parent
        }

        foreach ($file in $files) {
            $script:sourceFilesEnumerated++
            $kind = Get-ArchiveKind $file.Name
            if ($kind -or $forceSingle -or (Test-Mask $file.Name $mask)) {
                Process-File $file.FullName $file.FullName $mask 0 $forceSingle
            }
        }
    } catch {
        # One invalid or unavailable source must not stop the remaining sources.
        Record-HelperError $_.Exception.Message
    }
}

try {
    foreach ($oneSpecification in ($Specification -split ';')) {
        Process-Specification $oneSpecification
    }
} finally {
    $writer.WriteLine('#STATS=' + $sourceFilesEnumerated + '|' +
                      $manifestEntriesWritten + '|' + $helperErrorCount + '|' +
                      $firstHelperError)
    $writer.Dispose()
}
