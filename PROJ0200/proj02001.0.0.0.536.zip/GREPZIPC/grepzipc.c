/* GREPZIPC 1.0.0.0.10 - filtering/output/cleanup revision, including nested archives.
   C89 + Win32 compatible (Borland C++ 5.5 -tWC); Linux builds supported for testing.
   Native DLL backends: libarchive and PCRE2-8, loaded at runtime without import libs.
   Copyright (c) 2026. MIT license (see README).
*/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <stdarg.h>
#include <limits.h>
#include <stddef.h>
#ifdef _WIN32
#include <windows.h>
#include <io.h>
/* Older Win32 SDK headers supplied with Borland C++ 5.5 omit this constant. */
#ifndef INVALID_FILE_ATTRIBUTES
#define INVALID_FILE_ATTRIBUTES ((DWORD)0xFFFFFFFFUL)
#endif
#define PATH_SEP '\\'
#define CDECL __cdecl
#define LIB_HANDLE HMODULE
#define lib_open(n) LoadLibraryA(n)
#define lib_symbol(h,n) GetProcAddress(h,n)
#define lib_close(h) FreeLibrary(h)
#else
#include <dirent.h>
#include <sys/stat.h>
#include <dlfcn.h>
#define PATH_SEP '/'
#define CDECL
#define LIB_HANDLE void *
#define lib_open(n) dlopen(n,RTLD_NOW)
#define lib_symbol(h,n) dlsym(h,n)
#define lib_close(h) dlclose(h)
#endif

#define VERSION "1.0.0.0.10"
#define PATH_CAP 8192
#define REGEX_LINE_DEFAULT 262144UL
#define CHUNK 65536
#define ARCHIVE_EOF 1
#define PCRE2_CASELESS 0x00000008U
#define PCRE2_MULTILINE 0x00000400U
#define AE_IFDIR 0040000

typedef struct archive ARC;
typedef struct archive_entry ENTRY;
typedef struct {
    LIB_HANDLE handle;
    ARC *(CDECL *read_new)(void);
    int (CDECL *support_filter_all)(ARC *);
    int (CDECL *support_format_all)(ARC *);
    int (CDECL *support_format_raw)(ARC *);
    int (CDECL *open_filename)(ARC *,const char *,size_t);
    int (CDECL *open_memory)(ARC *,const void *,size_t);
    int (CDECL *next_header)(ARC *,ENTRY **);
    long (CDECL *read_data)(ARC *,void *,size_t);
    int (CDECL *read_free)(ARC *);
    const char *(CDECL *entry_pathname)(ENTRY *);
    unsigned int (CDECL *entry_filetype)(ENTRY *);
    const char *(CDECL *error_string)(ARC *);
} ARCH_API;
typedef struct {
    LIB_HANDLE handle;
    void *(CDECL *compile)(const unsigned char *,size_t,unsigned int,int *,size_t *,void *);
    void *(CDECL *matchdata)(const void *,void *);
    int (CDECL *match)(const void *,const unsigned char *,size_t,size_t,unsigned int,void *,void *);
    size_t *(CDECL *ovector)(void *);
    void (CDECL *freecode)(void *);
    void (CDECL *freematchdata)(void *);
} RE_API;

typedef struct {
    char topdirs[PATH_CAP];
    char expression[4096];
    char options[128];
    char inclusions[4096];
    char exclusions[4096];
    char inclusion_file[PATH_CAP];
    char exclusion_file[PATH_CAP];
    char logfile[PATH_CAP];
    char sevenzip[PATH_CAP];
    char rar[PATH_CAP];
    int use_external_fallback;
    unsigned long extractor_timeout_seconds;
    unsigned long progress_interval_seconds;
    unsigned long max_external_attempts;
    int logging;
    int log_results;
    unsigned long max_log_mb;
    unsigned long max_warnings;
    int show_filenames;
    int max_depth;
    unsigned long max_nested_mb;
    unsigned long max_line;
    int verbose;
} SETTINGS;
typedef struct {
    unsigned long files, archives, members, hits, lines, skipped, errors;
    unsigned long nested_skipped, long_lines;
} COUNTS;
typedef struct {
    char *line;
    size_t used, cap;
    unsigned long number;
    int discard, has_nul, long_reported;
    const char *name;
} LINECTX;

static ARCH_API ar;
static RE_API re;
static SETTINGS cfg;
static COUNTS stat_count;
static FILE *log_fp;
static unsigned long log_bytes;
static unsigned long log_limit;
static unsigned long warnings_shown;
static char active_log_path[PATH_CAP];
static int log_limit_notified;
static void *regex_code, *regex_match_data;
static time_t began;
static time_t last_progress;
static const char *current_work="starting";
static int stop_requested;
static char fallback_diagnostic[1024];
static unsigned long external_attempts;
static unsigned long external_skipped;
static unsigned long external_timeouts;
/* When a topdirectory ends with a DOS wildcard, filter disk filenames only. */
static char current_root_mask[1024];

/* Diagnostic logs exclude result lines by default; all log writes are size-capped. */
static void log_text(const char *msg) {
    size_t len;
    if (!log_fp || log_limit_notified) return;
    len=strlen(msg);
    if (len > (size_t)(log_limit-log_bytes)) {
        const char *notice="[GREPZIPC] Log size limit reached; subsequent log records suppressed.\n";
        size_t n=strlen(notice);
        if(n <= (size_t)(log_limit-log_bytes)) {fwrite(notice,1,n,log_fp);log_bytes+=(unsigned long)n;}
        log_limit_notified=1;
        fflush(log_fp);
        return;
    }
    if(len) {fwrite(msg,1,len,log_fp);log_bytes+=(unsigned long)len;}
}
static void output(const char *fmt,...) {
    char text[12288];
    va_list ap;
    va_start(ap,fmt);
#ifdef _WIN32
    _vsnprintf(text,sizeof(text)-1,fmt,ap);
#else
    vsnprintf(text,sizeof(text)-1,fmt,ap);
#endif
    va_end(ap);
    text[sizeof(text)-1]=0;
    fputs(text,stdout);
    log_text(text);
}
/* Lightweight periodic progress, written to console only to prevent log feedback.
   This runs in the main thread, so a blocked DLL operation cannot heartbeat. */
static void progress_tick(const char *work,int force) {
    time_t now=time(0);
    if(work)current_work=work;
    if(cfg.logging && (force || (cfg.progress_interval_seconds && difftime(now,last_progress)>=(double)cfg.progress_interval_seconds))) {
        fprintf(stderr,"PROGRESS elapsed=%.0fs files=%lu archives=%lu members=%lu hits=%lu errors=%lu | %.320s\n",
                difftime(now,began),stat_count.files,stat_count.archives,
                stat_count.members,stat_count.hits,stat_count.errors,current_work);
        fflush(stderr);
        last_progress=now;
    }
}
static void warnmsg(const char *fmt,...) {
    char msg[4096];va_list ap;
    stat_count.errors++;
    if (!cfg.logging)return; /* quiet search: diagnostics are fully suppressed */
    if (warnings_shown>=cfg.max_warnings)return;
    warnings_shown++;
    va_start(ap,fmt);
#ifdef _WIN32
    _vsnprintf(msg,sizeof(msg)-1,fmt,ap);
#else
    vsnprintf(msg,sizeof(msg)-1,fmt,ap);
#endif
    va_end(ap);msg[sizeof(msg)-1]=0;
    output("WARNING: %s\n",msg);
    if(warnings_shown==cfg.max_warnings)
        output("WARNING: Warning display limit reached; additional warnings counted but suppressed.\n");
}
static int ci_char(int c) { return tolower((unsigned char)c); }
static int ci_equal(const char *a,const char *b) {
    while(*a && *b) { if(ci_char(*a)!=ci_char(*b)) return 0; a++;b++; }
    return !*a && !*b;
}
static int ci_ends(const char *s,const char *end) {
    size_t a=strlen(s),b=strlen(end),i;
    if(a<b) return 0;
    for(i=0;i<b;i++) if(ci_char(s[a-b+i])!=ci_char(end[i])) return 0;
    return 1;
}
static void copystr(char *dst,size_t n,const char *src) {
    if(!n)return;
    strncpy(dst,src,n-1);dst[n-1]=0;
}
static void trim(char *s) {
    char *p=s; size_t n;
    while(*p && isspace((unsigned char)*p))p++;
    if(p!=s)memmove(s,p,strlen(p)+1);
    n=strlen(s);while(n && isspace((unsigned char)s[n-1]))s[--n]=0;
    if(n>=2 && s[0]=='"' && s[n-1]=='"') {memmove(s,s+1,n-2);s[n-2]=0;}
}
static int flag(const char *s) {return ci_equal(s,"true")||ci_equal(s,"yes")||ci_equal(s,"on")||!strcmp(s,"1");}
static void append_filter_file(char *target,size_t capacity,const char *path) {
    FILE *f;char line[PATH_CAP+256];size_t used;
    if(!path[0])return;
    f=fopen(path,"rb");if(!f)return;
    while(fgets(line,sizeof(line),f)) {
        trim(line);
        if(!line[0]||line[0]==';'||line[0]=='#'||line[0]=='[')continue;
        used=strlen(target);
        if(used && used+1<capacity)target[used++]=';';
        target[used]=0;
        if(used+strlen(line)<capacity)copystr(target+used,capacity-used,line);
    }
    fclose(f);
}
static void defaults(void) {
    memset(&cfg,0,sizeof(cfg));
    copystr(cfg.topdirs,sizeof(cfg.topdirs),".");
    copystr(cfg.options,sizeof(cfg.options),"ix");
    cfg.show_filenames=1;cfg.max_depth=12;cfg.max_nested_mb=256;
    cfg.max_line=REGEX_LINE_DEFAULT;
    cfg.max_log_mb=10;cfg.max_warnings=100;
    cfg.use_external_fallback=1;
    cfg.extractor_timeout_seconds=30;
    cfg.progress_interval_seconds=10;
    cfg.max_external_attempts=200;
    copystr(cfg.sevenzip,sizeof(cfg.sevenzip),"C:\\Program Files\\7-Zip\\7z.exe");
    copystr(cfg.rar,sizeof(cfg.rar),"C:\\Program Files\\WinRAR\\Rar.exe");
}
static int read_ini(const char *path) {
    FILE *f=fopen(path,"rb");char line[PATH_CAP+256];int number=0;
    if(!f)return 0;
    while(fgets(line,sizeof(line),f)) {
        char *eq,*key,*value;
        number++;trim(line);
        if(!line[0]||line[0]==';'||line[0]=='#'||line[0]=='[')continue;
        eq=strchr(line,'=');if(!eq)continue;
        *eq=0;key=line;value=eq+1;trim(key);trim(value);
        if(ci_equal(key,"topdirectories")||ci_equal(key,"topdirectory"))copystr(cfg.topdirs,sizeof(cfg.topdirs),value);
        else if(ci_equal(key,"searchstring")||ci_equal(key,"regex"))copystr(cfg.expression,sizeof(cfg.expression),value);
        else if(ci_equal(key,"searchoptions"))copystr(cfg.options,sizeof(cfg.options),value);
        else if(ci_equal(key,"inclusions"))copystr(cfg.inclusions,sizeof(cfg.inclusions),value);
        else if(ci_equal(key,"exclusions"))copystr(cfg.exclusions,sizeof(cfg.exclusions),value);
        else if(ci_equal(key,"includefile"))copystr(cfg.inclusion_file,sizeof(cfg.inclusion_file),value);
        else if(ci_equal(key,"excludefile"))copystr(cfg.exclusion_file,sizeof(cfg.exclusion_file),value);
        else if(ci_equal(key,"SevenZipExecutable"))copystr(cfg.sevenzip,sizeof(cfg.sevenzip),value);
        else if(ci_equal(key,"RarExecutable"))copystr(cfg.rar,sizeof(cfg.rar),value);
        else if(ci_equal(key,"UseExternalFallback")||ci_equal(key,"UseSevenZipFallback"))cfg.use_external_fallback=flag(value);
        else if(ci_equal(key,"extractortimeoutseconds"))cfg.extractor_timeout_seconds=strtoul(value,0,10);
        else if(ci_equal(key,"progressintervalseconds"))cfg.progress_interval_seconds=strtoul(value,0,10);
        else if(ci_equal(key,"maxexternalattempts"))cfg.max_external_attempts=strtoul(value,0,10);
        else if(ci_equal(key,"logging"))cfg.logging=flag(value);
        else if(ci_equal(key,"logresults"))cfg.log_results=flag(value);
        else if(ci_equal(key,"maxlogmb"))cfg.max_log_mb=strtoul(value,0,10);
        else if(ci_equal(key,"maxwarnings"))cfg.max_warnings=strtoul(value,0,10);
        else if(ci_equal(key,"logfile"))copystr(cfg.logfile,sizeof(cfg.logfile),value);
        else if(ci_equal(key,"showfilenames"))cfg.show_filenames=flag(value);
        else if(ci_equal(key,"maxnesteddepth"))cfg.max_depth=atoi(value);
        else if(ci_equal(key,"maxnestedmb"))cfg.max_nested_mb=strtoul(value,0,10);
        else if(ci_equal(key,"maxlinelength"))cfg.max_line=strtoul(value,0,10);
        else if(ci_equal(key,"verbose"))cfg.verbose=flag(value);
    }
    fclose(f);
    if(cfg.max_log_mb<1)cfg.max_log_mb=1;
    if(cfg.max_log_mb>1024)cfg.max_log_mb=1024;
    if(cfg.max_warnings<1)cfg.max_warnings=1;
    if(cfg.max_warnings>100000)cfg.max_warnings=100000;
    if(cfg.extractor_timeout_seconds<1)cfg.extractor_timeout_seconds=1;
    if(cfg.extractor_timeout_seconds>3600)cfg.extractor_timeout_seconds=3600;
    if(cfg.progress_interval_seconds>3600)cfg.progress_interval_seconds=3600;
    if(cfg.max_external_attempts>1000000UL)cfg.max_external_attempts=1000000UL;
    if(cfg.max_depth<0)cfg.max_depth=0;
    if(cfg.max_depth>64)cfg.max_depth=64;
    if(cfg.max_nested_mb<1)cfg.max_nested_mb=1;
    if(cfg.max_line<256)cfg.max_line=256;
    if(cfg.max_line>16777216UL)cfg.max_line=16777216UL;
    return 1;
}
static const char *base_name(const char *s) {
    const char *p=s,*q=s;
    while(*q) {if(*q=='/'||*q=='\\')p=q+1;q++;}return p;
}
static int wild(const char *pat,const char *s) {
    const char *star=0,*saved=0;
    while(*s) {
        if(*pat=='*'){star=pat++;saved=s;}
        else if(*pat=='?'||ci_char(*pat)==ci_char(*s)){pat++;s++;}
        else if(star){pat=star+1;s=++saved;}
        else return 0;
    }
    while(*pat=='*')pat++;
    return !*pat;
}
static int listed(const char *patterns,const char *path) {
    const char *p=patterns,*b=base_name(path);char pattern[1024];size_t j;
    while(*p) {
        j=0;while(*p==';'||isspace((unsigned char)*p))p++;
        while(*p&&*p!=';'){if(j+1<sizeof(pattern))pattern[j++]=*p;p++;}
        pattern[j]=0;trim(pattern);
        if(pattern[0]) {
            size_t n=strlen(pattern);int dir=0;
            if(n && (pattern[n-1]=='/'||pattern[n-1]=='\\'))dir=1;
            if(dir){ /* directory prefix anywhere within the full path */
                const char *q=path;
                while(*q){size_t k=0;while(k<n && q[k] && ci_char(q[k])==ci_char(pattern[k]))k++;
                    if(k==n)return 1;
                    q++;
                }
            } else if(wild(pattern,b)||wild(pattern,path))return 1;
        }
        if(*p==';')p++;
    }
    return 0;
}
static int allowed(const char *name,int is_dir) {
    if(cfg.exclusions[0]&&listed(cfg.exclusions,name))return 0;
    if(!is_dir && cfg.inclusions[0]&&!listed(cfg.inclusions,name))return 0;
    return 1;
}
static int archive_name(const char *name) {
    static const char *ext[]={".zip",".jar",".war",".ear",".tar",".tgz",".tar.gz",".gz",".tar.bz2",".tbz2",".bz2",".tar.xz",".txz",".xz",".7z",".rar",".cab",".cpio",".iso",".zst",".tar.zst",0};
    int i;for(i=0;ext[i];i++)if(ci_ends(name,ext[i]))return 1;
    return 0;
}
static int init_archive(void) {
    static const char *names[]={
#ifdef _WIN32
        "archive.dll","libarchive.dll","libarchive-13.dll",0
#else
        "libarchive.so.13","libarchive.so",0
#endif
    };
    int i;
    for(i=0;names[i]&&!ar.handle;i++)ar.handle=lib_open(names[i]);
    if(!ar.handle)return 0;
#define LOAD_AR(field,symbol) ar.field=(void *)lib_symbol(ar.handle,symbol);if(!ar.field)return 0
    LOAD_AR(read_new,"archive_read_new");
    LOAD_AR(support_filter_all,"archive_read_support_filter_all");
    LOAD_AR(support_format_all,"archive_read_support_format_all");
    LOAD_AR(support_format_raw,"archive_read_support_format_raw");
    LOAD_AR(open_filename,"archive_read_open_filename");
    LOAD_AR(open_memory,"archive_read_open_memory");
    LOAD_AR(next_header,"archive_read_next_header");
    LOAD_AR(read_data,"archive_read_data");
    LOAD_AR(read_free,"archive_read_free");
    LOAD_AR(entry_pathname,"archive_entry_pathname");
    LOAD_AR(entry_filetype,"archive_entry_filetype");
    LOAD_AR(error_string,"archive_error_string");
#undef LOAD_AR
    return 1;
}
static int init_regex(void) {
    static const char *names[]={
#ifdef _WIN32
        "pcre2-8.dll","libpcre2-8-0.dll",0
#else
        "libpcre2-8.so.0","libpcre2-8.so",0
#endif
    };
    int i;
    for(i=0;names[i]&&!re.handle;i++)re.handle=lib_open(names[i]);
    if(!re.handle)return 0;
#define LOAD_RE(field,symbol) re.field=(void *)lib_symbol(re.handle,symbol);if(!re.field)return 0
    LOAD_RE(compile,"pcre2_compile_8");
    LOAD_RE(matchdata,"pcre2_match_data_create_from_pattern_8");
    LOAD_RE(match,"pcre2_match_8");
    LOAD_RE(ovector,"pcre2_get_ovector_pointer_8");
    LOAD_RE(freecode,"pcre2_code_free_8");
    LOAD_RE(freematchdata,"pcre2_match_data_free_8");
#undef LOAD_RE
    return 1;
}
static int prepare_regex(void) {
    unsigned int opts=PCRE2_MULTILINE;
    char escaped[8192]; const char *pattern=cfg.expression;
    int err;size_t off;size_t k=0;const char *s;
    if(strchr(cfg.options,'i')||strchr(cfg.options,'I'))opts|=PCRE2_CASELESS;
    if(!strchr(cfg.options,'x')&&!strchr(cfg.options,'X')) {
        const char *meta=".\\+*?[^]$(){}=!<>|:-";
        for(s=pattern;*s&&k+2<sizeof(escaped);s++) {
            if(strchr(meta,*s))escaped[k++]='\\';
            escaped[k++]=*s;
        }
        escaped[k]=0;pattern=escaped;
    }
    regex_code=re.compile((const unsigned char *)pattern,strlen(pattern),opts,&err,&off,0);
    if(!regex_code){fprintf(stderr,"ERROR: invalid PCRE2 expression, code %d at offset %lu\n",err,(unsigned long)off);return 0;}
    regex_match_data=re.matchdata(regex_code,0);
    return regex_match_data!=0;
}
static void match_line(LINECTX *ctx) {
    int result;size_t *vec;size_t i;
    if(ctx->discard||ctx->has_nul||!ctx->used)return;
    stat_count.lines++;
    result=re.match(regex_code,(const unsigned char *)ctx->line,ctx->used,0,0,regex_match_data,0);
    if(result>=0) {
        char *p;
        vec=re.ovector(regex_match_data);
        stat_count.hits++;
        if(cfg.show_filenames)printf("%s:%lu:%lu:",ctx->name,ctx->number,(unsigned long)vec[0]+1);
        else printf("%lu:%lu:",ctx->number,(unsigned long)vec[0]+1);
        for(i=0;i<ctx->used;i++) {
            if(ctx->line[i]=='\r'||ctx->line[i]=='\n')ctx->line[i]=' ';
            if(ctx->line[i]=='\t')ctx->line[i]=' ';
        }
        p=ctx->line;
        fputs(p,stdout);fputc('\n',stdout);
        if(cfg.log_results && log_fp) {
            char prefix[PATH_CAP+128];
            if(cfg.show_filenames) {
#ifdef _WIN32
                _snprintf(prefix,sizeof(prefix)-1,"%s:%lu:%lu:",ctx->name,ctx->number,(unsigned long)vec[0]+1);
#else
                snprintf(prefix,sizeof(prefix)-1,"%s:%lu:%lu:",ctx->name,ctx->number,(unsigned long)vec[0]+1);
#endif
            } else sprintf(prefix,"%lu:%lu:",ctx->number,(unsigned long)vec[0]+1);
            prefix[sizeof(prefix)-1]=0;
            log_text(prefix);log_text(p);log_text("\n");
        }
    }
}
static int line_init(LINECTX *ctx,const char *name) {
    memset(ctx,0,sizeof(*ctx));ctx->name=name;ctx->number=1;
    ctx->cap=(size_t)cfg.max_line+1;
    ctx->line=(char *)malloc(ctx->cap);
    if(!ctx->line){warnmsg("Out of memory for line buffer");return 0;}
    return 1;
}
static void line_feed(LINECTX *ctx,const unsigned char *data,size_t len) {
    size_t i;unsigned char c;
    for(i=0;i<len;i++) {
        c=data[i];
        if(c=='\n') {
            if(!ctx->discard){ctx->line[ctx->used]=0;match_line(ctx);}
            ctx->number++;ctx->used=0;ctx->discard=0;ctx->has_nul=0;ctx->long_reported=0;
        } else if(!ctx->discard) {
            if(c==0)ctx->has_nul=1;
            if(ctx->used+1>=ctx->cap){ctx->discard=1;stat_count.long_lines++;}
            else ctx->line[ctx->used++]=(char)c;
        }
    }
}
static void line_finish(LINECTX *ctx) {
    if(!ctx->discard&&ctx->used){ctx->line[ctx->used]=0;match_line(ctx);}
    free(ctx->line);ctx->line=0;
}
static void grep_disk(const char *path) {
    unsigned char buffer[CHUNK];size_t n;FILE *f;LINECTX ctx;
    if(!allowed(path,0))return;
    f=fopen(path,"rb");if(!f){stat_count.skipped++;return;}
    stat_count.files++;
    if(cfg.logging && cfg.verbose)output("FILE %s\n",path);
    if(!line_init(&ctx,path)){fclose(f);return;}
    while((n=fread(buffer,1,sizeof(buffer),f))>0){line_feed(&ctx,buffer,n);progress_tick(path,0);}
    line_finish(&ctx);fclose(f);
}
static ARC *new_reader(void) {
    ARC *a=ar.read_new();
    if(a){ar.support_filter_all(a);ar.support_format_all(a);ar.support_format_raw(a);}
    return a;
}
/* External fallback is used only for members libarchive cannot decode.
   Windows CreateProcess redirects stdout directly to a temporary file; this
   avoids CMD.EXE quoting, shell expansion, and unexpected console output. */
static void process_archive(ARC *a,const char *display,int depth,
                            const char *source,const unsigned char *raw,size_t rawlen);
#ifdef _WIN32
static int make_temp_file(char *path) {
    char dir[MAX_PATH];DWORD n=GetTempPathA(sizeof(dir),dir);
    if(!n || n>=sizeof(dir))return 0;
    return GetTempFileNameA(dir,"gzc",0,path)!=0;
}
static int save_temp_bytes(const unsigned char *buf,size_t len,char *path) {
    HANDLE h;DWORD written;size_t pos=0,step;
    if(!make_temp_file(path))return 0;
    h=CreateFileA(path,GENERIC_WRITE,0,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
    if(h==INVALID_HANDLE_VALUE){DeleteFileA(path);return 0;}
    while(pos<len) {
        step=len-pos;if(step>65536)step=65536;
        if(!WriteFile(h,buf+pos,(DWORD)step,&written,0) || written!=(DWORD)step)break;
        pos+=step;
    }
    CloseHandle(h);
    if(pos!=len){DeleteFileA(path);return 0;}
    return 1;
}
static void fallback_problem(const char *tool,const char *reason) {
    size_t len;
    if(!tool)tool="Extractor";
    if(!reason)reason="unknown failure";
    len=strlen(fallback_diagnostic);
    if(len && len+4<sizeof(fallback_diagnostic))strcat(fallback_diagnostic,"; ");
    len=strlen(fallback_diagnostic);
    if(len+strlen(tool)+strlen(reason)+4<sizeof(fallback_diagnostic)) {
        strcat(fallback_diagnostic,tool);strcat(fallback_diagnostic,": ");
        strcat(fallback_diagnostic,reason);
    }
}
static int run_extractor(const char *exe,int is_rar,const char *archive,
                         const char *member,const char *dest) {
    char *cmd;size_t needed;STARTUPINFOA si;PROCESS_INFORMATION pi;
    SECURITY_ATTRIBUTES sec;HANDLE out,err=INVALID_HANDLE_VALUE;
    DWORD exitcode=1,winerr=0,attrs,waitresult=WAIT_FAILED;
    HANDLE input_handle=INVALID_HANDLE_VALUE;
    int timed_out=0;
    char msg[420],errfile[MAX_PATH];int good=0;FILE *fp;size_t got;
    const char *tool=is_rar?"WinRAR":"7-Zip";
    if(cfg.max_external_attempts && external_attempts>=cfg.max_external_attempts){
        external_skipped++;
        fallback_problem(tool,"external attempt limit reached; member skipped");
        return 0;
    }
    if(!exe[0]){fallback_problem(tool,"executable path is empty");return 0;}
    attrs=GetFileAttributesA(exe);
    if(attrs==INVALID_FILE_ATTRIBUTES || (attrs&FILE_ATTRIBUTE_DIRECTORY)) {
        fallback_problem(tool,"executable not found at configured path");return 0;
    }
    if(!archive[0]||!member[0]){fallback_problem(tool,"archive/member path missing");return 0;}
    if(strpbrk(exe,"\"\r\n")||strpbrk(archive,"\"\r\n")||strpbrk(member,"\"\r\n")){
        fallback_problem(tool,"unsafe quote/newline in argument");return 0;
    }
    needed=strlen(exe)+strlen(archive)+strlen(member)+100;
    cmd=(char*)malloc(needed);if(!cmd){fallback_problem(tool,"out of memory");return 0;}
    if(is_rar)sprintf(cmd,"\"%s\" p -inul -y \"%s\" \"%s\"",exe,archive,member);
    else sprintf(cmd,"\"%s\" e -so -bd -y \"%s\" \"%s\"",exe,archive,member);
    memset(&sec,0,sizeof(sec));sec.nLength=sizeof(sec);sec.bInheritHandle=TRUE;
    out=CreateFileA(dest,GENERIC_WRITE,FILE_SHARE_READ,&sec,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
    if(out==INVALID_HANDLE_VALUE){fallback_problem(tool,"cannot create temporary output file");free(cmd);return 0;}
    /* Capture the extractor's stderr independently from binary stdout. */
    errfile[0]=0;
    if(make_temp_file(errfile)) {
        err=CreateFileA(errfile,GENERIC_WRITE,FILE_SHARE_READ,&sec,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
        if(err==INVALID_HANDLE_VALUE){DeleteFileA(errfile);errfile[0]=0;}
    }
    memset(&si,0,sizeof(si));si.cb=sizeof(si);si.dwFlags=STARTF_USESTDHANDLES|STARTF_USESHOWWINDOW;
    si.wShowWindow=SW_HIDE;
    si.hStdOutput=out;
    si.hStdError=(err!=INVALID_HANDLE_VALUE)?err:GetStdHandle(STD_ERROR_HANDLE);
    /* Feed the extractor EOF immediately so password prompts cannot block it. */
    input_handle=CreateFileA("NUL",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,
                             &sec,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);
    si.hStdInput=(input_handle!=INVALID_HANDLE_VALUE)?input_handle:GetStdHandle(STD_INPUT_HANDLE);
    memset(&pi,0,sizeof(pi));
    external_attempts++;
    if(cfg.logging)fprintf(stderr,"EXTRACT start: %s | attempt=%lu | timeout=%lus | %.220s!%.120s\n",
            tool,external_attempts,cfg.extractor_timeout_seconds,archive,member);
    if(cfg.logging)fflush(stderr);
    if(CreateProcessA(exe,cmd,0,0,TRUE,CREATE_NO_WINDOW,0,0,&si,&pi)) {
        waitresult=WaitForSingleObject(pi.hProcess,cfg.extractor_timeout_seconds*1000UL);
        if(waitresult==WAIT_TIMEOUT) {
            timed_out=1;
            external_timeouts++;
            TerminateProcess(pi.hProcess,124);
            WaitForSingleObject(pi.hProcess,5000UL);
        } else if(waitresult==WAIT_OBJECT_0) {
            if(GetExitCodeProcess(pi.hProcess,&exitcode) && exitcode==0)good=1;
        } else winerr=GetLastError();
        CloseHandle(pi.hThread);CloseHandle(pi.hProcess);
    } else winerr=GetLastError();
    if(input_handle!=INVALID_HANDLE_VALUE)CloseHandle(input_handle);
    if(cfg.logging)fprintf(stderr,"EXTRACT end: %s | %s | exit=%lu | timeout=%s\n",
            tool,good?"success":"failure",(unsigned long)exitcode,timed_out?"yes":"no");
    if(cfg.logging)fflush(stderr);
    CloseHandle(out);
    if(err!=INVALID_HANDLE_VALUE)CloseHandle(err);
    if(!good){
        if(timed_out)sprintf(msg,"timed out after %lu seconds; process terminated",cfg.extractor_timeout_seconds);
        else if(winerr)sprintf(msg,"CreateProcess/Wait failed (Windows error %lu)",(unsigned long)winerr);
        else sprintf(msg,"extractor exit code %lu",(unsigned long)exitcode);
        /* Last output lines of stderr are often the useful part. */
        if(errfile[0]){
            fp=fopen(errfile,"rb");
            if(fp){
                char details[250];long size;
                fseek(fp,0,SEEK_END);size=ftell(fp);
                if(size>230)fseek(fp,-230,SEEK_END);else rewind(fp);
                got=fread(details,1,sizeof(details)-1,fp);details[got]=0;
                fclose(fp);
                while(got && (details[got-1]=='\r'||details[got-1]=='\n'||details[got-1]==' '))details[--got]=0;
                if(got) {
                    size_t i;for(i=0;i<got;i++)if(details[i]=='\r'||details[i]=='\n')details[i]=' ';
                    if(strlen(msg)+got+5<sizeof(msg)){strcat(msg,"; ");strcat(msg,details);}
                }
            }
        }
        fallback_problem(tool,msg);
    }
    if(errfile[0])DeleteFileA(errfile);
    free(cmd);
    return good;
}
static int process_fallback_file(const char *temp,const char *display,int depth,int nested) {
    unsigned char buffer[CHUNK];size_t n;FILE *f;LINECTX ctx;ARC *child;
    if(!nested) {
        f=fopen(temp,"rb");if(!f)return 0;
        if(!line_init(&ctx,display)){fclose(f);return 0;}
        while((n=fread(buffer,1,sizeof(buffer),f))>0)line_feed(&ctx,buffer,n);
        line_finish(&ctx);fclose(f);return 1;
    }
    if(depth>cfg.max_depth){stat_count.nested_skipped++;return 1;}
    child=new_reader();if(!child)return 0;
    if(ar.open_filename(child,temp,CHUNK)!=0){ar.read_free(child);return 0;}
    process_archive(child,display,depth,temp,0,0);
    ar.read_free(child);return 1;
}
static int fallback_member(const char *source,const unsigned char *raw,size_t rawlen,
                           const char *member,const char *display,int depth,int nested) {
    char srcbuf[MAX_PATH],dest[MAX_PATH];const char *archive=source;
    int made_source=0,success=0;
    fallback_diagnostic[0]=0;
    if(!cfg.use_external_fallback){fallback_problem("Fallback","disabled in INI");return 0;}
    if(raw) {
        if(!save_temp_bytes(raw,rawlen,srcbuf)){fallback_problem("Fallback","cannot create temporary nested archive");return 0;}
        archive=srcbuf;made_source=1;
    }
    if(!archive || !archive[0]){fallback_problem("Fallback","no archive source");return 0;}
    if(!make_temp_file(dest)){fallback_problem("Fallback","cannot create temporary result");if(made_source)DeleteFileA(srcbuf);return 0;}
    if(run_extractor(cfg.sevenzip,0,archive,member,dest) ||
       run_extractor(cfg.rar,1,archive,member,dest)) {
        if(nested) {
            WIN32_FILE_ATTRIBUTE_DATA fileinfo;
            unsigned long maxbytes=cfg.max_nested_mb*1048576UL;
            if(GetFileAttributesExA(dest,GetFileExInfoStandard,&fileinfo) &&
               (fileinfo.nFileSizeHigh || fileinfo.nFileSizeLow>maxbytes)) {
                stat_count.nested_skipped++;
                if(cfg.logging && cfg.verbose)output("SKIP fallback nested archive size limit: %s\n",display);
                success=1;
            } else success=process_fallback_file(dest,display,depth,nested);
        } else success=process_fallback_file(dest,display,depth,nested);
        if(!success)fallback_problem("Fallback","extraction succeeded but processing output failed");
    }
    DeleteFileA(dest);
    if(made_source)DeleteFileA(srcbuf);
    if(success && cfg.verbose)output("FALLBACK extracted: %s\n",display);
    return success;
}
#else
static int fallback_member(const char *source,const unsigned char *raw,size_t rawlen,
                           const char *member,const char *display,int depth,int nested) {
    (void)source;(void)raw;(void)rawlen;(void)member;(void)display;(void)depth;(void)nested;
    return 0; /* POSIX build retains native libarchive engine only. */
}
#endif
static int grep_entry(ARC *a,const char *display) {
    unsigned char buffer[CHUNK];long n;LINECTX ctx;
    if(!line_init(&ctx,display))return 0;
    while((n=ar.read_data(a,buffer,sizeof(buffer)))>0)line_feed(&ctx,buffer,(size_t)n);
    line_finish(&ctx);
    return n>=0;
}
static int archive_nested(ARC *a,const char *display,int depth) {
    size_t len=0,capacity=0,maxbytes,nread;
    unsigned char *data=0,*grown;unsigned char scratch[CHUNK];long n;
    ARC *child;
    if(depth>cfg.max_depth){stat_count.nested_skipped++;return 1;}
    maxbytes=(size_t)cfg.max_nested_mb*1024UL*1024UL;
    if(maxbytes/1048576UL != (size_t)cfg.max_nested_mb)maxbytes=(size_t)-1;
    while((n=ar.read_data(a,scratch,sizeof(scratch)))>0) {
        progress_tick(display,0);
        nread=(size_t)n;
        if(nread>maxbytes-len){stat_count.nested_skipped++;free(data);
            if(cfg.logging && cfg.verbose)output("SKIP nested archive size limit: %s\n",display);
            return 1;}
        if(len+nread>capacity) {
            size_t want=capacity?capacity*2:CHUNK;
            if(want<len+nread)want=len+nread;
            if(want>maxbytes)want=maxbytes;
            grown=(unsigned char *)realloc(data,want);
            if(!grown){warnmsg("Out of memory for nested archive %s",display);free(data);return 1;}
            data=grown;capacity=want;
        }
        memcpy(data+len,scratch,nread);len+=nread;
    }
    if(n<0){free(data);return 0;}
    if(!len){free(data);return 1;}
    child=new_reader();if(!child){free(data);return 0;}
    if(ar.open_memory(child,data,len)==0)process_archive(child,display,depth,0,data,len);
    else {stat_count.skipped++;if(cfg.logging && cfg.verbose)output("SKIP unsupported nested archive: %s\n",display);}
    ar.read_free(child);free(data);return 1;
}
static void process_archive(ARC *a,const char *display,int depth,
                            const char *source,const unsigned char *raw,size_t rawlen) {
    ENTRY *entry;int status,ok,nested;const char *name;char *full;size_t needed;
    stat_count.archives++;
    if(cfg.logging && cfg.verbose)output("ARCHIVE %s\n",display);
    while((status=ar.next_header(a,&entry))==0) {
        name=ar.entry_pathname(entry);
        if(!name||!name[0])continue;
        if((ar.entry_filetype(entry)&0170000)==AE_IFDIR)continue;
        needed=strlen(display)+strlen(name)+4;
        full=(char *)malloc(needed);
        if(!full){warnmsg("Out of memory for entry name");return;}
        sprintf(full,"%s!%s",display,name);
        stat_count.members++;
        progress_tick(full,0);
        if(cfg.exclusions[0]&&listed(cfg.exclusions,full)){free(full);continue;}
        nested=archive_name(name);
        if(nested)ok=archive_nested(a,full,depth+1);
        else if(allowed(full,0))ok=grep_entry(a,full);
        else ok=1;
        if(!ok) {
            /* Do this while entry pathname remains valid. Use captured path
               rather than a shell command so the archive cannot inject CMD syntax. */
            int rescued=fallback_member(source,raw,rawlen,name,full,depth+1,nested);
            if(!rescued){const char *detail=ar.error_string(a);
                warnmsg("Archive member read error: %s [%s] (fallback: %s)",
                    full,detail?detail:"no detail from libarchive",
                    fallback_diagnostic[0]?fallback_diagnostic:"unknown failure");}
        }
        free(full);
        if(stop_requested)break;
    }
    if(status!=ARCHIVE_EOF && !stop_requested) {
        const char *err=ar.error_string(a);
        warnmsg("Archive parse ended early in %s: %s",display,err?err:"unknown error");
    }
}
/* Ignore every GREPZIPC generated log, including the active log, even when
   the search root contains the application directory. Prevents log feedback. */
static int own_log_file(const char *path) {
    const char *name=base_name(path);
    const char *p=name;
    const char *prefix="grepzipc";
    while(*prefix && *p && ci_char(*prefix)==ci_char(*p)){prefix++;p++;}
    if(!*prefix && ci_ends(name,".log"))return 1;
#ifdef _WIN32
    if(active_log_path[0]){
        char canonical[PATH_CAP];DWORD n=GetFullPathNameA(path,sizeof(canonical),canonical,0);
        if(n && n<sizeof(canonical) && ci_equal(canonical,active_log_path))return 1;
    }
#else
    if(active_log_path[0] && !strcmp(path,active_log_path))return 1;
#endif
    return 0;
}
static void scan_file(const char *path) {
    ARC *a;
    if(own_log_file(path))return;
    if(current_root_mask[0] && !wild(current_root_mask,base_name(path)))return;
    progress_tick(path,0);
    if(cfg.exclusions[0]&&listed(cfg.exclusions,path))return;
    if(!archive_name(path)){grep_disk(path);return;}
    a=new_reader();if(!a){warnmsg("Cannot create archive reader");return;}
    if(ar.open_filename(a,path,CHUNK)==0) {
        stat_count.files++;
        process_archive(a,path,0,path,0,0);
    } else {
        if(cfg.logging && cfg.verbose)output("FALLBACK plain text (unreadable archive): %s\n",path);
        ar.read_free(a);grep_disk(path);return;
    }
    ar.read_free(a);
}
static void scan_path(const char *path,int level) {
#ifdef _WIN32
    WIN32_FIND_DATAA data;HANDLE handle;char search[PATH_CAP],full[PATH_CAP];
    size_t len=strlen(path);
    DWORD attr;
    if(level>256){warnmsg("Directory nesting limit exceeded: %s",path);return;}
    attr=GetFileAttributesA(path);
    if(attr==INVALID_FILE_ATTRIBUTES){warnmsg("Cannot access path: %s",path);return;}
    if(!(attr&FILE_ATTRIBUTE_DIRECTORY)){scan_file(path);return;}
    if(!allowed(path,1))return;
    if(len+4>=sizeof(search))return;
    strcpy(search,path);
    if(len&&path[len-1]!='\\'&&path[len-1]!='/')strcat(search,"\\");
    strcat(search,"*");
    handle=FindFirstFileA(search,&data);
    if(handle==INVALID_HANDLE_VALUE)return;
    do {
        if(!strcmp(data.cFileName,".")||!strcmp(data.cFileName,".."))continue;
        if((data.dwFileAttributes&FILE_ATTRIBUTE_REPARSE_POINT)!=0)continue;
        if(len+strlen(data.cFileName)+3>=sizeof(full)){stat_count.skipped++;continue;}
        strcpy(full,path);
        if(len&&path[len-1]!='\\'&&path[len-1]!='/')strcat(full,"\\");
        strcat(full,data.cFileName);
        if(data.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)scan_path(full,level+1);
        else scan_file(full);
    }while(FindNextFileA(handle,&data));
    FindClose(handle);
#else
    DIR *dir;struct dirent *ent;struct stat st;char full[PATH_CAP];size_t len;
    if(level>256){warnmsg("Directory nesting limit exceeded: %s",path);return;}
    if(lstat(path,&st)!=0){warnmsg("Cannot access path: %s",path);return;}
    if(S_ISLNK(st.st_mode))return;
    if(!S_ISDIR(st.st_mode)){scan_file(path);return;}
    if(!allowed(path,1))return;
    dir=opendir(path);if(!dir){stat_count.skipped++;return;}
    while((ent=readdir(dir))!=0) {
        if(!strcmp(ent->d_name,".")||!strcmp(ent->d_name,".."))continue;
        len=strlen(path);
        if(len+strlen(ent->d_name)+3>=sizeof(full)){stat_count.skipped++;continue;}
        strcpy(full,path);if(len&&path[len-1]!='/')strcat(full,"/");strcat(full,ent->d_name);
        scan_path(full,level+1);
    }
    closedir(dir);
#endif
}
static void scan_roots(void) {
    const char *p=cfg.topdirs;char path[PATH_CAP];size_t j;
    while(*p) {
        j=0;while(*p==';'||isspace((unsigned char)*p))p++;
        while(*p&&*p!=';'){if(j+1<sizeof(path))path[j++]=*p;p++;}
        path[j]=0;trim(path);
        if(path[0]) {
            /* A root with trailing DOS wildcards means recursive basename
               filtering, e.g. G:\downloads\*.zip; do not pass wildcard
               characters to GetFileAttributesA(). */
            char *last=path,*q=path;
            while(*q){if(*q=='/'||*q=='\\')last=q+1;q++;}
            current_root_mask[0]=0;
            if(strchr(last,'*')||strchr(last,'?')) {
                copystr(current_root_mask,sizeof(current_root_mask),last);
                if(last==path)copystr(path,sizeof(path),".");
                else if(last==path+3 && path[1]==':')path[3]=0;
                else if(last>path)last[-1]=0;
            }
            scan_path(path,0);
            current_root_mask[0]=0;
        }
        if(*p==';')p++;
    }
}
static void help(const char *exe) {
    printf("GREPZIPC %s - recursive text regex search in nested archives\n",VERSION);
    printf("Usage: %s [-ini file] [-d dir[;dir...]] [-e regex] [-o ix] [-v]\n",exe);
    printf("  -ini FILE   Read settings file (default grepzipc.ini)\n");
    printf("  -d PATHS   Override topdirectories (semicolon separated; quote on shell)\n");
    printf("  -e REGEX   Override searchstring (PCRE2 when x option is set)\n");
    printf("  -o FLAGS   i=case-insensitive; x=regex; missing x=literal\n");
    printf("  -v         Verbose traversal\n");
    printf("  -h         Show help\n");
}
int main(int argc,char **argv) {
    int i,verbose_cli=0;char inifile[PATH_CAP]="grepzipc.ini";char *dirs=0,*expr=0,*opts=0;
    char defaultlog[128];struct tm *t;time_t end;
    defaults();
    for(i=1;i<argc;i++){
        if(!strcmp(argv[i],"-ini")&&i+1<argc)copystr(inifile,sizeof(inifile),argv[++i]);
        else if(!strcmp(argv[i],"-d")&&i+1<argc)dirs=argv[++i];
        else if(!strcmp(argv[i],"-e")&&i+1<argc)expr=argv[++i];
        else if(!strcmp(argv[i],"-o")&&i+1<argc)opts=argv[++i];
        else if(!strcmp(argv[i],"-v"))verbose_cli=1;
        else if(!strcmp(argv[i],"-h")||!strcmp(argv[i],"--help")||!strcmp(argv[i],"/?")){help(argv[0]);return 0;}
        else {fprintf(stderr,"Unknown or incomplete argument: %s\n",argv[i]);help(argv[0]);return 2;}
    }
    read_ini(inifile);
    append_filter_file(cfg.inclusions,sizeof(cfg.inclusions),cfg.inclusion_file);
    append_filter_file(cfg.exclusions,sizeof(cfg.exclusions),cfg.exclusion_file);
    if(verbose_cli)cfg.verbose=1;
    if(dirs)copystr(cfg.topdirs,sizeof(cfg.topdirs),dirs);
    if(expr)copystr(cfg.expression,sizeof(cfg.expression),expr);
    if(opts)copystr(cfg.options,sizeof(cfg.options),opts);
    if(!cfg.expression[0]){help(argv[0]);fprintf(stderr,"ERROR: searchstring missing from INI / -e\n");return 2;}
    if(!init_archive()){
        fprintf(stderr,"ERROR: libarchive dynamic library or its exports not found. See README.\n");return 3;
    }
    if(!init_regex()){
        fprintf(stderr,"ERROR: PCRE2-8 dynamic library or its exports not found. See README.\n");return 3;
    }
    if(!prepare_regex())return 2;
    began=time(0);
    last_progress=began;
    if(cfg.logging){
        if(!cfg.logfile[0]){
            t=localtime(&began);
            sprintf(defaultlog,"grepzipc%04d%02d%02d%02d%02d%02d.log",
                t->tm_year+1900,t->tm_mon+1,t->tm_mday,t->tm_hour,t->tm_min,t->tm_sec);
            copystr(cfg.logfile,sizeof(cfg.logfile),defaultlog);
        }
        log_limit=cfg.max_log_mb*1048576UL;
#ifdef _WIN32
        {
            DWORD n=GetFullPathNameA(cfg.logfile,sizeof(active_log_path),active_log_path,0);
            if(!n || n>=sizeof(active_log_path))active_log_path[0]=0;
        }
#else
        copystr(active_log_path,sizeof(active_log_path),cfg.logfile);
#endif
        /* Use a new/truncated file rather than appending to an existing giant log. */
        log_fp=fopen(cfg.logfile,"wb");
        if(!log_fp)fprintf(stderr,"WARNING: could not open log file %s\n",cfg.logfile);
    }
    if(cfg.logging) {
        output("GREPZIPC %s | PCRE2 regex | libarchive nested archives\n",VERSION);
        output("Top directories: %s\nExpression: %s\nOptions: %s\n",cfg.topdirs,cfg.expression,cfg.options);
        output("Inclusions: %s | Exclusions: %s\n",cfg.inclusions[0]?cfg.inclusions:"(all)",cfg.exclusions[0]?cfg.exclusions:"(none)");
        output("Archive nesting limit: %d | Nested archive buffer limit: %lu MiB\n",cfg.max_depth,cfg.max_nested_mb);
        output("External archive fallback: %s | 7-Zip: %s | RAR: %s\n",cfg.use_external_fallback?"yes":"no",cfg.sevenzip,cfg.rar);
        output("Extractor timeout: %lu s | Progress interval: %lu s | Max external attempts: %lu (0=unlimited)\n",cfg.extractor_timeout_seconds,cfg.progress_interval_seconds,cfg.max_external_attempts);
        output("Logging: %s | Log results: %s | Max log: %lu MiB | Warning display limit: %lu\n",
            cfg.logging?"yes":"no",cfg.log_results?"yes":"no",cfg.max_log_mb,cfg.max_warnings);
        output("--- RESULTS ---\n");
    }
    scan_roots();
    progress_tick("completed",1);
    end=time(0);
    output("--- SUMMARY ---\n");
    output("Files: %lu | Archives: %lu | Members: %lu | Lines: %lu | Hits: %lu\n",
        stat_count.files,stat_count.archives,stat_count.members,stat_count.lines,stat_count.hits);
    output("Skipped: %lu | Oversize nested archives: %lu | Overlong lines: %lu | Errors: %lu\n",
        stat_count.skipped,stat_count.nested_skipped,stat_count.long_lines,stat_count.errors);
    output("External attempts: %lu | Timeouts: %lu | Skipped due to attempt limit: %lu\n",external_attempts,external_timeouts,external_skipped);
    output("Elapsed: %.0f seconds\n",difftime(end,began));
    if(cfg.logging && stat_count.errors>warnings_shown)
        output("Warnings suppressed: %lu (total warnings: %lu)\n",stat_count.errors-warnings_shown,stat_count.errors);
    if(log_fp)fclose(log_fp);
    if(regex_match_data)re.freematchdata(regex_match_data);
    if(regex_code)re.freecode(regex_code);
    if(ar.handle)lib_close(ar.handle);
    if(re.handle)lib_close(re.handle);
    return stat_count.errors?1:0;
}
