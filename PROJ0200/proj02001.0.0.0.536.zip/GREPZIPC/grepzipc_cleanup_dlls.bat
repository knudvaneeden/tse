@echo off
setlocal
REM GREPZIPC 1.0.0.0.10 - default PREVIEW; DELETE requires confirmation.
REM Uses Windows PowerShell and reads DLL PE import tables recursively.
set "APPLY="
if /I "%~1"=="DELETE" set "APPLY=-Apply"
if not "%~1"=="" if not defined APPLY (
  echo Usage: grepzipc_cleanup_dlls.bat [DELETE]
  exit /b 2
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0grepzipc_cleanup_dlls.ps1" %APPLY%
exit /b %ERRORLEVEL%
