# GREPZIPC 1.0.0.0.10 — changes

- **No DLLs bundled.** Use the 32-bit DLLs already in the GREPZIPC directory.
- **Root wildcard paths** such as `G:\mydownloadfiles\from_job_to_home\*.zip` recursively traverse the directory but only open disk files whose basename matches the wildcard. Archive members inside matching ZIPs remain eligible for searching. Other roots without masks remain unrestricted.
- **`logging=no`** displays only matching lines and a concise final summary. Progress, archive warnings, extractor start/end diagnostics, and verbose traversal are suppressed; errors still count in the final summary. No log file is created.
- **`logging=yes`** enables diagnostics/progress and writes the bounded logfile, with `logresults=no` by default.
- **DLL cleanup:** `grepzipc_cleanup_dlls.bat` previews deletion candidates without changing files. `grepzipc_cleanup_dlls.bat DELETE` reruns the dependency analysis and asks for a typed confirmation. It uses `grepzipc_cleanup_dlls.ps1` (included), recursively reads native PE normal/delay import tables and keeps the two explicitly dynamically loaded root DLLs. **Back up first.** Other explicit runtime LoadLibrary calls, optional codecs, or dynamically chosen plugins cannot always be detected from PE imports; test the cleaned copy. Any unresolved dependency or unparseable module stops deletion.
- The working fallback and 30-second timeout behavior from version 9 is retained.

## Files

`grepzipc.c`, `grepzipc.ini`, `grepzipc_readme.md`, `build_bcc55.bat`, `build_linux.sh`, `grepzipc_cleanup_dlls.bat`, `grepzipc_cleanup_dlls.ps1`.

---

# GREPZIPC 1.0.0.0.5

**Native C recursive regular-expression search over directories and nested archives**

## What this version implements

- The main program is a single `grepzipc.c` file, written in conservative C89/C90 style with Win32 directory traversal so it can be **compiled with the Borland C++ 5.5 command-line compiler (`bcc32.exe`)**.
- Recursively scans one or multiple `topdirectories` separated by `;`.
- Uses **PCRE2** regex matching, including `i` (ignore case) and `x` (regex mode); without `x`, the expression is treated literally.
- Uses **libarchive** to read ZIP/JAR, TAR/TGZ, GZIP, BZIP2, XZ, 7Z, CPIO and other formats supported by the particular library build. RAR read support varies by libarchive build and by RAR variant.
- Scans nested archive files recursively, e.g. `outer.zip!inner.tar.gz!file.txt`.
- Streams normal files and normal archive members through 64-KiB input buffers. Only **nested archive members** need to be buffered in RAM for libarchive's memory reader.
- Reports matching filenames, line numbers, **1-based byte column numbers**, and matching source lines.
- Uses DOS-like, case-insensitive wildcard inclusions and exclusions; skips excluded directories; recognizes directory-prefix exclusions.
- Optional INFO-style logging, elapsed-time summary, counters, and verbose traversal.

## Important distinction: standalone source vs. standalone executable

All GREPZIPC *application logic* is in `grepzipc.c`; **no TSE/SAL, PowerShell, Python, shell scripts or 7z.exe are required to run it**. However, this v1 implementation **does not produce a dependency-free EXE**: fast PCRE2 regex and archive decompression are supplied by **external native DLLs**. To run the Windows EXE, obtain **32-bit** builds of:

- `archive.dll` (or `libarchive.dll` / `libarchive-13.dll`) and all DLLs it depends on;
- `pcre2-8.dll` (or `libpcre2-8-0.dll`).

Place the required DLLs (and their dependencies) beside `grepzipc.exe`, or otherwise make them available on the DLL search path. **64-bit DLLs cannot be loaded into the Borland-generated 32-bit executable.** They are **not bundled** in the ZIP to avoid mismatched builds and redistribution/licensing complications. GREPZIPC uses Windows `LoadLibrary`/`GetProcAddress`, so **no Borland `.lib` import libraries and no PCRE2/libarchive header files are required** to compile.

This design is intentionally a pragmatic first native-C version. Producing a genuinely single-file EXE would require statically linking or vendoring the full archive decompression and PCRE2 implementations, which is a separate, larger task.

## Borland C++ 5.5 (Windows 11, 32-bit console)

1. Install the Borland C++ 5.5 command-line compiler and ensure its standard headers and startup libraries are configured correctly.
2. Run `build_bcc55.bat` beside `grepzipc.c`. The script automatically discovers `bcc32.exe` beside the script, in the current directory, or on `PATH`. It also derives the standard `include` and `lib` locations from the detected `bcc32.exe` path, passing both `-I` and `-L` automatically. No compiler path editing is needed. Alternatively build directly with:

   ```bat
   bcc32 -tWC -O2 -w- -I"G:\language\computer\cpp\embarcadero\borland\bcc55\include" -L"G:\language\computer\cpp\embarcadero\borland\bcc55\lib" grepzipc.c
   ```

3. Place the required 32-bit DLLs beside the compiled EXE.
4. Edit `grepzipc.ini` and execute `grepzipc.exe` in the directory containing the INI (or specify `-ini` explicitly).

**Validation:** The C source was built and tested using GCC on Linux. A local installation of Borland C++ 5.5 and compatible Windows DLLs was not available for a direct Borland compile/run test. The build command and compatibility are therefore **targets, not a verified Borland build**.

## Linux build (included for regression testing)

```sh
./build_linux.sh
./grepzipc -d test -e 'ERROR|WARNING' -o ix
```

The Linux program loads `libarchive.so` and `libpcre2-8.so` at runtime; it links only to `libdl`. Native Windows use is the primary target.

## Command line

```text
grepzipc [-ini FILE] [-d "dir1;dir2"] [-e "REGEX"] [-o ix] [-v]
```

- `-ini FILE`: INI filename (defaults to `grepzipc.ini` in the current working directory).
- `-d "PATHS"`: override semicolon-delimited `topdirectories`.
- `-e "REGEX"`: override `searchstring`.
- `-o ix`: override the options; `i` ignore case, `x` PCRE2 regex; without `x`, literal matching.
- `-v`: print traversed filenames/archives for debugging.
- `-h`: help.

Example on Windows:

```bat
grepzipc.exe -d "C:\projects;D:\sources" -e "ERROR|WARNING|fatal" -o ix
```

## grepzipc.ini

| Key | Meaning |
|---|---|
| `topdirectories` | One or more roots separated by `;` |
| `searchstring` | Regular expression or literal text |
| `searchoptions` | `i`, `x` (default `ix`) |
| `inclusions` | Semicolon-delimited DOS wildcard filename masks / optional directory prefixes |
| `exclusions` | Semicolon-delimited DOS wildcard filename masks / directory prefixes |
| `includefile` | Optional one-pattern-per-line inclusion file appended to `inclusions` |
| `excludefile` | Optional one-pattern-per-line exclusion file appended to `exclusions` |
| `showfilenames` | `yes`/`no`, default `yes` |
| `logging` | `yes`/`no` |
| `logfile` | Explicit log path; empty creates timestamped `grepzipcYYYYMMDDHHMMSS.log` |
| `verbose` | `yes`/`no` |
| `maxnesteddepth` | Maximum archive-in-archive depth (default 12) |
| `maxnestedmb` | Maximum RAM used per buffered nested archive (default 256 MiB) |
| `maxlinelength` | Maximum line bytes for matching (default 262144) |

A leading `;` comments out an entire INI line. Within a non-comment value, `;` separates masks or paths.

**Important filter behavior:** Archive containers are always traversed even when their filenames do not match `inclusions`. Only actual text members/files need to match inclusions. Exclusions can suppress archive containers or whole directory subtrees. Member paths use `!` to represent nesting.

## Result format

```text
C:\data\outer.zip!inner.zip!file.txt:17:6:ERROR found something
```

The displayed column counts **bytes**, not Unicode characters; regex matching is byte-oriented. Each matching line appears once, not once per occurrence. With `showfilenames=no`, only line, byte column, and text are shown.

## Current limitations and technical caveats

- **Not a dependency-free single EXE**; native DLLs are required on Windows.
- Requires compatible DLL distributions; this release does not include the DLLs or an EXE.
- The program is designed for speed but **has no proven performance advantage** over GREPZIP or GREPZIPTSE yet; benchmark on your actual archive datasets.
- Recursive archive formats available depend on the installed libarchive. Encrypted, corrupt, unsupported, or unusual RAR/7z archives may be skipped or produce diagnostic messages.
- Nested archives must fit within `maxnestedmb` (and available process RAM). Because Borland 5.5 is 32-bit, this limit is especially important.
- Long lines above `maxlinelength` are **skipped**, never silently truncated; the count is included in the summary.
- Binary files with NUL bytes are not searched as text on affected lines.
- For now, filenames are read with the platform's native narrow-character encoding and PCRE2 searches byte strings (no Unicode normalization).
- Filesystem symbolic links/reparse points are not recursively followed.
- Logging and output are synchronous; logging every hit can reduce speed.
- Numeric counters are 32-bit `unsigned long` for compatibility with the classic compiler and may wrap for extremely large searches.
- INI keys and values are capped by the fixed-size input buffers. This first version does not support multiline patterns, GUI clickable results, TSE macro navigation, or non-`ix` TSE-specific search switches.

## Test performed

Built the code using GCC (`-std=c89`), generated `outer.zip` containing `inner.zip` containing `inside.txt`, and confirmed a hit from `outer.zip!inner.zip!inside.txt` plus a separate hit from an ordinary text file. The archive and plain-file test directories are **not included** in the release ZIP.

## Package contents

- `grepzipc.c` — full native application source
- `grepzipc.ini` — configurable settings and disabled examples
- `grepzipc_readme.md` — this documentation
- `build_bcc55.bat` — Borland C++ 5.5 build command
- `build_linux.sh` — Linux validation build command

## License

GREPZIPC application source in this package: MIT license, copyright (c) 2026. Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files, to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to inclusion of this copyright notice and permission notice in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.

The third-party PCRE2 and libarchive libraries have their own license terms.

## Borland C++ 5.5 header compatibility (1.0.0.0.5)

Borland 5.5 `windows.h` can lack `INVALID_FILE_ATTRIBUTES`. The C source now provides the SDK-compatible `((DWORD)0xFFFFFFFFUL)` value only when the header has not defined it. This addresses compiler error E2451 at `scan_path`; native Borland compilation still requires testing on Windows.

## Windows DLLs bundled with version 1.0.0.0.5

The package includes the user-provided 32-bit Windows DLLs `libarchive-13.dll` and `libpcre2-8-0.dll`, originating from `G:\LANGUAGE\COMPUTER\CPP\CLANG19\mingw32\bin\`. Both are PE32 (x86) and their exports required by GREPZIPC have been verified.

**These are not sufficient by themselves for a fully portable installation.** `libarchive-13.dll` additionally imports (among system libraries) `libb2-1.dll`, `libbz2.dll`, `libexpat-1.dll`, `libgcc_s_dw2-1.dll`, `libiconv-2.dll`, `liblz4.dll`, `liblzma-5.dll`, `liblzo2-2.dll`, `libnettle-8.dll`, `libzstd.dll`, and `zlib1.dll`. These must be found via the Windows DLL search path, typically by adding `G:\LANGUAGE\COMPUTER\CPP\CLANG19\mingw32\bin` to PATH, if present. Other dependent DLLs may have their own requirements.

Run from CMD or TCC:

```bat
set "PATH=G:\LANGUAGE\COMPUTER\CPP\CLANG19\mingw32\bin;%PATH%"
cd /d F:\BBC\taal\GREPZIPC
grepzipc.exe
```

The two bundled DLLs should be kept alongside `grepzipc.exe`. The C executable remains built by `build_bcc55.bat` using Borland C++ 5.5.1. DLL architecture and exports were inspected, but the Windows runtime has not been tested here.


## 1.0.0.0.10 external archive fallback (Windows)

When native libarchive cannot decode an individual archive member (including legacy ZIP
Shrink method 1 and Implode method 6), GREPZIPC attempts to extract just that member
with 7-Zip and search the resulting temporary file. This also applies to members
of nested archives; the in-memory parent archive is staged to a temporary file only
when necessary. The fallback is intentionally not used for normally readable members.

Configure:

```ini
[ArchiveTools]
UseExternalFallback=yes
SevenZipExecutable=C:\Program Files\7-Zip\7z.exe
RarExecutable=C:\Program Files\WinRAR\Rar.exe
```

Supported archive extensions recognized by GREPZIPC include ZIP, JAR, TAR, TGZ,
RAR, 7Z and several others supported by libarchive. The WinRAR executable is
attempted as a secondary fallback if 7-Zip fails (WinRAR primarily supports RAR).
The fallback launches tools directly via CreateProcess, redirects their stdout to
a temporary file and deletes temporary files afterward. If fallback also fails,
a warning is reported and the error is counted. Password-protected archives need
user-supplied extraction credentials; unattended password prompts are not supported.

**Limitations:** Fallback handles member read failures where libarchive is able
to enumerate the archive and its member names. It does not yet recover archives
whose headers cannot be parsed at all. Linux builds retain native libarchive
processing; external tool fallback currently targets Windows.

The current release has been compiled and tested with GCC on Linux. Borland C++
5.5.1 compilation and Windows 7-Zip execution still require user testing.


## Version 1.0.0.0.10: fallback diagnostics

Version 7 reported a generic `external fallback unavailable/failed` even if
`7z.exe` was missing or failed to launch. Version 8 distinguishes these outcomes:
configured executable not found, process launch Win32 error, extractor exit code,
and captured extractor standard-error output (when available).

The archive type and ZIP compression method are separate concepts. ZIP method 6
(Implode) and method 1 (Shrink) can be handled by supported versions of 7-Zip,
but successful fallback requires the correct 7-Zip executable path and working
extraction of the exact archive member.

For a focused test on Windows (do not scan all top directories yet):

```bat
grepzipc.exe -d "F:\BBC\taal\COMPARE4\compare4.zip" -e "PipeBytesAvail" -o i
```

If the fallback fails, capture the entire `WARNING` line. Confirm that
`C:\Program Files\7-Zip\7z.exe` exists and is runnable.

This release was compiled/tested under Linux GCC for the native path.
Borland C++ 5.5 and Windows external fallback remain to be verified.


## Version 1.0.0.0.10 timeout/diagnostic revision (2026-11-14)

* `ExtractorTimeoutSeconds=30` limits each 7-Zip / WinRAR child-process wait.
  On timeout GREPZIPC terminates the extractor, reports the timeout, and skips
  the unreadable entry. The timeout applies to *each* extractor attempt.
* Extractors receive EOF on stdin (Windows NUL handle), preventing interactive
  password prompts from waiting for terminal input.
* `ProgressIntervalSeconds=10` prints counts and the current path periodically
  at file/member/chunk boundaries. This is **not** a separate heartbeat thread:
  a blocked DLL call may prevent intermediate messages.
* `EXTRACT start` / `EXTRACT end` messages identify exact external calls and
  result codes. They print even when ordinary `verbose=no`.
* Existing 10-MB capped logging, self-log exclusion and warning limits remain.

These are protective diagnostics, not a verified fix for all archive corruption
or unsupported-method cases. Test a single problematic ZIP before a large scan.
Borland C++ 5.5 compilation must still be checked on Windows.


## Version 1.0.0.0.10: protection against repeated slow extraction

- Continues to use the 30-second **per-process** timeout from version 8.
- New `MaxExternalAttempts=200` controls the number of external 7-Zip/WinRAR invocations per entire search. This protects against an unexpected collection of slow legacy ZIP members. `0` disables the cap.
- Each invocation prints its attempt number. Summary includes attempts, timeouts and entries skipped because of the cap.
- **Correctness tradeoff:** when the cap is reached, unreadable members are skipped and reported as warnings. Raise it or set it to `0` for a more exhaustive search.
- No changes to GREPZIPC's built-in search semantics or Borland build command.
- A single long-running call inside libarchive cannot be timed out by this option; this requires process-level isolation for a hard deadline.

Borland C++ 5.5.1 / Windows testing still required. GNU C regression compilation is not equivalent to testing the 32-bit Windows fallback.


### Cleanup script compatibility correction

The `grepzipc1.0.0.0.10_cleanupfix.zip` repackage corrects the PowerShell 5.1 parser error caused by a UTF-8 em dash in the original cleanup script. The script now has an explicit UTF-8 BOM and ASCII-only script body. No changes to the C search program were made. The cleanup remains a dry-run by default; DLLs must not be deleted without reviewing the candidates and making a backup.
