@echo off
REM GREPZIPC 1.0.0.0.6 - Borland C++ 5.5 auto compiler/include/lib detection.
REM Works under CMD.EXE and TCC.EXE without aliases or hard-coded drive letters.
setlocal
set "SOURCE_DIR=%~dp0"
set "BCC32="
if exist "%SOURCE_DIR%bcc32.exe" set "BCC32=%SOURCE_DIR%bcc32.exe"
if not defined BCC32 if exist "%CD%\bcc32.exe" set "BCC32=%CD%\bcc32.exe"
if not defined BCC32 for %%G in (bcc32.exe) do if not "%%~$PATH:G"=="" set "BCC32=%%~$PATH:G"
if not defined BCC32 (
  echo ERROR: bcc32.exe not found beside script, in current directory, or on PATH.
  exit /b 1
)
if not exist "%SOURCE_DIR%grepzipc.c" (
  echo ERROR: Missing "%SOURCE_DIR%grepzipc.c".
  exit /b 1
)
REM Derive bcc55 root from the parent of the detected Bin directory.
for %%G in ("%BCC32%") do set "BORLAND_BIN=%%~dpG"
for %%G in ("%BORLAND_BIN%..") do set "BORLAND_ROOT=%%~fG"
set "BORLAND_INCLUDE=%BORLAND_ROOT%\include"
set "BORLAND_LIB=%BORLAND_ROOT%\lib"
if not exist "%BORLAND_INCLUDE%\stdio.h" (
  echo ERROR: Standard Borland header not found: "%BORLAND_INCLUDE%\stdio.h"
  echo Expected bcc32.exe under the compiler's bin directory, alongside include and lib.
  exit /b 1
)
if not exist "%BORLAND_LIB%\" (
  echo ERROR: Borland library directory not found: "%BORLAND_LIB%"
  exit /b 1
)
echo Compiler: "%BCC32%"
echo Headers : "%BORLAND_INCLUDE%"
echo Libraries: "%BORLAND_LIB%"
pushd "%SOURCE_DIR%"
"%BCC32%" -tWC -O2 -w- -I"%BORLAND_INCLUDE%" -L"%BORLAND_LIB%" grepzipc.c
set "RESULT=%ERRORLEVEL%"
popd
if not "%RESULT%"=="0" (
  echo ERROR: Borland compilation failed with error %RESULT%.
  exit /b %RESULT%
)
echo Built "%SOURCE_DIR%grepzipc.exe".
echo Runtime requires matching 32-bit libarchive and PCRE2 DLLs.
endlocal
exit /b 0
