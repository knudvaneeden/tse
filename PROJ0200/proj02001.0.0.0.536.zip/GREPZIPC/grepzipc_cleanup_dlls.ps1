﻿# GREPZIPC 1.0.0.0.10 - PE import table dependency closure, NO third party modules.
# Preview is default. -Apply requires interactive DELETE confirmation.
param([switch]$Apply)
$ErrorActionPreference = 'Stop'
$folder = Split-Path -Parent $MyInvocation.MyCommand.Path
$systemNames = @('kernel32.dll','kernelbase.dll','ntdll.dll','user32.dll','gdi32.dll','gdi32full.dll','advapi32.dll','shell32.dll','shlwapi.dll','ole32.dll','oleaut32.dll','comdlg32.dll','comctl32.dll','ws2_32.dll','wsock32.dll','winmm.dll','version.dll','rpcrt4.dll','bcrypt.dll','bcryptprimitives.dll','crypt32.dll','secur32.dll','wintrust.dll','setupapi.dll','imm32.dll','msvcrt.dll','ucrtbase.dll','msvcp_win.dll','vcruntime140.dll','vcruntime140_1.dll','dbghelp.dll','psapi.dll','iphlpapi.dll','dnsapi.dll','userenv.dll','netapi32.dll','normaliz.dll','cfgmgr32.dll','mpr.dll','winhttp.dll','wininet.dll','usp10.dll','dwmapi.dll','wtsapi32.dll','cryptbase.dll','ncrypt.dll','profapi.dll','powrprof.dll','propsys.dll','msimg32.dll','msacm32.dll','avrt.dll')
function IsSystemName([string]$s) {
  if ($s -match '^(api-ms-win-|ext-ms-win-)') {return $true}
  return $systemNames -contains $s.ToLowerInvariant()
}
# Parse PE32 and PE32+ normal and delay imports, resolving file offsets through section table.
function GetImports([string]$file) {
  $bytes = [IO.File]::ReadAllBytes($file)
  if ($bytes.Length -lt 256) {throw "Not a valid PE file: $file"}
  function U16([int]$o) {if($o -lt 0 -or $o+2 -gt $bytes.Length){throw 'PE truncated'};return [BitConverter]::ToUInt16($bytes,$o)}
  function U32([int]$o) {if($o -lt 0 -or $o+4 -gt $bytes.Length){throw 'PE truncated'};return [BitConverter]::ToUInt32($bytes,$o)}
  if ((U16 0) -ne 0x5a4d) {throw "Missing MZ signature: $file"}
  $pe=[int](U32 0x3c)
  if ((U32 $pe) -ne 0x4550) {throw "Missing PE signature: $file"}
  $nsect=[int](U16 ($pe+6));$optsize=[int](U16 ($pe+20));$opt=$pe+24
  $magic=U16 $opt
  if($magic -eq 0x10b){$dirs=$opt+96}
  elseif($magic -eq 0x20b){$dirs=$opt+112}
  else {throw "Unknown PE optional header: $file"}
  $sectAt=$opt+$optsize;$sects=@()
  for($i=0;$i -lt $nsect;$i++){
    $a=$sectAt+($i*40)
    $sects+=@{VA=[uint64](U32 ($a+12));VS=[uint64](U32 ($a+8));Size=[uint64](U32 ($a+16));Raw=[uint64](U32 ($a+20))}
  }
  function RvaOff([uint64]$rva) {
    foreach($s in $sects){
      $count=[Math]::Max($s.VS,$s.Size)
      if($rva -ge $s.VA -and $rva -lt $s.VA+$count){
        $off=[uint64]($s.Raw+$rva-$s.VA)
        if($off -ge $bytes.Length){throw 'RVA points beyond file'}
        return [int]$off
      }
    }
    if($rva -lt $sectAt){return [int]$rva}
    throw "Unmappable RVA $rva in $file"
  }
  function ReadName([int]$o){
    $end=$o
    while($end -lt $bytes.Length -and $bytes[$end] -ne 0){$end++;if($end-$o -gt 512){throw 'PE DLL name too long'}}
    if($end -eq $bytes.Length){throw 'Unterminated PE DLL name'}
    return [Text.Encoding]::ASCII.GetString($bytes,$o,$end-$o)
  }
  $names=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
  $importRva=U32 ($dirs+8)
  if($importRva -ne 0){
    $offset=RvaOff $importRva
    for($i=0;$i -lt 8192;$i++){
      $a=$offset+20*$i;$nameRva=U32 ($a+12)
      if((U32 $a) -eq 0 -and $nameRva -eq 0 -and (U32 ($a+16)) -eq 0){break}
      if($nameRva -ne 0){[void]$names.Add((ReadName (RvaOff $nameRva)))}
      if($i -eq 8191){throw 'Import descriptor limit exceeded'}
    }
  }
  $delayRva=U32 ($dirs+13*8)
  if($delayRva -ne 0){
    $offset=RvaOff $delayRva
    for($i=0;$i -lt 8192;$i++){
      $a=$offset+32*$i;$attr=U32 $a;$nameRva=U32 ($a+4)
      if($attr -eq 0 -and $nameRva -eq 0){break}
      if(($attr -band 1) -eq 0){throw "Delay import uses absolute address, cannot resolve safely: $file"}
      if($nameRva -ne 0){[void]$names.Add((ReadName (RvaOff $nameRva)))}
      if($i -eq 8191){throw 'Delay import descriptor limit exceeded'}
    }
  }
  return @($names)
}
try {
  $dlls=@(Get-ChildItem -LiteralPath $folder -Filter '*.dll' -File)
  $fileMap=@{}
  foreach($f in $dlls){$fileMap[$f.Name.ToLowerInvariant()]=$f.FullName}
  $needed=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
  $queue=[Collections.Generic.Queue[string]]::new()
  foreach($name in @('libarchive-13.dll','libpcre2-8-0.dll')){
    if(-not $fileMap.ContainsKey($name)){throw "Required root DLL is missing: $name"}
    [void]$needed.Add($name);$queue.Enqueue($fileMap[$name])
  }
  $exe=Join-Path $folder 'grepzipc.exe'
  if(Test-Path -LiteralPath $exe){$queue.Enqueue($exe)}
  while($queue.Count -gt 0){
    $file=$queue.Dequeue()
    foreach($dep in @(GetImports $file)){
      $lower=$dep.ToLowerInvariant()
      if($fileMap.ContainsKey($lower)){
        if($needed.Add($lower)){$queue.Enqueue($fileMap[$lower])}
      } elseif (-not (IsSystemName $lower)) {
        throw "Unresolved dependency '$dep' of '$file' - cleanup aborted. Supply the missing DLL or inspect it manually."
      }
    }
  }
  $remove=@($dlls | Where-Object { -not $needed.Contains($_.Name) } | Sort-Object Name)
  Write-Host "GREPZIPC DLL cleanup: $folder"
  Write-Host "DLL files found: $($dlls.Count); required by import tables: $($needed.Count); candidate unused: $($remove.Count)"
  Write-Host 'NOTE: Dynamic LoadLibrary calls cannot be inferred from PE imports. Root DLLs are explicitly retained.'
  foreach($f in $remove){Write-Host "UNUSED? $($f.Name)"}
  if(-not $Apply){Write-Host 'DRY RUN ONLY. To delete, back up the folder then run grepzipc_cleanup_dlls.bat DELETE';exit 0}
  if($remove.Count -eq 0){Write-Host 'No DLLs to delete.';exit 0}
  $confirm=Read-Host "Type DELETE to remove these $($remove.Count) DLLs after backup"
  if($confirm -cne 'DELETE'){Write-Host 'Cancelled; no files deleted.';exit 1}
  foreach($f in $remove){Remove-Item -LiteralPath $f.FullName -ErrorAction Stop;Write-Host "DELETED $($f.Name)"}
  Write-Host "Deleted $($remove.Count) DLLs; preserved $($needed.Count) DLLs."
}catch{
  Write-Error "Dependency analysis failed; deletion aborted: $_"
  exit 2
}
