#!/bin/sh
# Native Linux test build (no compile-time archive/PCRE2 linkage necessary).
set -eu
cc -O2 -std=c89 -D_POSIX_C_SOURCE=200809L -Wall -Wextra -o grepzipc grepzipc.c -ldl
