@echo off
REM COMMERMAID version 1.0.0.0.16 - Created by Codex
REM Render a Mermaid source file to SVG and write TSE diagnostics.
REM No PowerShell, JavaScript or SAL helper file is required.
REM PART 1 contains local settings. PART 2 contains stable logic.
REM Direct test in native TCC: COMMERMAID.BAT "C:\TEMP\errorstest.mmd"
REM CMD test: cmd.exe /d /c COMMERMAID.BAT "C:\TEMP\errorstest.mmd"
REM TSE parameters: %1=name %2=extension %3=full source filename
REM                 %4=drive %5=path %6=diagnostic output filename
REM Six-parameter test in either shell:
REM COMMERMAID.BAT "errorstest" ".mmd" "C:\TEMP\errorstest.mmd" "C:" "\TEMP\" "C:\TEMP\mermaid.err"
REM Runtime override: set COMMERMAID_CLI=full path to mmdc.cmd
REM Runtime override: set COMMERMAID_FORMAT=svg (or png or pdf)
REM Runtime override: set COMMERMAID_OPEN=0 to disable automatic opening
REM CLI stops at the first syntax error in a single diagram.
REM Error line comes from CLI. Column 1 is a fallback, NOT a measured column.
REM Raw CLI output is displayed and retained in a unique temporary folder.
REM No nested TCC invocation. CMD is used only for npm's mmdc.cmd wrapper.
REM Tested logic by inspection here; actual Windows shell tests are required.

REM ================= PART 1: USER SETTINGS =================
setlocal
if not defined COMMERMAID_CLI set "COMMERMAID_CLI=G:\UTILS\DIAGRAM\MERMAID\node_modules\.bin\mmdc.cmd"
if not defined COMMERMAID_FORMAT set "COMMERMAID_FORMAT=svg"
if not defined COMMERMAID_OPEN set "COMMERMAID_OPEN=1"

REM ================= PART 2: STABLE LOGIC ==================
set "CM_VERSION=1.0.0.0.16"
set "CM_RC=1"
set "CM_SHELL=CMD"
REM _4VER is a TCC internal variable, not an environment variable.
if not "%_4VER%"=="" set "CM_SHELL=TCC"
echo COMMERMAID version %CM_VERSION%
echo Shell: %CM_SHELL%
set "CM_SOURCE=%~1"
if not "%~3"=="" set "CM_SOURCE=%~3"
set "CM_ERR=%~6"
if not defined CM_ERR set "CM_ERR=%TEMP%\COMMERMAID_%RANDOM%_%RANDOM%.err"
>"%CM_ERR%" echo COMMERMAID version %CM_VERSION%
if not defined CM_SOURCE goto usage
for %%F in ("%CM_SOURCE%") do set "CM_SOURCE=%%~fF"
REM TCC: do not use IF EXIST filename\ to test whether it is a directory.
if "%CM_SHELL%"=="TCC" goto check_tcc
if exist "%CM_SOURCE%\NUL" goto missing
 goto check_file
:check_tcc
if isdir "%CM_SOURCE%" goto missing
:check_file
if not exist "%CM_SOURCE%" goto missing
if not exist "%COMMERMAID_CLI%" goto missing_cli
if /i "%COMMERMAID_FORMAT%"=="svg" goto format_ok
if /i "%COMMERMAID_FORMAT%"=="png" goto format_ok
if /i "%COMMERMAID_FORMAT%"=="pdf" goto format_ok
echo ERROR: COMMERMAID_FORMAT must be svg, png or pdf.
goto finish
:format_ok
for %%F in ("%CM_SOURCE%") do set "CM_OUT=%%~dpnF.%COMMERMAID_FORMAT%"
set "CM_WORK=%TEMP%\COMMERMAID_%RANDOM%_%RANDOM%"
md "%CM_WORK%"
if not exist "%CM_WORK%" goto temp_failed
set "CM_RAW=%CM_WORK%\raw.txt"
echo Rendering "%CM_SOURCE%"
REM CALL inside CMD lets npm's wrapper use CMD syntax even under native TCC.
REM Display resolved settings so command-line differences are visible.
echo CLI: "%COMMERMAID_CLI%"
echo Output: "%CM_OUT%"
echo Automatic opening: %COMMERMAID_OPEN%
cmd.exe /d /c call "%COMMERMAID_CLI%" -i "%CM_SOURCE%" -o "%CM_OUT%" >"%CM_RAW%" 2>&1
set "CM_RC=%ERRORLEVEL%"
type "%CM_RAW%"
echo Render exit code: %CM_RC%
if "%CM_RC%"=="0" goto success
REM Read only real diagnostic headers, not stack-frame line/column numbers.
"%SystemRoot%\System32\findstr.exe" /c:"Parse error on line " /c:"Lexical error on line " "%CM_RAW%" >"%CM_WORK%\locations.txt"
set "CM_LINE="
for /f "usebackq tokens=6 delims= :." %%L in ("%CM_WORK%\locations.txt") do set "CM_LINE=%%L"
if defined CM_LINE goto syntax_error
>>"%CM_ERR%" echo TSE: %CM_SOURCE%:1:1: Mermaid CLI failed - inspect retained raw output; source position unavailable.
goto show_errors
:syntax_error
>>"%CM_ERR%" echo TSE: %CM_SOURCE%:%CM_LINE%:1: Mermaid syntax error - column 1 fallback; see console for parser details.
:show_errors
type "%CM_ERR%"
echo Raw diagnostics: "%CM_RAW%"
goto finish
:success
echo Created "%CM_OUT%"
if not "%COMMERMAID_OPEN%"=="1" goto finish
if "%CM_SHELL%"=="TCC" goto open_tcc
echo Opening with CMD START.
start "Mermaid" "%CM_OUT%"
goto finish
:open_tcc
echo Opening with TCC START /PGM.
start /PGM "%CM_OUT%"
goto finish
:missing
>>"%CM_ERR%" echo ERROR: source file not found or is a directory: "%CM_SOURCE%"
type "%CM_ERR%"
goto finish
:missing_cli
>>"%CM_ERR%" echo ERROR: Mermaid CLI not found: "%COMMERMAID_CLI%"
type "%CM_ERR%"
goto finish
:temp_failed
echo ERROR: Could not create temporary directory "%CM_WORK%".
goto finish
:usage
echo Usage: COMMERMAID.BAT "source.mmd"
echo Or supply the six TSE parameters described in the REM header.
:finish
echo Diagnostics saved to "%CM_ERR%"
pause
if "%CM_SHELL%"=="TCC" goto finish_tcc
endlocal & exit /b %CM_RC%
:finish_tcc
endlocal & quit %CM_RC%
