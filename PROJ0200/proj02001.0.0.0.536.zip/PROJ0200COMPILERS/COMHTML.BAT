@echo off
REM COMHTML.BAT version 1.0.0.0.10 - OpenAI GPT-6
REM Browser launcher only: this does NOT validate or compile HTML.
REM No helper script or additional validator is required.
REM PART 1 contains user settings; PART 2 contains stable logic.
REM 1.0.0.0.10: TCC START errors use a scoped native ON ERROR handler.
REM Log writes still capture TCC internal status immediately via %_?%.
REM Native TCC START uses /PGM to identify the quoted launch target.
REM CMD status is reset before checked internal commands.
REM Regression test: after a failed external command, run this BAT.
REM An existing page should open with exit code 0 and no false error.
REM
REM Native TCC tests: run these directly at the TCC prompt.
REM COMHTML.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.html"
REM COMHTML.BAT "errorstest" "html" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.html" "F" "BBC\TAAL\PROJ0200ERRORSMULTIPLE" "C:\TEMP\comhtml.err"
REM CMD tests: run the same calls prefixed with cmd.exe /d /c.
REM Do not start another tcc.exe from a TCC console.
REM %1=name or direct filename; %2=extension; %3=full source filename;
REM %4=drive; %5=directory; %6=TSE diagnostics filename (overwritten).
REM In six-parameter mode %3 is authoritative; %1,%2,%4,%5 are unused.
REM Use full source paths for dependable TSE error jumps.
REM Optional browser: set COMHTML_BROWSER to a full executable path.
REM Optional unattended test: set COMHTML_PAUSE=0 before the call.
REM
REM OPTIONAL JUMP TEST (synthetic messages, NOT HTML validation):
REM COMHTML.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.html" --testjump
REM In TSE mode append --testjump as argument %7 to the rule Command.
REM This emits three explicitly synthetic messages at sample lines 8,9,10.
REM Restore the normal rule Command after checking all three jumps.
REM Normal mode opens the page and produces no syntax-error messages.
REM Missing file test: use a nonexistent full path; expect exit code 2.
REM Directory test: use an existing directory; expect exit code 2.
REM Also test an existing file in a directory containing spaces.
REM Exit codes: 0=launch accepted/test messages written; 1=usage;
REM 2=source missing/directory; 3=browser missing; 4=launch failure;
REM 5=diagnostics cannot be written.
REM Operational errors point to 1,1 as a navigation anchor, NOT an
REM HTML syntax location. The original source is never modified/deleted.
REM
REM ==================================================================
REM PART 1 - USER SETTINGS
REM ==================================================================
setlocal
REM Empty browser uses the Windows default HTML application.
REM Example: set "COMHTML_BROWSER=C:\Program Files\Mozilla Firefox\firefox.exe"
if not defined COMHTML_BROWSER set "COMHTML_BROWSER="
if not defined COMHTML_PAUSE set "COMHTML_PAUSE=1"
REM Default diagnostics directory; an explicit %6 takes precedence.
if not defined COMHTML_LOGDIR set "COMHTML_LOGDIR=%TEMP%"
if not defined COMHTML_LOGDIR set "COMHTML_LOGDIR=."

REM ==================================================================
REM PART 2 - MAIN LOGIC
REM ==================================================================
set "shellName=CMD"
if /i "%_CMDPROC%"=="TCC" set "shellName=TCC"
if /i "%_CMDPROC%"=="4NT" set "shellName=TCC"
if "%shellName%"=="CMD" setlocal DisableDelayedExpansion
set "source=%1"
set "tseSource=%3"
set "diagnostics=%6"
set "testMode=%2"
set "lastOption=%7"
set "source=%source:"=%"
set "tseSource=%tseSource:"=%"
set "diagnostics=%diagnostics:"=%"
set "testMode=%testMode:"=%"
set "lastOption=%lastOption:"=%"
set "COMHTML_BROWSER=%COMHTML_BROWSER:"=%"
if not "%tseSource%"=="" set "source=%tseSource%"
if not "%tseSource%"=="" set "testMode=%lastOption%"
if "%diagnostics%"=="" set "diagnostics=%COMHTML_LOGDIR%\COMHTML_%RANDOM%_%RANDOM%.err"
set "result=0"
set "message="
echo COMHTML version 1.0.0.0.10
echo Shell: %shellName%
if "%shellName%"=="TCC" goto internalTcc1
call :clearCmdStatus
> "%diagnostics%" echo COMHTML version 1.0.0.0.10
set "commandStatus=%ERRORLEVEL%"
goto internalChecked1
:internalTcc1
> "%diagnostics%" echo COMHTML version 1.0.0.0.10
set "commandStatus=%_?%"
:internalChecked1
if not "%commandStatus%"=="0" goto logError
if "%source%"=="" goto usage
if "%shellName%"=="TCC" goto internalTcc2
call :clearCmdStatus
>> "%diagnostics%" echo filename=%source%
set "commandStatus=%ERRORLEVEL%"
goto internalChecked2
:internalTcc2
>> "%diagnostics%" echo filename=%source%
set "commandStatus=%_?%"
:internalChecked2
if not "%commandStatus%"=="0" goto logError
if not exist "%source%" goto missing
if "%shellName%"=="TCC" goto checkTccDirectory
REM Only CMD executes attribute expansion; no trailing-slash file test.
for %%I in ("%source%") do set "sourceAttributes=%%~aI"
if /i "%sourceAttributes:~0,1%"=="d" goto directoryError
goto checkedSource

:checkTccDirectory
if isdir "%source%" goto directoryError

:checkedSource
if /i "%testMode%"=="--testjump" goto testJump
echo Opening "%source%"
if not "%COMHTML_BROWSER%"=="" goto customBrowser
if "%shellName%"=="TCC" goto internalTcc3
call :clearCmdStatus
start "" "%source%"
set "commandStatus=%ERRORLEVEL%"
goto internalChecked3
:internalTcc3
REM Trap actual START errors; asynchronous launch status is not HTML validation.
on error goto nativeStartError
start /PGM "%source%"
set "nativeStartStatus=%_?%"
on error
set "commandStatus=0"
:internalChecked3
if not "%commandStatus%"=="0" goto launchError
goto done

:customBrowser
if not exist "%COMHTML_BROWSER%" goto browserError
if "%shellName%"=="TCC" goto internalTcc4
call :clearCmdStatus
start "" "%COMHTML_BROWSER%" "%source%"
set "commandStatus=%ERRORLEVEL%"
goto internalChecked4
:internalTcc4
REM Trap actual START errors; asynchronous launch status is not HTML validation.
on error goto nativeStartError
start /PGM "%COMHTML_BROWSER%" "%source%"
set "nativeStartStatus=%_?%"
on error
set "commandStatus=0"
:internalChecked4
if not "%commandStatus%"=="0" goto launchError
goto done

:testJump
echo SYNTHETIC jump test only. No HTML validation was performed.
if "%shellName%"=="TCC" goto internalTcc5
call :clearCmdStatus
>> "%diagnostics%" echo TSE: "%source%"(8,1): SYNTHETIC jump test 1 - sample img lacks alt.
set "commandStatus=%ERRORLEVEL%"
goto internalChecked5
:internalTcc5
>> "%diagnostics%" echo TSE: "%source%"(8,1): SYNTHETIC jump test 1 - sample img lacks alt.
set "commandStatus=%_?%"
:internalChecked5
if not "%commandStatus%"=="0" goto logError
if "%shellName%"=="TCC" goto internalTcc6
call :clearCmdStatus
>> "%diagnostics%" echo TSE: "%source%"(9,1): SYNTHETIC jump test 2 - sample has duplicate attributes.
set "commandStatus=%ERRORLEVEL%"
goto internalChecked6
:internalTcc6
>> "%diagnostics%" echo TSE: "%source%"(9,1): SYNTHETIC jump test 2 - sample has duplicate attributes.
set "commandStatus=%_?%"
:internalChecked6
if not "%commandStatus%"=="0" goto logError
if "%shellName%"=="TCC" goto internalTcc7
call :clearCmdStatus
>> "%diagnostics%" echo TSE: "%source%"(10,1): SYNTHETIC jump test 3 - sample closing tag is mismatched.
set "commandStatus=%ERRORLEVEL%"
goto internalChecked7
:internalTcc7
>> "%diagnostics%" echo TSE: "%source%"(10,1): SYNTHETIC jump test 3 - sample closing tag is mismatched.
set "commandStatus=%_?%"
:internalChecked7
if not "%commandStatus%"=="0" goto logError
type "%diagnostics%"
goto done

:usage
echo Usage: COMHTML.BAT "C:\path\page.html"
set "result=1"
goto done

:missing
set "message=Source file not found."
set "result=2"
goto reportError

:directoryError
set "message=Source is a directory, not an HTML file."
set "result=2"
goto reportError

:browserError
set "message=Configured browser executable not found."
echo Browser: "%COMHTML_BROWSER%"
set "result=3"
goto reportError

:nativeStartError
on error
goto launchError

:launchError
set "message=Browser launch failed."
set "result=4"
goto reportError

:reportError
echo TSE: "%source%"(1,1): %message% [launch error; not an HTML syntax location]
if "%shellName%"=="TCC" goto internalTcc8
call :clearCmdStatus
>> "%diagnostics%" echo TSE: "%source%"(1,1): %message% [launch error; not an HTML syntax location]
set "commandStatus=%ERRORLEVEL%"
goto internalChecked8
:internalTcc8
>> "%diagnostics%" echo TSE: "%source%"(1,1): %message% [launch error; not an HTML syntax location]
set "commandStatus=%_?%"
:internalChecked8
if not "%commandStatus%"=="0" goto logError

:done
if "%shellName%"=="TCC" goto internalTcc9
call :clearCmdStatus
>> "%diagnostics%" echo Launch exit code: %result%
set "commandStatus=%ERRORLEVEL%"
goto internalChecked9
:internalTcc9
>> "%diagnostics%" echo Launch exit code: %result%
set "commandStatus=%_?%"
:internalChecked9
if not "%commandStatus%"=="0" goto logError
echo Diagnostics saved to "%diagnostics%"
goto finish

:logError
echo ERROR: Cannot write diagnostics: "%diagnostics%"
echo Check that the parent directory exists and is writable.
set "result=5"

:finish
echo Launch exit code: %result%
if "%COMHTML_PAUSE%"=="1" pause
if "%shellName%"=="CMD" goto returnCmd
endlocal & exit /b %result%
:returnCmd
endlocal & endlocal & exit /b %result%


:clearCmdStatus
REM CMD-only subroutine; establish zero before ECHO or START.
exit /b 0
