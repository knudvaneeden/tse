@echo off
setlocal DisableDelayedExpansion
REM COMOCAML.BAT version 1.0.0.0.7 - OpenAI GPT-6
REM Run OCaml program. Native TCC first; also Microsoft CMD.
REM PART 1 - USER SETTINGS
REM ocaml.exe runs scripts directly; ocamlc.exe/ocamlopt.exe compile and run.
set "OCAML_EXE=G:\CYGWIN\bin\ocaml.exe"
set "OCAML_OPTIONS=-color never -error-style short"
set "OCAML_PAUSE=YES"
set "OCAML_RUN=YES"
REM Put required DLLs and ocamlrun.exe on PATH (especially for Cygwin).
REM Override without editing: COMOCAML_EXE, COMOCAML_PAUSE, COMOCAML_RUN.
REM Usage with TSE's six parameters:
REM   %1 output name; %2 extension (reserved); %3 full source filename;
REM   %4 drive without colon; %5 output directory; %6 diagnostic filename.
REM Optional: %7 compiler exe; %8 output exe; %9 pause YES/NO.
REM Simple usage: COMOCAML.BAT "C:\work\helloworld.ml"
REM Full usage:
REM COMOCAML.BAT helloworld .ml "C:\work\helloworld.ml" C "\work" "C:\work\ocaml.log" "G:\CYGWIN\bin\ocaml.exe" "" YES
REM Shell tests (run from this BAT's directory; include quotes):
REM cmd.exe /d /c COMOCAML.BAT /test "G:\CYGWIN\bin\ocaml.exe"
REM "G:\UTILS\JPSoft\TCMD\tcc.exe" /c COMOCAML.BAT /test "G:\CYGWIN\bin\ocaml.exe"
REM Tests compile/run success, spaces, failure, missing source, stale output,
REM and the diagnostic formatter. They leave logs in a new TEMP directory.
REM OCaml normally stops at its first compilation error per source file.
REM No helper scripts. Only shell built-ins plus the selected OCaml toolchain.
REM Compiler mode creates .cmi/.cmo or .cmx/.o beside the source.
REM Interpreter mode creates no executable.
REM Requires a toolchain that accepts Windows paths.
REM ----------------------------------------------------------------------
REM PART 2 - COMMON LOGIC (NO INSTALLATION SETTINGS BELOW THIS LINE)
set "RC=1"
if not "%COMOCAML_EXE%"=="" set "OCAML_EXE=%COMOCAML_EXE%"
if not "%COMOCAML_PAUSE%"=="" set "OCAML_PAUSE=%COMOCAML_PAUSE%"
if not "%COMOCAML_RUN%"=="" set "OCAML_RUN=%COMOCAML_RUN%"
if /i "%~1"=="/?" goto usage
if /i "%~1"=="/test" goto selftest
if /i "%~1"=="/testformat" goto testformat
if not "%~7"=="" set "OCAML_EXE=%~7"
if not "%~9"=="" set "OCAML_PAUSE=%~9"
echo COMOCAML.BAT version 1.0.0.0.7
if "%~1"=="" goto usage
set "SOURCE=%~f1"
if not "%~3"=="" set "SOURCE=%~f3"
for %%F in ("%SOURCE%") do set "OUTPUT=%%~dpnF.exe"
for %%F in ("%SOURCE%") do set "LOG=%%~dpnF.ocaml.log"
if not "%~6"=="" set "LOG=%~f6"
if not "%~4"=="" set "OUTPUT=%~4:%~5\%~1.exe"
if not "%~8"=="" set "OUTPUT=%~f8"
if not exist "%SOURCE%" goto noSource
REM Never use IF EXIST "filename\" as a directory test under TCC.
if not "%_TCC%"=="" goto tccSource
for %%F in ("%SOURCE%") do set "ATTR=%%~aF"
if /i "%ATTR:~0,1%"=="d" goto noSource
goto sourceOK
:tccSource
if isdir "%SOURCE%" goto noSource
:sourceOK
if not exist "%OCAML_EXE%" goto noCompiler
if /i "%SOURCE%"=="%OUTPUT%" goto collision
if /i "%SOURCE%"=="%LOG%" goto collision
if /i "%OUTPUT%"=="%LOG%" goto collision
for %%F in ("%OCAML_EXE%") do set "PATH=%%~dpF;%PATH%"
set "RAW=%LOG%.raw"
if /i "%RAW%"=="%SOURCE%" goto collision
if /i "%RAW%"=="%OUTPUT%" goto collision
> "%LOG%" echo COMOCAML.BAT version 1.0.0.0.7
if errorlevel 1 goto noLog
for %%F in ("%OCAML_EXE%") do set "TOOLNAME=%%~nxF"
if /i "%TOOLNAME%"=="ocaml.exe" goto interpret
if exist "%OUTPUT%" del /q "%OUTPUT%" >nul 2>&1
if exist "%OUTPUT%" goto noDelete
"%OCAML_EXE%" %OCAML_OPTIONS% -o "%OUTPUT%" "%SOURCE%" >"%RAW%" 2>&1
set "RC=%ERRORLEVEL%"
type "%RAW%" >>"%LOG%"
call :format >>"%LOG%"
if not "%RC%"=="0" goto show
if not exist "%OUTPUT%" goto noOutput
if /i not "%OCAML_RUN%"=="YES" goto show
echo Running "%OUTPUT%" >>"%LOG%"
"%OUTPUT%" >>"%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
:show
type "%LOG%"
goto finish
:interpret
"%OCAML_EXE%" %OCAML_OPTIONS% "%SOURCE%" >"%RAW%" 2>&1
set "RC=%ERRORLEVEL%"
type "%RAW%" >>"%LOG%"
call :format >>"%LOG%"
goto show
:noSource
echo ERROR: source file not found or is a directory: "%SOURCE%"
goto finish
:noCompiler
echo ERROR: compiler not found: "%OCAML_EXE%"
goto finish
:collision
echo ERROR: source, executable and diagnostic files must be different.
goto finish
:noLog
echo ERROR: cannot write "%LOG%"
goto finish
:noDelete
echo ERROR: cannot remove old executable. >>"%LOG%"
goto show
:noOutput
echo ERROR: compiler returned success without producing "%OUTPUT%". >>"%LOG%"
set "RC=1"
goto show
:finish
echo Exit code: %RC%
if /i "%OCAML_PAUSE%"=="YES" pause
endlocal & exit /b %RC%
:usage
echo COMOCAML.BAT version 1.0.0.0.7
echo Usage: COMOCAML.BAT source.ml
echo Or: COMOCAML.BAT name ext source drive directory log [compiler] [output] [YES/NO]
echo Tests: COMOCAML.BAT /test "compiler.exe"
set "RC=2"
if /i "%~1"=="/?" set "RC=0"
goto finish
:format
REM Preserve raw diagnostics above; append navigable TSE records.
setlocal EnableDelayedExpansion
set "DFILE="
set "DLINE="
set "DCOL="
for /f "usebackq delims=" %%L in ("!RAW!") do (
  set "TEXT=%%L"
  call :formatLine
)
endlocal
exit /b 0
:formatLine
if "!TEXT:~0,5!"=="File " goto location
if not "!TEXT:~0,6!"=="Error:" exit /b 0
if not defined DFILE exit /b 0
if not defined DLINE exit /b 0
if not defined DCOL exit /b 0
echo TSE: !DFILE!:!DLINE!:!DCOL!: !TEXT!
set "DFILE="
exit /b 0
:location
set "DFILE="
set "DLINE="
set "DCOL="
set "HEADER=!TEXT:"=|!"
for /f "tokens=2,3 delims=|" %%F in ("!HEADER!") do (
  set "DFILE=%%F"
  set "TAIL=%%G"
)
for /f "tokens=2,4 delims=, " %%N in ("!TAIL!") do (
  set "DLINE=%%N"
  set "RANGE=%%O"
)
for /f "tokens=1 delims=-" %%C in ("!RANGE!") do set "DCOL=%%C"
REM First line of a multiline location range.
for /f "tokens=1 delims=-" %%N in ("!DLINE!") do set "DLINE=%%N"
if not defined DCOL exit /b 0
REM Use ordinary decimal conversion (OCaml positions have no leading zeros).
for /f "tokens=1 delims=-" %%C in ("!RANGE!") do set /a DCOL=%%C+1 >nul 2>&1
exit /b 0
:testformat
set "RAW=%TEMP%\COMOCAML-format-%RANDOM%.txt"
> "%RAW%" echo File "C:\space dir\errorstest.ml", line 10, characters 4-8:
>>"%RAW%" echo Error: Unbound value missing_one
call :format
del /q "%RAW%" >nul 2>&1
exit /b 0
:selftest
if not "%~2"=="" set "OCAML_EXE=%~2"
set "COMOCAML_PAUSE=NO"
set "COMOCAML_RUN=YES"
set "OCAML_PAUSE=NO"
set "TESTDIR=%TEMP%\COMOCAML test %RANDOM%-%RANDOM%"
md "%TESTDIR%"
if errorlevel 1 goto testFail
call "%~f0" /testformat >"%TESTDIR%\formatter.log"
type "%TESTDIR%\formatter.log"
> "%TESTDIR%\hello.ml" echo let () = print_endline "Hello from OCaml!"
call "%~f0" hello .ml "%TESTDIR%\hello.ml" "" "" "%TESTDIR%\hello.log" "%OCAML_EXE%" "%TESTDIR%\hello.exe" NO
if errorlevel 1 goto testFail
for %%F in ("%OCAML_EXE%") do set "TESTTOOL=%%~nxF"
if /i not "%TESTTOOL%"=="ocaml.exe" if not exist "%TESTDIR%\hello.exe" goto testFail
> "%TESTDIR%\broken.ml" echo let x = missing_one
call "%~f0" broken .ml "%TESTDIR%\broken.ml" "" "" "%TESTDIR%\broken.log" "%OCAML_EXE%" "%TESTDIR%\hello.exe" NO
if not errorlevel 1 goto testFail
if exist "%TESTDIR%\hello.exe" goto testFail
call "%~f0" missing .ml "%TESTDIR%\missing.ml" "" "" "%TESTDIR%\missing.log" "%OCAML_EXE%" "%TESTDIR%\missing.exe" NO
if not errorlevel 1 goto testFail
echo PASS: success, program execution, spaces, failure and missing source.
echo Compiler mode also checked stale executable removal.
echo Formatter output should show line 10, column 5; verify the TSE jump manually.
echo Logs: "%TESTDIR%"
endlocal & exit /b 0
:testFail
echo FAIL: inspect "%TESTDIR%".
endlocal & exit /b 1
