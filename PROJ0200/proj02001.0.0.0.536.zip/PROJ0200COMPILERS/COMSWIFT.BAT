@echo off
REM COMSWIFT.BAT version 1.0.0.0.7 - updated with OpenAI GPT-6
REM Compile one Swift source, capture diagnostics, optionally run the EXE.
REM Intended for JPSoft TCC and Microsoft CMD; ASCII, CRLF.
REM
REM PARAMETERS - existing TSE positions retained:
REM   %1 EXE basename without extension; empty uses source basename.
REM   %2 Reserved for the existing editor integration; ignored.
REM   %3 Swift source filename in the editor call.
REM Direct call: COMSWIFT.BAT "C:\work\hello.swift"
REM Quote paths containing spaces. No helper script is required.
REM   %4 Output drive letter without colon; empty uses source directory.
REM   %5 Output directory on that drive, e.g. \work; used with %4.
REM   %6 Diagnostic file for TSE; empty uses a unique TEMP .err file.
REM   %7 Optional full path to swiftc.exe, overrides the setting below.
REM   %8 Optional pause: 1=yes, 0=no. %9 Optional run: 1=yes, 0=no.
REM Supply empty quoted arguments to skip a position.
REM Example (all paths below are examples to adapt):
REM   COMSWIFT.BAT hello "" "C:\work\hello.swift" C \work "C:\work\hello.log" "C:\Swift\usr\bin\swiftc.exe" 0 1
REM Example using defaults:
REM   COMSWIFT.BAT "" "" "C:\work\hello.swift"
REM Shell tests, from the directory containing this BAT:
REM   tcc.exe /c COMSWIFT.BAT /selftest "C:\Swift\usr\bin\swiftc.exe"
REM   cmd.exe /d /c COMSWIFT.BAT /selftest "C:\Swift\usr\bin\swiftc.exe"
REM Self-test checks direct/editor calls, successful compilation/run, invalid Swift,
REM directory rejection, missing source,
REM and missing compiler, with spaces in paths. It leaves its logs in TEMP.
REM Exit codes: 0=success; 2=arguments/input; 3=compiler missing;
REM 4=directory/log setup; 5=output deletion/missing EXE; otherwise tool status.
REM Use a Swift/Visual Studio developer shell with the required SDK, linker,
REM and Swift runtime DLL paths already configured. This BAT does not install them.
REM
REM ======================================================================
REM PART 1 - USER SETTINGS: change only this section for your installation.
REM ======================================================================
setlocal EnableExtensions DisableDelayedExpansion
set "CS_COMPILER=c:\library\developer\toolchains\unknown-asserts-development.xctoolchain\usr\bin\swiftc.exe"
REM Extra compiler flags, e.g. -g or -sdk "C:\path\to\Windows.sdk".
set "CS_FLAGS="
set "CS_PAUSE=1"
if defined COMSWIFT_COMPILER set "CS_COMPILER=%COMSWIFT_COMPILER%"
if defined COMSWIFT_PAUSE set "CS_PAUSE=%COMSWIFT_PAUSE%"
set "CS_RUN=1"
REM Set COMSWIFT_PAUSE=0 before a direct call to disable its final pause.
REM Optional extra runtime DLL directory; empty retains inherited PATH.
set "CS_RUNTIME_DIR="
REM Optional copy of the compiler log; empty disables the old dddoutput copy.
set "CS_LOG_COPY="
REM ======================================================================
REM PART 2 - COMMON LOGIC: no installation-specific edits required below.
REM ======================================================================
set "CS_VERSION=1.0.0.0.7"
set "CS_SHELL=CMD"
if /i "%_cmdproc%"=="TCC" set "CS_SHELL=TCC"
if /i "%_cmdproc%"=="TCC/LE" set "CS_SHELL=TCC"
echo COMSWIFT version %CS_VERSION%
echo Shell: %CS_SHELL%
if /i "%~1"=="/selftest" goto selftest
set "CS_RC=2"
if "%~1"=="" if "%~3"=="" goto usage
set "CS_SOURCE=%~f1"
set "CS_NAME=%~n1"
if not "%~3"=="" set "CS_SOURCE=%~f3"
if not "%~3"=="" set "CS_NAME=%~1"
for %%F in ("%CS_SOURCE%") do set "CS_SOURCEDIR=%%~dpF"
for %%F in ("%CS_SOURCE%") do if "%CS_NAME%"=="" set "CS_NAME=%%~nF"
set "CS_OUTPUT=%CS_SOURCEDIR%%CS_NAME%.exe"
if not "%~4"=="" if "%~5"=="" goto usage
if "%~4"=="" if not "%~5"=="" goto usage
set "CS_DRIVE=%~4"
set "CS_DRIVE=%CS_DRIVE::=%"
if not "%~4"=="" set "CS_OUTPUT=%CS_DRIVE%:%~5\%CS_NAME%.exe"
set "CS_LOG=%TEMP%\COMSWIFT_%RANDOM%_%RANDOM%.err"
if not "%~6"=="" set "CS_LOG=%~f6"
if /i "%CS_LOG%"=="%CS_SOURCE%" goto usage
if /i "%CS_LOG%"=="%CS_OUTPUT%" goto usage
if not "%~7"=="" set "CS_COMPILER=%~7"
if not "%~8"=="" set "CS_PAUSE=%~8"
if not "%~9"=="" set "CS_RUN=%~9"
if not "%CS_PAUSE%"=="0" if not "%CS_PAUSE%"=="1" goto usage
if not "%CS_RUN%"=="0" if not "%CS_RUN%"=="1" goto usage
set "CS_RC=4"
for %%F in ("%CS_OUTPUT%") do set "CS_OUTDIR=%%~dpF"
for %%F in ("%CS_LOG%") do set "CS_LOGDIR=%%~dpF"
if not exist "%CS_LOGDIR%." mkdir "%CS_LOGDIR%"
if not exist "%CS_LOGDIR%." goto setupFailed
>"%CS_LOG%" echo COMSWIFT version %CS_VERSION%
if errorlevel 1 goto setupFailed
>>"%CS_LOG%" echo filename=%CS_SOURCE%
set "CS_RC=2"
if not exist "%CS_SOURCE%" goto missingSource
REM Do not test IF EXIST "source\" in TCC: it can also match a file.
if "%CS_SHELL%"=="TCC" goto checkSourceTcc
if exist "%CS_SOURCE%\" goto missingSource
goto sourceChecked
:checkSourceTcc
if isdir "%CS_SOURCE%" goto missingSource
:sourceChecked
set "CS_RC=3"
if not exist "%CS_COMPILER%" goto missingCompiler
if not "%CS_RUNTIME_DIR%"=="" set "PATH=%CS_RUNTIME_DIR%;%PATH%"
set "CS_RC=4"
if not exist "%CS_OUTDIR%." mkdir "%CS_OUTDIR%"
if not exist "%CS_OUTDIR%." goto setupFailed
set "CS_RC=5"
if exist "%CS_OUTPUT%" del /q "%CS_OUTPUT%"
if exist "%CS_OUTPUT%" goto staleOutput
echo Compiling "%CS_SOURCE%"
"%CS_COMPILER%" %CS_FLAGS% -no-color-diagnostics -emit-executable "%CS_SOURCE%" -o "%CS_OUTPUT%" >>"%CS_LOG%" 2>&1
set "CS_RC=%errorlevel%"
echo Compile exit code: %CS_RC%
type "%CS_LOG%"
if "%CS_LOG_COPY%"=="" goto afterCopy
copy /y "%CS_LOG%" "%CS_LOG_COPY%" >nul 2>&1
if errorlevel 1 echo Warning: could not copy the log to "%CS_LOG_COPY%".
:afterCopy
if not "%CS_RC%"=="0" goto compileFailed
set "CS_RC=5"
if not exist "%CS_OUTPUT%" goto staleOutput
set "CS_RC=0"
if "%CS_RUN%"=="0" goto finish
echo Running "%CS_OUTPUT%"
"%CS_OUTPUT%"
set "CS_RC=%errorlevel%"
echo Run exit code: %CS_RC%
goto finish
:missingSource
set "CS_ERROR=ERROR: source file not found or is a directory: %CS_SOURCE%"
goto reportError
:missingCompiler
set "CS_ERROR=ERROR: swiftc.exe not found: %CS_COMPILER%"
goto reportError
:setupFailed
set "CS_ERROR=ERROR: cannot create output directory or diagnostic log."
goto reportError
:staleOutput
set "CS_ERROR=ERROR: output EXE could not be removed or was not generated."
goto reportError
:compileFailed
echo ERROR: Swift compilation failed, exit code %CS_RC%. See "%CS_LOG%".
goto finish
:usage
echo Usage: COMSWIFT basename "" source drive directory log compiler pause run
echo See REM documentation at the top for examples and /selftest.
goto finish
:reportError
echo %CS_ERROR%
if defined CS_LOG >>"%CS_LOG%" echo %CS_ERROR%
goto finish
:finish
echo Exit code: %CS_RC%
if defined CS_LOG echo Diagnostics saved to "%CS_LOG%".
if "%CS_PAUSE%"=="1" pause
endlocal & exit /b %CS_RC%

:selftest
set "CS_PAUSE=0"
set "COMSWIFT_PAUSE=0"
set "CS_RC=1"
if not "%~2"=="" set "CS_COMPILER=%~2"
set "COMSWIFT_COMPILER=%CS_COMPILER%"
if not exist "%CS_COMPILER%" goto missingCompiler
if "%TEMP%"=="" goto setupFailed
set "CS_TEST=%TEMP%\COMSWIFT test %RANDOM% %RANDOM%"
if exist "%CS_TEST%" goto setupFailed
mkdir "%CS_TEST%"
if errorlevel 1 goto setupFailed
>"%CS_TEST%\hello.swift" echo print("COMSWIFT test passed")
>"%CS_TEST%\invalid.swift" echo this is not valid Swift !!!
call "%~f0" hello "" "%CS_TEST%\hello.swift" "" "" "%CS_TEST%\hello.log" "%CS_COMPILER%" 0 1 >"%CS_TEST%\run.log" 2>&1
if errorlevel 1 goto testFailed
if not exist "%CS_TEST%\hello.exe" goto testFailed
call "%~f0" "%CS_TEST%\hello.swift" >"%CS_TEST%\direct.log" 2>&1
if errorlevel 1 goto testFailed
findstr /c:"COMSWIFT test passed" "%CS_TEST%\run.log" >nul
if errorlevel 1 goto testFailed
REM Compile invalid Swift to the SAME output: old EXE must not survive.
call "%~f0" hello "" "%CS_TEST%\invalid.swift" "" "" "%CS_TEST%\invalid.log" "%CS_COMPILER%" 0 1 >"%CS_TEST%\invalid-run.log" 2>&1
if not errorlevel 1 goto testFailed
if exist "%CS_TEST%\hello.exe" goto testFailed
call "%~f0" missing "" "%CS_TEST%\missing.swift" "" "" "" "%CS_COMPILER%" 0 0 >"%CS_TEST%\missing.log" 2>&1
if not errorlevel 2 goto testFailed
if errorlevel 3 goto testFailed
call "%~f0" hello "" "%CS_TEST%\hello.swift" "" "" "" "%CS_TEST%\missing-swiftc.exe" 0 0 >"%CS_TEST%\compiler.log" 2>&1
if not errorlevel 3 goto testFailed
if errorlevel 4 goto testFailed
mkdir "%CS_TEST%\folder.swift"
call "%~f0" folder "" "%CS_TEST%\folder.swift" "" "" "%CS_TEST%\folder.err" "%CS_COMPILER%" 0 0 >"%CS_TEST%\directory.log" 2>&1
if not errorlevel 2 goto testFailed
if errorlevel 3 goto testFailed
set "CS_RC=0"
echo PASS: COMSWIFT compilation, execution and failure tests.
echo Test files and logs: "%CS_TEST%"
goto finish
:testFailed
set "CS_RC=1"
echo FAIL: inspect the test files and logs in "%CS_TEST%".
goto finish
