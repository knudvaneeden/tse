@ECHO OFF
REM COMOCTAVE.BAT version 1.0.0.0.7 - 2026-11-01
REM Run OCTAVE program
REM PART 1 - USER SETTINGS: change these installation-dependent values.
SET "OCTAVE_EXE=g:\language\computer\octave\mingw64\bin\octave-cli.exe"
SET "PAUSE_AT_END=1"
REM TSE arguments: %1=name %2=extension %3=full source filename
REM                %4=drive %5=directory %6=output/error filename
REM Optional %7 overrides OCTAVE_EXE; %8=0 disables the final pause.
REM Test in native TCC (start tcc.exe, then enter this command):
REM COMOCTAVE.BAT "helloworldoctave" ".oct" "F:\BBC\TAAL\helloworldoctave.oct" "F:" "F:\BBC\TAAL" "C:\TEMP\octave-tcc.err"
REM Test in cmd.exe (start cmd.exe, then enter this command):
REM COMOCTAVE.BAT "helloworldoctave" ".oct" "F:\BBC\TAAL\helloworldoctave.oct" "F:" "F:\BBC\TAAL" "C:\TEMP\octave-cmd.err"
REM Repeat both tests with errorstestoctave and its full source path.
REM Expected: greeting and exit 0; error test gives TSEERROR and exit 1.
REM To test an alternative installation append "C:\Octave\bin\octave-cli.exe" "0".
REM Run from TSE through the supplied compiler rule; no helper files needed.
REM .oct is deliberately read as source, not loaded as an Octave binary module.
REM Standard Octave .m scripts may also be supplied explicitly as argument 3.
REM Octave stops at the first uncaught error. Fix that error, then rerun.
REM Column defaults to 1 if unavailable; absent locations default to line 1.
REM Check the full diagnostic when a parser error supplies no location.
REM
REM PART 2 - FIXED BODY: no installation-dependent edits below this line.
SETLOCAL
IF NOT "%~7"=="" SET "OCTAVE_EXE=%~7"
IF NOT "%~8"=="" SET "PAUSE_AT_END=%~8"
SET "TSE_OCT_SOURCE=%~f3"
SET "OCT_OUTPUT=%~f6"
SET "OCT_RC=2"
ECHO COMOCTAVE.BAT version 1.0.0.0.7
IF "%~3"=="" GOTO usage
IF "%~6"=="" GOTO usage
>"%OCT_OUTPUT%" ECHO filename=%TSE_OCT_SOURCE%
IF ERRORLEVEL 1 GOTO outputfailed
IF NOT EXIST "%TSE_OCT_SOURCE%" GOTO missing
REM Only TCC parses IF ISDIR; CMD jumps past that line.
IF DEFINED _4VER GOTO tccdir
GOTO cmddir
:tccdir
IF ISDIR "%TSE_OCT_SOURCE%" GOTO missing
GOTO checkexe
:cmddir
FOR %%A IN ("%TSE_OCT_SOURCE%") DO SET "OCT_ATTR=%%~aA"
IF /I "%OCT_ATTR:~0,1%"=="d" GOTO missing
:checkexe
IF NOT EXIST "%OCTAVE_EXE%" GOTO noexe
"%OCTAVE_EXE%" --no-init-file --no-site-file --no-history --quiet --eval "try; source(getenv('TSE_OCT_SOURCE')); catch err; f=getenv('TSE_OCT_SOURCE'); l=1; c=1; if (!isempty(err.stack)); s=err.stack(1); f=s.file; l=max(1,s.line); if (isfield(s,'column')); c=max(1,s.column); endif; endif; t=regexp(err.message,'near line ([0-9]+)(?:[^0-9]+column ([0-9]+))?','tokens','once'); if (!isempty(t)); l=str2double(t{1}); if (numel(t)>1 && !isempty(t{2})); c=str2double(t{2}); endif; endif; m=strrep(strrep(err.message,char(13),' '),char(10),' | '); fprintf(2,'filename=%%s\n',f); fprintf(2,'TSEERROR line %%d column %%d: %%s\n',l,c,m); exit(1); end_try_catch; exit(0);" >>"%OCT_OUTPUT%" 2>&1
SET "OCT_RC=%ERRORLEVEL%"
GOTO show
:missing
>>"%OCT_OUTPUT%" ECHO TSEERROR line 1 column 1: Source is missing or is a directory: %TSE_OCT_SOURCE%
GOTO show
:noexe
>>"%OCT_OUTPUT%" ECHO TSEERROR line 1 column 1: Octave executable not found: %OCTAVE_EXE%
GOTO show
:outputfailed
ECHO ERROR: Cannot write output file: %OCT_OUTPUT%
GOTO done
:usage
ECHO Usage: COMOCTAVE.BAT name ext "source" drive "directory" "output" ["exe"] [0]
GOTO done
:show
TYPE "%OCT_OUTPUT%"
ECHO.
ECHO Octave exit status: %OCT_RC%
:done
IF "%PAUSE_AT_END%"=="1" PAUSE
ENDLOCAL & EXIT /B %OCT_RC%
