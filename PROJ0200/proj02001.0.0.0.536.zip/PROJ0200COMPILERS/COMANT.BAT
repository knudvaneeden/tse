@echo off
REM COMANT.BAT version 1.0.0.0.13 - OpenAI GPT-6
REM Run Apache Ant XML build files saved with extension .ant.
REM PART 1: USER SETTINGS. Set COMANT_EXE to your Apache Ant batch file.
REM java.exe alone does not contain Ant; lib\ant-launcher.jar is required.
REM Usage: COMANT.BAT "full-source.ant" [target]
REM TSE: COMANT.BAT "&name&" "&ext&" "&fn&" "&drive&" "&path&" "&output&"
REM Six arguments select TSE mode; argument 3 is the complete source filename.
REM Argument 6 is TSE error output: always created, empty on success.
REM Normalized diagnostics are appended to that file for TSE navigation.
REM Direct mode: argument 1 is the filename; argument 2 is an optional target.
REM Overrides in either shell, before running this BAT:
REM   set "COMANT_JAVA=G:\language\computer\java\jdk1.8.0_05_64\bin\java.exe"
REM   set "COMANT_EXE=G:\utils\ant\apache-ant-1.8.2\bin\ant.bat"
REM   set "COMANT_PAUSE=0"
REM COMANT_PAUSE=1 keeps the console open; 0 is useful for unattended testing.
REM Test in native TCC (adjust TCC path if necessary):
REM   "G:\UTILS\JPSoft\TCMD\tcc.exe" /c COMANT.BAT "F:\BBC\TAAL\PROJ0200HELLOWORLD\helloworldant.ant"
REM   "G:\UTILS\JPSoft\TCMD\tcc.exe" /c COMANT.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstestant.ant"
REM Test in CMD:
REM   cmd.exe /d /c COMANT.BAT "F:\BBC\TAAL\PROJ0200HELLOWORLD\helloworldant.ant"
REM   cmd.exe /d /c COMANT.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstestant.ant"
REM Expected: Hello World / exit 0; three deliberate failures / exit 1.
REM Ant -keep-going continues independent targets, not failed target contents.
REM Built-in XmlLogger supplies later target locations; temporary XML is deleted.
REM For target-level failures the last executed task is used as context.
REM Custom parallel/macro tasks can have less precise contextual locations.
REM Malformed XML normally stops parsing at the first error.
REM No generated programs, scripts, or source modifications are used.
setlocal DisableDelayedExpansion
if not defined COMANT_JAVA set "COMANT_JAVA=G:\language\computer\java\jdk1.8.0_05_64\bin\java.exe"
if not defined COMANT_EXE set "COMANT_EXE=G:\utils\ant\apache-ant-1.8.2\bin\ant.bat"
if not defined COMANT_PAUSE set "COMANT_PAUSE=1"
REM PART 2: ENGINE. Normally no changes below this line.
set "rc=1"
set "log="
set "xmlLog="
set "target="
set "errorOutput="
set "source=%~1"
if not "%~3"=="" goto tseargs
set "target=%~2"
goto argsdone
:tseargs
set "source=%~3"
set "errorOutput=%~6"
:argsdone
echo COMANT.BAT version 1.0.0.0.13
if not defined errorOutput goto outputready
REM Truncate stale errors, including when the next build succeeds.
type nul >"%errorOutput%"
if errorlevel 1 goto badoutput
:outputready
if not defined source goto usage
for %%F in ("%source%") do set "source=%%~fF"
if not exist "%source%" goto missing
REM Never use IF EXIST "filename\" for directory detection in TCC.
if defined _4VER goto tccdir
for %%F in ("%source%") do set "attributes=%%~aF"
if /i "%attributes:~0,1%"=="d" goto missing
goto checked
:tccdir
if isdir "%source%" goto missing
:checked
if not exist "%COMANT_JAVA%" goto nojava
if not exist "%COMANT_EXE%" goto noant
for %%F in ("%COMANT_EXE%") do set "antBin=%%~dpF"
for %%F in ("%antBin%..") do set "ANT_HOME=%%~fF"
if not exist "%ANT_HOME%\lib\ant-launcher.jar" goto noant
set "JAVACMD=%COMANT_JAVA%"
for %%F in ("%COMANT_JAVA%") do set "javaBin=%%~dpF"
for %%F in ("%javaBin%..") do set "JAVA_HOME=%%~fF"
set "log=%TEMP%\COMANT_%RANDOM%_%RANDOM%.log"
if exist "%log%" goto checked
set "xmlLog=%log%.xml"
if exist "%xmlLog%" goto checked
REM CALL returns to this runner after the installed ant.bat finishes.
REM Ant resolves basedir relative to the build file, even outside current dir.
if defined target goto withtarget
call "%COMANT_EXE%" -noinput -emacs -keep-going -listener org.apache.tools.ant.XmlLogger "-DXmlLogger.file=%xmlLog%" -buildfile "%source%" >"%log%" 2>&1
goto ran
:withtarget
call "%COMANT_EXE%" -noinput -emacs -keep-going -listener org.apache.tools.ant.XmlLogger "-DXmlLogger.file=%xmlLog%" -buildfile "%source%" "%target%" >"%log%" 2>&1
:ran
set "rc=%errorlevel%"
type "%log%"
REM Normalize absolute Windows file:line[:column]: diagnostics for TSE.
REM Ant task locations omit columns: explicitly report column 1 in that case.
REM Raw Ant output above remains visible, including XML parser diagnostics.
REM Delayed expansion is confined to log parsing. Literal ! in diagnostic
REM text or filenames is a limitation of this native batch parser.
setlocal EnableDelayedExpansion
REM Built-in XmlLogger records task locations even for later failed targets.
REM Read targets, tasks and failure messages in XML event order.
set "xmlTarget="
if not exist "!xmlLog!" goto parseconsole
for /f "usebackq delims=" %%L in ("!xmlLog!") do (
  set "xmlEntry=%%L"
  call :xmlLocation
)
:parseconsole
for /f "usebackq delims=" %%L in ("!log!") do (
  set "entry=%%L"
  call :parse
)
endlocal
goto finish
:xmlLocation
REM Read the XML log as an ordered event stream; no indirect variable lookup.
for /f "tokens=*" %%A in ("!xmlEntry!") do set "xmlEntry=%%A"
set "xmlFields=!xmlEntry:"=?!"
if "!xmlFields:~0,8!"=="<target " goto xmlTargetName
if "!xmlFields:~0,6!"=="<task " goto xmlTaskLocation
if not "!xmlFields:~0,35!"=="<message priority=?error?><![CDATA[" exit /b
set "xmlMessage=!xmlFields:~35!"
if not "!xmlMessage:~0,8!"=="Target '" exit /b
if not defined taskLocation exit /b
set "failedTarget="
for /f "tokens=2 delims='" %%A in ("!xmlMessage!") do set "failedTarget=%%A"
if not "!failedTarget!"=="!xmlTarget!" exit /b
REM Remove the closing CDATA/message tag from this single-line message.
set "xmlMessage=!xmlMessage:~0,-13!"
set "entry=!taskLocation!!xmlMessage!"
call :parseLocation
exit /b
:xmlTargetName
set "taskLocation="
for /f "tokens=2 delims=?" %%A in ("!xmlFields!") do set "xmlTarget=%%A"
exit /b
:xmlTaskLocation
for /f "tokens=2 delims=?" %%A in ("!xmlFields!") do set "taskLocation=%%A"
exit /b
:parse
:parseLocation
set "drive="
set "tail="
for /f "tokens=1,2,* delims=:" %%A in ("!entry!") do (
  set "drive=%%A"
  set "filepart=%%B"
  set "tail=%%C"
)
if not defined tail exit /b
if "!drive:~1,1!" NEQ "" exit /b
if not "!filepart:~0,1!"=="\" exit /b
set "row="
set "message="
for /f "tokens=1,* delims=:" %%A in ("!tail!") do (
  set "row=%%A"
  set "message=%%B"
)
if not defined row exit /b
set "bad="
for /f "delims=0123456789" %%A in ("!row!") do set "bad=%%A"
if defined bad exit /b
set "column=1"
set "candidate="
set "remaining="
for /f "tokens=1,* delims=:" %%A in ("!message!") do (
  set "candidate=%%A"
  set "remaining=%%B"
)
set "bad="
if not defined candidate goto emit
for /f "delims=0123456789" %%A in ("!candidate!") do set "bad=%%A"
if defined bad goto emit
set "column=!candidate!"
set "message=!remaining!"
:emit
REM Suppress repeated summaries of the same file/line/column.
for %%K in ("!drive!:!filepart!:!row!:!column!") do if defined seen.%%~K exit /b
set "seen.!drive!:!filepart!:!row!:!column!=1"
echo TSE: !drive!:!filepart!:!row!:!column!: !message!
if defined errorOutput >>"!errorOutput!" echo TSE: !drive!:!filepart!:!row!:!column!: !message!
exit /b
:badoutput
echo ERROR: Cannot create TSE error output: "%errorOutput%"
set "errorOutput="
goto finish
:usage
echo Usage: COMANT.BAT "full-source.ant" [target]
goto finish
:missing
echo ERROR: source file not found or is a directory: "%source%"
goto finish
:nojava
echo ERROR: Java executable not found: "%COMANT_JAVA%"
goto finish
:noant
echo ERROR: Ant installation missing or incomplete: "%COMANT_EXE%"
echo Set COMANT_EXE to the installed bin\ant.bat file.
goto finish
:finish
REM Do not let a failed launch/build appear successful if no location parsed.
if "%rc%"=="0" goto cleanup
if not defined errorOutput goto cleanup
for %%F in ("%errorOutput%") do set "errorBytes=%%~zF"
if not "%errorBytes%"=="0" goto cleanup
>>"%errorOutput%" echo TSE: %source%:1:1: Ant failed; see console output for details.
:cleanup
if defined xmlLog if exist "%xmlLog%" del /q "%xmlLog%" >nul 2>&1
if defined log if exist "%log%" del /q "%log%" >nul 2>&1
echo Exit code: %rc%
if "%COMANT_PAUSE%"=="1" pause
endlocal & exit /b %rc%
