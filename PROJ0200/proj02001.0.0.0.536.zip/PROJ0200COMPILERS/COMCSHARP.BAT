@echo off
rem COMCSHARP.BAT version 1.0.0.0.9
rem Updated 2026-10-04 by OpenAI GPT-6 / Codex.
rem Compile a standalone C# console source file and run its .exe.
rem
rem TEST 1: Supply the source filename as the only external parameter:
rem   COMCSHARP.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.cs"
rem
rem TEST 2: Supply the six external parameters used by TSE:
rem   COMCSHARP.BAT "ddd" "unused" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.cs" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\comcsharp_test.err"
rem
rem External parameter meanings:
rem   %1 = Source filename in one-parameter mode; program name in TSE mode.
rem   %2 = Unused; keep its position when supplying TSE parameters.
rem   %3 = C# source filename in TSE mode; takes precedence over %1.
rem   %4 = Drive supplied by TSE; unused because %3 supplies the full path.
rem   %5 = Directory supplied by TSE; unused for the same reason.
rem   %6 = Compiler log filename; its parent directory must already exist.
rem If %6 is omitted, the log is source-name_compile.log beside the source.
rem The .exe is generated from the source name: ddd.cs becomes ddd.exe.
rem Quote filenames and paths, especially when they contain spaces.
rem Expected result for the sample ddd.cs: Hello, then program exit code 0.
rem In another batch file, use CALL COMCSHARP.BAT followed by the parameters.

setlocal
rem =====================================================================
rem PART 1 - USER SETTINGS: Adapt only this section to your local system.
rem =====================================================================
rem CMD interpreter used even when this batch is launched from TCC.
set "CSHARP_CMD=%SystemRoot%\System32\cmd.exe"

rem Explicit compiler .exe path. Leave empty to try the three paths below.
rem Example: set "CSHARP_COMPILER=D:\Tools\Roslyn\csc.exe"
set "CSHARP_COMPILER="

rem Automatic compiler search order, when CSHARP_COMPILER is empty.
set "CSHARP_COMPILER_64=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
set "CSHARP_COMPILER_32=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
set "CSHARP_COMPILER_VS=C:\Program Files\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\Roslyn\csc.exe"

rem Compiler options for a standalone console executable.
set "CSHARP_COMPILER_OPTIONS=/nologo /target:exe"

rem Output directory for the generated .exe. Leave empty for source folder.
rem If specified, this directory must already exist. Example: C:\TEMP
set "CSHARP_OUTPUT_DIRECTORY="

rem Pause after compilation/run: true or false.
set "CSHARP_PAUSE=true"

rem =====================================================================
rem PART 2 - PROCESSING: No user changes are normally needed below here.
rem =====================================================================
if /i "%~1"=="--comcsharp-cmd" goto cmdEntry
"%CSHARP_CMD%" /d /c call "%~f0" --comcsharp-cmd %*
set "result=%errorlevel%"
endlocal & exit /b %result%

:cmdEntry
shift
set "source=%~3"
if not defined source set "source=%~1"
if not defined source goto usage
if exist "%source%" goto sourceFound
if exist "%source%.cs" set "source=%source%.cs"
if not exist "%source%" goto missingSource

:sourceFound
for %%F in ("%source%") do set "source=%%~fF"
for %%F in ("%source%") do set "exe=%%~dpnF.exe"
if defined CSHARP_OUTPUT_DIRECTORY for %%F in ("%source%") do set "exe=%CSHARP_OUTPUT_DIRECTORY%\%%~nF.exe"
if defined CSHARP_OUTPUT_DIRECTORY if not exist "%CSHARP_OUTPUT_DIRECTORY%\." goto missingOutputDirectory
set "log=%~6"
if not defined log for %%F in ("%source%") do set "log=%%~dpnF_compile.log"

set "compiler=%CSHARP_COMPILER%"
if defined compiler goto compilerSelected
set "compiler=%CSHARP_COMPILER_64%"
if exist "%compiler%" goto compile
set "compiler=%CSHARP_COMPILER_32%"
if exist "%compiler%" goto compile
set "compiler=%CSHARP_COMPILER_VS%"
if exist "%compiler%" goto compile
echo ERROR: Cannot find csc.exe.
set "result=1"
goto finish

:compilerSelected
if exist "%compiler%" goto compile
echo ERROR: Configured compiler not found: "%compiler%"
set "result=1"
goto finish

:compile
rem TSE uses this header to resolve even relative compiler filenames.
>"%log%" echo filename=%source%
if errorlevel 1 goto logFailed
echo Compiling "%source%"
"%compiler%" %CSHARP_COMPILER_OPTIONS% /out:"%exe%" "%source%" >>"%log%" 2>&1
set "result=%errorlevel%"
echo Compiler exit code: %result%
if exist "%log%" type "%log%"
if not "%result%"=="0" goto compileFailed
if not exist "%exe%" goto missingExe
echo.
echo Running "%exe%"
"%exe%"
set "result=%errorlevel%"
echo.
echo Program exit code: %result%
goto finish

:logFailed
echo ERROR: Cannot write compiler log: "%log%"
set "result=1"
goto finish

:compileFailed
echo ERROR: Compilation failed. See "%log%".
goto finish

:missingExe
echo ERROR: Compiler did not create "%exe%".
set "result=1"
goto finish

:missingOutputDirectory
echo ERROR: Output directory not found: "%CSHARP_OUTPUT_DIRECTORY%"
set "result=1"
goto finish

:missingSource
echo ERROR: Source file not found: "%source%"
set "result=1"
goto finish

:usage
echo Usage: COMCSHARP.BAT "full\path\ddd.cs"
set "result=1"

:finish
echo.
if /i "%CSHARP_PAUSE%"=="true" pause
endlocal & exit /b %result%
