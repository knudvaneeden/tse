# comnodejs.ps1 - version 1.0.0.0.9 - 2026-11-02
# Windows PowerShell 5.1: format native Node output for unchanged TSE rules.
# Node is run once by COMNODEJS.BAT; this helper never executes source code.
param(
    [Parameter(Mandatory=$true)][string]$InputFile,
    [Parameter(Mandatory=$true)][string]$OutputFile,
    [Parameter(Mandatory=$true)][string]$SourceFile,
    [Parameter(Mandatory=$true)][int]$NodeExitCode
)
$ErrorActionPreference = 'Stop'
try {
    $rawPath = [IO.Path]::GetFullPath($InputFile)
    $outPath = [IO.Path]::GetFullPath($OutputFile)
    $srcPath = [IO.Path]::GetFullPath($SourceFile)
    if ($outPath -eq $srcPath -or $outPath -eq $rawPath) {
        throw 'Source, raw output and formatted output must be different files.'
    }
    $raw = [IO.File]::ReadAllText($rawPath)
    $rows = [regex]::Split($raw, '\r?\n')
    $result = $raw
    if ($NodeExitCode -ne 0) {
        $errorText = 'Node.js failed; see raw output: ' + $rawPath
        foreach ($row in $rows) {
            if ($row -match '^\s*(?:[A-Za-z]*Error|Error)(?:\s*\[[^\]]+\])?:\s*.*$') {
                $errorText = $row.Trim()
                break
            }
        }
        $file = $srcPath
        $line = 1
        $column = 1
        $located = $false
        for ($i = 0; $i -lt $rows.Length; $i++) {
            # Primary native diagnostic header, never internal stack frames.
            $hit = [regex]::Match($rows[$i], '^(?<file>.+?):(?<line>\d+)(?::(?<col>\d+))?$')
            if (-not $hit.Success) { continue }
            $file = $hit.Groups['file'].Value
            $line = [int]$hit.Groups['line'].Value
            if ($hit.Groups['col'].Success) {
                $column = [int]$hit.Groups['col'].Value
            } elseif ($i + 2 -lt $rows.Length -and $rows[$i + 2] -match '^[\t ]*\^') {
                $column = $rows[$i + 2].IndexOf('^') + 1
            } else {
                $errorText += ' [column unavailable; using 1]'
            }
            $located = $true
            break
        }
        if (-not $located) {
            # Runtime failures can provide a location only in the stack.
            foreach ($row in $rows) {
                $hit = [regex]::Match($row, '^\s*at\s+(?:.*?\s+\()?(?<file>(?:[A-Za-z]:[\\/]|/|\\\\).+?):(?<line>\d+):(?<col>\d+)\)?\s*$')
                if ($hit.Success) {
                    $file = $hit.Groups['file'].Value
                    $line = [int]$hit.Groups['line'].Value
                    $column = [int]$hit.Groups['col'].Value
                    $located = $true
                    break
                }
            }
        }
        if (-not $located) { $errorText += ' [location unavailable; using entry file 1,1]' }
        $result = '{0}({1},{2}): {3}' -f $file, $line, $column, $errorText
    }
    # ASCII without BOM, CRLF: compatible with TSE.
    $result = ($result -replace '\r?\n', "`r`n").TrimEnd([char[]]"`r`n")
    if ($result.Length -gt 0) { $result += "`r`n" }
    [IO.File]::WriteAllText($outPath, $result, [Text.Encoding]::ASCII)
    exit 0
} catch {
    [Console]::Error.WriteLine('COMNODEJS helper: ' + $_.Exception.Message)
    exit 2
}
