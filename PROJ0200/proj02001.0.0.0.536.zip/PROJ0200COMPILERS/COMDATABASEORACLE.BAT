@echo off
rem COMDATABASEORACLE.BAT version 1.0.0.0.9
rem Knud van Eeden / OpenAI ChatGPT GPT-6
rem Run DATABASEORACLE program
rem PART 1: USER SETTINGS AND TEST INSTRUCTIONS
rem Requires a running Oracle XE database; this runner does not start services.
rem Default: local Windows authentication, SID XE, container XEPDB1.
rem Run with your Windows account that successfully used / as sysdba.
rem This default has DBA privileges. Use a normal schema for normal development.
rem No password is stored here. CONNECT can be overridden for wallet or other
rem noninteractive connections. This captured-output runner uses no password prompt.
rem Set CONTAINER to NONE when the connection already selects the target PDB.
rem Environment overrides below are optional; use SET in TCC or CMD.
rem Standalone: COMDATABASEORACLE.BAT "full-source.sql" "full-output.err"
rem TSE legacy parameters: %1 name, %2 extension, %3 full source,
rem                       %4 drive, %5 directory, %6 error output.
rem Optional environment overrides: COMDATABASEORACLE_EXE, _CONNECT,
rem _SID, _CONTAINER, _PAUSE (prefix COMDATABASEORACLE for every name).
rem Test TCC (adjust its path):
rem "G:\UTILS\JPSoft\TCMD\tcc.exe" /c COMDATABASEORACLE.BAT "F:\BBC\TAAL\PROJ0200HELLOWORLD\helloworlddatabaseoracle.sql" "F:\BBC\TAAL\oracle-tcc.err"
rem Test CMD:
rem cmd.exe /d /c COMDATABASEORACLE.BAT "F:\BBC\TAAL\PROJ0200HELLOWORLD\helloworlddatabaseoracle.sql" "F:\BBC\TAAL\oracle-cmd.err"
rem Repeat both tests with PROJ0200ERRORSMULTIPLE\errorstestdatabaseoracle.sql.
rem Expected: hello exit 0, errors exit 1, three TSE diagnostics at 4/7/10.
rem After the test, display the shell errorlevel immediately to check 0 or 1.
rem .err.sqlplus.raw retains complete SQLPlus output. Source runs ONCE.
rem No external parser/helper program is used; temporary SQL is SQLPlus input.
rem SQLPlus ECHO line mapping supports ordinary top-level SQL/PLSQL scripts.
rem Keep ECHO/SQLPROMPT/SQLNUMBER unchanged, and do not EXIT in source scripts.
rem Nested @ scripts and stored-object SHOW ERRORS tables need separate mapping.
rem Runtime stops within one failed block; subsequent statements continue.
rem Source DML left uncommitted is rolled back at runner exit; use COMMIT explicitly.
rem Stored-object compilation warnings require SHOW ERRORS and are not parsed here.
rem Standard English SQLPlus diagnostic text is expected for line/column parsing.
rem Column 1 is used when Oracle supplies no column. Raw output is preserved.
setlocal DisableDelayedExpansion
set "oracleExe=G:\DATABASE\SERVER\ORACLE\dbhomeXE\bin\sqlplus.exe"
set "oracleConnect=/ as sysdba"
set "oracleSid=XE"
set "oracleContainer=XEPDB1"
set "oraclePause=1"
if defined COMDATABASEORACLE_EXE set "oracleExe=%COMDATABASEORACLE_EXE%"
if defined COMDATABASEORACLE_CONNECT set "oracleConnect=%COMDATABASEORACLE_CONNECT%"
if defined COMDATABASEORACLE_SID set "oracleSid=%COMDATABASEORACLE_SID%"
rem Set CONTAINER to NONE to keep the container selected by the connection.
if defined COMDATABASEORACLE_CONTAINER set "oracleContainer=%COMDATABASEORACLE_CONTAINER%"
if /i "%oracleContainer%"=="NONE" set "oracleContainer="
if defined COMDATABASEORACLE_PAUSE set "oraclePause=%COMDATABASEORACLE_PAUSE%"
rem TCC uses native DO/GOSUB and string functions for diagnostic parsing.
rem CMD uses its own delayed-expansion parser; TCC settings need no changes.
rem PART 2: RUNNER - NO USER SETTINGS BELOW
set "source=%~1"
set "errFile=%~2"
if not "%~3"=="" set "source=%~3"
if not "%~6"=="" set "errFile=%~6"
if not defined source goto usage
for %%F in ("%source%") do set "source=%%~fF"
if not defined errFile set "errFile=%source%.err"
for %%F in ("%errFile%") do set "errFile=%%~fF"
if /i "%source%"=="%errFile%" goto badOutput
set "rawFile=%errFile%.sqlplus.raw"
set "driver=%errFile%.driver.sql"
if /i "%source%"=="%rawFile%" goto badOutput
if /i "%source%"=="%driver%" goto badOutput
>"%errFile%" type nul
if errorlevel 1 goto badOutput
if not exist "%source%" goto missingSource
rem TCC and CMD use different directory tests. Never use IF EXIST file\.
if not "%_4VER%"=="" goto tccDirectory
for %%F in ("%source%") do set "sourceAttr=%%~aF"
if /i "%sourceAttr:~0,1%"=="d" goto missingSource
goto sourceReady
:tccDirectory
if isdir "%source%" goto missingSource
:sourceReady
if not exist "%oracleExe%" goto missingExe
set "ORACLE_SID=%oracleSid%"
set "runCode=0"
set "mapCount=0"
rem Map nonblank source echo lines to original physical source line numbers.
for /f "usebackq tokens=1,* delims=:" %%A in (`findstr.exe /n "." "%source%"`) do call :mapLine %%A
>"%driver%" echo SET ECHO OFF
>>"%driver%" echo SET DEFINE OFF
>>"%driver%" echo SET TERMOUT ON
>>"%driver%" echo SET VERIFY OFF
>>"%driver%" echo SET TAB OFF
>>"%driver%" echo SET SQLBLANKLINES ON
>>"%driver%" echo SET SQLNUMBER ON
>>"%driver%" echo SET SQLPROMPT 'TSESQL^> '
>>"%driver%" echo SET LINESIZE 32767
>>"%driver%" echo WHENEVER OSERROR EXIT FAILURE ROLLBACK
>>"%driver%" echo WHENEVER SQLERROR EXIT FAILURE ROLLBACK
if defined oracleContainer >>"%driver%" echo ALTER SESSION SET CONTAINER = %oracleContainer%;
rem Enable DBMS_OUTPUT in the selected PDB, after switching containers.
>>"%driver%" echo SET SERVEROUTPUT ON SIZE UNLIMITED
>>"%driver%" echo WHENEVER SQLERROR CONTINUE NONE
>>"%driver%" echo PROMPT TSE_BEGIN_SOURCE
>>"%driver%" echo SET ECHO ON
>>"%driver%" echo @"%source%"
>>"%driver%" echo SET ECHO OFF
>>"%driver%" echo PROMPT TSE_END_SOURCE
>>"%driver%" echo EXIT SUCCESS ROLLBACK
echo COMDATABASEORACLE.BAT version 1.0.0.0.9
echo Source: "%source%"
echo Oracle SID: %oracleSid%  Container: %oracleContainer%
rem SQLPlus accepts / as sysdba as separate arguments. -L prevents login loops.
"%oracleExe%" -L %oracleConnect% @"%driver%" >"%rawFile%" 2>&1
set "sqlExit=%errorlevel%"
type "%rawFile%"
set "inSource=0"
set "echoIndex=0"
set "currentLine=1"
set "baseLine=1"
set "errorLine=1"
set "errorColumn=1"
set "recordCount=0"
set "nextSource=0"
if not "%_4VER%"=="" goto tccParseStart
for /f "usebackq delims=" %%L in ("%rawFile%") do (
    set "rawLine=%%L"
    call :parseLine
)
goto parseDone
:tccParseStart
rem Native TCC DO/GOSUB parser: no CMD exclamation-mark expansion required.
do rawLine in @"%rawFile%"
    gosub tccParseLine
enddo
:parseDone
if not "%recordCount%"=="0" set "runCode=1"
rem Defensive check: never report success when raw Oracle errors were missed.
findstr.exe /r /b /c:"ORA-[0-9]" /c:"PLS-[0-9]" /c:"SP2-[0-9]" "%rawFile%" >nul
if not errorlevel 1 set "runCode=1"
if not "%sqlExit%"=="0" set "runCode=1"
for %%F in ("%errFile%") do if not "%%~zF"=="0" set "runCode=1"
if "%runCode%"=="1" for %%F in ("%errFile%") do if "%%~zF"=="0" >>"%errFile%" echo TSE: %source%:1:1: Oracle errors found; inspect %rawFile%
if "%runCode%"=="0" echo No Oracle errors detected.
if "%runCode%"=="1" type "%errFile%"
del /q "%driver%" >nul 2>&1
echo Exit code: %runCode%
if "%oraclePause%"=="1" pause
endlocal & exit /b %runCode%
:mapLine
set /a mapCount+=1
set "map.%mapCount%=%1"
exit /b
:parseLine
setlocal EnableDelayedExpansion
set "s=!rawLine!"
if "!s!"=="TSE_BEGIN_SOURCE" (
    endlocal & set "inSource=1"
    exit /b
)
if "!s!"=="TSE_END_SOURCE" (
    endlocal & set "inSource=0"
    exit /b
)
set "isEcho=0"
set "relative=1"
set "body="
if "!s:~0,8!"=="TSESQL> " (
    set "body=!s:~8!"
    set "isEcho=1"
)
if "!s:~0,1!"==" " for /f "tokens=1,*" %%A in ("!s!") do (
    set "number=%%A"
    set "nondigits="
    for /f "delims=0123456789" %%N in ("%%A") do set "nondigits=%%N"
    if not defined nondigits (
        set "relative=%%A"
        set "body=%%B"
        set "isEcho=1"
    )
)
if "!isEcho!"=="1" (
    if "!inSource!"=="0" (
        endlocal
        exit /b
    )
    if "!body:~0,1!"=="@" (
        endlocal
        exit /b
    )
    if /i "!body!"=="SET ECHO OFF" (
        endlocal & set "inSource=0"
        exit /b
    )
    if not defined body (
        endlocal
        exit /b
    )
    for %%R in (!relative!) do endlocal & set "echoRelative=%%R"
    set /a echoIndex+=1
    call :advanceEcho
    exit /b
)
if "!s:~0,14!"=="ERROR at line " (
    for /f "tokens=4 delims= :" %%N in ("!s!") do set /a errorLine=baseLine+%%N-1
    for %%N in (!errorLine!) do endlocal & set "errorLine=%%N"
    exit /b
)
rem Marker line: column is the number of spaces preceding the asterisk + 1.
set "marker=!s: =!"
if "!marker!"=="*" (
    set "col=1"
    set "tail=!s!"
    for /l %%N in (1,1,1024) do if "!tail:~0,1!"==" " (
        set /a col+=1
        set "tail=!tail:~1!"
    )
    for %%C in (!col!) do endlocal & set "errorColumn=%%C"
    exit /b
)
if "!s:~0,10!"=="ORA-06550:" (
    for /f "tokens=3,5 delims= ,:" %%A in ("!s!") do (
        set /a ln=baseLine+%%A-1
        set "co=%%B"
    )
    for %%A in (!ln!) do for %%B in (!co!) do endlocal & set "errorLine=%%A" & set "errorColumn=%%B"
    exit /b
)
if "!s:~0,10!"=="ORA-06512:" (
    rem Only anonymous-block stacks have locations in the current source.
    rem Named stored-object stacks refer to their database object, not this file.
    if "!s:~0,18!"=="ORA-06512: at line" (
        for /f "tokens=4 delims= :" %%N in ("!s!") do set /a errorLine=baseLine+%%N-1
        >>"!errFile!" echo TSE: !source!:!errorLine!:1: !s!
    )
    endlocal
    exit /b
)
if "!s:~0,4!"=="PLS-" (
    >>"!errFile!" echo TSE: !source!:!errorLine!:!errorColumn!: !s!
    endlocal & exit /b
)
if "!s:~0,4!"=="ORA-" (
    >>"!errFile!" echo TSE: !source!:!errorLine!:!errorColumn!: !s!
    endlocal
    exit /b
)
if "!s:~0,4!"=="SP2-" (
    >>"!errFile!" echo TSE: !source!:!currentLine!:1: !s!
)
endlocal
exit /b
:advanceEcho
setlocal EnableDelayedExpansion
for %%N in (!echoIndex!) do set "physical=!map.%%N!"
if not defined physical set "physical=!currentLine!"
set /a base=physical-echoRelative+1
for %%L in (!physical!) do for %%B in (!base!) do endlocal & set "currentLine=%%L" & set "baseLine=%%B" & set "errorLine=%%L" & set "errorColumn=1"
exit /b
:missingSource
>>"%errFile%" echo TSE: %source%:1:1: Source file not found or is a directory.
goto fail
:missingExe
>>"%errFile%" echo TSE: %source%:1:1: SQLPlus executable not found: %oracleExe%
:fail
type "%errFile%"
if "%oraclePause%"=="1" pause
endlocal & exit /b 1
:badOutput
echo ERROR: Output path is invalid, unwritable, or conflicts with the source.
endlocal & exit /b 1
:usage
echo COMDATABASEORACLE.BAT version 1.0.0.0.9
echo Usage: COMDATABASEORACLE.BAT "source.sql" "output.err"
endlocal & exit /b 2

:tccParseLine
rem All text-derived comparisons use short prefixes, never a whole SQL command.
iff "%@left[16,%rawLine]" == "TSE_BEGIN_SOURCE" then
    set inSource=1
    return
endiff
iff "%@left[14,%rawLine]" == "TSE_END_SOURCE" then
    set inSource=0
    return
endiff
iff "%@left[8,%rawLine]" == "TSESQL> " then
    set relative=1
    rem Exclude the wrapper's @source command and trailing SET ECHO OFF.
    if "%@instr[8,1,%rawLine]" == "@" return
    iff "%@instr[8,12,%rawLine]" == "SET ECHO OFF" then
        set inSource=0
        return
    endiff
    if %@len[%@trim[%@instr[8,,%rawLine]]] == 0 return
    if %inSource == 1 gosub tccAdvanceEcho
    return
endiff
iff "%@left[1,%rawLine]" == " " then
    set firstWord=%@word[" ",0,%rawLine]
    iff %@digits[%firstWord] == 1 then
        if %@len[%@word[" ",1-,%rawLine]] == 0 return
        set relative=%firstWord
        if %inSource == 1 gosub tccAdvanceEcho
        return
    endiff
endiff
iff "%@left[14,%rawLine]" == "ERROR at line " then
    set relError=%@word[" :",3,%rawLine]
    if %@digits[%relError] == 1 set /a errorLine=baseLine+relError-1
    return
endiff
iff "%@trim[%rawLine]" == "*" then
    set errorColumn=%@len[%@rtrim[%rawLine]]
    return
endiff
iff "%@left[10,%rawLine]" == "ORA-06550:" then
    set relError=%@word[" ,:",2,%rawLine]
    set relColumn=%@word[" ,:",4,%rawLine]
    if %@digits[%relError] == 1 set /a errorLine=baseLine+relError-1
    if %@digits[%relColumn] == 1 set errorColumn=%relColumn
    return
endiff
iff "%@left[10,%rawLine]" == "ORA-06512:" then
    iff "%@left[18,%rawLine]" == "ORA-06512: at line" then
        set relError=%@word[" :",3,%rawLine]
        iff %@digits[%relError] == 1 then
            set /a errorLine=baseLine+relError-1
            set errorColumn=1
            gosub tccWriteError >>"%errFile%"
        endiff
    endiff
    return
endiff
iff "%@left[4,%rawLine]" == "ORA-" .or. "%@left[4,%rawLine]" == "PLS-" then
    gosub tccWriteError >>"%errFile%"
    return
endiff
iff "%@left[4,%rawLine]" == "SP2-" then
    set errorLine=%currentLine
    set errorColumn=1
    gosub tccWriteError >>"%errFile%"
endiff
return
:tccAdvanceEcho
rem Resolve each nonblank echoed line to its physical line in the source.
rem @LINE is zero based; this retains original blank-line offsets.
do forever
    set sourceText=%@line["%source%",%nextSource]
    set /a nextSource+=1
    iff "%@left[7,%sourceText]" == "**EOF**" then
        leave
    endiff
    iff %@len[%@trim[%sourceText]] GT 0 then
        set currentLine=%nextSource
        set /a baseLine=currentLine-relative+1
        set errorLine=%currentLine
        set errorColumn=1
        leave
    endiff
enddo
return
:tccWriteError
set /a recordCount+=1
rem Redirection is established by GOSUB before special-character processing
rem is disabled. Oracle message text cannot become a shell command here.
setlocal
setdos /x-4568
echo TSE: %source%:%errorLine%:%errorColumn%: %rawLine%
endlocal
return
