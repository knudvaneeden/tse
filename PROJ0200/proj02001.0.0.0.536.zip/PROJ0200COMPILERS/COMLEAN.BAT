@echo off
rem COMLEAN.BAT version 1.0.0.0.8
rem Run Lean program - TSE compile/check and optional execution.
rem Single argument: COMLEAN.BAT "F:\path\errorstest.lean"
rem Six TSE arguments:
rem COMLEAN.BAT "errorstest" ".lean" "F:\path\errorstest.lean" "F:" "\path" "C:\TEMP\lean-errors.err"
rem In JPSoft TCC: run COMLEAN.BAT directly (never start nested tcc.exe).
rem In Microsoft CMD: run COMLEAN.BAT directly, or cmd.exe /d /c COMLEAN.BAT ...
rem The TSE compiler rule consumes diagnostics from parameter %%6.
rem =====================================================================
rem PART 1 - USER SETTINGS (edit these for your computer)
rem =====================================================================
set "CL_LEAN_HOME=G:\LANGUAGE\COMPUTER\LEAN"
set "CL_LEAN_EXE=G:\LANGUAGE\COMPUTER\LEAN\bin\lean.exe"
rem Pin installed toolchain: avoids 'stable' checking/downloading new releases.
set "CL_TOOLCHAIN=leanprover/lean4:v4.34.1"
rem 1 = run main after successful proof/type checking; 0 = check only.
set "CL_RUN_AFTER_CHECK=1"
rem 1 = pause at end; 0 = return immediately.
set "CL_PAUSE=1"
rem Output file when running with only one argument.
set "CL_DEFAULT_ERR=%TEMP%\COMLEAN-errors.err"
rem =====================================================================
rem PART 2 - FIXED LOGIC (normally do not edit)
rem =====================================================================
set "CL_SOURCE=%~3"
if "%~3"=="" set "CL_SOURCE=%~1"
set "CL_ERR=%~6"
if "%~6"=="" set "CL_ERR=%CL_DEFAULT_ERR%"
set "ELAN_HOME=%CL_LEAN_HOME%"
rem ELAN_TOOLCHAIN overrides any default, without changing settings.toml.
set "ELAN_TOOLCHAIN=%CL_TOOLCHAIN%"
echo COMLEAN version 1.0.0.0.8
echo Shell: TCC or CMD
echo filename=%CL_SOURCE%
rem The diagnostics file must contain the original compiler output for TSE.
>"%CL_ERR%" echo filename=%CL_SOURCE%
if "%CL_SOURCE%"=="" goto CL_MISSING_SOURCE
rem Avoid IF EXIST "filename\" which can misclassify files in TCC.
if not exist "%CL_SOURCE%" goto CL_MISSING_SOURCE
if not exist "%CL_LEAN_EXE%" goto CL_MISSING_LEAN
rem First, check proofs and definitions. Preserve native Lean diagnostic lines.
echo CHECK: Lean %CL_TOOLCHAIN%
"%CL_LEAN_EXE%" "%CL_SOURCE%" >>"%CL_ERR%" 2>&1
if errorlevel 1 goto CL_CHECK_FAILED
echo CHECK OK
if not "%CL_RUN_AFTER_CHECK%"=="1" goto CL_DONE
rem Only attempt --run when a conventional main is visibly defined.
rem findstr.exe is a standard Windows utility, not an extra helper script.
findstr /R /C:"^[ ]*def main" /C:"^[ ]*unsafe def main" "%CL_SOURCE%" >nul 2>&1
if errorlevel 1 goto CL_NO_MAIN
echo RUN:
"%CL_LEAN_EXE%" --run "%CL_SOURCE%"
if errorlevel 1 goto CL_RUN_FAILED
goto CL_DONE
:CL_NO_MAIN
echo No ordinary main found; proof checking complete.
goto CL_DONE
:CL_CHECK_FAILED
echo CHECK ERROR - Lean diagnostics:
type "%CL_ERR%"
goto CL_DONE
:CL_RUN_FAILED
echo RUN ERROR - see console output.
goto CL_DONE
:CL_MISSING_SOURCE
echo ERROR: source file not found: "%CL_SOURCE%"
>>"%CL_ERR%" echo ERROR: source file not found: "%CL_SOURCE%"
goto CL_DONE
:CL_MISSING_LEAN
echo ERROR: Lean executable not found: "%CL_LEAN_EXE%"
>>"%CL_ERR%" echo ERROR: Lean executable not found: "%CL_LEAN_EXE%"
:CL_DONE
if "%CL_PAUSE%"=="1" pause
