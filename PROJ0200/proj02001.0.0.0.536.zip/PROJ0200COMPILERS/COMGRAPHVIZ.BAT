@echo off
REM COMGRAPHVIZ version 1.0.0.0.12 - generated with OpenAI GPT-6
REM Render Graphviz DOT to PostScript, then PDF; no PowerShell or external parsing helper.
REM Hello-world test: COMGRAPHVIZ.BAT "C:\TEMP\ddd.dot"
REM PART 1 contains the settings other users should change.
REM Direct test in native TCC: COMGRAPHVIZ.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.dot"
REM CMD test: cmd.exe /d /c COMGRAPHVIZ.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.dot"
REM Six-parameter test (both shells):
REM COMGRAPHVIZ.BAT "errorstest" "dot" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.dot" "F:" "\BBC\TAAL\PROJ0200ERRORSMULTIPLE\" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\graphviz.err"
REM %1=name (or full file for direct call), %2=extension, %3=full source,
REM %4=drive, %5=directory, %6=TSE diagnostic output file.
REM The executable is configured below, not supplied as a positional argument.
REM Correct-program test: remove the three marked invalid statements from
REM errorstest.dot. A small valid graph remains and its PDF should open.
REM DOT syntax parsing normally stops at the first syntax error. Correct it
REM and rerun to reveal the next. Graphviz supplies no syntax error column;
REM normalized diagnostics use column 1 as a navigation fallback.

REM ================= PART 1: USER SETTINGS =================
setlocal
set "GRAPHVIZ_EXE=G:\UTILS\DIAGRAM\GRAPHVIZ\graphviz 2.28\bin\dot.exe"
set "GRAPHVIZ_FORMAT=ps"
set "GRAPHVIZ_DISTILLER=C:\Program Files (x86)\Adobe\Acrobat 8.0\Acrobat\acrodist.exe"
set "GRAPHVIZ_PDF=1"
set "GRAPHVIZ_OPEN=1"
set "GRAPHVIZ_PAUSE=1"
REM GRAPHVIZ_PDF=1 converts PostScript to PDF with Distiller.
REM Set GRAPHVIZ_PDF=0 and GRAPHVIZ_FORMAT=svg for direct SVG output.
REM PDF is opened with its Windows default application.
REM Set GRAPHVIZ_OPEN=0 to suppress opening the generated image.
REM Distiller conversion and PDF opening are automatic.
REM Set GRAPHVIZ_PAUSE=0 to suppress the final console pause.
REM Change GRAPHVIZ_EXE to the full path of your installed dot.exe.

REM ================= PART 2: STABLE LOGIC ===================
set "GV_VERSION=1.0.0.0.12"
set "GV_SHELL=CMD"
REM TCC internal variables are not environment variables: DEFINED fails.
if /i "%_CMDPROC%"=="TCC" set "GV_SHELL=TCC"
if /i "%_CMDPROC%"=="TCC-RT" set "GV_SHELL=TCC"
REM Prefix internal EXIT and PAUSE with * in TCC to bypass user aliases.
set "GV_COMMAND_PREFIX="
if "%GV_SHELL%"=="TCC" set "GV_COMMAND_PREFIX=*"
echo COMGRAPHVIZ version %GV_VERSION%
echo Shell: %GV_SHELL%
set "GV_EXIT=1"
set "GV_SOURCE="
set "GV_ERR="
set "GV_RAW="
if "%~1"=="" goto usage
set "GV_SOURCE=%~f1"
if not "%~3"=="" set "GV_SOURCE=%~f3"
if not "%~6"=="" set "GV_ERR=%~f6"
if not defined GV_ERR set "GV_ERR=%TEMP%\COMGRAPHVIZ_%RANDOM%_%RANDOM%.err"
set "GV_RAW=%TEMP%\COMGRAPHVIZ_%RANDOM%_%RANDOM%.raw"
>"%GV_ERR%" echo COMGRAPHVIZ version %GV_VERSION%
if errorlevel 1 goto errwrite
if not exist "%GV_SOURCE%" goto missing
if "%GV_SHELL%"=="TCC" goto tccdir
REM This trailing-slash test is restricted to CMD, never executed in TCC.
if exist "%GV_SOURCE%\" goto missing
goto checked
:tccdir
if isdir "%GV_SOURCE%" goto missing
:checked
if not exist "%GRAPHVIZ_EXE%" goto missingexe
for %%F in ("%GV_SOURCE%") do set "GV_OUT=%%~dpnF.%GRAPHVIZ_FORMAT%"
for %%F in ("%GV_SOURCE%") do set "GV_DIR=%%~dpF"
pushd "%GV_DIR%"
if errorlevel 1 goto direrror
echo Rendering "%GV_SOURCE%"
REM Feeding stdin makes the syntax diagnostic prefix independent of filename
REM spaces and drive colons. Relative image references use the source folder.
"%GRAPHVIZ_EXE%" -T%GRAPHVIZ_FORMAT% -o "%GV_OUT%" <"%GV_SOURCE%" >"%GV_RAW%" 2>&1
set "GV_EXIT=%ERRORLEVEL%"
popd
REM Typical native diagnostic: Error: ^<stdin^>: syntax error in line 6 near ...
REM Tokens 1,3,6,7 are Error:, syntax, line, and the source line number.
for /f "usebackq tokens=1,3,6,7" %%A in ("%GV_RAW%") do call :diagnostic "%%A" "%%B" "%%C" "%%D"
REM Preserve original details for inspection; only TSE: lines match the rule.
type "%GV_RAW%" >>"%GV_ERR%"
type "%GV_ERR%"
echo Render exit code: %GV_EXIT%
echo Diagnostics saved to "%GV_ERR%"
if not "%GV_EXIT%"=="0" goto finish
if not exist "%GV_OUT%" goto nooutput
if "%GRAPHVIZ_PDF%"=="1" call :distill
if not "%GV_EXIT%"=="0" goto finish
if not "%GRAPHVIZ_OPEN%"=="1" goto finish
if "%GV_SHELL%"=="TCC" goto opentcc
start "" "%GV_OUT%"
goto finish
:opentcc
%GV_COMMAND_PREFIX%start /pgm "%GV_OUT%"
goto finish
:distill
if not "%GRAPHVIZ_FORMAT%"=="ps" goto badformat
if not exist "%GRAPHVIZ_DISTILLER%" goto nodistiller
for %%F in ("%GV_SOURCE%") do set "GV_PDF=%%~dpnF.pdf"
REM Remove previous generated PDF so an old file cannot look like success.
if exist "%GV_PDF%" del /q "%GV_PDF%"
if exist "%GV_PDF%" goto pdfblocked
echo Converting "%GV_OUT%" to PDF...
if "%GV_SHELL%"=="TCC" goto distilltcc
REM Wait for a separate Distiller instance to convert and quit.
start "" /wait "%GRAPHVIZ_DISTILLER%" /N /Q "%GV_OUT%"
goto distillcheck
:distilltcc
REM /PGM identifies the quoted executable instead of treating it as a title.
%GV_COMMAND_PREFIX%start /wait /pgm "%GRAPHVIZ_DISTILLER%" /N /Q "%GV_OUT%"
:distillcheck
set "GV_DISTILL_EXIT=%ERRORLEVEL%"
echo Distiller exit code: %GV_DISTILL_EXIT%
if not "%GV_DISTILL_EXIT%"=="0" goto pdffailed
if not exist "%GV_PDF%" goto pdffailed
set "GV_OUT=%GV_PDF%"
%GV_COMMAND_PREFIX%exit /b
:badformat
>>"%GV_ERR%" echo TSE: %GV_SOURCE%:1:1: Set GRAPHVIZ_FORMAT=ps when GRAPHVIZ_PDF=1.
goto pdferror
:nodistiller
>>"%GV_ERR%" echo TSE: %GV_SOURCE%:1:1: Distiller not found. Check GRAPHVIZ_DISTILLER in PART 1.
goto pdferror
:pdfblocked
>>"%GV_ERR%" echo TSE: %GV_SOURCE%:1:1: Previous PDF cannot be removed; close it in the viewer and retry.
goto pdferror
:pdffailed
>>"%GV_ERR%" echo TSE: %GV_SOURCE%:1:1: Distiller did not produce the expected PDF. Check its log beside the PostScript file.
:pdferror
set "GV_EXIT=1"
type "%GV_ERR%"
%GV_COMMAND_PREFIX%exit /b
:diagnostic
if not "%~1"=="Error:" %GV_COMMAND_PREFIX%exit /b
if not "%~2"=="syntax" %GV_COMMAND_PREFIX%exit /b
if not "%~3"=="line" %GV_COMMAND_PREFIX%exit /b
>>"%GV_ERR%" echo TSE: %GV_SOURCE%:%~4:1: Graphviz syntax error; column unavailable - see native diagnostic below.
%GV_COMMAND_PREFIX%exit /b
:missing
>>"%GV_ERR%" echo TSE: %GV_SOURCE%:1:1: Source file not found or is a directory.
goto showerror
:missingexe
>>"%GV_ERR%" echo TSE: %GV_SOURCE%:1:1: Graphviz executable not found. Set GRAPHVIZ_EXE in PART 1.
goto showerror
:direrror
>>"%GV_ERR%" echo TSE: %GV_SOURCE%:1:1: Cannot enter source directory.
goto showerror
:nooutput
set "GV_EXIT=1"
>>"%GV_ERR%" echo TSE: %GV_SOURCE%:1:1: Graphviz returned success but output is missing.
:showerror
type "%GV_ERR%"
goto finish
:errwrite
echo ERROR: Cannot write diagnostic file "%GV_ERR%".
goto finish
:usage
echo Usage: COMGRAPHVIZ.BAT "full source.dot"
echo Or: COMGRAPHVIZ.BAT name dot "full source.dot" drive path "error file"
:finish
if defined GV_RAW if exist "%GV_RAW%" del /q "%GV_RAW%" >nul 2>&1
if "%GRAPHVIZ_PAUSE%"=="1" %GV_COMMAND_PREFIX%pause
endlocal & %GV_COMMAND_PREFIX%exit /b %GV_EXIT%
