@echo off
rem COMCPP.BAT version 1.0.0.0.8
rem Updated 2026-10-11 by OpenAI Codex
rem Compile a C/C++ source with Borland C++ 5.5.1, copy and run its EXE.
rem Edit the local settings in PART 1 only. PART 2 uses the TSE arguments.
rem
rem External parameters (quote paths, especially those containing spaces):
rem   %1 = executable base name WITHOUT .exe, for example ddd
rem   %2 = unused; supply "unused" to keep the argument positions
rem   %3 = full source filename, for example F:\examples\ddd.c
rem   %4 = output drive letter WITHOUT colon, for example F
rem   %5 = output directory on that drive, for example examples
rem   %6 = full compiler log filename; its parent directory must exist
rem The output EXE is constructed as drive:\directory\name.exe.
rem RLINK32.DLL must be in cppBin or the configured cppDllDir.
rem No parameters are passed to the resulting program.
rem
rem Test from a console (adjust these example paths for your system):
rem "F:\BBC\TAAL\COMCPP.BAT" "ddd" "unused" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.c" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\comcpp_test.err"
rem Expected output for the sample ddd.c: 1. Open project / 2. Exit
rem The source, output directory and compiler log directory must exist.
rem The batch overwrites the named EXE and logs on each compilation.
rem
setlocal

rem ====================================================================
rem PART 1 - LOCAL SETTINGS: users may change these values
rem ====================================================================
rem Borland installation directory:
set "cppRoot=G:\language\computer\cpp\embarcadero\borland\bcc55"
rem Compiler, include and library paths (normally derived from cppRoot):
set "cppBin=%cppRoot%\bin"
rem Additional DLL folder; this contains RLINK32.DLL on this system.
rem Leave empty if all compiler DLLs are already in cppBin.
set "cppDllDir=%cppBin%\DDD"
set "cppCompiler=%cppBin%\bcc32.exe"
set "cppInclude=%cppRoot%\include"
set "cppLib=%cppRoot%\lib"
rem Optional additional compiler switches; leave empty for current defaults:
set "cppOptions="
rem Optional extra copy of compiler log; set empty to disable it:
set "cppLogCopy=C:\temp\dddoutput.txt"
rem Keep the console output visible until a key is pressed: true or false.
set "cppPause=true"

rem ====================================================================
rem PART 2 - SHARED LOGIC: no local settings need to be changed below
rem ====================================================================
rem Make Borland DLLs discoverable for compiler and linker processes.
set "PATH=%cppBin%;%PATH%"
if not "%cppDllDir%"=="" set "PATH=%cppDllDir%;%PATH%"
set "cppTarget=%~4:\%~5\%~1.exe"
if "%~1"=="" goto usage
if "%~3"=="" goto usage
if "%~4"=="" goto usage
if "%~5"=="" goto usage
if "%~6"=="" goto usage
pushd "%cppBin%"
if errorlevel 1 goto directoryError
if exist "%~1.exe" del "%~1.exe"
echo filename=%~3>"%~6"
"%cppCompiler%" %cppOptions% -I"%cppInclude%" -L"%cppLib%" "%~3" >>"%~6" 2>&1
set "cppResult=%errorlevel%"
echo.
type "%~6"
if not "%cppLogCopy%"=="" copy /y "%~6" "%cppLogCopy%" >nul
if not "%cppResult%"=="0" goto compileError
if not exist "%~1.exe" goto compileError
copy /y "%~1.exe" "%cppTarget%"
if errorlevel 1 goto copyError
popd
echo.
echo Running "%cppTarget%"
echo.
"%cppTarget%"
set "cppResult=%errorlevel%"
echo.
if /i "%cppPause%"=="true" pause
endlocal & exit /b %cppResult%

:compileError
echo.
echo Compilation failed. The program was not run.
popd
if /i "%cppPause%"=="true" pause
endlocal & exit /b 1

:copyError
echo Could not copy the executable to "%cppTarget%".
popd
if /i "%cppPause%"=="true" pause
endlocal & exit /b 1

:directoryError
echo Could not open the compiler directory "%cppBin%".
if /i "%cppPause%"=="true" pause
endlocal & exit /b 1

:usage
echo Usage: COMCPP name unused source drive directory logfile
if /i "%cppPause%"=="true" pause
endlocal & exit /b 1
