@ECHO OFF
REM COMFORTH.BAT version 1.0.0.0.8
REM Date: 2026-11-05
REM Run FORTH program - Gforth / TSE compiler integration.
REM
REM PART 1 - USER SETTINGS: change these for your installation.
SETLOCAL
SET "FORTH_EXE=g:\language\computer\forth\gforth\gforth.exe"
SET "FORTH_PAUSE=yes"
REM Optional parameter 7 overrides FORTH_EXE; parameter 8 is yes/no pause.
REM TSE supplies: 1=name 2=extension 3=full source 4=drive 5=path 6=output.
REM Always quote every argument, including empty arguments.
REM
REM EXTERNAL TESTS - run these commands in the respective console.
REM Replace the executable and source paths if required.
REM Native TCC: start tcc.exe, then run:
REM CALL COMFORTH.BAT "helloworldforth" ".fth" "f:\bbc\taal\proj0200\helloworldforth.fth" "" "" "%TEMP%\forth-tcc-hello.err" "g:\language\computer\forth\gforth\gforth.exe" "yes"
REM CALL COMFORTH.BAT "errorstestforth" ".fth" "f:\bbc\taal\proj0200errorsmultiple\errorstestforth.fth" "" "" "%TEMP%\forth-tcc-errors.err" "g:\language\computer\forth\gforth\gforth.exe" "yes"
REM Native CMD: start cmd.exe /D, then run:
REM CALL COMFORTH.BAT "helloworldforth" ".fth" "f:\bbc\taal\proj0200\helloworldforth.fth" "" "" "%TEMP%\forth-cmd-hello.err" "g:\language\computer\forth\gforth\gforth.exe" "yes"
REM CALL COMFORTH.BAT "errorstestforth" ".fth" "f:\bbc\taal\proj0200errorsmultiple\errorstestforth.fth" "" "" "%TEMP%\forth-cmd-errors.err" "g:\language\computer\forth\gforth\gforth.exe" "yes"
REM Expected: hello prints once and returns 0; error test returns nonzero.
REM In either shell, ECHO %ERRORLEVEL% immediately after CALL shows status.
REM Also test paths with spaces, missing files, and a directory as source.
REM Use distinct source/output files. Output parent directory must exist.
REM
REM PART 2 - FIXED LOGIC: no installation changes needed below here.
SET "FORTH_SOURCE=%~f3"
SET "FORTH_OUTPUT=%~f6"
SET "FORTH_RC=1"
IF NOT "%~7"=="" SET "FORTH_EXE=%~7"
IF NOT "%~8"=="" SET "FORTH_PAUSE=%~8"
IF "%~3"=="" GOTO usage
IF "%~6"=="" GOTO usage
IF /I "%FORTH_SOURCE%"=="%FORTH_OUTPUT%" GOTO samefile
>"%FORTH_OUTPUT%" ECHO filename=%FORTH_SOURCE%
IF ERRORLEVEL 1 GOTO outputerror
IF NOT EXIST "%FORTH_SOURCE%" GOTO sourceerror
REM No directory probe: TCC can treat a file with a trailing slash as existing.
REM Gforth itself reports an invalid source if a directory is supplied.
:checkexe
IF NOT EXIST "%FORTH_EXE%" GOTO exeerror
ECHO COMFORTH.BAT version 1.0.0.0.8
REM Execute exactly once. Save exit status before TYPE or PAUSE changes it.
"%FORTH_EXE%" "%FORTH_SOURCE%" -e bye >>"%FORTH_OUTPUT%" 2>&1
SET "FORTH_RC=%ERRORLEVEL%"
GOTO show
:sourceerror
>>"%FORTH_OUTPUT%" ECHO ERROR: source file not found: %FORTH_SOURCE%
GOTO show
:exeerror
>>"%FORTH_OUTPUT%" ECHO ERROR: Gforth executable not found: %FORTH_EXE%
GOTO show
:samefile
ECHO ERROR: source and output must be different files.
GOTO finish
:outputerror
ECHO ERROR: cannot write output file: %FORTH_OUTPUT%
GOTO finish
:usage
ECHO COMFORTH.BAT version 1.0.0.0.8
ECHO Usage: CALL COMFORTH.BAT name ext "source" drive path "output" ["exe"] [yes/no]
GOTO finish
:show
TYPE "%FORTH_OUTPUT%"
ECHO.
ECHO Gforth exit code: %FORTH_RC%
:finish
IF /I "%FORTH_PAUSE%"=="yes" PAUSE
ENDLOCAL & EXIT /B %FORTH_RC%
