@ECHO OFF
SETLOCAL EnableExtensions DisableDelayedExpansion
IF /I "%~1"=="--format-log" GOTO format_log
REM COMSCALA.BAT version 1.0.0.0.8 - 2026-10-09
REM Updated with OpenAI GPT-6. No helper scripts or programs are generated.
REM Scala 3 runner: capture every compiler diagnostic for the TSE error list.
REM Version 1.0.0.0.8: explicit field searches and one-based TSE columns.
REM Original Scala headers remain unchanged; appended TSE: summaries use
REM column+1. Scala 6:12 therefore jumps to TSE line 6, column 13.
REM
REM DIRECT CALL: COMSCALA.BAT "source.scala" ["diagnostics.err"]
REM TSE CALL:    COMSCALA.BAT "name" "ext" "full-source" "drive" "path" "errfile"
REM In the TSE call, source=%3 and diagnostics=%6; the other four parameters
REM are editor metadata, not tool paths or switches.
REM Use full source filenames, especially when launching from the editor.
REM
REM TEST FROM AN ALREADY OPEN TCC CONSOLE (do not start another tcc.exe):
REM   COMSCALA.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.scala"
REM   ECHO %ERRORLEVEL%
REM TEST FROM CMD, OR FROM TCC THROUGH CMD:
REM   cmd.exe /d /c COMSCALA.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.scala"
REM SIX-PARAMETER TEST FROM EITHER SHELL:
REM   COMSCALA.BAT "errorstest" ".scala" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.scala" "F:" "\BBC\TAAL\PROJ0200ERRORSMULTIPLE\" "C:\TEMP\scala.err"
REM VERSION CHECK: COMSCALA.BAT --version
REM Expected errorstest.scala errors: lines 6, 9, 12; column 13 on each.
REM Expected status: nonzero; the three missing names are compile errors.
REM Correct the names to 1, 2, 3 to run the program successfully.
REM
REM TOOL OVERRIDES WITHOUT EDITING THIS BAT (before running it):
REM   SET "COMSCALA_SCALA=C:\Scala\bin\scala.bat"
REM   SET "COMSCALA_JAVA=C:\Java\bin\java.exe"
REM   SET "COMSCALA_PAUSE=0"
REM The Scala 3 rule needs uncolored -- ... Error: file:line:column headers.
REM Scala 2 has a different format; this rule targets Scala 3, like the input.
REM Paths/logs containing spaces are quoted. Existing logs are overwritten.
REM Keep the source and output filenames different. Output parent must exist.
REM Windows/TSE execution must be checked on the user's Windows installation.

REM =====================================================================
REM PART 1 - USER SETTINGS: local tools and preferences belong here.
REM Existing COMSCALA_* environment values override the following defaults.
REM =====================================================================
IF NOT DEFINED COMSCALA_SCALA SET "COMSCALA_SCALA=g:\language\computer\scala\bin\scala.bat"
IF NOT DEFINED COMSCALA_JAVA SET "COMSCALA_JAVA=g:\language\computer\java\jdk-11.0.15\bin\java.exe"
REM Set COMSCALA_JAVA to AUTO to use Scala's existing Java discovery.
REM Select a JDK supported by your installed Scala distribution.
IF NOT DEFINED COMSCALA_OPTIONS SET "COMSCALA_OPTIONS=-color:never"
REM COMSCALA_OPTIONS contains trusted Scala 3 runner/compiler switches.
IF NOT DEFINED COMSCALA_PAUSE SET "COMSCALA_PAUSE=1"
IF NOT DEFINED COMSCALA_TEMP SET "COMSCALA_TEMP=%TEMP%"
IF NOT DEFINED COMSCALA_CMD SET "COMSCALA_CMD=%SystemRoot%\System32\cmd.exe"
REM Optional second copy of the diagnostics. Default is disabled.
REM SET "COMSCALA_COPY=c:\temp\dddoutput.txt"

REM =====================================================================
REM PART 2 - COMMON LOGIC: normally no changes needed below this line.
REM =====================================================================
SET "CSC_VERSION=1.0.0.0.8"
SET "CSC_RC=2"
SET "CSC_SHELL=CMD"
SET "CSC_SOURCE="
SET "CSC_LOG="
SET "CSC_MODE=run"
REM JPSoft documents numeric 01==1 as true in TCC and false in CMD.
IF 01 == 1 SET "CSC_SHELL=TCC"
ECHO COMSCALA version %CSC_VERSION%
ECHO Shell: %CSC_SHELL%
IF "%~1"=="" GOTO usage
IF /I "%~1"=="--version" GOTO version_mode
IF NOT "%~3"=="" GOTO editor_call
REM Direct source call, with an optional diagnostics filename in parameter 2.
SET "CSC_SOURCE=%~f1"
IF NOT "%~2"=="" SET "CSC_LOG=%~f2"
GOTO arguments_ready
:editor_call
SET "CSC_SOURCE=%~f3"
IF "%~6"=="" GOTO usage
SET "CSC_LOG=%~f6"
GOTO arguments_ready
:version_mode
SET "CSC_MODE=version"
:arguments_ready
IF NOT "%~7"=="" GOTO usage
IF "%CSC_LOG%"=="" SET "CSC_LOG=%COMSCALA_TEMP%\COMSCALA_%RANDOM%_%RANDOM%.err"
FOR %%I IN ("%CSC_LOG%") DO SET "CSC_LOG=%%~fI"
IF /I "%CSC_SOURCE%"=="%CSC_LOG%" GOTO collision
IF NOT DEFINED COMSCALA_COPY GOTO copy_checked
FOR %%I IN ("%COMSCALA_COPY%") DO SET "COMSCALA_COPY=%%~fI"
IF /I "%CSC_SOURCE%"=="%COMSCALA_COPY%" GOTO collision
:copy_checked
IF "%COMSCALA_PAUSE%"=="0" GOTO pause_valid
IF "%COMSCALA_PAUSE%"=="1" GOTO pause_valid
SET "CSC_ERROR=pause setting must be 0 or 1"
GOTO setup_error
:pause_valid
REM Create the diagnostics file before validation so TSE receives setup errors.
>"%CSC_LOG%" ECHO COMSCALA version %CSC_VERSION%
IF ERRORLEVEL 1 GOTO log_error
IF "%CSC_MODE%"=="version" GOTO check_tools
IF NOT EXIST "%CSC_SOURCE%" GOTO source_missing
IF "%CSC_SHELL%"=="TCC" GOTO source_tcc
REM CMD directory check uses the attributes, never a trailing backslash test.
FOR %%I IN ("%CSC_SOURCE%") DO SET "CSC_ATTR=%%~aI"
IF /I "%CSC_ATTR:~0,1%"=="d" GOTO source_directory
GOTO source_ready
:source_tcc
REM Execute ISDIR only in TCC. CMD skips this label completely.
IF ISDIR "%CSC_SOURCE%" GOTO source_directory
:source_ready
>>"%CSC_LOG%" ECHO filename=%CSC_SOURCE%
:check_tools
IF NOT EXIST "%COMSCALA_SCALA%" GOTO scala_missing
IF NOT EXIST "%COMSCALA_CMD%" GOTO cmd_missing
IF /I "%COMSCALA_JAVA%"=="AUTO" GOTO run_tool
IF NOT EXIST "%COMSCALA_JAVA%" GOTO java_missing
SET "JAVACMD=%COMSCALA_JAVA%"
FOR %%I IN ("%COMSCALA_JAVA%") DO SET "JAVA_HOME=%%~dpI.."
FOR %%I IN ("%JAVA_HOME%") DO SET "JAVA_HOME=%%~fI"
:run_tool
SET "CSC_RAW=%CSC_LOG%.raw.%RANDOM%"
IF "%CSC_MODE%"=="version" GOTO run_version
ECHO Compiling/running "%CSC_SOURCE%"
REM Wrapper logic remains native in the selected shell. The vendor's Windows
REM Scala launcher is hosted in CMD because it contains CMD-specific syntax.
REM Never invoke tcc.exe from this batch; do not execute the source twice.
"%COMSCALA_CMD%" /d /s /v:off /c ""%COMSCALA_SCALA%" %COMSCALA_OPTIONS% "%CSC_SOURCE%"" >"%CSC_RAW%" 2>&1
SET "CSC_RC=%ERRORLEVEL%"
GOTO format_output
:run_version
"%COMSCALA_CMD%" /d /s /v:off /c ""%COMSCALA_SCALA%" -version" >"%CSC_RAW%" 2>&1
SET "CSC_RC=%ERRORLEVEL%"
GOTO format_output
:format_output
REM The same BAT hosts its internal CMD formatter; no helper is created.
"%COMSCALA_CMD%" /d /s /v:off /c ""%~f0" --format-log "%CSC_RAW%" "%CSC_LOG%""
IF ERRORLEVEL 1 GOTO formatting_failed
DEL /Q "%CSC_RAW%" >NUL 2>&1
GOTO show_log
:formatting_failed
>>"%CSC_LOG%" ECHO ERROR: diagnostic formatting failed; raw output retained.
ECHO Raw diagnostics: "%CSC_RAW%"
IF "%CSC_RC%"=="0" SET "CSC_RC=3"
GOTO show_log
:source_missing
SET "CSC_ERROR=source file not found: "%CSC_SOURCE%""
GOTO setup_error
:source_directory
SET "CSC_ERROR=source is a directory: "%CSC_SOURCE%""
GOTO setup_error
:scala_missing
SET "CSC_ERROR=Scala launcher not found: "%COMSCALA_SCALA%""
GOTO setup_error
:cmd_missing
SET "CSC_ERROR=CMD executable not found: "%COMSCALA_CMD%""
GOTO setup_error
:java_missing
SET "CSC_ERROR=Java executable not found: "%COMSCALA_JAVA%""
GOTO setup_error
:setup_error
IF "%CSC_LOG%"=="" GOTO error_without_log
>>"%CSC_LOG%" ECHO ERROR: %CSC_ERROR%
IF ERRORLEVEL 1 GOTO error_without_log
GOTO show_log
:error_without_log
ECHO ERROR: %CSC_ERROR%
GOTO finish
:collision
ECHO ERROR: source and diagnostics/copy filenames must be different.
GOTO finish
:log_error
ECHO ERROR: cannot write diagnostics file "%CSC_LOG%".
SET "CSC_RC=3"
GOTO finish
:show_log
TYPE "%CSC_LOG%"
IF NOT DEFINED COMSCALA_COPY GOTO finish
IF /I "%CSC_LOG%"=="%COMSCALA_COPY%" GOTO finish
COPY /Y "%CSC_LOG%" "%COMSCALA_COPY%" >NUL
IF NOT ERRORLEVEL 1 GOTO finish
ECHO ERROR: cannot copy diagnostics to "%COMSCALA_COPY%".
IF "%CSC_RC%"=="0" SET "CSC_RC=3"
GOTO finish
:usage
ECHO Usage: COMSCALA.BAT "source.scala" ["diagnostics.err"]
ECHO Or: COMSCALA.BAT "name" "ext" "full-source" "drive" "path" "errfile"
ECHO Or: COMSCALA.BAT --version
:finish
IF NOT "%CSC_LOG%"=="" ECHO Diagnostics: "%CSC_LOG%"
ECHO Exit code: %CSC_RC%
IF "%COMSCALA_PAUSE%"=="1" PAUSE
ENDLOCAL & EXIT /B %CSC_RC%

REM Internal formatter: invoked by CMD in this same BAT, never a helper file.
:format_log
IF "%~2"=="" EXIT /B 3
IF "%~3"=="" EXIT /B 3
IF NOT EXIST "%~2" EXIT /B 3
TYPE "%~2" >>"%~3"
IF ERRORLEVEL 1 EXIT /B 3
SET "CSC_FORMAT_LOG=%~3"
FOR /F "usebackq delims=" %%L IN ("%~2") DO (
    SET "CSC_TEXT=%%L"
    CALL :format_line
    IF ERRORLEVEL 1 EXIT /B 3
)
EXIT /B 0

:format_line
SETLOCAL EnableDelayedExpansion
IF NOT "!CSC_TEXT:~0,2!"=="--" GOTO format_skip
SET "CSC_REST=!CSC_TEXT:*Error: =!"
IF "!CSC_REST!"=="!CSC_TEXT!" GOTO format_skip
SET "CSC_FILE="
SET "CSC_LNUM="
SET "CSC_CNUM="
FOR /F "tokens=1 delims=:" %%T IN ("!CSC_TEXT!") DO SET "CSC_TITLE=%%T"
IF "!CSC_REST:~1,1!"==":" GOTO format_drive
FOR /F "tokens=1-3 delims=:" %%A IN ("!CSC_REST!") DO (
    SET "CSC_FILE=%%A"
    SET "CSC_LNUM=%%B"
    SET "CSC_CNUM=%%C"
)
GOTO format_numbers
:format_drive
FOR /F "tokens=1-4 delims=:" %%A IN ("!CSC_REST!") DO (
    SET "CSC_FILE=%%A:%%B"
    SET "CSC_LNUM=%%C"
    SET "CSC_CNUM=%%D"
)
:format_numbers
IF "!CSC_FILE!"=="" GOTO format_skip
IF "!CSC_LNUM!"=="" GOTO format_skip
IF "!CSC_CNUM!"=="" GOTO format_skip
REM Drop the optional horizontal dash decoration after the column number.
FOR /F "tokens=1" %%N IN ("!CSC_CNUM!") DO SET "CSC_CNUM=%%N"
FOR /F "delims=0123456789" %%N IN ("!CSC_LNUM!") DO GOTO format_skip
FOR /F "delims=0123456789" %%N IN ("!CSC_CNUM!") DO GOTO format_skip
REM Remove leading zeroes before SET /A to avoid octal interpretation.
:format_strip_line
IF "!CSC_LNUM!"=="0" GOTO format_skip
IF NOT "!CSC_LNUM:~0,1!"=="0" GOTO format_strip_col
SET "CSC_LNUM=!CSC_LNUM:~1!"
GOTO format_strip_line
:format_strip_col
IF "!CSC_CNUM!"=="0" GOTO format_increment
IF NOT "!CSC_CNUM:~0,1!"=="0" GOTO format_increment
SET "CSC_CNUM=!CSC_CNUM:~1!"
GOTO format_strip_col
:format_increment
SET /A CSC_CNUM=CSC_CNUM+1 >NUL
IF ERRORLEVEL 1 GOTO format_failed
REM The marker matches only these summaries, so raw errors are not duplicated
REM in TSE's jump list. Preserve raw diagnostics verbatim above the summaries.
>>"!CSC_FORMAT_LOG!" ECHO(TSE: !CSC_FILE!:!CSC_LNUM!:!CSC_CNUM!: !CSC_TITLE!
IF ERRORLEVEL 1 GOTO format_failed
:format_skip
ENDLOCAL
EXIT /B 0
:format_failed
ENDLOCAL
EXIT /B 3
