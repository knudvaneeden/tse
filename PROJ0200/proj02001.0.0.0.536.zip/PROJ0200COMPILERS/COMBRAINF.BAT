@ECHO OFF
REM COMBRAINF version 1.0.0.0.9
REM Run BRAINF program
REM Prepared with OpenAI ChatGPT (Codex), 2026-10-17.
REM
REM PART 1 - USER SETTINGS AND TEST INSTRUCTIONS
REM Direct: COMBRAINF.BAT "source.b" ["brainf.exe" ["output.txt"]]
REM TSE: COMBRAINF.BAT "name" ".b" "full source" "drive" "path" "output"
REM Direct parameters: 1=source, 2=executable override, 3=output.
REM TSE parameters: 1=name, 2=extension, 3=source, 4=drive, 5=path, 6=output.
REM Six-parameter TSE mode takes priority. Quote all paths.
REM Environment overrides: set COMBRAINF_EXE or COMBRAINF_PAUSE before calling.
REM COMBRAINF_PAUSE=yes keeps the console open; no disables the final pause.
REM Output is captured in TSE's output file, or a temporary diagnostic file.
REM Interactive input still comes from the console; output is shown at the end.
REM
REM Install this BAT in F:\BBC\TAAL and the two .b tests in
REM F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE. Run these FOUR console tests:
REM tcc.exe /c F:\BBC\TAAL\COMBRAINF.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\helloworld.b"
REM tcc.exe /c F:\BBC\TAAL\COMBRAINF.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.b"
REM cmd.exe /d /c F:\BBC\TAAL\COMBRAINF.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\helloworld.b"
REM cmd.exe /d /c F:\BBC\TAAL\COMBRAINF.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.b"
REM Use your full tcc.exe path if TCC is not on PATH.
REM Expected: Hello World! and exit 0; three bracket errors and exit 1.
REM helloworld.b places version text after the newline; its four dots add
REM four harmless blank lines. Brainfuck has no ordinary comment syntax.
REM Errors: line 6 column 3; line 8 column 5; line 10 column 7.
REM Check ERRORLEVEL immediately after each run: ECHO %%ERRORLEVEL%%
REM Override test: COMBRAINF.BAT "helloworld.b" "G:\LANGUAGE\COMPUTER\BRAINF\brainf.exe" "brainf-output.txt"
REM TSE test: load the supplied .b rule, compile errorstest.b, jump to all errors.
REM Also test a source path containing spaces and a nonexistent source path.
REM
REM Bracket validation is implemented below in this BAT, without helper programs.
REM It reports ALL unmatched brackets before deciding whether to run brainf.exe.
REM The interpreter itself stops at the first unmatched bracket in its source.
REM Built-in Windows FINDSTR is used only to number source lines.
REM Use the all-lines pattern .* rather than a caret, which escapes in TCC.
REM Use ASCII sources, spaces rather than tabs for predictable editor columns,
REM and source lines shorter than 4000 characters (batch/FINDSTR limitations).
REM The wrapper runs natively in TCC or CMD; no shell trampoline is used.
REM Shell tests and TSE jumps must be verified on Windows; not run on Linux.
SETLOCAL EnableExtensions DisableDelayedExpansion
SET "BRAINF_EXE=G:\LANGUAGE\COMPUTER\BRAINF\brainf.exe"
IF DEFINED COMBRAINF_EXE SET "BRAINF_EXE=%COMBRAINF_EXE%"
IF NOT DEFINED COMBRAINF_PAUSE SET "COMBRAINF_PAUSE=yes"
REM ------------------------------------------------------------------------------
REM PART 2 - GENERAL IMPLEMENTATION (NO USER CHANGES REQUIRED)
SET "SOURCE="
SET "OUTPUT="
SET "SCANFILE="
SET "RUN_RC=1"
ECHO COMBRAINF version 1.0.0.0.9
IF NOT "%~6"=="" GOTO tseParameters
SET "SOURCE=%~1"
IF NOT "%~2"=="" SET "BRAINF_EXE=%~2"
SET "OUTPUT=%~3"
GOTO parametersReady

:tseParameters
SET "SOURCE=%~3"
SET "OUTPUT=%~6"

:parametersReady
IF "%SOURCE%"=="" GOTO usage
FOR %%F IN ("%SOURCE%") DO SET "SOURCE=%%~fF"
IF "%OUTPUT%"=="" SET "OUTPUT=%TEMP%\combrainf-%RANDOM%-%RANDOM%.txt"
FOR %%F IN ("%OUTPUT%") DO SET "OUTPUT=%%~fF"
IF /I "%SOURCE%"=="%OUTPUT%" GOTO outputIsSource
IF /I "%BRAINF_EXE%"=="%OUTPUT%" GOTO outputIsSource
>"%OUTPUT%" ECHO filename=%SOURCE%
IF ERRORLEVEL 1 GOTO outputFailed
IF NOT EXIST "%SOURCE%" GOTO sourceMissing
REM Never use IF EXIST "filename\" to test directories in TCC.
IF DEFINED _TCC GOTO checkTccDirectory
SET "SOURCE_ATTRIBUTES="
FOR %%F IN ("%SOURCE%") DO SET "SOURCE_ATTRIBUTES=%%~aF"
IF /I "%SOURCE_ATTRIBUTES:~0,1%"=="d" GOTO sourceDirectory
GOTO sourceReady

:checkTccDirectory
IF ISDIR "%SOURCE%" GOTO sourceDirectory

:sourceReady
IF NOT EXIST "%SystemRoot%\System32\findstr.exe" GOTO findstrMissing
SET "SCANFILE=%TEMP%\combrainf-scan-%RANDOM%-%RANDOM%.txt"
"%SystemRoot%\System32\findstr.exe" /N /R ".*" "%SOURCE%" > "%SCANFILE%"
IF ERRORLEVEL 2 GOTO scanFailed
IF NOT EXIST "%SCANFILE%" GOTO scanFailed
SET "BF_DEPTH=0"
SET "BF_ERRORS=0"
SET "BF_ROW=0"
FOR /F "usebackq delims=" %%L IN ("%SCANFILE%") DO (
  SET "BF_TEXT=%%L"
  CALL :scanLine
)
CALL :remainingOpens
DEL /Q "%SCANFILE%" >NUL 2>&1
SET "SCANFILE="
IF NOT "%BF_ERRORS%"=="0" GOTO bracketErrors
IF NOT EXIST "%BRAINF_EXE%" GOTO runnerMissing
ECHO Running "%SOURCE%"
FOR %%F IN ("%SOURCE%") DO PUSHD "%%~dpF"
IF ERRORLEVEL 1 GOTO directoryFailed
"%BRAINF_EXE%" "%SOURCE%" >>"%OUTPUT%" 2>&1
SET "RUN_RC=%ERRORLEVEL%"
POPD
GOTO showOutput

:scanLine
SET /A BF_ROW=BF_ROW+1 >NUL
REM Remove only FINDSTR's number and first colon; retain source indentation.
:stripNumber
IF "%BF_TEXT:~0,1%"==":" GOTO numberRemoved
IF NOT DEFINED BF_TEXT EXIT /B 0
SET "BF_TEXT=%BF_TEXT:~1%"
GOTO stripNumber
:numberRemoved
SET "BF_TEXT=%BF_TEXT:~1%"
SET "BF_COL=0"
:scanCharacter
IF NOT DEFINED BF_TEXT EXIT /B 0
SET /A BF_COL=BF_COL+1 >NUL
SET "BF_CHAR=%BF_TEXT:~0,1%"
IF "%BF_CHAR%"=="[" CALL :openBracket
IF "%BF_CHAR%"=="]" CALL :closeBracket
SET "BF_TEXT=%BF_TEXT:~1%"
GOTO scanCharacter

:openBracket
SET /A BF_DEPTH=BF_DEPTH+1 >NUL
SET "BF_OPEN_%BF_DEPTH%=%BF_ROW%:%BF_COL%"
EXIT /B 0

:closeBracket
IF "%BF_DEPTH%"=="0" GOTO unmatchedClose
SET "BF_OPEN_%BF_DEPTH%="
SET /A BF_DEPTH=BF_DEPTH-1 >NUL
EXIT /B 0
:unmatchedClose
>>"%OUTPUT%" ECHO BRAINF:%BF_ROW%:%BF_COL%: Error: unmatched closing bracket
SET /A BF_ERRORS=BF_ERRORS+1 >NUL
EXIT /B 0

:remainingOpens
IF "%BF_DEPTH%"=="0" EXIT /B 0
REM CALL expands only internal variable names and numeric coordinates.
CALL SET "BF_POSITION=%%BF_OPEN_%BF_DEPTH%%%"
>>"%OUTPUT%" ECHO BRAINF:%BF_POSITION%: Error: unmatched opening bracket
SET "BF_OPEN_%BF_DEPTH%="
SET /A BF_ERRORS=BF_ERRORS+1 >NUL
SET /A BF_DEPTH=BF_DEPTH-1 >NUL
GOTO remainingOpens

:bracketErrors
>>"%OUTPUT%" ECHO Bracket errors: %BF_ERRORS%. Interpreter was not started.
GOTO showOutput
:sourceMissing
>>"%OUTPUT%" ECHO ERROR: source file not found: "%SOURCE%"
GOTO showOutput
:sourceDirectory
>>"%OUTPUT%" ECHO ERROR: source path is a directory: "%SOURCE%"
GOTO showOutput
:runnerMissing
>>"%OUTPUT%" ECHO ERROR: BrainF executable not found: "%BRAINF_EXE%"
GOTO showOutput
:findstrMissing
>>"%OUTPUT%" ECHO ERROR: Windows FINDSTR was not found.
GOTO showOutput
:scanFailed
>>"%OUTPUT%" ECHO ERROR: cannot read source or write temporary numbered source.
GOTO showOutput
:directoryFailed
>>"%OUTPUT%" ECHO ERROR: cannot enter source directory.
GOTO showOutput
:outputIsSource
ECHO ERROR: output must not overwrite the source or executable.
GOTO finish
:outputFailed
ECHO ERROR: cannot write output file: "%OUTPUT%"
GOTO finish
:usage
ECHO Usage: COMBRAINF.BAT "source.b" ["brainf.exe" ["output.txt"]]
GOTO finish

:showOutput
TYPE "%OUTPUT%"
ECHO.
ECHO Exit code: %RUN_RC%
ECHO Diagnostics: "%OUTPUT%"
:finish
IF DEFINED SCANFILE DEL /Q "%SCANFILE%" >NUL 2>&1
IF /I "%COMBRAINF_PAUSE%"=="yes" PAUSE
ENDLOCAL & EXIT /B %RUN_RC%
