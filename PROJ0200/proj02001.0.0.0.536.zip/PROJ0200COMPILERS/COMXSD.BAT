@echo off
REM COMXSD.BAT - Version 1.0.0.0.8 - 2026-10-30
REM XSD 1.0 schema checking with Python/lxml; no separate helper file.
REM PART 1 - USER SETTINGS AND USAGE
REM Change PYTHON_EXE below to your installed Python executable.
REM Install dependency with: "g:\language\computer\python\python\python.exe" -m pip install lxml
REM Direct use: COMXSD.BAT "full path\source.xsd"
REM TSE use: COMXSD.BAT "%1" "%2" "%3" "%4" "%5" "%6"
REM Arguments: 1=name, 2=extension, 3=full source, 4=drive, 5=path,
REM 6=diagnostic output file. Direct use needs only argument 1.
REM Run these tests from the folder containing COMXSD.BAT:
REM tcc.exe /c call COMXSD.BAT "helloworldxsd.xsd"
REM tcc.exe /c call COMXSD.BAT "errorstestxsd.xsd"
REM cmd.exe /d /c call COMXSD.BAT "helloworldxsd.xsd"
REM cmd.exe /d /c call COMXSD.BAT "errorstestxsd.xsd"
REM Expected exit codes: hello=0, errors=1. Check with echo %%errorlevel%%.
REM Repeat with full paths containing spaces and the six-argument TSE form:
REM COMXSD.BAT "errorstestxsd" ".xsd" "f:\bbc\taal\proj0200errorsmultiple\errorstestxsd.xsd" "f:" "\bbc\taal\proj0200errorsmultiple\" "c:\temp\xsd.err"
REM Also test a missing source and a directory: expected exit code 2.
REM File checks use Python is_file(), avoiding TCC IF EXIST file\ ambiguity.
REM Exit codes: 0=OK; 1=XSD errors; 2=configuration or file error.
setlocal
set "PYTHON_EXE=g:\language\computer\python\python\python.exe"
REM The console always pauses after each run.
REM PART 2 - FIXED LOGIC
set "COMXSD_SELF=%~f0"
set "COMXSD_SOURCE=%~1"
set "COMXSD_OUTPUT="
if not "%~3"=="" set "COMXSD_SOURCE=%~3"
if not "%~3"=="" set "COMXSD_OUTPUT=%~6"
if "%~1"=="" goto usage
if not exist "%PYTHON_EXE%" goto noengine
"%PYTHON_EXE%" -c "import os; p=os.environ['COMXSD_SELF']; t=open(p,encoding='ascii').read(); exec(compile(t.split('# COMXSD_'+'PYTHON_BEGIN',1)[1],p,'exec'))"
set "COMXSD_RESULT=%errorlevel%"
goto finish
:usage
echo COMXSD.BAT version 1.0.0.0.8
echo Usage: COMXSD.BAT "source.xsd"
set "COMXSD_RESULT=2"
goto finish
:noengine
echo ERROR: Python executable not found: "%PYTHON_EXE%"
set "COMXSD_RESULT=2"
goto finish
:finish
pause
exit /b %COMXSD_RESULT%
# COMXSD_PYTHON_BEGIN
import os, sys, re
from pathlib import Path
from urllib.parse import urlsplit, unquote
VERSION = "1.0.0.0.8"
lines = []
status = 2
source = Path(os.environ["COMXSD_SOURCE"]).absolute()
def native_filename(filename):
    if not filename or filename.startswith("<"):
        return str(source)
    if filename.lower().startswith("file:"):
        uri = urlsplit(filename)
        name = unquote(uri.path)
        if uri.netloc and uri.netloc.lower() != "localhost":
            name = "//" + uri.netloc + name
        elif re.match(r"^/[A-Za-z]:", name):
            name = name[1:]
        return name.replace("/", "\\") if os.name == "nt" else name
    return filename

def diagnostic(filename, row, col, message):
    filename = native_filename(filename)
    message = " ".join(str(message).splitlines())
    lines.append(f'TSE: "{filename}" line {max(1,row)} column {max(1,col)}: ERROR: {message}')
try:
    from lxml import etree
    if not source.is_file():
        raise OSError("Source file not found or is a directory: " + str(source))
    parser = etree.XMLParser(no_network=True, resolve_entities=False)
    entries = []
    try:
        doc = etree.parse(str(source), parser)
        etree.XMLSchema(doc)
        status = 0
    except (etree.XMLSyntaxError, etree.XMLSchemaParseError) as exc:
        entries = list(exc.error_log)
        status = 1
    seen = set()
    for entry in entries:
        if entry.level_name not in ("ERROR", "FATAL"):
            continue
        key = (native_filename(entry.filename), entry.line, entry.column, entry.message)
        if key not in seen:
            seen.add(key)
            diagnostic(*key)
        status = 1
    if status == 0:
        lines.append("COMXSD.BAT version " + VERSION + ": XSD 1.0 schema OK: " + str(source))
    elif not seen:
        diagnostic(str(source), 1, 1, "Schema compilation failed without a location diagnostic")
except ImportError:
    lines.append("COMXSD configuration error: install lxml with the configured Python: python -m pip install lxml")
except Exception as exc:
    lines.append("COMXSD configuration error: " + str(exc))
# Keep console and TSE diagnostics ASCII.
lines = [line.encode("ascii", errors="replace").decode("ascii") for line in lines]
for line in lines:
    print(line, flush=True)
output = os.environ.get("COMXSD_OUTPUT", "")
if output:
    try:
        Path(output).write_text("\n".join(lines) + "\n", encoding="ascii")
    except OSError as exc:
        print("COMXSD cannot write output: " + str(exc))
        status = 2
sys.exit(status)
