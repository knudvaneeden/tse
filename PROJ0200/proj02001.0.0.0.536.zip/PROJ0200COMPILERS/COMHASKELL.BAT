@echo off
REM COMHASKELL.BAT version 1.0.0.13 - updated with OpenAI GPT-6
REM Compile and run a Haskell program with GHC. Intended for TCC and CMD.
REM
REM PART 1 - USER SETTINGS AND USAGE
REM Edit the settings below. Store paths without surrounding quotes.
REM GHC_EXE: compiler executable; missing original installation falls back
REM to ghc.exe on PATH. Parameter 7 overrides this setting.
REM BUILD_ROOT: temporary build parent; it must already exist.
REM PAUSE_AT_END: yes/no. COMHASKELL_NOPAUSE=yes overrides it for tests.
REM OUTPUT_COPY: optional diagnostics copy for editor integration; empty
REM disables it. Its parent directory must already exist.
REM
REM Simple form: COMHASKELL.BAT "C:\My Sources\hello.hs"
REM TSE form: COMHASKELL.BAT "hello" "hs" "C:\My Sources\hello.hs" "C" "My Sources" "C:\TEMP\haskell.err"
REM Parameters: 1=source in simple form, or basename in TSE form;
REM 2=legacy extension, 3=full source path, 4=legacy drive, 5=legacy directory,
REM 6=diagnostics file, 7=optional full path to ghc.exe.
REM Parameters 2, 4 and 5 are accepted for compatibility; source comes from 3.
REM No program arguments are passed. Relative source paths use the caller's
REM directory. The program runs in its source directory.
REM
REM Test both shells from the directory containing this BAT:
REM   From an existing TCC prompt: COMHASKELL.BAT --test
REM   cmd.exe /d /v:off /c COMHASKELL.BAT --test
REM To use a different compiler for the tests, set GHC_EXE below first.
REM Tests cover spaces, simple/TSE forms, compiler errors, missing source
REM and rejection of a directory supplied as a source filename.
REM Error positions use GHC point locations: filename:line:column:.
REM Native batch formatter appends TSE: filename:line:column: message.
REM TSE rule reads those combined lines as Message, Tag 0.
REM Original GHC output remains in the diagnostics file.
REM Test formatter without GHC: COMHASKELL.BAT --testformat
REM CMD formatter test: cmd.exe /d /v:off /c COMHASKELL.BAT --testformat
REM No external helper script or nested TCC invocation is used.
REM Manual compiler override test:
REM   COMHASKELL.BAT "hello" "hs" "C:\My Sources\hello.hs" "C" "My Sources" "C:\TEMP\haskell.err" "C:\ghcup\bin\ghc.exe"
REM Quote path parameters. Use CMD with delayed expansion disabled for ! paths.
REM Diagnostics remain available after temporary build files are removed.
REM Exit status is the compiler/program status, or 1 for wrapper errors.
REM Test mode returns 0 only if every test passes. --test requires GHC; --testformat does not.

setlocal
REM TCC aliases must not replace batch commands such as DO or EXIT.
REM ENDLOCAL restores the caller's expansion settings.
if not "%_TCCVER%"=="" setdos /x-1
set GHC_EXE=g:\language\computer\haskell\haskell platform\2013.2.0.0\bin\ghc.exe
set BUILD_ROOT=%TEMP%
set PAUSE_AT_END=yes
set OUTPUT_COPY=

REM PART 2 - EXECUTION CODE - NO USER CHANGES REQUIRED
echo COMHASKELL.BAT version 1.0.0.13
set CH_RC=1
set CH_BUILD=
set CH_PUSHED=no
if /i "%COMHASKELL_NOPAUSE%"=="yes" set PAUSE_AT_END=no
if not exist "%GHC_EXE%" set GHC_EXE=ghc.exe
if /i "%~1"=="--testformat" goto formattest
if /i "%~1"=="--test" goto selftest
if not "%~7"=="" set GHC_EXE=%~7
set CH_SOURCE=%~1
if not "%~3"=="" set CH_SOURCE=%~3
if "%CH_SOURCE%"=="" goto usage
for %%I in ("%CH_SOURCE%") do set CH_SOURCE=%%~fI
if not exist "%CH_SOURCE%" goto missing
REM TCC: ISDIR avoids the false file-as-directory result of IF EXIST file\.
if "%_TCCVER%"=="" goto sourcecmd
if isdir "%CH_SOURCE%" goto missing
goto sourcechecked
:sourcecmd
for %%I in ("%CH_SOURCE%") do set CH_ATTR=%%~aI
if /i "%CH_ATTR:~0,1%"=="d" goto missing
:sourcechecked
if "%BUILD_ROOT%"=="" goto badroot
if not exist "%BUILD_ROOT%\." goto badroot
"%GHC_EXE%" --numeric-version >nul 2>&1
if errorlevel 1 goto badcompiler
set CH_BUILD=%BUILD_ROOT%\COMHASKELL_%RANDOM%_%RANDOM%
REM Never reuse a pre-existing build directory.
if exist "%CH_BUILD%" goto collision
mkdir "%CH_BUILD%" >nul 2>&1
if errorlevel 1 goto buildfailed
set CH_LOG=%~6
if "%CH_LOG%"=="" set CH_LOG=%CH_BUILD%.err
for %%I in ("%CH_LOG%") do set CH_LOG=%%~fI
>"%CH_LOG%" echo filename=%CH_SOURCE%
if errorlevel 1 goto logfailed
for %%I in ("%CH_SOURCE%") do set CH_DIR=%%~dpI
pushd "%CH_DIR%"
if errorlevel 1 goto dirfailed
set CH_PUSHED=yes
echo Compiling "%CH_SOURCE%"
"%GHC_EXE%" --make "%CH_SOURCE%" -o "%CH_BUILD%\program.exe" -hidir "%CH_BUILD%" -odir "%CH_BUILD%" >>"%CH_LOG%" 2>&1
set CH_RC=%ERRORLEVEL%
set CH_RAW=%CH_LOG%
set CH_SUM=%CH_BUILD%\combined.err
set CH_LINEFILE=%CH_BUILD%\current-line.txt
set CH_PENDING=%CH_BUILD%\pending-location.txt
call :CH_Normalize
if errorlevel 1 goto normalizefailed
type "%CH_SUM%" >>"%CH_LOG%"
if errorlevel 1 goto normalizefailed
type "%CH_LOG%"
if "%OUTPUT_COPY%"=="" goto copied
copy /y "%CH_LOG%" "%OUTPUT_COPY%" >nul
if errorlevel 1 echo WARNING: Could not copy diagnostics to "%OUTPUT_COPY%".
:copied
echo.
echo Compiler diagnostics saved to "%CH_LOG%"
if not "%CH_RC%"=="0" goto compilefailed
if not exist "%CH_BUILD%\program.exe" goto noexe
echo.
echo Running "%CH_BUILD%\program.exe"
"%CH_BUILD%\program.exe"
set CH_RC=%ERRORLEVEL%
echo.
echo Program exit code: %CH_RC%
goto finish
:usage
echo Usage: COMHASKELL.BAT "source.hs"
echo Or: COMHASKELL.BAT "name" "hs" "full source.hs" "drive" "directory" "diagnostics.err" "ghc.exe"
goto finish
:missing
echo ERROR: Haskell source not found: "%CH_SOURCE%"
goto finish
:badroot
echo ERROR: BUILD_ROOT does not name an existing directory: "%BUILD_ROOT%"
goto finish
:badcompiler
echo ERROR: Cannot execute GHC: "%GHC_EXE%"
goto finish
:collision
REM Clear ownership marker so cleanup cannot remove someone else's directory.
set CH_BUILD=
echo ERROR: Temporary build name collision. Please run again.
goto finish
:buildfailed
set CH_BUILD=
echo ERROR: Cannot create temporary build directory.
goto finish
:logfailed
echo ERROR: Cannot write diagnostics: "%CH_LOG%"
goto finish
:dirfailed
echo ERROR: Cannot enter source directory: "%CH_DIR%"
goto finish
:normalizefailed
type "%CH_LOG%"
echo ERROR: Could not format Haskell diagnostics. Original output is in "%CH_LOG%".
if "%CH_RC%"=="0" set CH_RC=1
goto finish
:compilefailed
echo Compilation failed with exit code %CH_RC%.
goto finish
:noexe
set CH_RC=1
echo ERROR: Compiler reported success but produced no executable.
:finish
if "%CH_PUSHED%"=="yes" popd
if not "%CH_BUILD%"=="" rmdir /s /q "%CH_BUILD%"
if /i "%PAUSE_AT_END%"=="yes" pause
set CH_RETURN=%CH_RC%
goto CH_Exit

:selftest
if "%BUILD_ROOT%"=="" goto testsetupfailed
if not exist "%BUILD_ROOT%\." goto testsetupfailed
set COMHASKELL_NOPAUSE=yes
set CH_FORMATONLY=no
goto testcreate
:formattest
set CH_FORMATONLY=yes
if "%BUILD_ROOT%"=="" goto testsetupfailed
if not exist "%BUILD_ROOT%\." goto testsetupfailed
:testcreate
set CH_TEST=%BUILD_ROOT%\COMHASKELL test %RANDOM%_%RANDOM%
if exist "%CH_TEST%" goto testsetupfailed
mkdir "%CH_TEST%" >nul 2>&1
if errorlevel 1 goto testsetupfailed
call :CH_FormatFixture
if errorlevel 1 goto testfailed
if "%CH_FORMATONLY%"=="yes" goto formatpassed
>"%CH_TEST%\hello world.hs" echo main = putStrLn "COMHASKELL_TEST_OK"
>"%CH_TEST%\broken.hs" echo main =
call "%~f0" "%CH_TEST%\hello world.hs" >"%CH_TEST%\simple.txt" 2>&1
if errorlevel 1 goto testfailed
findstr /x /c:"COMHASKELL_TEST_OK" "%CH_TEST%\simple.txt" >nul
if errorlevel 1 goto testfailed
call "%~f0" "hello world" "hs" "%CH_TEST%\hello world.hs" "unused" "unused" "%CH_TEST%\legacy.err" "%GHC_EXE%" >"%CH_TEST%\legacy.txt" 2>&1
if errorlevel 1 goto testfailed
findstr /x /c:"COMHASKELL_TEST_OK" "%CH_TEST%\legacy.txt" >nul
if errorlevel 1 goto testfailed
if not exist "%CH_TEST%\legacy.err" goto testfailed
call "%~f0" "broken" "hs" "%CH_TEST%\broken.hs" "unused" "unused" "%CH_TEST%\broken.err" "%GHC_EXE%" >"%CH_TEST%\broken.txt" 2>&1
if not errorlevel 1 goto testfailed
findstr /b /c:"Running " "%CH_TEST%\broken.txt" >nul
if not errorlevel 1 goto testfailed
call "%~f0" "%CH_TEST%\missing.hs" >"%CH_TEST%\missing.txt" 2>&1
if not errorlevel 1 goto testfailed
call "%~f0" "%CH_TEST%" >"%CH_TEST%\directory.txt" 2>&1
if not errorlevel 1 goto testfailed
echo PASS: formatter, simple form, TSE form, compiler error, missing source, directory rejected.
echo Test evidence retained in "%CH_TEST%"
set CH_RETURN=0
goto CH_Exit
:formatpassed
type "%CH_SUM%"
echo PASS: all three combined diagnostics include their line, column and message.
echo Test evidence retained in "%CH_TEST%"
set CH_RETURN=0
goto CH_Exit
:testfailed
echo FAIL: inspect test logs in "%CH_TEST%".
set CH_RETURN=1
goto CH_Exit
:testsetupfailed
echo ERROR: Cannot create a fresh test directory under BUILD_ROOT.
set CH_RETURN=1
goto CH_Exit

:CH_Exit
if "%_TCCVER%"=="" goto CH_ExitCmd
REM Bypass the EXIT alias after ENDLOCAL restores alias expansion.
endlocal & *exit /b %CH_RETURN%
:CH_ExitCmd
endlocal & exit /b %CH_RETURN%

REM Native formatter entry. Neither branch starts another shell or helper.
REM TCC uses its own file functions, regex and DO loop; CMD uses FOR /F.
REM Only location headers and their first nonblank indented explanation
REM become combined records. A header with no such line is retained alone.
:CH_Normalize
if "%_TCCVER%"=="" goto CH_NormalizeCmd
goto CH_NormalizeTcc

:CH_NormalizeTcc
setlocal
set CH_NIN=%@fileopen["%CH_RAW%",r]
if %CH_NIN% == -1 goto CH_TccOpenFailed
set CH_NOUT=%@fileopen["%CH_SUM%",w]
if %CH_NOUT% == -1 goto CH_TccOutputFailed
set CH_HAVEHEADER=0
set CH_NFAIL=0
REM Disable text reinterpretation while reading/writing compiler output.
REM Keep quote parsing disabled: GHC messages contain unmatched backticks.
REM Regex uses separator-free patterns, so expression quotes are unnecessary.
REM Prefix every regex input with x: an empty line is then a valid string.
REM Reset each result first, so a failed function cannot reuse an old match.
REM SETLOCAL restores the caller's SETDOS switches at ENDLOCAL.
setdos /x-45678
do forever
    setdos /x-7
    set CH_TEXT=%@fileread[%CH_NIN%]
    set CH_NMATCH=-1
    set CH_NMATCH=%@regex[^x\*\*EOF\*\*$,x%CH_TEXT%]
    if %CH_NMATCH% == -1 gosub CH_TccRegexFailed
    if %CH_NFAIL% == 1 leave
    if %CH_NMATCH% == 1 leave
    set CH_NMATCH=-1
    set CH_NMATCH=%@regex[^x.+:\d+:\d+:,x%CH_TEXT%]
    if %CH_NMATCH% == -1 gosub CH_TccRegexFailed
    if %CH_NFAIL% == 1 leave
    if %CH_NMATCH% == 1 gosub CH_TccHeader
    set CH_NMATCH=-1
    set CH_NMATCH=%@regex[^x\s+\S,x%CH_TEXT%]
    if %CH_NMATCH% == -1 gosub CH_TccRegexFailed
    if %CH_NFAIL% == 1 leave
    if %CH_NMATCH% == 1 gosub CH_TccMessage
enddo
setdos /x-7
if %CH_HAVEHEADER% == 1 gosub CH_TccFlush
set CH_IGNORE=%@fileclose[%CH_NIN%]
set CH_IGNORE=%@fileclose[%CH_NOUT%]
if %CH_NFAIL% == 1 goto CH_TccWriteFailed
endlocal
exit /b 0
:CH_TccOutputFailed
set CH_IGNORE=%@fileclose[%CH_NIN%]
:CH_TccOpenFailed
:CH_TccWriteFailed
endlocal
exit /b 1
:CH_TccRegexFailed
set CH_NFAIL=1
return
:CH_TccHeader
setdos /x-7
if %CH_HAVEHEADER% == 1 gosub CH_TccFlush
set CH_HEADER=%CH_TEXT%
set CH_HAVEHEADER=1
return
:CH_TccMessage
setdos /x-7
if %CH_HAVEHEADER% == 0 return
set CH_NWRITE=%@filewrite[%CH_NOUT%,TSE: %CH_HEADER% %CH_TEXT%]
if %CH_NWRITE% == -1 set CH_NFAIL=1
set CH_HAVEHEADER=0
return
:CH_TccFlush
setdos /x-7
set CH_NWRITE=%@filewrite[%CH_NOUT%,TSE: %CH_HEADER%]
if %CH_NWRITE% == -1 set CH_NFAIL=1
set CH_HAVEHEADER=0
return

:CH_NormalizeCmd
setlocal DisableDelayedExpansion
if exist "%CH_PENDING%" del /q "%CH_PENDING%" >nul 2>&1
type nul >"%CH_SUM%"
if errorlevel 1 goto CH_CmdFailed
REM Capture with expansion disabled, then expand text late in a subroutine.
REM Text is never supplied as CALL arguments or evaluated as command code.
for /f "usebackq delims=" %%L in ("%CH_RAW%") do (
    set "CH_TEXT=%%L"
    call :CH_CmdLine
)
if exist "%CH_PENDING%" call :CH_CmdFlush
if exist "%CH_LINEFILE%" del /q "%CH_LINEFILE%" >nul 2>&1
if exist "%CH_PENDING%" del /q "%CH_PENDING%" >nul 2>&1
if exist "%CH_SUM%.failed" goto CH_CmdFailed
endlocal
exit /b 0
:CH_CmdFailed
endlocal
exit /b 1

:CH_CmdLine
setlocal EnableDelayedExpansion
>"!CH_LINEFILE!" echo(!CH_TEXT!
if errorlevel 1 goto CH_CmdLineFailed
findstr /r /c:"^.*:[0-9][0-9]*:[0-9][0-9]*:" "!CH_LINEFILE!" >nul
if not errorlevel 1 goto CH_CmdHeader
if not exist "!CH_PENDING!" goto CH_CmdLineDone
REM The character class below contains both a space and a literal tab.
findstr /r /c:"^[ 	][ 	]*[^ 	]" "!CH_LINEFILE!" >nul
if errorlevel 1 goto CH_CmdLineDone
call :CH_CmdEmit
if errorlevel 1 goto CH_CmdLineFailed
del /q "!CH_PENDING!" >nul 2>&1
goto CH_CmdLineDone
:CH_CmdHeader
if exist "!CH_PENDING!" call :CH_CmdFlush
copy /y "!CH_LINEFILE!" "!CH_PENDING!" >nul
if errorlevel 1 goto CH_CmdLineFailed
:CH_CmdLineDone
endlocal
exit /b 0
:CH_CmdLineFailed
>"!CH_SUM!.failed" echo Formatter write failed.
endlocal
exit /b 1

:CH_CmdEmit
setlocal DisableDelayedExpansion
for /f "usebackq delims=" %%H in ("%CH_PENDING%") do set "CH_HEADER=%%H"
setlocal EnableDelayedExpansion
>>"!CH_SUM!" echo(TSE: !CH_HEADER! !CH_TEXT!
if errorlevel 1 goto CH_CmdEmitFailed
endlocal
endlocal
exit /b 0
:CH_CmdEmitFailed
endlocal
endlocal
exit /b 1

:CH_CmdFlush
setlocal DisableDelayedExpansion
for /f "usebackq delims=" %%H in ("%CH_PENDING%") do set "CH_HEADER=%%H"
setlocal EnableDelayedExpansion
>>"!CH_SUM!" echo(TSE: !CH_HEADER!
if errorlevel 1 >"!CH_SUM!.failed" echo Formatter write failed.
endlocal
endlocal
exit /b 0

:CH_FormatFixture
set CH_RAW=%CH_TEST%\fixture.raw.err
set CH_SUM=%CH_TEST%\fixture.combined.err
set CH_LINEFILE=%CH_TEST%\current-line.txt
set CH_PENDING=%CH_TEST%\pending-location.txt
if not "%_TCCVER%"=="" goto CH_FixtureTcc
>"%CH_RAW%" echo F:\sources with spaces\errorstest.hs:6:9:
>>"%CH_RAW%" echo.    Not in scope: `missingFirst'
>>"%CH_RAW%" echo.
>>"%CH_RAW%" echo F:\sources with spaces\errorstest.hs:9:10:
>>"%CH_RAW%" echo.    Not in scope: `missingSecond'
>>"%CH_RAW%" echo.
>>"%CH_RAW%" echo F:\sources with spaces\errorstest.hs:12:9:
>>"%CH_RAW%" echo.    Not in scope: `missingThird'
goto CH_FixtureReady
:CH_FixtureTcc
call :CH_WriteTccFixture
if errorlevel 1 exit /b 1
:CH_FixtureReady
call :CH_Normalize
if errorlevel 1 exit /b 1
findstr /r /c:"^TSE: .*:6:9: .*missingFirst" "%CH_SUM%" >nul
if errorlevel 1 exit /b 1
findstr /r /c:"^TSE: .*:9:10: .*missingSecond" "%CH_SUM%" >nul
if errorlevel 1 exit /b 1
findstr /r /c:"^TSE: .*:12:9: .*missingThird" "%CH_SUM%" >nul
if errorlevel 1 exit /b 1
exit /b 0

REM Write real old-GHC quoting without letting TCC interpret the backticks.
:CH_WriteTccFixture
setlocal
set CH_FIXHANDLE=%@fileopen["%CH_RAW%",w]
if %CH_FIXHANDLE% == -1 goto CH_FixtureOpenFailed
setdos /x-45678
set CH_IGNORE=%@filewrite[%CH_FIXHANDLE%,F:\sources with spaces\errorstest.hs:6:9:]
set CH_IGNORE=%@filewrite[%CH_FIXHANDLE%,    Not in scope: `missingFirst']
set CH_IGNORE=%@filewrite[%CH_FIXHANDLE%, ]
set CH_IGNORE=%@filewrite[%CH_FIXHANDLE%,F:\sources with spaces\errorstest.hs:9:10:]
set CH_IGNORE=%@filewrite[%CH_FIXHANDLE%,    Not in scope: `missingSecond']
set CH_IGNORE=%@filewrite[%CH_FIXHANDLE%, ]
set CH_IGNORE=%@filewrite[%CH_FIXHANDLE%,F:\sources with spaces\errorstest.hs:12:9:]
set CH_IGNORE=%@filewrite[%CH_FIXHANDLE%,    Not in scope: `missingThird']
set CH_IGNORE=%@fileclose[%CH_FIXHANDLE%]
endlocal
exit /b 0
:CH_FixtureOpenFailed
endlocal
exit /b 1
