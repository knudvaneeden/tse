@ECHO OFF
REM COMR.BAT version 1.0.0.0.10 - 2026-10-06 - OpenAI GPT-6.
REM Uses only Rscript.exe and native R source(); no helper program.
REM Run the source once. source() supplies parse error line/column diagnostics.
REM Runtime errors may have no source location.
REM Do not test file paths with a trailing backslash: TCC may ignore it.
REM Direct: COMR.BAT "C:\work\errorstest.r"
REM TSE: COMR.BAT "name" "r" "C:\work\errorstest.r" "C" "work" "C:\temp\r.err"
REM %1=name, %2=extension, %3=full source, %4=drive, %5=path, %6=errfile.
REM In direct mode %1 is the source. Parameters 2,4,5 are unused.
REM Override tool/settings with COMR_R_EXE, COMR_PAUSE, COMR_COPY environment vars.
REM Test in each shell from this folder:
REM   cmd.exe /D /C COMR.BAT "errorstest.r"
REM   tcc.exe /C COMR.BAT "errorstest.r"
REM Repeat with the six parameters above; check the named errfile and TSE jump.
REM Expected syntax error: line 5, column 16, exit code 1.
REM Fix line 5 as its comment says: Hello from R, exit code 0.
REM Use SET COMR_PAUSE=0 for unattended tests; inspect ERRORLEVEL immediately.
REM ================================================================
REM PART 1 - USER SETTINGS
REM ================================================================
SETLOCAL
SET "R_EXE=g:\language\computer\r\r-2.15.1\bin\i386\rscript.exe"
SET "R_OPTIONS=--vanilla"
SET "PAUSE_AT_END=1"
REM Empty disables the optional second copy of the output.
SET "COPY_OUTPUT="
IF DEFINED COMR_R_EXE SET "R_EXE=%COMR_R_EXE%"
IF DEFINED COMR_PAUSE SET "PAUSE_AT_END=%COMR_PAUSE%"
IF DEFINED COMR_COPY SET "COPY_OUTPUT=%COMR_COPY%"
REM ================================================================
REM PART 2 - STABLE LOGIC
REM ================================================================
SET "COMR_RC=0"
ECHO COMR version 1.0.0.0.10
IF "%~1"=="" GOTO Usage
SET "SOURCE_FILE=%~f1"
IF NOT "%~3"=="" SET "SOURCE_FILE=%~f3"
SET "LOG_FILE=%TEMP%\comr_output.err"
IF NOT "%~6"=="" SET "LOG_FILE=%~f6"
IF /I "%LOG_FILE%"=="%SOURCE_FILE%" GOTO UnsafeOutput
IF "%COPY_OUTPUT%"=="" GOTO StartLog
FOR %%I IN ("%COPY_OUTPUT%") DO SET "COPY_OUTPUT=%%~fI"
IF /I "%COPY_OUTPUT%"=="%SOURCE_FILE%" GOTO UnsafeOutput
:StartLog
> "%LOG_FILE%" ECHO filename=%SOURCE_FILE%
IF ERRORLEVEL 1 GOTO LogFailure
IF NOT EXIST "%SOURCE_FILE%" GOTO MissingSource
IF EXIST "%R_EXE%" GOTO RunR
IF DEFINED COMR_R_EXE GOTO MissingR
SET "R_EXE="
FOR %%I IN (Rscript.exe) DO SET "R_EXE=%%~$PATH:I"
IF "%R_EXE%"=="" GOTO MissingR
:RunR
"%R_EXE%" %R_OPTIONS% -e "source(commandArgs(trailingOnly=TRUE)[1], keep.source=TRUE, print.eval=TRUE)" "%SOURCE_FILE%" >> "%LOG_FILE%" 2>&1
SET "COMR_RC=%ERRORLEVEL%"
GOTO Display
:MissingSource
>> "%LOG_FILE%" ECHO Error: Source file not found: "%SOURCE_FILE%".
SET "COMR_RC=2"
GOTO Display
:MissingR
>> "%LOG_FILE%" ECHO Error: Rscript.exe not found; configure R_EXE; source location unavailable.
SET "COMR_RC=3"
:Display
TYPE "%LOG_FILE%"
IF "%COPY_OUTPUT%"=="" GOTO Finish
IF /I "%COPY_OUTPUT%"=="%LOG_FILE%" GOTO Finish
COPY /Y "%LOG_FILE%" "%COPY_OUTPUT%" >NUL
IF NOT ERRORLEVEL 1 GOTO Finish
ECHO ERROR: Could not copy output to "%COPY_OUTPUT%".
IF "%COMR_RC%"=="0" SET "COMR_RC=5"
GOTO Finish
:Usage
ECHO Usage: COMR.BAT "source.r" or COMR.BAT name r "source.r" drive path "errfile"
SET "COMR_RC=2"
GOTO Finish
:UnsafeOutput
ECHO ERROR: Output must not overwrite the source.
SET "COMR_RC=2"
GOTO Finish
:LogFailure
ECHO ERROR: Cannot write "%LOG_FILE%". Check directory and permissions.
SET "COMR_RC=4"
:Finish
ECHO Exit code: %COMR_RC%
IF "%PAUSE_AT_END%"=="1" PAUSE
ENDLOCAL & EXIT /B %COMR_RC%
