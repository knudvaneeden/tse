@echo off
REM COMFORTRAN.BAT - Compile and run a Fortran program with GNU Fortran.
REM Version 1.0.0.0.11 - Updated 2026-10-05 - OpenAI GPT-6
REM Original: kn, ri, su, 19-03-2023 03:47:19.
REM
REM Change only PART 1 for your computer. PART 2 normally needs no changes.
REM Run through Windows CMD, including when launched from TCC or TSE.
REM Quote all filenames and directories that contain spaces.
REM
REM Test with one source argument:
REM   COMFORTRAN.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.f90"
REM
REM Test with the six TSE arguments:
REM   COMFORTRAN.BAT "ddd" "unused" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.f90" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\comfortran_test.err"
REM
REM Argument meanings in the six-argument form:
REM   %%1 = executable base name, without .exe, e.g. ddd
REM   %%2 = unused placeholder, retained for compatibility
REM   %%3 = source filename, including extension and preferably full path
REM   %%4 = output drive letter, without colon, e.g. F
REM   %%5 = output directory on that drive, with or without leading backslash
REM   %%6 = compiler diagnostic log filename, preferably full path
REM In one-argument mode %%1 is the source; the .exe goes beside the source.
REM In six-argument mode empty %%4/%%5 use the source directory instead.
REM The compiler .exe path is a PART 1 setting, not a positional argument.
REM Compiler output is displayed and logged; program output stays interactive.
REM Error messages include line:column and work with both .for and .f90 rules.
REM Original compiler output is retained in the diagnostic filename plus .raw.
REM Windows PowerShell joins multiline diagnostics; no separate script is needed.
REM Program arguments are not supplied by this batch file.
REM Example ddd.f90 contents:
REM   program hello
REM     print *, 'Hello from Fortran'
REM   end program hello
REM Exit code: compiler failure, program result, or 1 for batch setup failure.

setlocal EnableExtensions DisableDelayedExpansion

REM ======================================================================
REM PART 1 - USER SETTINGS: adapt these paths and options to your computer.
REM ======================================================================
REM Full path to gfortran.exe. Its directory is added to PATH for DLLs.
set "fortranCompiler=G:\cygwin\bin\gfortran.exe"
REM Optional compiler switches, e.g. -Wall -Wextra -O2. Empty is allowed.
set "fortranOptions="
REM Optional extra DLL/runtime directory. Empty uses only the compiler dir.
set "fortranRuntimeDirectory="
REM Empty disables the extra copy of the compiler diagnostic log.
set "fortranOutputCopy=C:\TEMP\dddoutput.txt"
REM Default log directory when argument 6 is absent.
set "fortranLogDirectory=%TEMP%"
REM true pauses at completion; false is useful for unattended execution.
set "fortranPause=true"
REM Windows command interpreter used for consistent behavior under TCC.
set "fortranCmd=%SystemRoot%\System32\cmd.exe"
REM Windows PowerShell used to combine error positions and messages.
set "fortranPowerShell=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"

REM ======================================================================
REM PART 2 - FIXED LOGIC: normally no user changes are needed below here.
REM ======================================================================
if defined COMFORTRAN_CMD_ACTIVE goto cmdReady
set "COMFORTRAN_CMD_ACTIVE=1"
"%fortranCmd%" /d /c call "%~f0" %*
set "fortranResult=%errorlevel%"
endlocal & exit /b %fortranResult%

:cmdReady
set "fortranResult=1"
set "fortranPushed=false"
if "%~1"=="" goto usage
set "fortranSource=%~1"
set "fortranBase="
set "fortranLog="
set "fortranOutputDirectory="
if "%~3"=="" goto argumentsReady
set "fortranSource=%~3"
set "fortranBase=%~1"
set "fortranLog=%~6"
if "%~4"=="" goto argumentsReady
if "%~5"=="" goto argumentsReady
set "fortranDrive=%~4"
set "fortranDirectory=%~5"
if "%fortranDirectory:~0,1%"=="\" goto outputDirectoryReady
set "fortranDirectory=\%fortranDirectory%"
:outputDirectoryReady
set "fortranOutputDirectory=%fortranDrive%:%fortranDirectory%"

:argumentsReady
for %%I in ("%fortranSource%") do set "fortranSource=%%~fI"
for %%I in ("%fortranSource%") do set "fortranSourceDirectory=%%~dpI"
if not defined fortranBase for %%I in ("%fortranSource%") do set "fortranBase=%%~nI"
if not defined fortranOutputDirectory set "fortranOutputDirectory=%fortranSourceDirectory%"
for %%I in ("%fortranOutputDirectory%\%fortranBase%.exe") do set "fortranExecutable=%%~fI"
if not defined fortranLog set "fortranLog=%fortranLogDirectory%\COMFORTRAN_%RANDOM%_%RANDOM%.txt"
for %%I in ("%fortranLog%") do set "fortranLog=%%~fI"
if /i "%fortranLog%"=="%fortranSource%" goto invalidLog
if /i "%fortranLog%"=="%fortranExecutable%" goto invalidLog
if not exist "%fortranSource%" goto missingSource
if not exist "%fortranCompiler%" goto missingCompiler
if not exist "%fortranPowerShell%" goto missingPowerShell
set "fortranRawLog=%fortranLog%.raw"
if /i "%fortranRawLog%"=="%fortranSource%" goto invalidLog
if /i "%fortranRawLog%"=="%fortranExecutable%" goto invalidLog
if not exist "%fortranOutputDirectory%\." md "%fortranOutputDirectory%"
if not exist "%fortranOutputDirectory%\." goto invalidDirectory
for %%I in ("%fortranLog%") do set "fortranLogParent=%%~dpI"
if not exist "%fortranLogParent%\." md "%fortranLogParent%"
>"%fortranLog%" echo filename=%fortranSource%
if errorlevel 1 goto invalidLog
for %%I in ("%fortranCompiler%") do set "fortranCompilerDirectory=%%~dpI"
set "PATH=%fortranCompilerDirectory%;%PATH%"
if defined fortranRuntimeDirectory set "PATH=%fortranRuntimeDirectory%;%PATH%"
pushd "%fortranSourceDirectory%"
if errorlevel 1 goto invalidDirectory
set "fortranPushed=true"
if exist "%fortranExecutable%" del /q "%fortranExecutable%"
if exist "%fortranExecutable%" goto deleteFailed

echo Compiling "%fortranSource%"
"%fortranCompiler%" %fortranOptions% "%fortranSource%" -o "%fortranExecutable%" >>"%fortranLog%" 2>&1
set "fortranResult=%errorlevel%"
copy /y "%fortranLog%" "%fortranRawLog%" >nul
if errorlevel 1 goto normalizationFailed
REM Keep the compiler exit code while normalizing all diagnostics.
"%fortranPowerShell%" -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop'; $enc=[Text.Encoding]::Default; $out=New-Object 'System.Collections.Generic.List[string]'; $out.Add('filename='+$env:fortranSource); $pos=$null; foreach($s in [IO.File]::ReadAllLines($env:fortranRawLog,$enc)) { if($s -match '^(.*):([0-9]+):([0-9]+):\s*(.*)$') { $pos=$Matches[1]+':'+$Matches[2]+':'+$Matches[3]+': '; $tail=$Matches[4]; if($tail -match '^(Fatal Error|Error):\s*(.*)$') { $out.Add($pos+'Error: '+$Matches[2]); } elseif($tail) { $out.Add($s); } } elseif($s -match '^\s*(Fatal Error|Error):\s*(.*)$') { if($pos) { $out.Add($pos+'Error: '+$Matches[2]); } else { $out.Add($env:fortranSource+':1:1: Error: [compiler supplied no position] '+$Matches[2]); } } elseif($s -ne ('filename='+$env:fortranSource)) { $out.Add($s); } }; [IO.File]::WriteAllLines($env:fortranLog,$out,$enc)"
if errorlevel 1 goto normalizationFailed
type "%fortranLog%"
if not defined fortranOutputCopy goto logCopied
for %%I in ("%fortranOutputCopy%") do set "fortranCopy=%%~fI"
if /i "%fortranCopy%"=="%fortranSource%" goto unsafeCopy
if /i "%fortranCopy%"=="%fortranExecutable%" goto unsafeCopy
if /i "%fortranCopy%"=="%fortranLog%" goto logCopied
if /i "%fortranCopy%"=="%fortranRawLog%" goto unsafeCopy
for %%I in ("%fortranCopy%") do if not exist "%%~dpI." md "%%~dpI"
copy /y "%fortranLog%" "%fortranCopy%" >nul
if errorlevel 1 echo Warning: Could not copy diagnostics to "%fortranCopy%".
goto logCopied
:unsafeCopy
echo Warning: Diagnostic copy skipped because it would overwrite source or executable.
:logCopied
echo.
echo Compiler diagnostics saved to "%fortranLog%"
echo Original compiler output saved to "%fortranRawLog%"
if not "%fortranResult%"=="0" goto compileFailed
if not exist "%fortranExecutable%" goto missingExecutable
echo.
echo Running "%fortranExecutable%"
"%fortranExecutable%"
set "fortranResult=%errorlevel%"
echo.
echo Program exit code: %fortranResult%
goto finish

:usage
echo Usage: COMFORTRAN.BAT "source.f90"
echo Or: COMFORTRAN.BAT "base" "unused" "source.f90" "drive" "directory" "logfile"
goto finish
:missingSource
echo ERROR: Source file not found: "%fortranSource%"
goto finish
:missingCompiler
echo ERROR: Compiler not found: "%fortranCompiler%"
echo Change fortranCompiler in PART 1.
goto finish
:missingPowerShell
echo ERROR: Windows PowerShell not found: "%fortranPowerShell%"
echo Change fortranPowerShell in PART 1.
goto finish
:normalizationFailed
echo ERROR: Could not combine compiler positions and messages.
echo Original diagnostics: "%fortranLog%" or "%fortranRawLog%"
set "fortranResult=1"
goto finish
:invalidDirectory
echo ERROR: Could not create or enter the required directory.
goto finish
:invalidLog
echo ERROR: Diagnostic log cannot be written or would overwrite source/executable.
goto finish
:deleteFailed
echo ERROR: Cannot remove old executable: "%fortranExecutable%"
goto finish
:compileFailed
echo Compilation failed with exit code %fortranResult%.
goto finish
:missingExecutable
set "fortranResult=1"
echo ERROR: Compiler returned success but the executable was not created.
:finish
if /i "%fortranPushed%"=="true" popd
if /i "%fortranPause%"=="true" pause
endlocal & exit /b %fortranResult%
