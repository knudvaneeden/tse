@ECHO OFF
REM COMRUBY.BAT version 1.0.0.7 - OpenAI GPT-6 / Codex
REM PART 1 contains local settings; PART 2 contains stable execution logic.
REM No PowerShell, generated Ruby helper, or nested TCC process is used.
REM Direct call: COMRUBY.BAT "C:\work\hello.rb"
REM TSE call: COMRUBY.BAT "name" "rb" "C:\work\hello.rb" "C" "work" "C:\temp\ruby.err"
REM %1=name, %2=extension, %3=source, %4=drive, %5=path, %6=error file.
REM With only one parameter, %1 is the source filename.
REM Tool paths/options are configured below, not passed in these six slots.
REM Native TCC test: CALL COMRUBY.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.rb"
REM CMD test: cmd.exe /d /c COMRUBY.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.rb"
REM TSE test: use the accompanying .rb rule, then select each reported error.
REM Ruby -c checks syntax first; a valid script is then executed once.
REM Ruby 2.0 reports filename and line, but no numeric diagnostic column.

REM =====================================================================
REM PART 1 - USER CONFIGURATION
REM =====================================================================
SETLOCAL
SET "CRB_RUBY=g:\language\computer\ruby\ruby200\bin\ruby.exe"
SET "CRB_OPTIONS="
SET "CRB_PAUSE=1"
REM For direct calls only; TSE's %6 always overrides this filename.
SET "CRB_DEFAULT_LOG=%TEMP%\comruby.err"

REM =====================================================================
REM PART 2 - STABLE EXECUTION LOGIC
REM =====================================================================
SET "CRB_SOURCE=%~1"
IF NOT "%~3"=="" SET "CRB_SOURCE=%~3"
SET "CRB_LOG=%~6"
IF "%CRB_LOG%"=="" SET "CRB_LOG=%CRB_DEFAULT_LOG%"
SET "CRB_EXIT=2"
ECHO COMRUBY.BAT version 1.0.0.7
IF "%CRB_SOURCE%"=="" GOTO CRB_Usage
FOR %%F IN ("%CRB_SOURCE%") DO SET "CRB_SOURCE=%%~fF"
FOR %%F IN ("%CRB_LOG%") DO SET "CRB_LOG=%%~fF"
FOR %%F IN ("%CRB_RUBY%") DO SET "CRB_TOOL_FULL=%%~fF"
IF /I "%CRB_SOURCE%"=="%CRB_LOG%" GOTO CRB_UnsafeLog
IF /I "%CRB_TOOL_FULL%"=="%CRB_LOG%" GOTO CRB_UnsafeLog
>"%CRB_LOG%" ECHO COMRUBY.BAT version 1.0.0.7
IF ERRORLEVEL 1 GOTO CRB_LogError
>>"%CRB_LOG%" ECHO filename=%CRB_SOURCE%
REM Detect shell before using shell-specific directory predicates.
IF "%_TCC%"=="" GOTO CRB_CheckCMD
REM TCC's ISDIR avoids the incorrect IF EXIST "filename\" test.
IF ISDIR "%CRB_SOURCE%" GOTO CRB_MissingSource
IF NOT EXIST "%CRB_SOURCE%" GOTO CRB_MissingSource
GOTO CRB_CheckTool
:CRB_CheckCMD
IF NOT EXIST "%CRB_SOURCE%" GOTO CRB_MissingSource
FOR %%F IN ("%CRB_SOURCE%") DO SET "CRB_ATTR=%%~aF"
IF /I "%CRB_ATTR:~0,1%"=="d" GOTO CRB_MissingSource
:CRB_CheckTool
IF NOT EXIST "%CRB_RUBY%" GOTO CRB_MissingRuby
"%CRB_RUBY%" %CRB_OPTIONS% -c "%CRB_SOURCE%" >>"%CRB_LOG%" 2>&1
SET "CRB_EXIT=%ERRORLEVEL%"
IF NOT "%CRB_EXIT%"=="0" GOTO CRB_ShowLog
"%CRB_RUBY%" %CRB_OPTIONS% "%CRB_SOURCE%" >>"%CRB_LOG%" 2>&1
SET "CRB_EXIT=%ERRORLEVEL%"
GOTO CRB_ShowLog
:CRB_MissingSource
>>"%CRB_LOG%" ECHO ERROR: Ruby source file not found or is a directory: "%CRB_SOURCE%"
GOTO CRB_ShowLog
:CRB_MissingRuby
>>"%CRB_LOG%" ECHO ERROR: Ruby executable not found: "%CRB_RUBY%"
GOTO CRB_ShowLog
:CRB_ShowLog
>>"%CRB_LOG%" ECHO Exit code: %CRB_EXIT%
TYPE "%CRB_LOG%"
GOTO CRB_Finish
:CRB_Usage
ECHO Usage: COMRUBY.BAT "source.rb"
ECHO TSE: COMRUBY.BAT "name" "rb" "source.rb" "drive" "path" "errorfile"
GOTO CRB_Finish
:CRB_UnsafeLog
ECHO ERROR: The log must not overwrite the source or Ruby executable.
GOTO CRB_Finish
:CRB_LogError
ECHO ERROR: Cannot write "%CRB_LOG%". Check that its parent directory exists.
SET "CRB_EXIT=3"
:CRB_Finish
IF "%CRB_PAUSE%"=="1" PAUSE
ENDLOCAL & EXIT /B %CRB_EXIT%
