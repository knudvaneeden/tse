@echo off
REM COMFLEX.BAT version 1.0.0.0.8 - OpenAI ChatGPT GPT-6
REM Run FLEX program
REM FLEX generates C; Borland C++ 5.5 compiles it; then the scanner runs.
REM No helper scripts. Requires flex.exe or win_flex.exe, and bcc32.exe.
REM FLEX executable: G:\CYGWIN\bin\flex.exe (user installation).
REM
REM Simple: COMFLEX.BAT "C:\TEMP\helloworld.l"
REM TSE: COMFLEX.BAT "&name&" "&ext&" "&fn&" "&drive&" "&path&" "&output&"
REM Parameters: 1=source/stem, 2=extension, 3=full source (preferred),
REM 4=drive and 5=directory (legacy), 6=TSE diagnostics output,
REM 7=optional FLEX executable, 8=optional bcc32 executable, 9=run/generate.
REM Override example:
REM COMFLEX.BAT "C:\TEMP\helloworld.l" "" "" "" "" "" "G:\TOOLS\win_flex.exe" "G:\LANGUAGE\COMPUTER\CPP\EMBARCADERO\BORLAND\BCC55\bin\bcc32.exe" run
REM Native TCC tests: enter these in an existing TCC console:
REM   COMFLEX.BAT --testformat
REM   COMFLEX.BAT "C:\TEMP\helloworld.l"
REM   COMFLEX.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.l"
REM CMD tests: enter these in an existing CMD console:
REM   COMFLEX.BAT --testformat
REM   COMFLEX.BAT "C:\TEMP\helloworld.l"
REM   COMFLEX.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.l"
REM Or from TCC: cmd.exe /d /v:off /c COMFLEX.BAT --testformat
REM Expected: Hello world, exit 0; errorstest: three undefined-definition
REM errors, nonzero exit. Some FLEX releases repeat individual diagnostics.
REM Also test a nonexistent source and a directory: both must fail.
REM Test TSE jumps using --testformat first, then compile errorstest.l.
REM FLEX normally reports lines but no columns: column 1 is a fallback.
REM Raw FLEX messages are preserved; TSE location lines are appended.
REM C compiler diagnostics are preserved but not parsed by this FLEX rule.
REM Source directory is used for relative include paths and program execution.
REM Generated .comflex.c/.obj/.exe files remain beside the source.
REM Existing outputs with those names are replaced. Input is not modified.
REM Use CMD with delayed expansion off for paths containing exclamation marks.

setlocal
REM ================= PART 1: USER SETTINGS =============================
set "FLEX_EXE=G:\CYGWIN\bin\flex.exe"
REM For win_flex, optionally set FLEX_OPTIONS=--wincompat.
set "FLEX_OPTIONS="
set "CC_EXE=G:\LANGUAGE\COMPUTER\CPP\EMBARCADERO\BORLAND\BCC55\bin\bcc32.exe"
set "CC_INCLUDE=G:\LANGUAGE\COMPUTER\CPP\EMBARCADERO\BORLAND\BCC55\include"
set "CC_LIBRARY=G:\LANGUAGE\COMPUTER\CPP\EMBARCADERO\BORLAND\BCC55\lib"
set "CC_OPTIONS=-w"
set "BUILD_MODE=run"
set "PAUSE_AFTER_RUN=yes"
REM Set BUILD_MODE=generate to skip the C compiler and program execution.
REM ================= PART 2: SHARED IMPLEMENTATION =====================
set "OUTPUT_FILE=%~6"
if "%OUTPUT_FILE%"=="" goto consoleonly
for %%I in ("%OUTPUT_FILE%") do set "OUTPUT_FILE=%%~fI"
REM Protect input from accidental redirection onto itself.
set "INPUT_CHECK=%~1"
if not "%~3"=="" set "INPUT_CHECK=%~3"
for %%I in ("%INPUT_CHECK%") do set "INPUT_CHECK=%%~fI"
if /i "%INPUT_CHECK%"=="%OUTPUT_FILE%" goto samefile
call :main %1 %2 %3 %4 %5 %6 %7 %8 %9 > "%OUTPUT_FILE%" 2>&1
set "FINAL_RESULT=%ERRORLEVEL%"
if not exist "%OUTPUT_FILE%" goto capturefailed
type "%OUTPUT_FILE%"
goto afterrun
:consoleonly
call :main %1 %2 %3 %4 %5 %6 %7 %8 %9
set "FINAL_RESULT=%ERRORLEVEL%"
goto afterrun
:samefile
echo ERROR: diagnostics output must not be the source file.
set "FINAL_RESULT=2"
goto afterrun
:capturefailed
echo ERROR: cannot create diagnostics output: "%OUTPUT_FILE%"
set "FINAL_RESULT=2"
:afterrun
if /i "%PAUSE_AFTER_RUN%"=="yes" pause
endlocal & exit /b %FINAL_RESULT%

:main
echo COMFLEX version 1.0.0.0.8
if "%~1"=="--testformat" goto testformat
if "%~1"=="" goto usage
if not "%~7"=="" set "FLEX_EXE=%~7"
if not "%~8"=="" set "CC_EXE=%~8"
if not "%~9"=="" set "BUILD_MODE=%~9"
if /i "%BUILD_MODE%"=="run" goto modeok
if /i "%BUILD_MODE%"=="generate" goto modeok
echo ERROR: mode must be run or generate.
exit /b 2
:modeok
set "SOURCE=%~1"
if not "%~3"=="" set "SOURCE=%~3"
if exist "%SOURCE%" goto sourcefound
if "%~2"=="" goto missing
set "EXTENSION=%~2"
if "%EXTENSION:~0,1%"=="." goto extready
set "EXTENSION=.%EXTENSION%"
:extready
set "SOURCE=%~1%EXTENSION%"
if not exist "%SOURCE%" goto missing
:sourcefound
REM Never use IF EXIST filename\ under TCC.
if defined _TCC goto tccdir
for %%I in ("%SOURCE%") do set "SOURCE_ATTR=%%~aI"
if /i "%SOURCE_ATTR:~0,1%"=="d" goto directory
goto dirchecked
:tccdir
if isdir "%SOURCE%" goto directory
:dirchecked
for %%I in ("%SOURCE%") do set "SOURCE=%%~fI"
for %%I in ("%SOURCE%") do set "SOURCE_DIR=%%~dpI"
for %%I in ("%SOURCE%") do set "SOURCE_NAME=%%~nxI"
for %%I in ("%SOURCE%") do set "SOURCE_STEM=%%~nI"
if not exist "%FLEX_EXE%" goto noflex
for %%I in ("%FLEX_EXE%") do set "FLEX_BIN=%%~dpI"
set "PATH=%FLEX_BIN%;%PATH%"
set "LC_ALL=C"
set "LANG=C"
set "RAW_LOG=%TEMP%\comflex-%RANDOM%-%RANDOM%.txt"
pushd "%SOURCE_DIR%"
if errorlevel 1 goto pushfailed
echo filename=%SOURCE%
echo Generating scanner for "%SOURCE%"
"%FLEX_EXE%" %FLEX_OPTIONS% -o "%SOURCE_STEM%.comflex.c" "%SOURCE_NAME%" > "%RAW_LOG%" 2>&1
set "RESULT=%ERRORLEVEL%"
if not exist "%RAW_LOG%" goto logfailed
type "%RAW_LOG%"
REM Only lines containing :digits: are source diagnostics. No drive colon
REM is present because FLEX receives the local filename in the source directory.
for /f "tokens=1,2,* delims=:" %%A in ('findstr /r /c:":[0-9][0-9]*:" "%RAW_LOG%"') do echo TSE:%%B:1: %%C [column 1 fallback]
del "%RAW_LOG%" >nul 2>&1
echo FLEX exit code: %RESULT%
if not "%RESULT%"=="0" goto finish
if /i "%BUILD_MODE%"=="generate" goto finish
if not exist "%CC_EXE%" goto nocc
for %%I in ("%CC_EXE%") do set "CC_BIN=%%~dpI"
set "PATH=%CC_BIN%;%PATH%"
"%CC_EXE%" %CC_OPTIONS% -I"%CC_INCLUDE%" -L"%CC_LIBRARY%" -e"%SOURCE_STEM%.comflex.exe" "%SOURCE_STEM%.comflex.c" 2>&1
set "RESULT=%ERRORLEVEL%"
echo C compiler exit code: %RESULT%
if not "%RESULT%"=="0" goto finish
echo Running "%SOURCE_STEM%.comflex.exe"
".\%SOURCE_STEM%.comflex.exe"
set "RESULT=%ERRORLEVEL%"
echo Program exit code: %RESULT%
:finish
popd
exit /b %RESULT%
:logfailed
echo ERROR: could not create temporary diagnostics file.
set "RESULT=2"
goto finish
:nocc
echo ERROR: C compiler not found: "%CC_EXE%"
set "RESULT=2"
goto finish
:noflex
echo ERROR: FLEX executable not found: "%FLEX_EXE%"
echo Edit FLEX_EXE in Part 1 or supply parameter 7.
exit /b 2
:missing
echo ERROR: source file not found: "%SOURCE%"
exit /b 2
:directory
echo ERROR: source is a directory: "%SOURCE%"
exit /b 2
:pushfailed
echo ERROR: cannot enter source directory: "%SOURCE_DIR%"
exit /b 2
:usage
echo Usage: COMFLEX.BAT "full-source.l"
echo See REM instructions above for TSE parameters and shell tests.
exit /b 2
:testformat
echo filename=F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.l
echo TSE:8:1: undefined definition ONE [column 1 fallback]
echo TSE:9:1: undefined definition TWO [column 1 fallback]
echo TSE:10:1: undefined definition THREE [column 1 fallback]
exit /b 0
