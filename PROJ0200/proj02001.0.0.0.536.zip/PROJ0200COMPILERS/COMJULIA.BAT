@echo off
REM COMJULIA.BAT version 1.0.0.0.8 - ChatGPT
REM Run JULIA program
REM Runs once; stdout/stderr go to the TSE diagnostics file, then the console.
REM No separate helper script or diagnostic converter is used.
REM TEST IN NATIVE TCC:
REM   COMJULIA.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.jl"
REM TEST IN CMD (from either shell):
REM   cmd.exe /d /c COMJULIA.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.jl"
REM SIX-PARAMETER TEST (run separately in TCC and CMD):
REM   COMJULIA.BAT "errorstest" ".jl" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.jl" "F:" "\BBC\TAAL\PROJ0200ERRORSMULTIPLE\" "C:\TEMP\julia.err"
REM Parameters: %%1=name, %%2=extension, %%3=source, %%4=drive,
REM             %%5=source directory, %%6=diagnostics output file.
REM A single parameter is the source filename. Quote all paths.
REM The diagnostics directory must already exist.
REM Ordinary unhandled Julia errors stop execution at the first error.
REM Runtime errors generally have a line but no column: column 1 is a fallback.
REM errorstest.jl catches three independent errors to test multiple TSE jumps.
REM Run successful programs by supplying their .jl filename instead.

REM ================= PART 1: USER SETTINGS =================
setlocal
set "CJ_JULIA=G:\language\computer\julia\julia-1.8.4\bin\julia.exe"
REM Use julia.exe above instead of a full path if Julia is on PATH.
set "CJ_PAUSE=1"
REM Set CJ_PAUSE=0 above for unattended use.

REM ================= PART 2: STABLE LOGIC ===================
set "CJ_VERSION=1.0.0.0.8"
set "CJ_RC=1"
set "CJ_SHELL=CMD"
REM TCC internal variables expand but are not necessarily environment variables.
if not "%_TCCVER%"=="" set "CJ_SHELL=TCC"
echo COMJULIA version %CJ_VERSION%
echo Shell: %CJ_SHELL%
set "CJ_SOURCE=%~1"
if not "%~3"=="" set "CJ_SOURCE=%~3"
if "%CJ_SOURCE%"=="" goto usage
if not exist "%CJ_SOURCE%" goto missing
if "%CJ_SHELL%"=="TCC" goto tcc_directory
REM CMD-only directory check. Never perform this check in TCC.
if exist "%CJ_SOURCE%\" goto missing
goto source_ok
:tcc_directory
if isdir "%CJ_SOURCE%" goto missing
:source_ok
for %%I in ("%CJ_SOURCE%") do set "COMJULIA_SOURCE=%%~fI"
set "CJ_ERR=%~6"
if "%CJ_ERR%"=="" set "CJ_ERR=%TEMP%\COMJULIA_%RANDOM%_%RANDOM%.err"
>"%CJ_ERR%" echo COMJULIA version %CJ_VERSION%
if errorlevel 1 goto output_error
>>"%CJ_ERR%" echo filename=%COMJULIA_SOURCE%
echo Running "%COMJULIA_SOURCE%"
REM Julia itself formats caught diagnostics; no helper file is created.
REM Keep the command below on one line. Source is passed through the environment.
"%CJ_JULIA%" --startup-file=no --color=no -e "src=ENV[\"COMJULIA_SOURCE\"]; try; include(src); catch err; bt=catch_backtrace(); e=err; file=src; line=1; while e isa LoadError; file=e.file; line=e.line; e=e.error; end; for f in stacktrace(bt); if string(f.file)==file && f.line>0; line=f.line; break; end; end; msg=replace(sprint(showerror,e),Char(13)=>' ',Char(10)=>' '); println(stderr,\"TSE: \",file,\":\",line,\":1: \",msg); exit(1); end" >>"%CJ_ERR%" 2>&1
set "CJ_RC=%ERRORLEVEL%"
type "%CJ_ERR%"
echo Diagnostics saved to "%CJ_ERR%"
echo Julia exit code: %CJ_RC%
goto finish
:usage
echo Usage: COMJULIA.BAT "source.jl"
echo Or: COMJULIA.BAT "name" ".jl" "source.jl" "drive" "path" "output.err"
goto finish
:missing
echo ERROR: source file not found or is a directory: "%CJ_SOURCE%"
goto finish
:output_error
echo ERROR: cannot write diagnostics file: "%CJ_ERR%"
goto finish
:finish
if "%CJ_PAUSE%"=="1" pause
endlocal & exit /b %CJ_RC%
