@echo off
setlocal DisableDelayedExpansion
REM COMLISP.BAT version 1.0.0.0.7 - OpenAI GPT-6
REM Run LISP program - GNU CLISP, native JPSoft TCC and Microsoft CMD.
REM
REM PART 1 - USER SETTINGS
if not defined COMLISP_EXE set "COMLISP_EXE=G:\CYGWIN\bin\clisp.exe"
if not defined COMLISP_OPTIONS set "COMLISP_OPTIONS=-q -q -norc -L english -on-error exit"
if not defined COMLISP_PAUSE set "COMLISP_PAUSE=YES"
REM Simple: COMLISP.BAT "F:\BBC\TAAL\PROJ0200HELLOWORLD\helloworld.lisp"
REM TSE parameters: %1 name, %2 extension, %3 full source filename,
REM %4 drive and %5 directory reserved, %6 output/diagnostic filename.
REM Optional %7 CLISP executable; %8 pause YES/NO.
REM Example:
REM COMLISP.BAT helloworld .lisp "C:\My Lisp\helloworld.lisp" C "\My Lisp" "C:\My Lisp\run.log" "G:\CYGWIN\bin\clisp.exe" YES
REM Tests, from the directory containing this BAT and the two Lisp files:
REM "G:\UTILS\JPSoft\TCMD\tcc.exe" /c COMLISP.BAT /test
REM cmd.exe /d /c COMLISP.BAT /test
REM Tests use Windows FINDSTR.EXE and leave logs in a TEMP directory.
REM Environment overrides: COMLISP_EXE, COMLISP_OPTIONS, COMLISP_PAUSE.
REM Evaluation errors continue at the NEXT TOP-LEVEL FORM. Prior side effects
REM remain; this mode is intended for small independent demonstration forms.
REM Reader errors stop the run. Exit 0=success, 1=Lisp/test error, 2=setup error.
REM Locations identify the start of the containing top-level form, not an
REM inner failing expression. Leading whitespace and semicolon comments skipped.
REM A leading block comment may be included in that form's reported location.
REM No helper program or generated Lisp driver; runner is inline via CLISP -x.
REM Logs are overwritten. Never choose the source file as the log filename.
REM ----------------------------------------------------------------------
REM PART 2 - COMMON LOGIC
set "RC=2"
if /i "%~1"=="/test" goto selftest
if /i "%~1"=="/?" goto usage
if "%~1"=="" goto usage
if not "%~7"=="" set "COMLISP_EXE=%~7"
if not "%~8"=="" set "COMLISP_PAUSE=%~8"
echo COMLISP.BAT version 1.0.0.0.7
set "COMLISP_SOURCE=%~f1"
if not "%~3"=="" set "COMLISP_SOURCE=%~f3"
if not exist "%COMLISP_SOURCE%" goto noSource
if not "%_TCC%"=="" goto tccSource
for %%F in ("%COMLISP_SOURCE%") do set "ATTR=%%~aF"
if /i "%ATTR:~0,1%"=="d" goto noSource
goto sourceOK
:tccSource
if isdir "%COMLISP_SOURCE%" goto noSource
:sourceOK
if not exist "%COMLISP_EXE%" goto noCompiler
for %%F in ("%COMLISP_SOURCE%") do set "LOG=%%~dpnF.lisp.log"
if not "%~6"=="" set "LOG=%~f6"
if /i "%LOG%"=="%COMLISP_SOURCE%" goto collision
> "%LOG%" echo COMLISP.BAT version 1.0.0.0.7
if errorlevel 1 goto noLog
for %%F in ("%COMLISP_EXE%") do set "PATH=%%~dpF;%PATH%"
for %%F in ("%COMLISP_SOURCE%") do set "SOURCEDIR=%%~dpF"
pushd "%SOURCEDIR%"
if errorlevel 1 goto noDirectory
REM Keep the inline expression on ONE line; no shell helper is required.
"%COMLISP_EXE%" %COMLISP_OPTIONS% -x "(let* ((src (ext:getenv (symbol-name '|COMLISP_SOURCE|))) (path (substitute #\/ (code-char 92) src)) (bad 0) (line 1) (col 1) (eof (gensym))) (labels ((report-error (e) (incf bad) (format t (symbol-name '|~&TSE: ~A:~D:~D: ~A~%%|) src line col (substitute #\Space #\Newline (princ-to-string e))))) (handler-case (let* ((text (with-open-file (s path) (with-output-to-string (o) (loop for c = (read-char s nil nil) while c do (write-char c o))))) (n (length text)) (i 0) (*load-pathname* (pathname path)) (*load-truename* (truename path))) (loop (when (= i n) (return)) (let ((c (char text i))) (cond ((find c '(#\Space #\Tab #\Return #\Newline)) (incf i)) ((char= c #\;) (setf i (or (position #\Newline text :start i) n))) (t (setf line 1 col 1) (loop for j from 0 below i do (if (char= (char text j) #\Newline) (setf line (1+ line) col 1) (incf col))) (multiple-value-bind (form next) (handler-case (read-from-string text nil eof :start i) (error (e) (report-error e) (return))) (setf i next) (when (eq form eof) (return)) (handler-case (eval form) (error (e) (report-error e))))))))) (error (e) (report-error e)))) (ext:quit (if (zerop bad) 0 1)))" >>"%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
popd
type "%LOG%"
goto finish
:noSource
echo ERROR: source file not found or is a directory: "%COMLISP_SOURCE%"
goto finish
:noCompiler
echo ERROR: CLISP executable not found: "%COMLISP_EXE%"
goto finish
:collision
echo ERROR: source and log filenames must differ.
goto finish
:noLog
echo ERROR: cannot write log: "%LOG%"
goto finish
:noDirectory
echo ERROR: cannot enter source directory: "%SOURCEDIR%"
goto finish
:usage
echo Usage: COMLISP.BAT source.lisp
echo Or: COMLISP.BAT name ext source drive directory log [clisp.exe] [YES/NO]
echo Tests: COMLISP.BAT /test
goto finish
:finish
echo Exit code: %RC%
if /i "%COMLISP_PAUSE%"=="YES" pause
endlocal & exit /b %RC%
:selftest
set "COMLISP_PAUSE=NO"
if not "%~2"=="" set "COMLISP_EXE=%~2"
set "TESTDIR=%TEMP%\COMLISP test %RANDOM%-%RANDOM%"
md "%TESTDIR%"
if errorlevel 1 goto testFail
copy /y "%~dp0helloworld.lisp" "%TESTDIR%\hello world.lisp" >nul
if errorlevel 1 goto testFail
copy /y "%~dp0errorstest.lisp" "%TESTDIR%\errorstest.lisp" >nul
if errorlevel 1 goto testFail
call "%~f0" hello .lisp "%TESTDIR%\hello world.lisp" "" "" "%TESTDIR%\hello.log" "%COMLISP_EXE%" NO
if errorlevel 1 goto testFail
"%SystemRoot%\System32\findstr.exe" /c:"Hello from Common Lisp!" "%TESTDIR%\hello.log" >nul
if errorlevel 1 goto testFail
call "%~f0" errorstest .lisp "%TESTDIR%\errorstest.lisp" "" "" "%TESTDIR%\errors.log" "%COMLISP_EXE%" NO
if not errorlevel 1 goto testFail
if errorlevel 2 goto testFail
"%SystemRoot%\System32\findstr.exe" /b /c:"TSE: " "%TESTDIR%\errors.log" >"%TESTDIR%\jumps.log"
for /f %%N in ('%SystemRoot%\System32\find.exe /c /v "" ^< "%TESTDIR%\jumps.log"') do set "COUNT=%%N"
if not "%COUNT%"=="3" goto testFail
"%SystemRoot%\System32\findstr.exe" /c:":6:1:" "%TESTDIR%\jumps.log" >nul
if errorlevel 1 goto testFail
"%SystemRoot%\System32\findstr.exe" /c:":8:3:" "%TESTDIR%\jumps.log" >nul
if errorlevel 1 goto testFail
"%SystemRoot%\System32\findstr.exe" /c:":10:5:" "%TESTDIR%\jumps.log" >nul
if errorlevel 1 goto testFail
call "%~f0" "%TESTDIR%\missing.lisp"
if not errorlevel 2 goto testFail
if errorlevel 3 goto testFail
call "%~f0" "%TESTDIR%"
if not errorlevel 2 goto testFail
if errorlevel 3 goto testFail
echo PASS: hello, spaces, six parameters, three error locations, missing source, directory.
echo Verify TSE jumps manually at 6:1, 8:3 and 10:5.
echo Logs: "%TESTDIR%"
endlocal & exit /b 0
:testFail
echo FAIL: inspect "%TESTDIR%".
endlocal & exit /b 1
