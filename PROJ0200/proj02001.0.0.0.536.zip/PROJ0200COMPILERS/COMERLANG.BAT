@echo off
rem COMERLANG.BAT version 1.0.0.9
rem Updated 2026-10-07 with OpenAI GPT-6 / Codex.
rem Compile and run an Erlang source file from TSE, TCC, or CMD.
rem
rem USAGE (quote all paths, particularly paths containing spaces):
rem   COMERLANG.BAT "F:\path\ddd.erl"
rem   COMERLANG.BAT "ddd" "unused" "F:\path\ddd.erl" "F" "path" "C:\TEMP\erlang.err"
rem TSE parameters: %%1 module name, %%2 unused, %%3 full source path,
rem %%4 drive and %%5 directory (legacy, unused), %%6 diagnostics file.
rem Optional: %%7 erlc.exe path, %%8 erl.exe path, %%9 entry function.
rem A supplied executable path overrides its setting below.
rem In one-parameter mode the module name is taken from the filename.
rem The filename and -module(...) declaration must match (case matters).
rem Default entry is module:module/0, as in the original batch file.
rem Set ENTRY_FUNCTION=main for module:main/0, or pass main as %%9.
rem The entry function must be exported and accept no arguments.
rem
rem Requires Erlang/OTP 24 or newer for line AND column diagnostics.
rem No helper program is used; TSE parses native compiler diagnostics.
rem Multi-error test in an existing TCC console:
rem   COMERLANG.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.erl"
rem   COMERLANG.BAT "errorstest" "erl" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.erl" "F" "BBC\TAAL\PROJ0200ERRORSMULTIPLE" "C:\TEMP\erlang_test.err"
rem CMD test:
rem   cmd.exe /d /c COMERLANG.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.erl"
rem Expected: three unbound-variable errors, no execution, nonzero exit.
rem In TSE import the .erl rule, compile errorstest.erl, select each error.
rem WINDOWS TESTS: save ddd.erl with these three lines:
rem   -module(ddd).
rem   -export([ddd/0]).
rem   ddd() -> io:format("Hello from Erlang~n").
rem In an already-open TCC console run COMERLANG.BAT directly.
rem In CMD use cmd.exe /d /c as below; do not nest tcc.exe in TCC.
rem Adjust the paths to your installation:
rem   COMERLANG.BAT "F:\path\ddd.erl"
rem   cmd.exe /d /c COMERLANG.BAT "F:\path\ddd.erl"
rem Test the full TSE interface and executable overrides in each shell:
rem   COMERLANG.BAT "ddd" "unused" "F:\path\ddd.erl" "F" "path" "C:\TEMP\tcc_erlang.err" "G:\language\computer\erlang\bin\erlc.exe" "G:\language\computer\erlang\bin\erl.exe" "ddd"
rem   cmd.exe /d /c COMERLANG.BAT "ddd" "unused" "F:\path\ddd.erl" "F" "path" "C:\TEMP\cmd_erlang.err" "G:\language\computer\erlang\bin\erlc.exe" "G:\language\computer\erlang\bin\erl.exe" "ddd"
rem Expected: Hello from Erlang, exit code 0, and filename= in diagnostics.
rem Also test a path with spaces, missing source, invalid executable path,
rem and a syntax error: failures must return nonzero and must not run code.
rem Diagnostics directory must already exist. Diagnostics are overwritten.
rem Set COMERLANG_PAUSE=no before automated tests to suppress the pause.
rem
rem ==================================================================
rem PART 1 - USER SETTINGS (change these for your local system)
rem ==================================================================
setlocal
set "ERLC_EXE=G:\language\computer\erlang\bin\erlc.exe"
set "ERL_EXE=G:\language\computer\erlang\bin\erl.exe"
rem Alternatively use erlc.exe and erl.exe when their directory is in PATH.
set "ENTRY_FUNCTION="
rem Empty ENTRY_FUNCTION means use the module name.
set "PAUSE_AT_END=yes"
rem Optional legacy TSE output copy; empty disables it.
set "OUTPUT_COPY=C:\temp\dddoutput.txt"
rem Temporary directory must exist; TEMP is normally set by Windows.
set "WORK_ROOT=%TEMP%"

rem ==================================================================
rem PART 2 - GENERAL LOGIC (normally no user changes needed)
rem ==================================================================
echo COMERLANG.BAT version 1.0.0.9
set "RESULT=1"
set "DID_PUSHD=no"
set "BUILD_DIR="
if not "%COMERLANG_PAUSE%"=="" set "PAUSE_AT_END=%COMERLANG_PAUSE%"
if "%~1"=="" goto usage
set "SOURCE=%~1"
set "MODULE=%~n1"
if "%~3"=="" goto source_ready
set "SOURCE=%~3"
set "MODULE=%~1"
:source_ready
rem TCC directory checks must use ISDIR, never IF EXIST "filename\".
if "%_4VER%"=="" goto cmd_source_check
if isdir "%SOURCE%" goto missing_source
goto source_exists
:cmd_source_check
for %%F in ("%SOURCE%") do set "SOURCE_ATTR=%%~aF"
if /i "%SOURCE_ATTR:~0,1%"=="d" goto missing_source
:source_exists
if not exist "%SOURCE%" goto missing_source
for %%F in ("%SOURCE%") do set "SOURCE=%%~fF"
for %%F in ("%SOURCE%") do set "SOURCE_DIR=%%~dpF"
if not "%~7"=="" set "ERLC_EXE=%~7"
if not "%~8"=="" set "ERL_EXE=%~8"
if "%ENTRY_FUNCTION%"=="" set "ENTRY_FUNCTION=%MODULE%"
if not "%~9"=="" set "ENTRY_FUNCTION=%~9"
if "%WORK_ROOT%"=="" set "WORK_ROOT=%SOURCE_DIR%"
if not exist "%WORK_ROOT%" goto missing_temp
set "LOG=%~6"
if "%LOG%"=="" set "LOG=%WORK_ROOT%\COMERLANG_%RANDOM%_%RANDOM%.err"
for %%F in ("%LOG%") do set "LOG=%%~fF"
>"%LOG%" echo filename=%SOURCE%
if errorlevel 1 goto log_error
:choose_build
set "BUILD_DIR=%WORK_ROOT%\COMERLANG_%RANDOM%_%RANDOM%"
if exist "%BUILD_DIR%" goto choose_build
mkdir "%BUILD_DIR%" >nul 2>&1
if errorlevel 1 goto build_error
pushd "%SOURCE_DIR%"
if errorlevel 1 goto directory_error
set "DID_PUSHD=yes"
set "ERL_CRASH_DUMP=%BUILD_DIR%\erl_crash.dump"
echo Compiling "%SOURCE%"
"%ERLC_EXE%" +brief +"{error_location,column}" -o "%BUILD_DIR%" "%SOURCE%" >>"%LOG%" 2>&1
set "RESULT=%ERRORLEVEL%"
type "%LOG%"
echo Compiler exit code: %RESULT%
if not "%RESULT%"=="0" goto report
if not exist "%BUILD_DIR%\%MODULE%.beam" goto missing_beam
echo.
echo Running %MODULE%:%ENTRY_FUNCTION%/0
"%ERL_EXE%" -pa "%BUILD_DIR%" -noshell -s "%MODULE%" "%ENTRY_FUNCTION%" -s init stop 2>>"%LOG%"
set "RESULT=%ERRORLEVEL%"
echo.
echo Program exit code: %RESULT%
goto report
:usage
echo Usage: COMERLANG.BAT "source.erl"
echo Or: COMERLANG.BAT "module" "unused" "source.erl" "drive" "directory" "diagnostics"
goto finish
:missing_source
echo ERROR: Erlang source not found: "%SOURCE%"
goto finish
:missing_temp
echo ERROR: Temporary directory not found: "%WORK_ROOT%"
goto finish
:log_error
echo ERROR: Cannot write diagnostics: "%LOG%"
goto finish
:build_error
echo ERROR: Cannot create build directory: "%BUILD_DIR%"
set "BUILD_DIR="
goto report
:directory_error
echo ERROR: Cannot enter source directory: "%SOURCE_DIR%"
goto report
:missing_beam
echo ERROR: Compiler did not produce "%MODULE%.beam". Check module name.
set "RESULT=1"
:report
echo Diagnostics saved to "%LOG%"
if "%OUTPUT_COPY%"=="" goto finish
if /i "%OUTPUT_COPY%"=="%LOG%" goto finish
copy /y "%LOG%" "%OUTPUT_COPY%" >nul 2>&1
if errorlevel 1 echo NOTE: Could not copy diagnostics to "%OUTPUT_COPY%".
:finish
if "%DID_PUSHD%"=="yes" popd
if "%BUILD_DIR%"=="" goto pause_done
rem Remove only files generated by this run; retain unexpected files.
if exist "%BUILD_DIR%\%MODULE%.beam" del /q "%BUILD_DIR%\%MODULE%.beam" >nul 2>&1
if exist "%BUILD_DIR%\erl_crash.dump" del /q "%BUILD_DIR%\erl_crash.dump" >nul 2>&1
rmdir "%BUILD_DIR%" >nul 2>&1
:pause_done
if /i "%PAUSE_AT_END%"=="yes" pause
endlocal & exit /b %RESULT%
