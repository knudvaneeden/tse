@echo off
setlocal
echo COMDELPHI version 1.0.0.0.10
REM COMDELPHI.BAT version 1.0.0.0.10 - Updated with OpenAI GPT-6
REM Compile and run a Delphi console program with TCC or CMD.
REM
REM USAGE - quote every path containing spaces:
REM   COMDELPHI.BAT "C:\projects\hello.dpr"
REM Legacy TSE interface:
REM   COMDELPHI.BAT "hello" "dpr" "C:\projects\hello.dpr" "C" "projects" "C:\TEMP\delphi.err" "C:\Delphi\bin\dcc32.exe" "C:\Delphi\lib"
REM   %%1 = basename; %%2 = extension; %%3 = full source pathname.
REM   %%4 and %%5 = legacy drive/directory fields; accepted but not needed.
REM   %%6 = diagnostics file; %%7 = compiler override; %%8 = library override.
REM Short interface: source, compiler override, library override, log override.
REM   COMDELPHI.BAT "C:\projects\hello.dpr" "C:\Delphi\bin\dcc32.exe" "C:\Delphi\lib" "C:\TEMP\delphi.err"
REM
REM WINDOWS TESTS - run each command and expect Hello from Delphi / exit 0:
REM   COMDELPHI.BAT --test
REM   cmd.exe /d /c COMDELPHI.BAT --test
REM Optional test overrides: --test "C:\Delphi\bin\dcc32.exe" "C:\Delphi\lib"
REM Failure test: supply a nonexistent source; expect exit 2 and no program run.
REM Test paths with spaces using the short interface above.
REM To automate tests: set COMDELPHI_PAUSE=0 before invoking this file.
REM Requires a configured Delphi installation, not just a copied dcc32.exe.
REM Temporary build directories are retained for inspection.
REM Multiple-error test (expect compiler errors, no executable run):
REM   COMDELPHI.BAT "errorstest.pas"
REM   cmd.exe /d /c COMDELPHI.BAT "errorstest.pas"
REM TSE test: open errorstest.pas, compile, then select each error to jump.
REM Native DCC32 diagnostics contain filename(line), without a column.
REM Message Tag 0 displays the complete diagnostic including the line.
REM No diagnostic helper program is used.

REM ======================================================================
REM PART 1 - USER SETTINGS: change these for your local installation.
REM Store paths WITHOUT surrounding quotes inside the variable value.
REM Avoid command metacharacters such as ampersands in configured paths.
REM Environment variables with these names override the defaults below.
REM ======================================================================
if not defined COMDELPHI_COMPILER set COMDELPHI_COMPILER=C:\Program Files (x86)\Embarcadero\RAD Studio\12.0\bin\DCC32.EXE
if not defined COMDELPHI_LIBRARY set COMDELPHI_LIBRARY=C:\Program Files (x86)\Embarcadero\RAD Studio\12.0\lib
REM Additional compiler options. Keep -CC for console applications.
if not defined COMDELPHI_OPTIONS set COMDELPHI_OPTIONS=-CC
if not defined COMDELPHI_BUILDROOT set COMDELPHI_BUILDROOT=%TEMP%
if not defined COMDELPHI_BUILDROOT set COMDELPHI_BUILDROOT=C:\TEMP
if not defined COMDELPHI_PAUSE set COMDELPHI_PAUSE=1
REM Optional compatibility copy of diagnostics; empty disables copying.
set COMDELPHI_OUTPUTCOPY=
REM Example: set COMDELPHI_OUTPUTCOPY=C:\TEMP\dddoutput.txt

REM ======================================================================
REM PART 2 - EXECUTION: no local configuration changes needed below.
REM Uses common batch syntax; no TCC-only commands or delayed expansion.
REM ======================================================================
set result=2
set source=
set log=
set pushed=0
if "%~1"=="" goto usage
if /i "%~1"=="--help" goto usage
if /i "%~1"=="--test" goto testargs
if not "%~3"=="" if not "%~5"=="" goto legacy
set source=%~1
if not "%~2"=="" set COMDELPHI_COMPILER=%~2
if not "%~3"=="" set COMDELPHI_LIBRARY=%~3
if not "%~4"=="" set log=%~4
goto prepare
:legacy
set source=%~3
set log=%~6
if not "%~7"=="" set COMDELPHI_COMPILER=%~7
if not "%~8"=="" set COMDELPHI_LIBRARY=%~8
goto prepare
:testargs
set COMDELPHI_PAUSE=0
if not "%~2"=="" set COMDELPHI_COMPILER=%~2
if not "%~3"=="" set COMDELPHI_LIBRARY=%~3
:prepare
if not exist "%COMDELPHI_COMPILER%" goto compilererror
if not exist "%COMDELPHI_LIBRARY%\." goto libraryerror
if not exist "%COMDELPHI_BUILDROOT%\." mkdir "%COMDELPHI_BUILDROOT%"
if not exist "%COMDELPHI_BUILDROOT%\." goto builderror
:choosebuild
set build=%COMDELPHI_BUILDROOT%\COMDELPHI_%RANDOM%_%RANDOM%
if exist "%build%" goto choosebuild
mkdir "%build%"
if errorlevel 1 goto builderror
if /i "%~1"=="--test" goto makesample
goto sourcecheck
:makesample
set source=%build%\hello.dpr
>"%source%" echo program hello;
>>"%source%" echo begin
>>"%source%" echo   WriteLn('Hello from Delphi');
>>"%source%" echo end.
:sourcecheck
if not exist "%source%" goto sourceerror
REM Do not append a directory suffix to a source filename: TCC differs here.
for %%F in ("%source%") do set source=%%~fF
for %%F in ("%source%") do set sourcedir=%%~dpF
for %%F in ("%source%") do set programname=%%~nF
if not defined log set log=%build%\compiler.err
for %%F in ("%log%") do set log=%%~fF
REM The supplied log parent directory must already exist.
>"%log%" echo filename=%source%
if errorlevel 1 goto logerror
pushd "%sourcedir%"
if errorlevel 1 goto directoryerror
set pushed=1
echo Compiling "%source%"
REM -E isolates the executable; -N isolates generated DCU files.
"%COMDELPHI_COMPILER%" %COMDELPHI_OPTIONS% -I"%COMDELPHI_LIBRARY%" -R"%COMDELPHI_LIBRARY%" -U"%COMDELPHI_LIBRARY%" -E"%build%" -N"%build%" "%source%" >>"%log%" 2>&1
set result=%errorlevel%
echo Compiler exit code: %result%
type "%log%"
echo Diagnostics saved to "%log%"
if not defined COMDELPHI_OUTPUTCOPY goto aftercopy
copy /y "%log%" "%COMDELPHI_OUTPUTCOPY%" >nul
if errorlevel 1 echo WARNING: Could not copy diagnostics.
:aftercopy
if not "%result%"=="0" goto compileerror
if not exist "%build%\%programname%.exe" goto executableerror
echo.
echo Running "%build%\%programname%.exe"
"%build%\%programname%.exe"
set result=%errorlevel%
echo.
echo Program exit code: %result%
goto finish
:usage
echo Usage: COMDELPHI.BAT "source.dpr" ["dcc32.exe" ["library" ["log"]]]
echo Or: COMDELPHI.BAT basename extension fullsource drive directory log [compiler] [library]
echo Test: COMDELPHI.BAT --test ["dcc32.exe" ["library"]]
goto finish
:compilererror
echo ERROR: Compiler not found: "%COMDELPHI_COMPILER%"
goto finish
:libraryerror
echo ERROR: Library directory not found: "%COMDELPHI_LIBRARY%"
goto finish
:builderror
echo ERROR: Cannot create temporary build directory.
goto finish
:sourceerror
echo ERROR: Delphi source file not found: "%source%"
goto finish
:logerror
echo ERROR: Cannot write diagnostics file: "%log%"
goto finish
:directoryerror
echo ERROR: Cannot enter source directory: "%sourcedir%"
goto finish
:compileerror
echo ERROR: Compilation failed with exit code %result%.
goto finish
:executableerror
set result=2
echo ERROR: Compiler did not create "%build%\%programname%.exe".
:finish
if "%pushed%"=="1" popd
if "%COMDELPHI_PAUSE%"=="1" pause
endlocal & exit /b %result%
