@ECHO OFF
REM COMNODEJS.BAT - version 1.0.0.0.9 - 2026-11-02
REM Run NODEJS program
REM Put comnodejs.ps1 beside this BAT. Keep your original compile.s unchanged.
REM Node runs once. PowerShell formats filename(line,column): error for TSE.
REM Full native output is kept in output.err.run.txt for troubleshooting.
REM Install the updated compiler rule before testing.
REM
REM PARAMETERS supplied by TSE:
REM   %1=name, %2=extension, %3=full source filename,
REM   %4=drive, %5=source directory, %6=output/error filename.
REM Optional: %7=full node.exe path; %8=pause yes/no.
REM Quote every filename. Output must differ from the source file.
REM
REM TESTS: run from the directory containing this BAT, in EACH shell.
REM Start native TCC: tcc.exe
REM Start native cmd: cmd.exe /D
REM Then run these same two commands in each shell:
REM COMNODEJS.BAT "helloworldnodejs" "js" "f:\bbc\taal\proj0200\helloworldnodejs.js" "f" "\bbc\taal\proj0200" "hello_nodejs.err" "g:\language\computer\javascript\nodejs\node.exe" "yes"
REM COMNODEJS.BAT "errorstestnodejs" "js" "f:\bbc\taal\proj0200errorsmultiple\errorstestnodejs.js" "f" "\bbc\taal\proj0200errorsmultiple" "errors_nodejs.err" "g:\language\computer\javascript\nodejs\node.exe" "yes"
REM Expected: hello prints once and returns 0; error returns nonzero.
REM Also test a source path containing spaces and a missing source file.
REM TSE: merge the supplied rule; compile hello, then the error test.
REM Expected first jump: line 9, column 15. Fix it and rerun for the next.
REM Node stops at the first syntax error; stack frames are not extra errors.
REM
REM ======================================================================
REM PART 1 - USER SETTINGS: edit only this section for your installation.
REM ======================================================================
SETLOCAL
SET "NODEJS_EXE=g:\language\computer\javascript\nodejs\node.exe"
SET "NODEJS_PAUSE=yes"
SET "NODEJS_POWERSHELL=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
SET "NODEJS_HELPER=%~dp0comnodejs.ps1"
REM ======================================================================
REM PART 2 - FIXED BODY: no installation-specific changes required below.
REM ======================================================================
IF NOT "%~7"=="" SET "NODEJS_EXE=%~7"
IF NOT "%~8"=="" SET "NODEJS_PAUSE=%~8"
SET "NODEJS_SOURCE=%~f3"
SET "NODEJS_OUTPUT=%~f6"
SET "NODEJS_RC=2"
ECHO COMNODEJS.BAT version 1.0.0.0.9
IF "%~3"=="" GOTO usage
IF "%~6"=="" GOTO usage
IF /I "%NODEJS_SOURCE%"=="%NODEJS_OUTPUT%" GOTO samefile
REM TCC must use ISDIR; never test an existing file with a trailing slash.
IF DEFINED _TCCVER GOTO tcc_check
IF EXIST "%NODEJS_SOURCE%\NUL" GOTO badsource
GOTO file_check
:tcc_check
IF ISDIR "%NODEJS_SOURCE%" GOTO badsource
:file_check
IF NOT EXIST "%NODEJS_SOURCE%" GOTO badsource
IF NOT EXIST "%NODEJS_EXE%" GOTO badnode
IF NOT EXIST "%NODEJS_POWERSHELL%" GOTO badhelper
IF NOT EXIST "%NODEJS_HELPER%" GOTO badhelper
IF /I "%NODEJS_SOURCE%"=="%NODEJS_OUTPUT%.run.txt" GOTO samefile
REM Verify the output can be written before running the program.
TYPE NUL > "%NODEJS_OUTPUT%"
IF ERRORLEVEL 1 GOTO badoutput
TYPE NUL > "%NODEJS_OUTPUT%.run.txt"
IF ERRORLEVEL 1 GOTO badoutput
"%NODEJS_EXE%" "%NODEJS_SOURCE%" > "%NODEJS_OUTPUT%.run.txt" 2>&1
SET "NODEJS_RC=%ERRORLEVEL%"
"%NODEJS_POWERSHELL%" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%NODEJS_HELPER%" -InputFile "%NODEJS_OUTPUT%.run.txt" -OutputFile "%NODEJS_OUTPUT%" -SourceFile "%NODEJS_SOURCE%" -NodeExitCode %NODEJS_RC%
IF ERRORLEVEL 1 GOTO formatfailed
TYPE "%NODEJS_OUTPUT%"
ECHO Node.js exit code: %NODEJS_RC%
GOTO finish
:formatfailed
SET "NODEJS_RC=2"
COPY /Y "%NODEJS_OUTPUT%.run.txt" "%NODEJS_OUTPUT%" > NUL
TYPE "%NODEJS_OUTPUT%"
ECHO ERROR: PowerShell formatting failed. Raw Node output shown above.
GOTO finish
:badhelper
ECHO ERROR: check NODEJS_POWERSHELL and NODEJS_HELPER in the user settings.
> "%NODEJS_OUTPUT%" ECHO ERROR: PowerShell or comnodejs.ps1 not found.
GOTO finish
:badsource
ECHO ERROR: source file not found or is a directory: "%NODEJS_SOURCE%"
> "%NODEJS_OUTPUT%" ECHO ERROR: source file not found or is a directory: "%NODEJS_SOURCE%"
GOTO finish
:badnode
ECHO ERROR: node.exe not found: "%NODEJS_EXE%"
> "%NODEJS_OUTPUT%" ECHO ERROR: node.exe not found: "%NODEJS_EXE%"
GOTO finish
:badoutput
ECHO ERROR: cannot write output file: "%NODEJS_OUTPUT%"
GOTO finish
:samefile
ECHO ERROR: source and output must be different files.
GOTO finish
:usage
ECHO Usage: COMNODEJS.BAT name ext "source.js" drive "path" "output.err" ["node.exe"] [yes/no]
:finish
IF /I "%NODEJS_PAUSE%"=="yes" PAUSE
ENDLOCAL & EXIT /B %NODEJS_RC%
