@echo off
REM Use Windows CMD for consistent IF, FOR, START and EXIT /B behavior.
if "%COMMARKDOWN_CMD%"=="1" goto cmdProcessing
set "COMMARKDOWN_CMD=1"
"%SystemRoot%\System32\cmd.exe" /d /s /c ""%~f0" %*"
set "COMMARKDOWN_RETURN=%ERRORLEVEL%"
set "COMMARKDOWN_CMD="
exit /b %COMMARKDOWN_RETURN%
:cmdProcessing
set "COMMARKDOWN_CMD="
setlocal EnableExtensions DisableDelayedExpansion
REM COMMARKDOWN.BAT - version 1.0.0.8
REM Updated 2026-10-11 01:57 +0200. LLM: GPT-6 / Codex.
REM Session: Run MarkDown program
REM Creates a Markdeep HTML preview and opens it in a browser.
REM Requires your existing markdeep.txt footer; no compiler is required.
REM Any script URLs in that footer determine whether Internet access is needed.
REM
REM TESTS - automatically delegates processing to Windows CMD.EXE:
REM   COMMARKDOWN.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.md"
REM   COMMARKDOWN.BAT "ddd" "unused" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.md" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\commarkdown_test.err"
REM Both commands can also be started directly from TCC.
REM From another BAT file, prefix the command with CALL.
REM
REM PARAMETERS, using conventional percent-number BAT arguments:
REM   Direct mode: argument 1 = Markdown filename, argument 2 = optional log.
REM   TSE mode:    argument 1 = basename; argument 2 = unused;
REM                argument 3 = full Markdown filename;
REM                arguments 4 and 5 = legacy drive/directory, unused;
REM                argument 6 = optional diagnostics filename.
REM   Argument 3 selects TSE mode. Paths with spaces must be quoted.
REM   TSE output is derived from argument 3, keeping it beside the source.
REM   Return codes: 0 = success, 1 = failure, 2 = missing arguments.
REM   Browser launch success does not verify Markdeep rendering.
REM   This is a preview runner, not a Markdown syntax checker.
REM   File-level failures use line 1, column 1 for TSE navigation.
REM   No source syntax location is available from this runner.
REM
REM ======================================================================
REM PART 1 - USER SETTINGS: edit only this section for your local system.
REM ======================================================================
REM Footer: default is beside this BAT, independent of the current directory.
set "MARKDEEP_FOOTER=%~dp0markdeep.txt"
REM Browser: empty uses the Windows default browser; otherwise full EXE path.
REM Example: set "BROWSER_EXE=C:\Program Files\Mozilla Firefox\firefox.exe"
set "BROWSER_EXE="
REM Output: empty uses source directory; otherwise an existing directory.
set "OUTPUT_DIRECTORY="
REM Pause after opening the browser or reporting a failure: yes/no.
set "PAUSE_AT_END=yes"
REM Delete generated HTML after the pause: yes/no. Close its browser tab first.
REM Default yes removes the preview after viewing. Existing output is preserved.
REM If the usual preview exists, a fresh filename is used beside it.
set "DELETE_AFTER_PAUSE=yes"
REM ======================================================================
REM PART 2 - PROCESSING: no local system changes should be needed below.
REM ======================================================================
set "RESULT=1"
set "OUTPUT_CREATED=no"
set "SOURCE=%~1"
set "LOGFILE=%~2"
if "%~3"=="" goto argumentsReady
set "SOURCE=%~3"
set "LOGFILE=%~6"
:argumentsReady
if not defined SOURCE goto usage
for %%I in ("%SOURCE%") do set "SOURCE=%%~fI"
for %%I in ("%SOURCE%") do set "OUTPUT_FILE=%%~fI.html"
if not defined OUTPUT_DIRECTORY goto outputReady
for %%I in ("%SOURCE%") do set "OUTPUT_FILE=%OUTPUT_DIRECTORY%\%%~nxI.html"
:outputReady
for %%I in ("%OUTPUT_FILE%") do set "OUTPUT_FILE=%%~fI"
if not defined LOGFILE set "LOGFILE=%TEMP%\COMMARKDOWN_%RANDOM%_%RANDOM%.txt"
for %%I in ("%LOGFILE%") do set "LOGFILE=%%~fI"
if /i "%LOGFILE%"=="%SOURCE%" goto unsafeLog
if /i "%LOGFILE%"=="%OUTPUT_FILE%" goto unsafeLog
if /i "%LOGFILE%"=="%MARKDEEP_FOOTER%" goto unsafeLog
for %%I in ("%LOGFILE%") do if not exist "%%~dpI." goto badLog
type nul > "%LOGFILE%"
if errorlevel 1 goto badLog
echo COMMARKDOWN version 1.0.0.8
if not exist "%SOURCE%" goto missingSource
if exist "%SOURCE%\" goto missingSource
if not exist "%MARKDEEP_FOOTER%" goto missingFooter
if exist "%MARKDEEP_FOOTER%\" goto missingFooter
if not defined BROWSER_EXE goto browserReady
if not exist "%BROWSER_EXE%" goto missingBrowser
:browserReady
for %%I in ("%OUTPUT_FILE%") do if not exist "%%~dpI." goto missingDirectory
if not exist "%OUTPUT_FILE%" goto previewNameReady
set "PREVIEW_BASE=%OUTPUT_FILE%"
:choosePreviewName
set "OUTPUT_FILE=%PREVIEW_BASE%.%RANDOM%_%RANDOM%.html"
if exist "%OUTPUT_FILE%" goto choosePreviewName
:previewNameReady
echo Creating "%OUTPUT_FILE%"
copy /b "%SOURCE%" "%OUTPUT_FILE%" > nul 2>&1
if errorlevel 1 goto creationFailed
set "OUTPUT_CREATED=yes"
REM Separate the footer from a source that has no final newline.
>> "%OUTPUT_FILE%" echo(
if errorlevel 1 goto creationFailed
type "%MARKDEEP_FOOTER%" >> "%OUTPUT_FILE%" 2> nul
if errorlevel 1 goto creationFailed
echo Opening "%OUTPUT_FILE%"
if defined BROWSER_EXE goto explicitBrowser
start "" "%OUTPUT_FILE%" > nul 2>&1
goto launchChecked
:explicitBrowser
start "" "%BROWSER_EXE%" "%OUTPUT_FILE%" > nul 2>&1
:launchChecked
if errorlevel 1 goto launchFailed
set "RESULT=0"
goto finish
:usage
echo Usage: COMMARKDOWN.BAT "filename.md" ["diagnostics.txt"]
echo TSE: COMMARKDOWN.BAT "name" "unused" "filename.md" "drive" "directory" "diagnostics.txt"
set "RESULT=2"
goto endPause
:unsafeLog
echo ERROR: Diagnostics filename must differ from source, footer and output.
goto endPause
:badLog
echo ERROR: Cannot write diagnostics to "%LOGFILE%".
echo Choose a writable filename in an existing directory.
goto endPause
:missingSource
set "MESSAGE=Markdown source not found or not a file: %SOURCE%"
goto reportError
:missingFooter
set "MESSAGE=Markdeep footer not found or not a file: %MARKDEEP_FOOTER%"
goto reportError
:missingBrowser
set "MESSAGE=Browser EXE not found: %BROWSER_EXE%"
goto reportError
:missingDirectory
set "MESSAGE=Output directory does not exist: %OUTPUT_FILE%"
goto reportError
:existingOutput
set "MESSAGE=Output already exists; rename or remove it before retrying: %OUTPUT_FILE%"
goto reportError
:creationFailed
set "MESSAGE=Could not create the complete HTML preview: %OUTPUT_FILE%"
goto reportError
:launchFailed
set "MESSAGE=Could not launch the browser for: %OUTPUT_FILE%"
:reportError
echo "%SOURCE%"(1,1): Error: %MESSAGE% [file-level failure; source location unavailable]
>> "%LOGFILE%" echo "%SOURCE%"(1,1): Error: %MESSAGE% [file-level failure; source location unavailable]
:finish
echo Diagnostics saved to "%LOGFILE%"
echo Exit code: %RESULT%
:endPause
if not "%OUTPUT_CREATED%"=="yes" goto normalPause
if /i not "%DELETE_AFTER_PAUSE%"=="yes" goto normalPause
echo Finish viewing the page and close its browser tab, then press any key.
REM Always wait before deleting a preview, even if PAUSE_AT_END is no.
pause > nul
goto cleanupPreview
:normalPause
if /i "%PAUSE_AT_END%"=="yes" pause
:cleanupPreview
if /i not "%DELETE_AFTER_PAUSE%"=="yes" goto done
if not "%OUTPUT_CREATED%"=="yes" goto done
del /q "%OUTPUT_FILE%" > nul 2>&1
if not errorlevel 1 goto done
set "RESULT=1"
set "MESSAGE=Could not delete preview: %OUTPUT_FILE%"
echo "%SOURCE%"(1,1): Error: %MESSAGE% [file-level failure; source location unavailable]
>> "%LOGFILE%" echo "%SOURCE%"(1,1): Error: %MESSAGE% [file-level failure; source location unavailable]
:done
endlocal & exit /b %RESULT%
