@echo off
REM COMVIMSCRIPT.BAT version 1.0.0.0.9 - OpenAI GPT-6.1
REM Run VIMSCRIPT program - trusted scripts are EXECUTED, not just checked.
REM Requires a normal Vim 8/9 build with +eval (not vim.tiny).
REM
REM Short form: COMVIMSCRIPT.BAT "script.vim" ["output.err"] ["gvim.exe"]
REM %1 source; %2 optional output; %3 optional executable override.
REM TSE form: COMVIMSCRIPT.BAT name ext "source.vim" drive path "output.err"
REM %3 source; %6 output; optional %7 executable override.
REM Quote paths with spaces. Relative paths use the caller's directory.
REM Output parent must exist. Output is overwritten. Source must differ.
REM No vimrc/plugins, swap files or interactive prompts. Source runs ONCE.
REM The embedded Vim code below performs capture/formatting; no helper program.
REM
REM TEST BOTH SHELLS from the folder containing these four release files:
REM cmd.exe /d /c COMVIMSCRIPT.BAT /test "G:\WORDPROC\vim\vim92\gvim.exe"
REM "G:\UTILS\JPSOFT\TCMD\tcc.exe" /c COMVIMSCRIPT.BAT /test "G:\WORDPROC\vim\vim92\gvim.exe"
REM /test copies the two samples to a spaced temporary path, tests short
REM and six-argument calls, three errors, missing source and output protection.
REM Tests use this shell natively, not a hidden invocation of cmd.exe.
REM Exit 0 success, 1 Vim/script/test failure, 2 bad input or output failure.
REM
REM Vim can report multiple independent errors; fatal errors may stop source.
REM Standard Vim errors often have no column. For E121/E117, an unambiguous
REM token on the reported line determines its byte column; otherwise column 1
REM is emitted with an explicit note. Function-relative locations without a
REM source-file line use source line 1 and retain the original context.
REM Diagnostic shape: fullpath(line,column): complete error message
REM Rule Message Tag=0 retains the complete normalized diagnostic.

setlocal
REM ==================================================================
REM PART 1 - USER SETTINGS: adapt these values to your installation.
REM ==================================================================
set "VIM_EXE=G:\WORDPROC\vim\vim92\gvim.exe"
set "VIM_FALLBACK=gvim.exe"
set "DEFAULT_LOG=%CD%\comvimscript.err"
set "PAUSE_AFTER=1"
REM Default 1 keeps the TSE-launched console open to read program output.
REM Press a key to return to TSE. Set 0 for unattended execution.
REM No extra output copies are made.

REM ==================================================================
REM PART 2 - EXECUTION LOGIC: normally leave everything below unchanged.
REM ==================================================================
if "%COMVIMSCRIPT_TESTING%"=="1" set "PAUSE_AFTER=0"
if not exist "%VIM_EXE%" set "VIM_EXE=%VIM_FALLBACK%"
if /i "%~1"=="/test" goto test
if /i "%~1"=="/?" goto usage
if "%~1"=="" goto usage
set "COMVIMSCRIPT_SOURCE=%~1"
set "COMVIMSCRIPT_LOG=%~2"
if not "%~6"=="" goto legacy
if not "%~3"=="" set "VIM_EXE=%~3"
goto validate
:legacy
set "COMVIMSCRIPT_SOURCE=%~3"
set "COMVIMSCRIPT_LOG=%~6"
if not "%~7"=="" set "VIM_EXE=%~7"
:validate
if "%COMVIMSCRIPT_LOG%"=="" set "COMVIMSCRIPT_LOG=%DEFAULT_LOG%"
for %%F in ("%COMVIMSCRIPT_SOURCE%") do set "COMVIMSCRIPT_SOURCE=%%~fF"
for %%F in ("%COMVIMSCRIPT_LOG%") do set "COMVIMSCRIPT_LOG=%%~fF"
if not exist "%COMVIMSCRIPT_SOURCE%" goto missing
REM TCC can match a FILE in IF EXIST filename\; do not use that test.
if "%_4VER%"=="" goto cmd_directory_check
if isdir "%COMVIMSCRIPT_SOURCE%" goto missing
goto directory_checked
:cmd_directory_check
for %%F in ("%COMVIMSCRIPT_SOURCE%") do set "CV_ATTR=%%~aF"
if /i "%CV_ATTR:~0,1%"=="d" goto missing
:directory_checked
if /i "%COMVIMSCRIPT_SOURCE%"=="%COMVIMSCRIPT_LOG%" goto samefile
>"%COMVIMSCRIPT_LOG%" type nul
if errorlevel 1 goto logerror
set "COMVIMSCRIPT_BAT=%~f0"
set "CV_BOOT=%COMVIMSCRIPT_LOG%.vim-bootstrap-%RANDOM%-%RANDOM%.log"
echo COMVIMSCRIPT version 1.0.0.0.9
echo Running "%COMVIMSCRIPT_SOURCE%"
REM -es selects batch Ex mode; -U NONE also skips GUI initialization files.
REM Read the Vim payload directly from this BAT, without extracting a helper.
"%VIM_EXE%" -N -u NONE -U NONE -i NONE -n -es -c "let g:cv_lines=readfile($COMVIMSCRIPT_BAT) | execute join(g:cv_lines[index(g:cv_lines, ':VIM_PAYLOAD')+1 :], nr2char(10))" >"%CV_BOOT%" 2>&1
set "CV_STATUS=%ERRORLEVEL%"
findstr /b /c:"Vim errors: " "%COMVIMSCRIPT_LOG%" >nul
if not errorlevel 1 goto result_ready
>>"%COMVIMSCRIPT_LOG%" echo ERROR: Vim stopped before diagnostics were completed. Check the executable and script for an early quit.
type "%CV_BOOT%" >>"%COMVIMSCRIPT_LOG%"
if "%CV_STATUS%"=="0" set "CV_STATUS=1"
:result_ready
type "%COMVIMSCRIPT_LOG%"
for %%F in ("%CV_BOOT%") do if not "%%~zF"=="0" type "%CV_BOOT%"
del /q "%CV_BOOT%" >nul 2>&1
echo Vim exit code: %CV_STATUS%
if "%PAUSE_AFTER%"=="1" pause
endlocal & exit /b %CV_STATUS%
:missing
echo ERROR: Source is missing or is a directory: "%COMVIMSCRIPT_SOURCE%". 1>&2
if "%PAUSE_AFTER%"=="1" pause
endlocal & exit /b 2
:samefile
echo ERROR: Source and output must be different files. 1>&2
if "%PAUSE_AFTER%"=="1" pause
endlocal & exit /b 2
:logerror
echo ERROR: Cannot write output: "%COMVIMSCRIPT_LOG%". 1>&2
if "%PAUSE_AFTER%"=="1" pause
endlocal & exit /b 2
:usage
echo COMVIMSCRIPT version 1.0.0.0.9
echo Usage: COMVIMSCRIPT.BAT "script.vim" ["output.err"] ["gvim.exe"]
echo TSE: COMVIMSCRIPT.BAT name ext "script.vim" drive path "output.err" ["gvim.exe"]
echo Tests: COMVIMSCRIPT.BAT /test ["gvim.exe"]
if "%PAUSE_AFTER%"=="1" pause
endlocal & exit /b 2

:test
set "COMVIMSCRIPT_TESTING=1"
if not "%~2"=="" set "VIM_EXE=%~2"
set "CV_TEST=%TEMP%\COMVIMSCRIPT test %RANDOM% %RANDOM%"
if exist "%CV_TEST%" goto testfail
mkdir "%CV_TEST%"
if errorlevel 1 goto testfail
copy /y "%~dp0helloworld.vim" "%CV_TEST%\helloworld.vim" >nul
if errorlevel 1 goto testcleanupfail
copy /y "%~dp0errorstest.vim" "%CV_TEST%\errorstest.vim" >nul
if errorlevel 1 goto testcleanupfail
call "%~f0" "%CV_TEST%\helloworld.vim" "%CV_TEST%\hello.err" "%VIM_EXE%"
if errorlevel 1 goto testcleanupfail
findstr /c:"Hello world" "%CV_TEST%\hello.err" >nul
if errorlevel 1 goto testcleanupfail
call "%~f0" errorstest .vim "%CV_TEST%\errorstest.vim" x x "%CV_TEST%\errors.err" "%VIM_EXE%"
if not errorlevel 1 goto testcleanupfail
findstr /c:"errorstest.vim(5,13): E121:" "%CV_TEST%\errors.err" >nul
if errorlevel 1 goto testcleanupfail
findstr /c:"errorstest.vim(7,13): E121:" "%CV_TEST%\errors.err" >nul
if errorlevel 1 goto testcleanupfail
findstr /c:"errorstest.vim(9,13): E121:" "%CV_TEST%\errors.err" >nul
if errorlevel 1 goto testcleanupfail
call "%~f0" "%CV_TEST%\missing.vim" "%CV_TEST%\missing.err" "%VIM_EXE%"
if not "%ERRORLEVEL%"=="2" goto testcleanupfail
call "%~f0" "%CV_TEST%\helloworld.vim" "%CV_TEST%\helloworld.vim" "%VIM_EXE%"
if not "%ERRORLEVEL%"=="2" goto testcleanupfail
rmdir /s /q "%CV_TEST%"
echo PASS 1.0.0.0.9: hello, spaced paths, six parameters, three locations, missing source, source protection.
if "%PAUSE_AFTER%"=="1" pause
endlocal & exit /b 0
:testcleanupfail
echo Test files retained at "%CV_TEST%" for diagnosis.
:testfail
echo FAIL 1.0.0.0.9: inspect the output above. 1>&2
if "%PAUSE_AFTER%"=="1" pause
endlocal & exit /b 1

:VIM_PAYLOAD
" Embedded Vimscript, part of COMVIMSCRIPT.BAT version 1.0.0.0.9.
set nomore
language messages C
let g:cv_capture = ''
let v:errmsg = ''
redir => g:cv_capture
silent! execute 'source ' . fnameescape($COMVIMSCRIPT_SOURCE)
redir END
let g:cv_last_error = v:errmsg
let g:cv_raw = split(g:cv_capture, nr2char(10))
let g:cv_result = ['COMVIMSCRIPT version 1.0.0.0.9', 'filename=' . $COMVIMSCRIPT_SOURCE]
let g:cv_file = $COMVIMSCRIPT_SOURCE
let g:cv_line = 1
let g:cv_context = ''
let g:cv_relative = 0
let g:cv_errors = 0
for g:cv_msg in g:cv_raw
  let g:cv_msg = substitute(g:cv_msg, '\r$', '', '')
  if g:cv_msg =~# '^Error detected while processing '
    let g:cv_context = g:cv_msg
    let g:cv_relative = g:cv_msg =~# '\.\.function ' || g:cv_msg =~# 'processing function '
    let g:cv_match = matchstr(g:cv_msg, '.*script \zs.*\ze:$')
    if !empty(g:cv_match) && !g:cv_relative
      let g:cv_file = fnamemodify(g:cv_match, ':p')
    else
      let g:cv_file = $COMVIMSCRIPT_SOURCE
    endif
    let g:cv_line = 1
  elseif g:cv_msg =~# '^\s*line\s\+\d\+:'
    let g:cv_line = str2nr(matchstr(g:cv_msg, '\d\+'))
  elseif g:cv_msg =~# '^E\d\+:'
    let g:cv_col = 1
    let g:cv_note = ' [column unavailable; using 1]'
    if g:cv_relative
      let g:cv_line = 1
      let g:cv_note = ' [function-relative location; using source line 1, column 1; ' . g:cv_context . ']'
    elseif filereadable(g:cv_file)
      let g:cv_source_lines = readfile(g:cv_file)
      let g:cv_token = matchstr(g:cv_msg, '^E121: Undefined variable: \zs.*')
      if empty(g:cv_token)
        let g:cv_token = matchstr(g:cv_msg, '^E117: Unknown function: \zs.*')
      endif
      if !empty(g:cv_token) && g:cv_line > 0 && g:cv_line <= len(g:cv_source_lines)
        let g:cv_text = g:cv_source_lines[g:cv_line - 1]
        let g:cv_at = stridx(g:cv_text, g:cv_token)
        if g:cv_at >= 0 && stridx(g:cv_text, g:cv_token, g:cv_at + 1) < 0
          let g:cv_col = g:cv_at + 1
          let g:cv_note = ' [column from error token]'
        endif
      endif
    endif
    call add(g:cv_result, 'filename=' . g:cv_file)
    call add(g:cv_result, printf('%s(%d,%d): %s%s', g:cv_file, g:cv_line, g:cv_col, g:cv_msg, g:cv_note))
    let g:cv_errors += 1
  elseif !empty(g:cv_msg)
    call add(g:cv_result, g:cv_msg)
  endif
endfor
if g:cv_errors == 0 && !empty(g:cv_last_error)
  call add(g:cv_result, 'filename=' . $COMVIMSCRIPT_SOURCE)
  call add(g:cv_result, $COMVIMSCRIPT_SOURCE . '(1,1): ' . g:cv_last_error . ' [location unavailable; using 1,1]')
  let g:cv_errors = 1
endif
call add(g:cv_result, 'Vim errors: ' . g:cv_errors)
if writefile(g:cv_result, $COMVIMSCRIPT_LOG) != 0
  cquit 2
endif
if g:cv_errors > 0
  cquit 1
endif
qa!
