@ECHO OFF
REM COMMAPLE version 1.0.0.0.14 - OpenAI GPT-6
REM PART 1 contains user settings; PART 2 contains common logic.
REM Direct: COMMAPLE.BAT "F:\sources with spaces\errorstest.mpl"
REM TSE: COMMAPLE.BAT "name" ".mpl" "fullfile" "drive" "path" "errfile"
REM %3 is the exact source filename; %6 is TSE's diagnostics filename.
REM %4 and %5 are retained for TSE compatibility, not executable overrides.
REM Test natively in TCC by entering the direct command above.
REM CMD test: cmd.exe /d /c COMMAPLE.BAT "F:\sources with spaces\errorstest.mpl"
REM Formatting self-test in either shell: COMMAPLE.BAT --testformat
REM No PS1, SAL, or Maple wrapper program is required.
REM Native TCC parsing uses DO, @INDEX, @WORD, and @EVAL.
REM TCC uses *CALL/*QUIT/*PAUSE to bypass user aliases and library functions.
REM Maple V Student Mint checks syntax; it does not execute Maple programs.
REM Caret columns include the printed source prefix; subtract it for TSE.
SETLOCAL ENABLEDELAYEDEXPANSION
REM ================= PART 1 - USER SETTINGS ============================
IF NOT DEFINED CM_EXE SET "CM_EXE=g:\math\maple\maple v release 5 - student version\bin.wnt\mint.exe"
IF NOT DEFINED CM_PAUSE SET "CM_PAUSE=1"
REM CM_EXE may also be set in the calling shell before running this BAT.
REM Set CM_PAUSE=0 in the calling shell for unattended tests.
REM ================= PART 2 - COMMON LOGIC =============================
SET "CM_VERSION=1.0.0.0.14"
SET "CM_RC=0"
REM _4VER is a TCC internal variable, not an environment variable.
SET "CM_ISTCC=0"
IF NOT "%_4VER%"=="" SET "CM_ISTCC=1"
SET "CM_PENDING="
SET "CM_COUNT=0"
ECHO COMMAPLE version %CM_VERSION%
IF "%CM_ISTCC%"=="1" (ECHO Shell: TCC) ELSE (ECHO Shell: CMD)
IF /I "%~1"=="--testformat" GOTO testformat
IF "%~1"=="" GOTO usage
SET "CM_SOURCE=%~f1"
IF NOT "%~3"=="" SET "CM_SOURCE=%~f3"
SET "CM_ERR=%TEMP%\COMMAPLE_%RANDOM%_%RANDOM%.err"
IF NOT "%~6"=="" SET "CM_ERR=%~f6"
SET "CM_RAW=%CM_ERR%.maple-raw"
IF /I "%CM_SOURCE%"=="%CM_ERR%" GOTO unsafe
IF /I "%CM_SOURCE%"=="%CM_RAW%" GOTO unsafe
>"%CM_ERR%" ECHO COMMAPLE version %CM_VERSION%
IF ERRORLEVEL 1 GOTO badoutput
IF NOT EXIST "%CM_SOURCE%" GOTO badsource
REM TCC: never use IF EXIST "file\" to determine whether file is a directory.
IF "%CM_ISTCC%"=="1" GOTO tccchecks
FOR %%I IN ("%CM_SOURCE%") DO SET "CM_ATTR=%%~aI"
IF /I "!CM_ATTR:~0,1!"=="d" GOTO badsource
GOTO execheck
:tccchecks
IF ISDIR "%CM_SOURCE%" GOTO badsource
:execheck
IF NOT EXIST "%CM_EXE%" GOTO badexe
IF "%CM_ISTCC%"=="1" GOTO tccexe
FOR %%I IN ("%CM_EXE%") DO SET "CM_ATTR=%%~aI"
IF /I "!CM_ATTR:~0,1!"=="d" GOTO badexe
GOTO run
:tccexe
IF ISDIR "%CM_EXE%" GOTO badexe
:run
ECHO filename=%CM_SOURCE%
REM Exact command verified on the user's Maple V Release 5 Student Mint.
"%CM_EXE%" "%CM_SOURCE%" <NUL >"%CM_RAW%" 2>&1
SET "CM_RC=%ERRORLEVEL%"
TYPE "%CM_RAW%"
TYPE "%CM_RAW%" >>"%CM_ERR%"
IF "%CM_ISTCC%"=="1" (*CALL :normalize) ELSE (CALL :normalize)
IF NOT "%CM_COUNT%"=="0" IF "%CM_RC%"=="0" SET "CM_RC=3"
GOTO finish

:normalize
IF "%CM_ISTCC%"=="1" GOTO tccnormalize
REM Read native output without CALL-expanding diagnostic text.
FOR /F "usebackq delims=" %%L IN ("%CM_RAW%") DO (
 SET "CM_TEXT=%%L"
 IF "%CM_ISTCC%"=="1" (*CALL :parseline) ELSE (CALL :parseline)
)
IF DEFINED CM_PENDING IF "%CM_ISTCC%"=="1" (*CALL :flushfallback) ELSE (CALL :flushfallback)
GOTO subreturn
:parseline
SET "CM_TAIL=!CM_TEXT:*on line =!"
IF "!CM_TAIL!"=="!CM_TEXT!" GOTO caret
IF DEFINED CM_PENDING IF "%CM_ISTCC%"=="1" (*CALL :flushfallback) ELSE (CALL :flushfallback)
FOR /F "tokens=1 delims=:, " %%N IN ("!CM_TAIL!") DO SET "CM_LINE=%%N"
REM Accept only numeric line numbers.
SET "CM_INVALID="
FOR /F "delims=0123456789" %%N IN ("!CM_LINE!") DO SET "CM_INVALID=1"
IF DEFINED CM_INVALID GOTO subreturn
SET "CM_PENDING=!CM_TEXT!"
SET "CM_PREFIX=!CM_TEXT!"
SET "CM_OFFSET=0"
:prefixscan
IF NOT DEFINED CM_PREFIX GOTO subreturn
SET /A CM_OFFSET=CM_OFFSET+1 >NUL
IF "!CM_PREFIX:~0,1!"==":" GOTO prefixdone
SET "CM_PREFIX=!CM_PREFIX:~1!"
GOTO prefixscan
:prefixdone
REM Source excerpt begins after the colon and one space.
SET /A CM_OFFSET=CM_OFFSET+1 >NUL
GOTO subreturn
:caret
IF NOT DEFINED CM_PENDING GOTO subreturn
SET "CM_SCAN=!CM_TEXT!"
SET "CM_COL=1"
:scan
IF NOT DEFINED CM_SCAN GOTO subreturn
IF "!CM_SCAN:~0,1!"=="^" GOTO mintcaret
REM Caret indentation must contain only spaces; source text is ignored.
IF NOT "!CM_SCAN:~0,1!"==" " GOTO subreturn
SET /A CM_COL=CM_COL+1 >NUL
SET "CM_SCAN=!CM_SCAN:~1!"
GOTO scan
:mintcaret
SET "CM_PENDING=Mint!CM_SCAN:~1!"
SET /A CM_COL=CM_COL-CM_OFFSET >NUL
IF !CM_COL! LSS 1 SET "CM_COL=1"
GOTO emit
:flushfallback
SET "CM_COL=1"
SET "CM_PENDING=!CM_PENDING! [column unavailable; using 1]"
:emit
SET /A CM_COUNT=CM_COUNT+1 >NUL
ECHO TSE: !CM_SOURCE!(!CM_LINE!,!CM_COL!): !CM_PENDING!
>>"%CM_ERR%" ECHO TSE: !CM_SOURCE!(!CM_LINE!,!CM_COL!): !CM_PENDING!
SET "CM_PENDING="
GOTO subreturn
:testformat
SET "CM_TRACE=1"
SET "CM_SOURCE=F:\sources with spaces\errorstest.mpl"
SET "CM_ERR=%TEMP%\COMMAPLE_format_%RANDOM%_%RANDOM%.err"
SET "CM_RAW=%CM_ERR%.maple-raw"
>"%CM_ERR%" ECHO COMMAPLE version %CM_VERSION%
>"%CM_RAW%" ECHO on line     5: first := 1 + * 2;
>>"%CM_RAW%" ECHO                             ^^ syntax error
>>"%CM_RAW%" ECHO on line     9: second := 3 + / 4;
>>"%CM_RAW%" ECHO                              ^^ syntax error
>>"%CM_RAW%" ECHO on line    12: third := 5 + ^^ 6;
>>"%CM_RAW%" ECHO                             ^^ syntax error
IF "%CM_ISTCC%"=="1" (*CALL :normalize) ELSE (CALL :normalize)
ECHO Parsed diagnostics: %CM_COUNT%
IF NOT "%CM_COUNT%"=="3" GOTO testfailed
"%SystemRoot%\System32\findstr.exe" /L /C:"(5,14):" "%CM_ERR%" >NUL
IF ERRORLEVEL 1 GOTO testfailed
"%SystemRoot%\System32\findstr.exe" /L /C:"(9,15):" "%CM_ERR%" >NUL
IF ERRORLEVEL 1 GOTO testfailed
"%SystemRoot%\System32\findstr.exe" /L /C:"(12,14):" "%CM_ERR%" >NUL
IF ERRORLEVEL 1 GOTO testfailed
ECHO PASS: three fixture diagnostics retain their line and caret column.
ECHO Fixture test only; this does not execute Mint.
GOTO finish
:testfailed
ECHO FAIL: diagnostic formatting self-test.
SET "CM_RC=1"
GOTO finish
:usage
ECHO Usage: COMMAPLE.BAT "source.mpl" or the six TSE parameters.
SET "CM_RC=2"
GOTO end
:unsafe
ECHO ERROR: Diagnostics would overwrite the source file.
SET "CM_RC=2"
GOTO end
:badoutput
ECHO ERROR: Cannot write diagnostics: "%CM_ERR%"
SET "CM_RC=2"
GOTO end
:badsource
SET "CM_FAILURE=ERROR: source file not found or is a directory: "%CM_SOURCE%""
SET "CM_RC=2"
GOTO failure
:badexe
SET "CM_FAILURE=ERROR: Maple executable not found: "%CM_EXE%". Set CM_EXE."
SET "CM_RC=2"
:failure
ECHO !CM_FAILURE!
>>"%CM_ERR%" ECHO !CM_FAILURE!
:finish
ECHO Diagnostics: "%CM_ERR%"
IF DEFINED CM_RAW ECHO Raw output: "%CM_RAW%"
:end
ECHO Exit code: %CM_RC%
IF "%CM_PAUSE%"=="1" IF "%CM_ISTCC%"=="1" (*PAUSE) ELSE (PAUSE)
IF "%CM_ISTCC%"=="1" GOTO tccend
ENDLOCAL & EXIT /B %CM_RC%
:tccend
ENDLOCAL & *QUIT %CM_RC%

:subreturn
REM TCC CALL-label uses QUIT; CMD uses EXIT /B.
IF "%CM_ISTCC%"=="1" *QUIT 0
EXIT /B 0

:tccnormalize
REM Native TCC parser: no CMD !variable:substring! substitutions.
REM DO preserves the leading spaces required for caret positions.
SET "CM_LINE="
*DO CM_TEXT IN @"%CM_RAW%"
 SET CM_POS=%@index["%CM_TEXT",on line ]
 IFF %CM_POS GE 0 THEN
  SET CM_OFFSET=%@index["%CM_TEXT",:]
  REM @INDEX counts enclosing quotes; @LEFT on unquoted input includes
  REM the colon, which @WORD's separator list removes. No source code
  REM is passed to @WORD, so commas/quotes in source cannot change tokens.
  SET CM_HEADER=%@left[%CM_OFFSET,%CM_TEXT]
  SET CM_LINE=%@word[" :",2,%CM_HEADER]
  IF "%CM_TRACE%"=="1" *ECHO TRACE header: line=%[CM_LINE] prefix-index=%[CM_OFFSET]
 ELSE
  SET CM_POS=%@index["%CM_TEXT",syntax error]
  IFF %CM_POS GE 0 THEN
   IFF "%CM_LINE" NE "" THEN
    REM Mint prints one caret and one space before 'syntax error'.
    REM TCC consumes the caret while expanding the pointer text; its
    REM observed message index is one lower than the original byte index.
    REM Correct that consumed character: source column = message-colon-2.
    SET CM_COL=%@eval[%CM_POS-%CM_OFFSET-2]
    IF "%CM_TRACE%"=="1" *ECHO TRACE location: line=%[CM_LINE] message-index=%[CM_POS] column=%[CM_COL]
    IF %CM_COL LT 1 SET CM_COL=1
    SET CM_COUNT=%@eval[%CM_COUNT+1]
    *ECHO TSE: %[CM_SOURCE](%[CM_LINE],%[CM_COL]): Mint syntax error
    *ECHO TSE: %[CM_SOURCE](%[CM_LINE],%[CM_COL]): Mint syntax error >>"%CM_ERR%"
    SET "CM_LINE="
   ENDIFF
  ENDIFF
 ENDIFF
*ENDDO
*QUIT 0
