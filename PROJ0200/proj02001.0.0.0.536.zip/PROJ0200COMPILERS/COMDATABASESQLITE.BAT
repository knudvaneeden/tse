@echo off
REM COMDATABASESQLITE.BAT version 1.0.0.0.8
REM Knud van Eeden / OpenAI ChatGPT GPT-6
REM Run DATABASESQLITE program
REM PART 1 - USER SETTINGS AND TEST INSTRUCTIONS
REM Executable override: set "COMDATABASESQLITE_EXE=G:\DATABASE\CLIENT\SQLITE\sqlite3.exe"
REM Database override: set "COMDATABASESQLITE_DB=C:\data\test.db"
REM Default :memory: creates a fresh temporary database for each execution.
REM SQL is EXECUTED; a persistent database override permits real changes.
REM Set COMDATABASESQLITE_PAUSE=0 to suppress the final pause.
REM Short form: COMDATABASESQLITE.BAT "source.sql" ["output.err"]
REM TSE form: %%1=name %%2=extension %%3=full source %%4=drive %%5=path %%6=output
REM TCC test (run each separately, then repeat with the other SQL file):
REM "G:\UTILS\JPSoft\TCMD\tcc.exe" /c F:\BBC\TAAL\COMDATABASESQLITE.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstestdatabasesqlite.sql" "C:\temp\sqlite-tcc.err"
REM CMD test (run each separately, then repeat with the other SQL file):
REM cmd.exe /d /c F:\BBC\TAAL\COMDATABASESQLITE.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstestdatabasesqlite.sql" "C:\temp\sqlite-cmd.err"
REM Hello test source: F:\BBC\TAAL\PROJ0200HELLOWORLD\helloworlddatabasesqlite.sql
REM Expected: Hello prints Hello world from SQLite!, exit 0, empty .err.
REM Errors: three TSE diagnostics, nonzero exit, lines 5, 8, 11; column 1.
REM SQLite reports statement start lines; exact token columns are unavailable.
REM .bail on or .quit inside source can prevent subsequent errors being found.
REM No helper program is used. Raw output is retained as output.err.sqlite.raw.
setlocal
set "sqliteExe=G:\DATABASE\CLIENT\SQLITE\sqlite3.exe"
set "sqliteDb=:memory:"
set "sqlitePause=1"
if defined COMDATABASESQLITE_EXE set "sqliteExe=%COMDATABASESQLITE_EXE%"
if defined COMDATABASESQLITE_DB set "sqliteDb=%COMDATABASESQLITE_DB%"
if defined COMDATABASESQLITE_PAUSE set "sqlitePause=%COMDATABASESQLITE_PAUSE%"
REM PART 2 - SYSTEM CODE; NO USER CHANGES REQUIRED
set "sqliteSource=%~1"
set "sqliteOutput=%~2"
if not "%~3"=="" goto tseArguments
goto argumentsReady
:tseArguments
set "sqliteSource=%~3"
set "sqliteOutput=%~6"
:argumentsReady
if not defined sqliteOutput set "sqliteOutput=%sqliteSource%.err"
if not defined sqliteSource goto usage
for %%I in ("%sqliteSource%") do set "sqliteSource=%%~fI"
for %%I in ("%sqliteOutput%") do set "sqliteOutput=%%~fI"
if /i "%sqliteSource%"=="%sqliteOutput%" goto sameFile
set "sqliteRaw=%sqliteOutput%.sqlite.raw"
set "sqliteRc=1"
set "sqliteFound=0"
echo COMDATABASESQLITE.BAT version 1.0.0.0.8
type nul > "%sqliteOutput%"
if errorlevel 1 goto outputFailed
if not exist "%sqliteSource%" goto sourceMissing
if "%@eval[2+2]"=="4" goto checkTccDirectory
if exist "%sqliteSource%\NUL" goto sourceMissing
goto checkExecutable
:checkTccDirectory
if isdir "%sqliteSource%" goto sourceMissing
:checkExecutable
if not exist "%sqliteExe%" goto executableMissing
REM -cmd does not add lines to stdin; source line numbers stay unchanged.
REM -init NUL prevents a user's startup file changing the runner settings.
"%sqliteExe%" -init NUL -batch -cmd ".bail off" "%sqliteDb%" < "%sqliteSource%" > "%sqliteRaw%" 2>&1
set "sqliteRc=%errorlevel%"
type "%sqliteRaw%"
if "%@eval[2+2]"=="4" goto tccParse
REM Recognize modern Parse/Runtime error near line N: and older Error: near line N:.
for /f "usebackq tokens=1-5,*" %%A in ("%sqliteRaw%") do call :diagnostic "%%A" "%%B" "%%C" "%%D" "%%E" "%%F"
:parseComplete
if "%sqliteFound%"=="1" if "%sqliteRc%"=="0" set "sqliteRc=1"
if not "%sqliteRc%"=="0" if "%sqliteFound%"=="0" goto unlocatedFailure
goto finish
:diagnostic
set "sqliteLine="
if /i "%~2 %~3 %~4"=="error near line" set "sqliteLine=%~5"
if /i "%~1 %~2 %~3"=="Error: near line" set "sqliteLine=%~4"
if not defined sqliteLine exit /b 0
set "sqliteLine=%sqliteLine::=%"
REM Reject anything other than digits before using the line as a jump target.
for /f "delims=0123456789" %%N in ("%sqliteLine%") do exit /b 0
set "sqliteFound=1"
set "sqliteMessage=%~1 %~2 %~3 %~4 %~5 %~6"
setlocal EnableDelayedExpansion
>> "!sqliteOutput!" echo TSE: !sqliteSource!:!sqliteLine!:1: !sqliteMessage!
endlocal
exit /b 0
:tccParse
REM Native TCC parsing: no CALL token arguments or CMD delayed expansion.
set sqliteReadHandle=%@fileopen["%sqliteRaw%",r]
if %sqliteReadHandle% LT 0 goto unlocatedFailure
set sqliteWriteHandle=%@fileopen["%sqliteOutput%",a]
if %sqliteWriteHandle% LT 0 goto tccCloseRead
setdos /x-568
:tccRead
set sqliteRecord=%@fileread[%sqliteReadHandle%]
if "%sqliteRecord%"=="**EOF**" goto tccDone
set sqlitePrefix=%@word[0-3,%sqliteRecord%]
if "%sqlitePrefix%"=="Parse error near line" goto tccModern
if "%sqlitePrefix%"=="Runtime error near line" goto tccModern
set sqlitePrefix=%@word[0-2,%sqliteRecord%]
if "%sqlitePrefix%"=="Error: near line" goto tccLegacy
goto tccRead
:tccModern
set sqliteLine=%@word[" :",4,%sqliteRecord%]
goto tccWrite
:tccLegacy
set sqliteLine=%@word[" :",3,%sqliteRecord%]
:tccWrite
set sqliteDiscard=%@filewrite[%sqliteWriteHandle%,TSE: %sqliteSource%:%sqliteLine%:1: %sqliteRecord%]
set sqliteFound=1
goto tccRead
:tccDone
set sqliteDiscard=%@fileclose[%sqliteReadHandle%]
set sqliteDiscard=%@fileclose[%sqliteWriteHandle%]
setdos /x0
goto parseComplete
:tccCloseRead
set sqliteDiscard=%@fileclose[%sqliteReadHandle%]
goto unlocatedFailure
:sourceMissing
> "%sqliteOutput%" echo TSE: %sqliteSource%:1:1: ERROR: source file not found or is a directory.
goto showFailure
:executableMissing
> "%sqliteOutput%" echo TSE: %sqliteSource%:1:1: ERROR: SQLite executable not found: %sqliteExe%
goto showFailure
:unlocatedFailure
> "%sqliteOutput%" echo TSE: %sqliteSource%:1:1: ERROR: SQLite failed; see %sqliteRaw% for details. Location unavailable.
:showFailure
type "%sqliteOutput%"
goto finish
:outputFailed
echo ERROR: Cannot create error output file: "%sqliteOutput%"
goto finish
:sameFile
echo ERROR: Source and output must be different files.
endlocal & exit /b 2
:usage
echo Usage: COMDATABASESQLITE.BAT "source.sql" ["output.err"]
set "sqliteRc=2"
:finish
echo Exit code: %sqliteRc%
if not "%sqlitePause%"=="0" pause
endlocal & exit /b %sqliteRc%
