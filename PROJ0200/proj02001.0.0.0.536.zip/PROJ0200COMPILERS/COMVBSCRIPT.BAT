@echo off
REM COMVBSCRIPT.BAT version 1.0.0.0.9
REM Created with OpenAI ChatGPT - 2026-10-17
REM Run VBSCRIPT program using the 32-bit console Windows Script Host.
REM User's GUI host: C:\Windows\SysWOW64\wscript.exe
REM Console counterpart: C:\Windows\SysWOW64\cscript.exe
REM No helper script or PowerShell is used. Windows FINDSTR checks diagnostics.
REM A temporary text log is used only for a standalone console invocation.
REM
REM PART 1 - USER SETTINGS AND TEST INSTRUCTIONS
REM Override settings before calling this BAT in either TCC or CMD:
REM   set "COMVBSCRIPT_EXE=C:\Windows\SysWOW64\cscript.exe"
REM   set "COMVBSCRIPT_PAUSE=1"
REM Set PAUSE=0 for unattended execution; default 1 keeps console visible.
REM
REM Parameter forms:
REM   COMVBSCRIPT.BAT "F:\BBC\TAAL\helloworld.vbs"
REM   COMVBSCRIPT.BAT name .vbs fullfilename drive path output
REM The six-parameter form writes stdout and stderr to output for TSE.
REM The captured output is also displayed in the console.
REM Script arguments are not forwarded from these editor parameters.
REM
REM Test from native TCC, then repeat from native CMD:
REM   COMVBSCRIPT.BAT "F:\BBC\TAAL\helloworld.vbs"
REM   COMVBSCRIPT.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.vbs"
REM Explicit shell tests (adjust the TCC path if necessary):
REM   "G:\UTILS\JPSoft\TCMD\tcc.exe" /c F:\BBC\TAAL\COMVBSCRIPT.BAT "F:\BBC\TAAL\helloworld.vbs"
REM   "C:\Windows\System32\cmd.exe" /d /c F:\BBC\TAAL\COMVBSCRIPT.BAT "F:\BBC\TAAL\helloworld.vbs"
REM Repeat both shell tests with the full path to errorstest.vbs.
REM Expected: hello prints Hello from VBScript and Exit code: 0.
REM Error test prints line/column and Exit code: 1.
REM This verifies both displayed status and the status returned to the shell.
REM CMD: echo %ERRORLEVEL% immediately after calling this BAT.
REM TCC: echo %? immediately after calling this BAT.
REM In TSE, import comvbscriptbatcompilersetting_vbs.txt and compile each.
REM Test each successive error after commenting out the previous bad line.
REM Also test a filename containing spaces and a missing source filename.
REM
setlocal
if not defined COMVBSCRIPT_EXE set "COMVBSCRIPT_EXE=C:\Windows\SysWOW64\cscript.exe"
if not defined COMVBSCRIPT_PAUSE set "COMVBSCRIPT_PAUSE=1"
REM --------------------------------------------------------------------------
REM PART 2 - IMPLEMENTATION; NO USER CHANGES NORMALLY REQUIRED
set "CVBS_VERSION=1.0.0.0.9"
set "CVBS_RC=1"
set "CVBS_OUTPUT=%~6"
set "CVBS_TEMPLOG=0"
if not defined CVBS_OUTPUT goto outputready
type nul > "%CVBS_OUTPUT%"
if not exist "%CVBS_OUTPUT%" goto outputfailed
:outputready
echo COMVBSCRIPT version %CVBS_VERSION%
if "%~1"=="" goto usage
set "CVBS_SOURCE=%~1"
if not "%~2"=="" goto editorargs
goto resolve
:editorargs
set "CVBS_SOURCE=%~4%~5%~1%~2"
if not "%~3"=="" set "CVBS_SOURCE=%~3"
if exist "%CVBS_SOURCE%" goto resolve
set "CVBS_SOURCE=%~4%~5%~1%~2"
:resolve
for %%F in ("%CVBS_SOURCE%") do set "CVBS_SOURCE=%%~fF"
if not exist "%CVBS_SOURCE%" goto missing
REM TCC's directory test must use ISDIR, never IF EXIST "filename\".
if defined _TCC goto tccdir
for %%F in ("%CVBS_SOURCE%") do set "CVBS_ATTR=%%~aF"
if /i "%CVBS_ATTR:~0,1%"=="d" goto directory
goto hostcheck
:tccdir
if isdir "%CVBS_SOURCE%" goto directory
:hostcheck
if not exist "%COMVBSCRIPT_EXE%" goto nohost
REM /I preserves error reporting even if host defaults were changed to batch.
REM Keep native filename(line, column) diagnostics intact, including message.
if defined CVBS_OUTPUT goto capture
REM Standalone mode needs a text log too, to recognize host diagnostics.
if not defined TEMP set "TEMP=%CD%"
:logname
set "CVBS_OUTPUT=%TEMP%\comvbscript_%RANDOM%_%RANDOM%.log"
if exist "%CVBS_OUTPUT%" goto logname
set "CVBS_TEMPLOG=1"
:capture
"%COMVBSCRIPT_EXE%" //nologo //I //E:VBScript "%CVBS_SOURCE%" > "%CVBS_OUTPUT%" 2>&1
set "CVBS_RC=%ERRORLEVEL%"
REM Match native location syntax independently of the message language.
REM Preserve any nonzero host code; turn a reported diagnostic plus zero into 1.
if not "%CVBS_RC%"=="0" goto showoutput
"%SystemRoot%\System32\findstr.exe" /r /i /c:"^.*\.vbs([0-9][0-9]*, *[0-9][0-9]*) " "%CVBS_OUTPUT%" > nul 2>&1
if not errorlevel 1 set "CVBS_RC=1"
:showoutput
type "%CVBS_OUTPUT%"
if "%CVBS_TEMPLOG%"=="1" del "%CVBS_OUTPUT%" > nul 2>&1
goto finish
:outputfailed
echo ERROR: cannot create TSE output file: "%CVBS_OUTPUT%"
goto finish
:usage
echo Usage: COMVBSCRIPT.BAT "fullpath\script.vbs"
goto finish
:missing
echo ERROR: source file not found: "%CVBS_SOURCE%"
goto finish
:directory
echo ERROR: source path is a directory: "%CVBS_SOURCE%"
goto finish
:nohost
echo ERROR: console script host not found: "%COMVBSCRIPT_EXE%"
echo Set COMVBSCRIPT_EXE to the full path of cscript.exe.
goto finish
:finish
echo Exit code: %CVBS_RC%
if "%COMVBSCRIPT_PAUSE%"=="0" goto done
pause
:done
endlocal & exit /b %CVBS_RC%
