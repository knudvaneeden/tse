@ECHO OFF
REM COMEMACSLISP.BAT - version 1.0.0.7
REM Updated with OpenAI GPT-6, 2026-10-08.
REM Byte-check an Emacs Lisp file, then run it once if no diagnostics occur.
REM No separate helper program or generated Lisp runner is used.
REM Inline --eval arguments configure the Emacs compiler itself.
REM Warnings are collected together and make this check return code 1.
REM Syntax errors can stop compilation; runtime errors stop execution.
REM Compiler locations use Emacs buffer positions, columns start at 1.
REM If no position is available, the message explicitly says file start.
REM
REM Usage 1: COMEMACSLISP.BAT "source.el" ["emacs.exe"]
REM Usage 2 (TSE): COMEMACSLISP.BAT "name" "unused" "source.el" "drive" "directory" "diagnostics.txt" ["emacs.exe"]
REM In TSE mode: %%1=name, %%2=unused, %%3=source, %%4=drive,
REM %%5=directory, %%6=diagnostics, %%7=optional Emacs executable.
REM Supply the complete source path in %%3; %%4 and %%5 are unused.
REM Quote paths containing spaces. The executable override is a path,
REM not a command with arguments. Relative paths use the current directory.
REM Diagnostics are overwritten. Emacs stdout and stderr are both saved.
REM Emacs Lisp should use princ or message to produce batch output.
REM
REM TESTS - run these directly INSIDE your existing TCC console:
REM COMEMACSLISP.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.el"
REM COMEMACSLISP.BAT "errorstest" "el" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.el" "F" "BBC\TAAL\PROJ0200ERRORSMULTIPLE" "C:\TEMP\emacslisp_tcc.err"
REM CMD test, from either console:
REM cmd.exe /d /v:off /c COMEMACSLISP.BAT "errorstest" "el" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.el" "F" "BBC\TAAL\PROJ0200ERRORSMULTIPLE" "C:\TEMP\emacslisp_cmd.err"
REM Expected: three Warning diagnostics about cem-missing-first/second/third,
REM on lines 7, 10 and 13, column 8; nonzero exit code; the test is not executed.
REM Use the optional executable override documented above if needed.
REM Test a source path containing spaces and a genuinely missing source too.
REM For a successful run, replace the three missing-variable references with
REM numbers: the file should then print Hello from Emacs Lisp exactly once.
REM Set PAUSE_AT_END=no below for automated exit-code checks.
REM Do not invoke another tcc.exe from within TCC.
REM Emacs 29.3 on Linux verified: three diagnostics at 7:8, 10:8, 13:8;
REM clean run once, syntax failure, runtime failure, and paths with spaces.
REM Windows TCC/CMD and TSE jump tests still require your PC.
REM
REM =====================================================================
REM PART 1 - USER SETTINGS: change system-dependent values only here.
REM =====================================================================
SETLOCAL
SET "EMACS_EXE=G:\wordproc\emacs\bin\emacs.exe"
REM Optional Emacs flags. -Q skips personal startup configuration.
SET "EMACS_OPTIONS=-Q --batch"
REM Empty means use TEMP, then the current directory if TEMP is unset.
SET "LOG_DIRECTORY="
REM Optional extra output copy; empty disables copying.
REM Example: SET "OUTPUT_COPY=C:\TEMP\dddoutput.txt"
SET "OUTPUT_COPY="
SET "PAUSE_AT_END=yes"

REM =====================================================================
REM PART 2 - EXECUTION LOGIC: normally no user changes are needed below.
REM Uses common TCC/CMD batch syntax; does not launch a second shell.
REM =====================================================================
ECHO COMEMACSLISP.BAT version 1.0.0.7
SET "RESULT=1"
SET "SOURCE_FILE=%1"
SET "SOURCE_FILE=%SOURCE_FILE:"=%"
SET "LOG_FILE="
SET "ARG_TWO=%2"
SET "ARG_TWO=%ARG_TWO:"=%"
SET "ARG_SEVEN=%7"
SET "ARG_SEVEN=%ARG_SEVEN:"=%"
SET "ARG_THREE=%3"
SET "ARG_THREE=%ARG_THREE:"=%"
IF NOT "%ARG_THREE%"=="" GOTO tse_arguments
IF "%ARG_TWO%"=="" GOTO arguments_ready
SET "EMACS_EXE=%2"
SET "EMACS_EXE=%EMACS_EXE:"=%"
GOTO arguments_ready

:tse_arguments
SET "SOURCE_FILE=%3"
SET "SOURCE_FILE=%SOURCE_FILE:"=%"
SET "LOG_FILE=%6"
SET "LOG_FILE=%LOG_FILE:"=%"
IF "%ARG_SEVEN%"=="" GOTO arguments_ready
SET "EMACS_EXE=%7"
SET "EMACS_EXE=%EMACS_EXE:"=%"

:arguments_ready
IF "%SOURCE_FILE%"=="" GOTO usage_error
IF NOT EXIST "%SOURCE_FILE%" GOTO source_error
REM Never use IF EXIST "filename\" to reject a directory under TCC.
IF DEFINED _TCC_VER GOTO tcc_source_type
FOR %%I IN ("%SOURCE_FILE%") DO SET "SOURCE_ATTRIBUTES=%%~aI"
IF /I "%SOURCE_ATTRIBUTES:~0,1%"=="d" GOTO source_error
GOTO source_type_ready
:tcc_source_type
IF ISDIR "%SOURCE_FILE%" GOTO source_error
:source_type_ready
IF NOT EXIST "%EMACS_EXE%" GOTO emacs_error
IF NOT "%LOG_FILE%"=="" GOTO log_ready
IF NOT "%LOG_DIRECTORY%"=="" GOTO log_directory_ready
SET "LOG_DIRECTORY=%TEMP%"
IF "%LOG_DIRECTORY%"=="" SET "LOG_DIRECTORY=."
:log_directory_ready
SET "LOG_FILE=%LOG_DIRECTORY%\COMEMACSLISP_%RANDOM%_%RANDOM%.txt"
:log_ready
REM Do not allow the diagnostic destination to overwrite the source.
FOR %%I IN ("%SOURCE_FILE%") DO SET "SOURCE_FULL=%%~fI"
FOR %%I IN ("%LOG_FILE%") DO SET "LOG_FULL=%%~fI"
IF /I "%SOURCE_FULL%"=="%LOG_FULL%" GOTO same_file_error
>"%LOG_FILE%" ECHO COMEMACSLISP.BAT version 1.0.0.7
IF ERRORLEVEL 1 GOTO log_error
>>"%LOG_FILE%" ECHO filename=%SOURCE_FULL%
IF ERRORLEVEL 1 GOTO log_error
SET "CEM_SOURCE=%SOURCE_FULL%"
REM Percent signs are doubled for BAT expansion; Emacs sees %s and %d.
SET "CEM_FORMAT=TSE: %%s(%%d,%%d): %%s: %%s"
ECHO Checking "%SOURCE_FULL%"
"%EMACS_EXE%" %EMACS_OPTIONS% --eval "(progn (require 'bytecomp) (setq cem-count 0 cem-source (expand-file-name (getenv (symbol-name 'CEM_SOURCE))) cem-dest (make-temp-file (symbol-name 'COMEMACSLISP-) nil (symbol-name '.elc))) (defun cem-report (text position fill level) (setq cem-count (1+ cem-count)) (let ((line 1) (column 1)) (if (and (integer-or-marker-p position) (buffer-live-p byte-compile-current-buffer)) (with-current-buffer byte-compile-current-buffer (save-excursion (goto-char (max (point-min) (min (point-max) position))) (setq line (line-number-at-pos) column (1+ (current-column))))) (setq text (concat text (string 32) (symbol-name 'location-unavailable-file-start)))) (princ (format (getenv (symbol-name 'CEM_FORMAT)) (if (stringp byte-compile-current-file) byte-compile-current-file cem-source) line column (symbol-name (if (eq level :error) 'Error 'Warning)) (replace-regexp-in-string (concat (string 91 10 13 93 43)) (string 32) text))) (terpri))) (setq byte-compile-log-warning-function 'cem-report byte-compile-error-on-warn nil byte-compile-warnings t byte-compile-dest-file-function (lambda (file) cem-dest)))" --eval "(unwind-protect (condition-case problem (unless (byte-compile-file cem-source) (when (= cem-count 0) (cem-report (symbol-name 'Byte-compilation-failed) nil nil :error))) (error (cem-report (error-message-string problem) nil nil :error))) (when (file-exists-p cem-dest) (delete-file cem-dest)))" --eval "(progn (when (= cem-count 0) (condition-case problem (load cem-source nil t t) (error (let ((byte-compile-current-file cem-source) (byte-compile-current-buffer nil)) (cem-report (error-message-string problem) nil nil :error))))) (kill-emacs (if (= cem-count 0) 0 1)))" >>"%LOG_FILE%" 2>&1
SET "RESULT=%ERRORLEVEL%"
ECHO.
TYPE "%LOG_FILE%"
ECHO.
ECHO Emacs exit code: %RESULT%
ECHO Diagnostics saved to "%LOG_FILE%"
IF "%OUTPUT_COPY%"=="" GOTO finish
FOR %%I IN ("%OUTPUT_COPY%") DO SET "COPY_FULL=%%~fI"
IF /I "%SOURCE_FULL%"=="%COPY_FULL%" GOTO copy_source_error
IF /I "%LOG_FULL%"=="%COPY_FULL%" GOTO finish
COPY /Y "%LOG_FILE%" "%OUTPUT_COPY%" >NUL
IF ERRORLEVEL 1 GOTO copy_error
GOTO finish

:usage_error
ECHO Usage: COMEMACSLISP.BAT "source.el" ["emacs.exe"]
ECHO Or: COMEMACSLISP.BAT "name" "unused" "source.el" "drive" "directory" "diagnostics.txt" ["emacs.exe"]
GOTO finish
:source_error
ECHO ERROR: Emacs Lisp source not found: "%SOURCE_FILE%"
GOTO finish
:emacs_error
ECHO ERROR: Emacs executable not found: "%EMACS_EXE%"
ECHO Change EMACS_EXE in Part 1 or supply an executable override.
GOTO finish
:same_file_error
ECHO ERROR: Diagnostics must not overwrite the source file.
GOTO finish
:log_error
ECHO ERROR: Cannot write diagnostics: "%LOG_FILE%"
ECHO Ensure the destination directory exists and is writable.
GOTO finish
:copy_source_error
ECHO ERROR: Output copy must not overwrite the source file.
IF "%RESULT%"=="0" SET "RESULT=1"
GOTO finish
:copy_error
ECHO ERROR: Cannot copy output to "%OUTPUT_COPY%"
IF "%RESULT%"=="0" SET "RESULT=1"
:finish
ECHO.
IF /I "%PAUSE_AT_END%"=="yes" PAUSE
ENDLOCAL & EXIT /B %RESULT%
