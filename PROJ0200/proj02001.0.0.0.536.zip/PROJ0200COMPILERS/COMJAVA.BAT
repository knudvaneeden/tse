@echo off
setlocal EnableExtensions DisableDelayedExpansion
REM COMJAVA.BAT - Compile and run a Java source file.
REM Version: 1.0.0.9
REM Updated: 2026-10-04 20:58 +02:00
REM Adapted with OpenAI GPT-6 (Codex).
REM Run through CMD.EXE, also when starting from TCC or another shell.
REM
REM Direct-file test:
REM   cmd.exe /d /c COMJAVA.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.java"
REM TSE six-parameter test:
REM   cmd.exe /d /c COMJAVA.BAT "ddd" "java" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.java" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\comjava_test.err"
REM Parameter meanings:
REM   %%1 = source basename in TSE mode; complete source path in direct mode.
REM   %%2 = extension in TSE mode (retained for calling compatibility).
REM   %%3 = source filename in TSE mode; this is the authoritative source path.
REM   %%4 = drive and %%5 = directory (retained for calling compatibility).
REM   %%6 = diagnostics filename; omitted means a unique file in TEMP.
REM The diagnostics parent directory must already exist.
REM Tests expect ddd.java to contain a runnable class named ddd or Ddd.
REM Java class names are case-sensitive. Program arguments are not accepted.
REM
REM ======================================================================
REM PART 1 - USER SETTINGS: adapt only this section to your local system.
REM ======================================================================
REM A JDK must be installed. Defaults find javac.exe and java.exe on PATH.
REM Alternatively set BOTH to matching full paths from the same JDK:
REM   set "JAVAC=C:\Program Files\Java\jdk-25\bin\javac.exe"
REM   set "JAVA=C:\Program Files\Java\jdk-25\bin\java.exe"
set "JAVAC=javac.exe"
set "JAVA=java.exe"
REM Leave MAIN_CLASS empty to use the source basename. After compilation,
REM the actual class filename supplies its exact case (ddd.java -> Ddd).
REM For a package declaration, set the fully qualified class, e.g. demo.ddd.
set "MAIN_CLASS="
REM Optional additional classpath (JARs/directories separated by semicolons).
set "EXTRA_CLASSPATH="
REM Optional javac source encoding, e.g. UTF-8. Empty uses the JDK default.
set "SOURCE_ENCODING="
REM true pauses after completion; false is suitable for unattended use.
set "PAUSE_AT_END=true"
REM Temporary class files are removed after execution. Diagnostics are kept.
set "BUILD_ROOT=%TEMP%"
set "DIAGNOSTICS_ROOT=%TEMP%"

REM ======================================================================
REM PART 2 - COMMON LOGIC: no local-system changes should be needed below.
REM ======================================================================
set "RESULT=1"
set "BUILD_DIR="
set "DID_PUSHD="
set "DIAGNOSTICS="
set "AUTO_MAIN="
if "%~1"=="" goto usage
set "SOURCE=%~1"
if not "%~3"=="" set "SOURCE=%~3"
for %%F in ("%SOURCE%") do set "SOURCE=%%~fF"
for %%F in ("%SOURCE%") do set "SOURCE_DIR=%%~dpF"
if defined MAIN_CLASS goto mainClassReady
set "AUTO_MAIN=true"
for %%F in ("%SOURCE%") do set "MAIN_CLASS=%%~nF"
:mainClassReady
if not defined BUILD_ROOT set "BUILD_ROOT=%CD%"
if not defined DIAGNOSTICS_ROOT set "DIAGNOSTICS_ROOT=%CD%"
set "RUN_ID=%RANDOM%_%RANDOM%"
set "DIAGNOSTICS=%~6"
if not defined DIAGNOSTICS set "DIAGNOSTICS=%DIAGNOSTICS_ROOT%\COMJAVA_%RUN_ID%.err"
for %%F in ("%DIAGNOSTICS%") do set "DIAGNOSTICS=%%~fF"
if /i "%DIAGNOSTICS%"=="%SOURCE%" goto unsafeDiagnostics
>"%DIAGNOSTICS%" echo filename=%SOURCE%
if errorlevel 1 goto diagnosticsFailed
if not exist "%SOURCE%" goto sourceMissing
call :checkTool "%JAVAC%"
if errorlevel 1 goto compilerMissing
call :checkTool "%JAVA%"
if errorlevel 1 goto runtimeMissing
set "BUILD_DIR=%BUILD_ROOT%\COMJAVA_%RUN_ID%"
if exist "%BUILD_DIR%" goto buildCollision
mkdir "%BUILD_DIR%" >>"%DIAGNOSTICS%" 2>&1
if errorlevel 1 goto buildFailed
pushd "%SOURCE_DIR%" >>"%DIAGNOSTICS%" 2>&1
if errorlevel 1 goto directoryFailed
set "DID_PUSHD=true"
set "RUN_CLASSPATH=%BUILD_DIR%;%SOURCE_DIR%."
if defined EXTRA_CLASSPATH set "RUN_CLASSPATH=%RUN_CLASSPATH%;%EXTRA_CLASSPATH%"
echo Compiling "%SOURCE%"
if defined SOURCE_ENCODING goto compileWithEncoding
"%JAVAC%" -classpath "%RUN_CLASSPATH%" -d "%BUILD_DIR%" "%SOURCE%" >>"%DIAGNOSTICS%" 2>&1
set "RESULT=%ERRORLEVEL%"
goto compiled
:compileWithEncoding
"%JAVAC%" -encoding "%SOURCE_ENCODING%" -classpath "%RUN_CLASSPATH%" -d "%BUILD_DIR%" "%SOURCE%" >>"%DIAGNOSTICS%" 2>&1
set "RESULT=%ERRORLEVEL%"
:compiled
type "%DIAGNOSTICS%"
echo.
echo Compiler diagnostics saved to "%DIAGNOSTICS%"
if not "%RESULT%"=="0" goto compileFailed
echo.
REM DIR returns the stored filename case on Windows, unlike the source basename.
REM Explicit MAIN_CLASS overrides retain the exact value supplied by the user.
if not defined AUTO_MAIN goto runProgram
for /f "delims=" %%F in ('dir /b /a-d "%BUILD_DIR%\%MAIN_CLASS%.class" 2^>nul') do set "MAIN_CLASS=%%~nF"
:runProgram
echo Running "%MAIN_CLASS%"
REM Keep stdin, stdout and stderr attached for interactive Java programs.
"%JAVA%" -classpath "%RUN_CLASSPATH%" "%MAIN_CLASS%"
set "RESULT=%ERRORLEVEL%"
echo.
echo Program exit code: %RESULT%
>>"%DIAGNOSTICS%" echo Program exit code: %RESULT%
goto finish

:checkTool
if exist "%~1" exit /b 0
where "%~1" >nul 2>&1
exit /b %ERRORLEVEL%

:usage
echo Usage: COMJAVA.BAT "full-path\ClassName.java"
echo Or:    COMJAVA.BAT "name" "java" "full-source-path" "drive" "directory" "diagnostics-file"
goto finish
:unsafeDiagnostics
echo ERROR: Diagnostics filename must differ from the source filename.
set "DIAGNOSTICS="
goto finish
:diagnosticsFailed
echo ERROR: Cannot write diagnostics to "%DIAGNOSTICS%".
echo Check that its parent directory exists and is writable.
goto finish
:sourceMissing
set "FAILURE=Source file not found."
goto reportFailure
:compilerMissing
set "FAILURE=Java compiler not found: %JAVAC%"
goto reportFailure
:runtimeMissing
set "FAILURE=Java runtime not found: %JAVA%"
goto reportFailure
:buildCollision
REM Do not remove an existing directory which this run did not create.
set "BUILD_DIR="
set "FAILURE=Temporary build directory already exists. Please try again."
goto reportFailure
:buildFailed
set "BUILD_DIR="
set "FAILURE=Cannot create temporary build directory. Check BUILD_ROOT."
goto reportFailure
:directoryFailed
set "FAILURE=Cannot enter source directory."
goto reportFailure
:reportFailure
>>"%DIAGNOSTICS%" echo ERROR: %FAILURE%
type "%DIAGNOSTICS%"
echo Diagnostics saved to "%DIAGNOSTICS%"
goto finish
:compileFailed
echo Compilation failed with exit code %RESULT%.
goto finish
:finish
if defined DID_PUSHD popd
if not defined BUILD_DIR goto afterCleanup
rmdir /s /q "%BUILD_DIR%" 2>nul
if exist "%BUILD_DIR%" echo WARNING: Could not remove temporary build directory "%BUILD_DIR%".
:afterCleanup
if /i "%PAUSE_AT_END%"=="true" pause
endlocal & exit /b %RESULT%
