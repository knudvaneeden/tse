@echo off
setlocal EnableExtensions DisableDelayedExpansion
REM COMDATABASETRANSACT.BAT version 1.0.0.0.13
REM Prepared with OpenAI ChatGPT GPT-6.1 Sol.
REM Runs Transact-SQL ONCE using SQL Server sqlcmd (ODBC).
REM PART 1 - USER SETTINGS AND TEST INSTRUCTIONS
REM TSE arguments: %1=name %2=extension %3=source %4=drive %5=path %6=errorfile
REM Standalone: COMDATABASETRANSACT.BAT "source.sql" "errors.err" -U sa
REM TSE: append -U sa after the existing six arguments.
REM -U selects SQL authentication; SQLCMD requests the password at run time.
REM Omit -P completely to request a hidden password prompt.
REM -P "" means an EMPTY password, not an interactive prompt.
REM Inherited SQLCMDPASSWORD and OSQLPASSWORD are cleared locally for prompting.
REM TSE mode is recognized by argument 2 being .sql or sql.
REM Optional standalone %3 overrides sqlcmd.exe, %4 server, %5 database.
REM Executable/server/database overrides apply only in standalone mode.
REM Environment overrides work in both modes; set these before launching TSE.
if not defined COMDATABASETRANSACT_EXE set "COMDATABASETRANSACT_EXE=c:\program files\microsoft sql server\client sdk\odbc\170\tools\binn\sqlcmd.exe"
if not defined COMDATABASETRANSACT_SERVER set "COMDATABASETRANSACT_SERVER=localhost"
if not defined COMDATABASETRANSACT_DATABASE set "COMDATABASETRANSACT_DATABASE=master"
REM Legacy database override is also accepted.
if defined databasetransactsql set "COMDATABASETRANSACT_DATABASE=%databasetransactsql%"
REM Blank user means Windows authentication (-E). Set USER for SQL authentication.
REM Default SQL login is sa. Override with -U username.
REM No password is stored; SQLCMD performs hidden console input.
if not defined COMDATABASETRANSACT_USER set "COMDATABASETRANSACT_USER=sa"
if not defined COMDATABASETRANSACT_PAUSE set "COMDATABASETRANSACT_PAUSE=yes"
REM Test from native TCC (adjust runner and source paths):
REM G:\UTILS\JPSoft\TCMD\tcc.exe /c COMDATABASETRANSACT.BAT "helloworlddatabasetransact.sql" "hello-tcc.err" -U sa
REM G:\UTILS\JPSoft\TCMD\tcc.exe /c COMDATABASETRANSACT.BAT "errorstestdatabasetransact.sql" "errors-tcc.err" -U sa
REM Test from native CMD:
REM cmd.exe /d /c COMDATABASETRANSACT.BAT "helloworlddatabasetransact.sql" "hello-cmd.err" -U sa
REM cmd.exe /d /c COMDATABASETRANSACT.BAT "errorstestdatabasetransact.sql" "errors-cmd.err" -U sa
REM Expected: hello -> no TSE error records; errors -> three records and exit 1.
REM Example override (quote executable paths containing spaces):
REM COMDATABASETRANSACT.BAT "hello.sql" "hello.err" "C:\SQL Tools\sqlcmd.exe" "localhost" "master"
REM SQL is executed, not merely syntax-checked. The supplied tests change no data.
REM Multiple errors: omit -b so later errors/batches can still be reported.
REM Line numbers: exact for ordinary SQL in ONE batch, as in the supplied tests.
REM SQL Server reports batch-relative lines after GO and procedure-relative lines
REM inside stored procedures. This runner does not remap those cases or :r files.
REM Column is unavailable from SQL Server; column 1 is an explicit fallback.
REM Header parsing expects English Msg/Line labels in sqlcmd diagnostics.
REM ------------------------------------------------------------------------------
REM PART 2 - SYSTEM CODE; NO USER CHANGES NORMALLY REQUIRED
set "version=1.0.0.0.13"
set "rc=0"
set "count=0"
set "pending="
set "raw="
REM SETLOCAL keeps these changes confined to this BAT invocation.
set "SQLCMDPASSWORD="
set "OSQLPASSWORD="
set "explicitPassword="
if /i "%~2"==".sql" goto tseArguments
if /i "%~2"=="sql" goto tseArguments
if "%~1"=="" goto usage
set "source=%~f1"
set "errors=%~f2"
if "%~2"=="" set "errors=%~dpn1.err"
shift
if not "%~1"=="" shift
set "position=0"
goto parseOptions
:tseArguments
set "source=%~f3"
set "errors=%~f6"
shift
shift
shift
shift
shift
shift
set "position=3"
:parseOptions
if "%~1"=="" goto argumentsReady
if /i "%~1"=="-U" goto userOption
if /i "%~1"=="-P" goto passwordOption
if "%position%"=="0" goto exeOption
if "%position%"=="1" goto serverOption
if "%position%"=="2" goto databaseOption
goto badArguments
:exeOption
set "COMDATABASETRANSACT_EXE=%~1"
set "position=1"
shift
goto parseOptions
:serverOption
set "COMDATABASETRANSACT_SERVER=%~1"
set "position=2"
shift
goto parseOptions
:databaseOption
set "COMDATABASETRANSACT_DATABASE=%~1"
set "position=3"
shift
goto parseOptions
:userOption
if "%~2"=="" goto badArguments
set "COMDATABASETRANSACT_USER=%~2"
shift
shift
goto parseOptions
:passwordOption
REM A trailing bare -P is accepted as a request to prompt.
if "%~2"=="" goto promptPassword
REM sqlcmd reads the supplied -P value through its local environment.
set "SQLCMDPASSWORD=%~2"
set "explicitPassword=yes"
shift
shift
goto parseOptions
:promptPassword
set "SQLCMDPASSWORD="
set "explicitPassword="
shift
goto parseOptions
:argumentsReady
echo COMDATABASETRANSACT version %version%
REM JPSoft documented test: numeric equality in TCC, string inequality in CMD.
set "parserName=CMD"
if 01 == 1 set "parserName=TCC"
echo Parser: %parserName%
if /i "%source%"=="%errors%" goto badOutput
REM Never use IF EXIST filename\ to determine whether source is a directory.
if 01 == 1 goto tccDirectory
if exist "%source%\NUL" goto badSource
goto checkSource
:tccDirectory
if isdir "%source%" goto badSource
:checkSource
if not exist "%source%" goto badSource
if /i "%source%"=="%errors%" goto badOutput
if not exist "%COMDATABASETRANSACT_EXE%" goto badExe
>"%errors%" echo filename=%source%
if errorlevel 1 goto badOutput
set "raw=%errors%.sqlcmd.raw"
if /i "%source%"=="%raw%" goto badOutput
set "auth=-E"
if defined COMDATABASETRANSACT_USER set "auth=-U "%COMDATABASETRANSACT_USER%""
REM SQL Server diagnostics use stdout by default and are captured for TSE.
REM Leave stderr on the console so authentication prompts/client errors are visible.
REM No -b: retain multiple-error reporting.
if defined COMDATABASETRANSACT_USER if not defined explicitPassword echo Enter the SQL Server password when requested; input is hidden.
"%COMDATABASETRANSACT_EXE%" -S "%COMDATABASETRANSACT_SERVER%" -d "%COMDATABASETRANSACT_DATABASE%" %auth% -l 15 -i "%source%" >"%raw%"
set "rc=%errorlevel%"
type "%raw%"
REM Read records with expansion disabled to preserve exclamation marks in SQL.
for /f "usebackq delims=" %%L in ("%raw%") do (
  set "record=%%L"
  call :parseRecord
)
if not "%count%"=="0" set "rc=1"
if "%rc%"=="0" goto summary
if not "%count%"=="0" goto summary
>>"%errors%" echo TSE: %source%:1:1: sqlcmd failed; see console and raw log.
:summary
echo.
echo Errors detected: %count%
echo Exit code: %rc%
echo Raw output: "%raw%"
goto finish
:parseRecord
if 01 == 1 goto parseRecordTcc
setlocal EnableDelayedExpansion
REM The hidden-input prompt can share a line with the first SQL diagnostic.
if "!record:~0,10!"=="Password: " set "record=!record:~10!"
if "!record:~0,9!"=="Password:" set "record=!record:~9!"
if not "!record:~0,4!"=="Msg " goto messageRecord
REM Read comma-separated header fields without CMD wildcard substitution.
set "tail=!record!"
set "line="
:nextHeaderField
set "field="
set "rest="
for /f "tokens=1,* delims=," %%A in ("!tail!") do (
  set "field=%%A"
  set "rest=%%B"
)
for /f "tokens=1,2" %%A in ("!field!") do if /i "%%A"=="Line" set "line=%%B"
set "tail=!rest!"
if defined tail goto nextHeaderField
if not defined line goto unparsedRecord
REM Reject any suffix which is not a positive integer.
for /f "delims=0123456789" %%N in ("!line!") do goto unparsedRecord
if not defined line goto unparsedRecord
if "!line!"=="0" set "line=1"
>>"!errors!" echo TSE: !source!:!line!:1: !record! [column unavailable; using 1]
endlocal
set /a count+=1
set "pending=yes"
exit /b
:messageRecord
if defined pending >>"!errors!" echo     !record!
endlocal
set "pending="
exit /b
:unparsedRecord
>>"!errors!" echo TSE: !source!:1:1: !record! [location unavailable]
endlocal
set /a count+=1
set "pending=yes"
exit /b
:parseRecordTcc
REM Native TCC path: no CMD FOR /F token validation or wildcard replacement.
REM Only inspect the prefix before using @WORD on a SQL diagnostic header.
set "head=%@left[10,%record%]"
if "%head%"=="Password: " set "record=%@right[-10,%record%]"
set "head=%@left[4,%record%]"
if not "%head%"=="Msg " exit /b
REM SQLCMD headers end with: Line N. TCC -0 means the LAST word.
set "sqlLineLabel=%@word[-1,%record%]"
set "sqlLineNumber=%@word[-0,%record%]"
if /i not "%sqlLineLabel%"=="Line" goto tccUnknownLocation
if %@numeric[%sqlLineNumber%] NE 1 goto tccUnknownLocation
if %sqlLineNumber% LT 1 goto tccUnknownLocation
>>"%errors%" echo TSE: %source%:%sqlLineNumber%:1: %record% [column unavailable; using 1]
echo TSE location: line %sqlLineNumber%, column 1
set /a count+=1
exit /b
:tccUnknownLocation
>>"%errors%" echo TSE: %source%:1:1: %record% [location unavailable]
echo WARNING: could not extract SQL line number.
set /a count+=1
exit /b
:badSource
echo ERROR: source file not found or is a directory: "%source%"
set "rc=2"
if not "%errors%"=="" >"%errors%" echo TSE: %source%:1:1: Source missing or is a directory.
goto finish
:badExe
echo ERROR: sqlcmd executable not found: "%COMDATABASETRANSACT_EXE%"
>"%errors%" echo TSE: %source%:1:1: sqlcmd executable not found; check USER SETTINGS.
set "rc=2"
goto finish
:badOutput
echo ERROR: invalid output path or output conflicts with source.
set "rc=2"
goto finish
:badArguments
echo ERROR: invalid arguments or missing value for -U or -P.
goto usage
:usage
echo Usage: COMDATABASETRANSACT.BAT "source.sql" "errors.err" -U username
set "rc=2"
:finish
if /i "%COMDATABASETRANSACT_PAUSE%"=="yes" pause
endlocal & exit /b %rc%
