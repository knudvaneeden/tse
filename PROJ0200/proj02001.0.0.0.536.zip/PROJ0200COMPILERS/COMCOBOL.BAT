@echo off
REM COMCOBOL version 1.0.0.0.10 - 2026-10-09
REM Run COBOL program. Updated with OpenAI Codex.
REM PART 1 contains installation settings; PART 2 is shared logic.
REM Direct test: COMCOBOL.BAT "C:\sources with spaces\errorstest.cob"
REM CMD test: cmd.exe /d /c COMCOBOL.BAT "C:\sources\errorstest.cob"
REM TCC test: run the direct test in an existing native TCC console.
REM TSE call: COMCOBOL.BAT name ext fullfile drive subpath errfile
REM Example: COMCOBOL.BAT "errorstest" "cob" "C:\sources\errorstest.cob" "C" "\sources" "C:\TEMP\cobol.err"
REM Parameters 1/2/4/5 are accepted for TSE compatibility.
REM Parameter 3 selects the source; parameter 6 receives all diagnostics.
REM --testjump produces three synthetic diagnostics, without compiling.
REM Test both shells with --testjump and with the actual errorstest.cob.
REM For a successful program, replace the three missing names in the test
REM with quoted text. Compilation errors prevent execution of stale EXEs.
REM GnuCOBOL's line-only diagnostics jump to column 1 (fallback, not exact).
REM No PowerShell, generated helper scripts, or nested TCC invocation.

setlocal
REM ================= PART 1: USER SETTINGS =================
set "COMCOBOL_ROOT=G:\language\computer\cobol\gnucobol\gnucobol-win32-mingw-master"
set "COMCOBOL_COMPILER=%COMCOBOL_ROOT%\bin\cobc.exe"
REM Optional vendor environment setup, called in this shell when present.
set "COMCOBOL_ENV=%COMCOBOL_ROOT%\set_env.cmd"
REM Default source format is fixed. Test file supplies its own FREE directive.
REM Add compiler options here if needed, e.g. -free for other free-form files.
set "COMCOBOL_OPTIONS="
set "COMCOBOL_PAUSE=yes"

REM ================= PART 2: SHARED LOGIC ==================
set "COMCOBOL_VERSION=1.0.0.0.10"
set "COMCOBOL_RC=1"
set "COMCOBOL_PUSHED=no"
set "COMCOBOL_SHELL=CMD"
REM TCC internal variables are not environment variables: do not use DEFINED.
if /i "%_CMDPROC%"=="TCC" set "COMCOBOL_SHELL=TCC"
if /i "%_CMDPROC%"=="TCC-RT" set "COMCOBOL_SHELL=TCC"
echo COMCOBOL version %COMCOBOL_VERSION%
echo Shell: %COMCOBOL_SHELL%
if "%~1"=="" goto usage
if "%~1"=="--testjump" goto testjump
set "COMCOBOL_SOURCE=%~1"
if not "%~3"=="" set "COMCOBOL_SOURCE=%~3"
for %%F in ("%COMCOBOL_SOURCE%") do set "COMCOBOL_SOURCE=%%~fF"
set "COMCOBOL_ERR=%TEMP%\COMCOBOL_%RANDOM%_%RANDOM%.err"
if not "%~6"=="" set "COMCOBOL_ERR=%~f6"
> "%COMCOBOL_ERR%" echo COMCOBOL version %COMCOBOL_VERSION%
if errorlevel 1 goto logfailed
>> "%COMCOBOL_ERR%" echo filename=%COMCOBOL_SOURCE%
>> "%COMCOBOL_ERR%" echo column=1
if not exist "%COMCOBOL_SOURCE%" goto missing
if "%COMCOBOL_SHELL%"=="TCC" goto checktcc
if exist "%COMCOBOL_SOURCE%\NUL" goto missing
goto setup
:checktcc
if isdir "%COMCOBOL_SOURCE%" goto missing
:setup
if exist "%COMCOBOL_ENV%" call "%COMCOBOL_ENV%" >> "%COMCOBOL_ERR%" 2>&1
set "COB_CONFIG_DIR=%COMCOBOL_ROOT%\config"
set "COB_LIBRARY_PATH=%COMCOBOL_ROOT%\lib"
set "PATH=%COMCOBOL_ROOT%\bin;%PATH%"
if not exist "%COMCOBOL_COMPILER%" goto compilerfailed
for %%F in ("%COMCOBOL_SOURCE%") do set "COMCOBOL_DIR=%%~dpF"
for %%F in ("%COMCOBOL_SOURCE%") do set "COMCOBOL_NAME=%%~nxF"
REM An isolated output folder prevents executing an EXE from an earlier run.
set "COMCOBOL_WORK=%TEMP%\COMCOBOL_%RANDOM%_%RANDOM%"
if exist "%COMCOBOL_WORK%" goto workfailed
mkdir "%COMCOBOL_WORK%" >> "%COMCOBOL_ERR%" 2>&1
if errorlevel 1 goto workfailed
pushd "%COMCOBOL_DIR%"
if errorlevel 1 goto workfailed
set "COMCOBOL_PUSHED=yes"
echo Compiling "%COMCOBOL_SOURCE%"
"%COMCOBOL_COMPILER%" -x %COMCOBOL_OPTIONS% "%COMCOBOL_NAME%" -o "%COMCOBOL_WORK%\program.exe" >> "%COMCOBOL_ERR%" 2>&1
set "COMCOBOL_RC=%ERRORLEVEL%"
type "%COMCOBOL_ERR%"
echo Compile exit code: %COMCOBOL_RC%
if not "%COMCOBOL_RC%"=="0" goto cleanup
if not exist "%COMCOBOL_WORK%\program.exe" goto noexe
echo Running "%COMCOBOL_SOURCE%"
REM Interactive program output stays on the console; compiler errors are in %6.
"%COMCOBOL_WORK%\program.exe"
set "COMCOBOL_RC=%ERRORLEVEL%"
echo Run exit code: %COMCOBOL_RC%
goto cleanup
:noexe
set "COMCOBOL_RC=1"
echo ERROR: compiler reported success but no executable was created.
goto cleanup
:missing
>> "%COMCOBOL_ERR%" echo ERROR: source file not found or is a directory: "%COMCOBOL_SOURCE%"
goto showfailed
:compilerfailed
>> "%COMCOBOL_ERR%" echo ERROR: compiler not found: "%COMCOBOL_COMPILER%"
goto showfailed
:workfailed
>> "%COMCOBOL_ERR%" echo ERROR: cannot create build folder or enter source folder.
goto showfailed
:showfailed
type "%COMCOBOL_ERR%"
set "COMCOBOL_RC=1"
goto cleanup
:logfailed
echo ERROR: cannot write diagnostics to "%COMCOBOL_ERR%"
goto finish
:usage
echo Usage: COMCOBOL.BAT "full-source.cob"
echo Or: COMCOBOL.BAT name ext fullfile drive subpath errfile
echo Or: COMCOBOL.BAT --testjump
goto finish
:testjump
set "COMCOBOL_ERR=%TEMP%\COMCOBOL_%RANDOM%_%RANDOM%.err"
if not "%~6"=="" set "COMCOBOL_ERR=%~f6"
> "%COMCOBOL_ERR%" echo COMCOBOL version %COMCOBOL_VERSION%
if errorlevel 1 goto logfailed
>> "%COMCOBOL_ERR%" echo filename=%~dp0errorstest.cob
>> "%COMCOBOL_ERR%" echo column=1
>> "%COMCOBOL_ERR%" echo errorstest.cob:8: error: 'missing-first' is not defined
>> "%COMCOBOL_ERR%" echo errorstest.cob:9: error: 'missing-second' is not defined
>> "%COMCOBOL_ERR%" echo errorstest.cob:10: error: 'missing-third' is not defined
type "%COMCOBOL_ERR%"
set "COMCOBOL_RC=0"
goto finish
:cleanup
if "%COMCOBOL_PUSHED%"=="yes" popd
if not defined COMCOBOL_WORK goto finish
if "%COMCOBOL_SHELL%"=="TCC" goto cleanuptcc
if exist "%COMCOBOL_WORK%\program.exe" del /q "%COMCOBOL_WORK%\program.exe" >nul 2>&1
if exist "%COMCOBOL_WORK%" rmdir "%COMCOBOL_WORK%" >nul 2>&1
goto finish
:cleanuptcc
REM A leading asterisk bypasses user aliases and calls the TCC built-in.
if exist "%COMCOBOL_WORK%\program.exe" *del /q "%COMCOBOL_WORK%\program.exe" >nul 2>&1
if isdir "%COMCOBOL_WORK%" *rmdir "%COMCOBOL_WORK%" >nul 2>&1
:finish
if defined COMCOBOL_ERR echo Diagnostics saved to "%COMCOBOL_ERR%"
echo Exit code: %COMCOBOL_RC%
if /i not "%COMCOBOL_PAUSE%"=="yes" goto returncode
if "%COMCOBOL_SHELL%"=="TCC" goto pausetcc
pause
goto returncode
:pausetcc
*pause
:returncode
endlocal & exit /b %COMCOBOL_RC%
