@echo off
setlocal DisableDelayedExpansion
REM COMLATEXMIKTEX.BAT version 1.0.0.0.14
REM Created with OpenAI ChatGPT - 2026-10-17
REM Run LATEXMIKTEX program
REM ---------------- USER SETTINGS ------------------------------------------
REM Executable override: set "COMLATEXMIKTEX_EXE=C:\MiKTeX\bin\x64\pdflatex.exe"
set "latexExe=g:\language\computer\tex\miktex\texmfs\install\miktex\bin\x64\pdflatex.exe"
if defined COMLATEXMIKTEX_EXE set "latexExe=%COMLATEXMIKTEX_EXE%"
REM Set COMLATEXMIKTEX_PAUSE=0 to suppress the final pause.
set "pauseAtEnd=1"
if defined COMLATEXMIKTEX_PAUSE set "pauseAtEnd=%COMLATEXMIKTEX_PAUSE%"
REM Open a newly generated PDF in the default Windows PDF viewer.
REM Set to 0 to disable. Environment override: COMLATEXMIKTEX_OPENPDF=0 or 1.
set "openPdf=1"
if defined COMLATEXMIKTEX_OPENPDF set "openPdf=%COMLATEXMIKTEX_OPENPDF%"
REM No automatic package installation dialogs; install missing packages first.
set "latexOptions=--interaction=nonstopmode --file-line-error --disable-installer --disable-write18"
REM ---------------- END USER SETTINGS --------------------------------------
REM Direct: COMLATEXMIKTEX.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.tex"
REM Optional second argument in direct mode: full path to pdflatex.exe.
REM TSE six arguments: name, extension, full filename, drive, path, output.
REM TSE uses argument 3 as the source; argument 6 receives console output.
REM Native TCC tests (run each test separately):
REM "G:\UTILS\JPSoft\TCMD\tcc.exe" /c COMLATEXMIKTEX.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.tex"
REM "G:\UTILS\JPSoft\TCMD\tcc.exe" /c COMLATEXMIKTEX.BAT "F:\BBC\TAAL\PROJ0200HELLOWORLD\helloworld.tex"
REM CMD tests (run each test separately):
REM cmd.exe /d /c COMLATEXMIKTEX.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.tex"
REM cmd.exe /d /c COMLATEXMIKTEX.BAT "F:\BBC\TAAL\PROJ0200HELLOWORLD\helloworld.tex"
REM Expected: hello exit 0 and PDF; error test exit 1, three undefined commands.
REM Check jumps to lines 7, 9, 11, column 1 in TSE.
REM MiKTeX does not report exact error columns; column 1 is a fallback.
REM PDF and auxiliary files are written beside the source.
REM A fresh PDF opens even after recoverable LaTeX errors (exit code 1).
REM An unchanged PDF left by an earlier run is not opened.
REM No generated helper scripts. Windows FINDSTR filters diagnostic lines.
REM ---------------- IMPLEMENTATION -----------------------------------------
set "source=%~1"
set "capture="
set "pdfWritten=0"
if not "%~3"=="" goto tseArguments
if not "%~2"=="" set "latexExe=%~2"
goto argumentsReady
:tseArguments
set "source=%~3"
set "capture=%~6"
:argumentsReady
if not defined capture goto runUncaptured
call :run >"%capture%" 2>&1
set "result=%errorlevel%"
type "%capture%"
goto finish
:runUncaptured
call :run
set "result=%errorlevel%"
:finish
call :openGeneratedPdf
if "%pauseAtEnd%"=="0" goto exitNow
pause
:exitNow
endlocal & exit /b %result%

:run
echo COMLATEXMIKTEX.BAT version 1.0.0.0.14
if not defined source goto noSource
for %%F in ("%source%") do set "source=%%~fF"
if not exist "%source%" goto missingSource
REM TCC must use ISDIR; do not use IF EXIST "filename\" there.
if defined _4VER goto tccDirectory
for %%F in ("%source%") do set "sourceAttributes=%%~aF"
if /i "%sourceAttributes:~0,1%"=="d" goto missingSource
goto sourceChecked
:tccDirectory
if isdir "%source%" goto missingSource
:sourceChecked
if not exist "%latexExe%" goto missingExe
for %%F in ("%source%") do set "sourceDir=%%~dpF"
for %%F in ("%source%") do set "sourceName=%%~nxF"
for %%F in ("%source%") do set "pdfFile=%%~dpnF.pdf"
set "rawLog=%TEMP%\COMLATEXMIKTEX_%RANDOM%_%RANDOM%.tmp"
pushd "%sourceDir%"
if errorlevel 1 goto badDirectory
"%latexExe%" %latexOptions% "%sourceName%" >"%rawLog%" 2>&1
set "compilerResult=%errorlevel%"
type "%rawLog%"
echo.
REM Print separate, unambiguous TSE records after the complete original log.
REM Filter file input directly, without a pipe or reparsing warning text.
%SystemRoot%\System32\findstr.exe /r /c:"[.]tex:[0-9][0-9]*:" "%rawLog%" >"%rawLog%.errors"
for /f "usebackq tokens=1,2,3,* delims=:" %%A in ("%rawLog%.errors") do (
    set "errorFile=%%A"
    set "errorLine=%%B"
    set "errorPart3=%%C"
    set "errorPart4=%%D"
    call :diagnostic
)
set "pdfWritten=0"
%SystemRoot%\System32\findstr.exe /b /c:"Output written on " "%rawLog%" >nul
if not errorlevel 1 set "pdfWritten=1"
del "%rawLog%.errors" >nul 2>&1
del "%rawLog%" >nul 2>&1
popd
if "%compilerResult%"=="0" for %%F in ("%source%") do echo PDF output: "%%~dpnF.pdf"
echo Exit code: %compilerResult%
exit /b %compilerResult%

:openGeneratedPdf
if not "%openPdf%"=="1" exit /b
if not "%pdfWritten%"=="1" exit /b
if not exist "%pdfFile%" exit /b
echo Opening PDF: "%pdfFile%"
REM Use Windows START; keep native TCC batch execution for compilation.
"%SystemRoot%\System32\cmd.exe" /d /c start "" "%pdfFile%"
exit /b

:diagnostic
REM Fields already split from file input, including an optional drive colon.
if not defined errorFile exit /b
set "errorMessage=%errorPart3%"
if defined errorPart4 set "errorMessage=%errorPart3%:%errorPart4%"
if not "%errorFile:~1%"=="" goto validateDiagnostic
set "errorFile=%errorFile%:%errorLine%"
set "errorLine=%errorPart3%"
set "errorMessage=%errorPart4%"
:validateDiagnostic
if not defined errorLine exit /b
set "nonDigits=%errorLine%"
set "nonDigits=%nonDigits:0=%"
set "nonDigits=%nonDigits:1=%"
set "nonDigits=%nonDigits:2=%"
set "nonDigits=%nonDigits:3=%"
set "nonDigits=%nonDigits:4=%"
set "nonDigits=%nonDigits:5=%"
set "nonDigits=%nonDigits:6=%"
set "nonDigits=%nonDigits:7=%"
set "nonDigits=%nonDigits:8=%"
set "nonDigits=%nonDigits:9=%"
if defined nonDigits exit /b
if not defined errorMessage exit /b
if exist "%errorFile%" goto diagnosticFileFound
set "errorFile=%sourceDir%%errorFile%"
if not exist "%errorFile%" exit /b
:diagnosticFileFound
for %%F in ("%errorFile%") do set "errorFile=%%~fF"
REM Delayed expansion safely prints metacharacters in diagnostic text.
setlocal EnableDelayedExpansion
echo TSEERROR: !errorFile!(!errorLine!,1^): !errorMessage! [column unavailable; using 1]
endlocal
exit /b
:noSource
echo ERROR: supply a .tex source filename.
exit /b 2
:missingSource
echo ERROR: source file not found or is a directory: "%source%"
exit /b 2
:missingExe
echo ERROR: pdflatex executable not found: "%latexExe%"
exit /b 2
:badDirectory
echo ERROR: cannot enter source directory: "%sourceDir%"
exit /b 2
