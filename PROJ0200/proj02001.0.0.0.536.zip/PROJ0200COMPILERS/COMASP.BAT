@echo off
REM COMASP.BAT - Classic ASP runner, version 1.0.0.8
REM Updated 2026-10-06 03:18 +02:00; OpenAI GPT-6 (Codex).
REM PART 1 - USER SETTINGS AND TEST INSTRUCTIONS
REM Keep COMASP.ps1 beside this BAT. Requires Windows PowerShell 5.1 + IIS ASP.
REM Configure a local IIS site's physical root and matching HTTP URL below.
REM IIS ASP / Debugging Properties / Send Errors To Browser must be True.
REM IIS Error Pages must preserve the detailed ASP response for local requests.
REM Only this page is deployed; its dependencies must already be installed.
REM TCC entry delegates to Windows CMD for consistent quoting and errorlevel.
REM OVERWRITE_PAGE=1 replaces the deployed page for repeated tests.
REM The deployed file remains in IIS. The request executes the page once;
REM OPEN_BROWSER=1 requests it again after success. Default 0 avoids this.
REM BROWSER_EXE empty uses the default browser. PAUSE_AT_END: 1=yes, 0=no.
REM
REM Direct call: COMASP.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\errorstest.asp"
REM TSE call: COMASP.BAT "errorstest" "asp" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\errorstest.asp" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\comasp_test.err"
REM Parameters: 1=source or TSE stem, 2=TSE extension, 3=TSE full source,
REM 4/5=legacy drive/path unused, 6=TSE diagnostics file (optional).
REM Quote arguments. Diagnostics parent directory must exist.
REM External test commands (run from this BAT's directory):
REM tcc.exe /c COMASP.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\errorstest.asp"
REM cmd.exe /d /c COMASP.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\errorstest.asp"
REM tcc.exe /c COMASP.BAT "errorstest" "asp" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\errorstest.asp" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\comasp_tcc.err"
REM cmd.exe /d /c COMASP.BAT "errorstest" "asp" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\errorstest.asp" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\comasp_cmd.err"
REM Expect one Error record on the first failing request. Fix it and repeat.
REM Column 1 is explicitly labelled as a fallback when IIS omits a column.
REM Set OVERWRITE_PAGE=0 if existing deployed pages must be protected.
REM Also test missing source and an invalid IIS directory: expect nonzero exit.
REM Windows TCC/CMD/IIS execution must be tested on the user's machine.
REM
if "%COMASP_CMD_ENGINE%"=="1" goto cmdMain
setlocal
set COMASP_CMD_ENGINE=1
"%SystemRoot%\System32\cmd.exe" /d /s /c ""%~f0" %*"
set COMASP_WRAPPER_RC=%errorlevel%
endlocal & exit /b %COMASP_WRAPPER_RC%
:cmdMain
setlocal EnableExtensions DisableDelayedExpansion
set "COMASP_CMD_ENGINE="
set "ASP_WEB_ROOT=C:\inetpub\wwwroot"
set "ASP_BASE_URL=http://localhost/"
set "POWERSHELL_EXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "BROWSER_EXE="
set "OPEN_BROWSER=0"
set "PAUSE_AT_END=1"
set "OVERWRITE_PAGE=1"
set "HTTP_TIMEOUT_SECONDS=30"
REM PART 2 - STABLE EXECUTION LOGIC
set "COMASP_SOURCE=%~f1"
if not "%~3"=="" set "COMASP_SOURCE=%~f3"
set "COMASP_LOG=%TEMP%\COMASP_%RANDOM%_%RANDOM%.err"
if not "%~6"=="" set "COMASP_LOG=%~f6"
if not exist "%POWERSHELL_EXE%" goto missingTool
if not exist "%~dp0COMASP.ps1" goto missingHelper
"%POWERSHELL_EXE%" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0COMASP.ps1"
set "COMASP_RC=%errorlevel%"
goto finish
:missingTool
echo ERROR: PowerShell not found: "%POWERSHELL_EXE%"
set "COMASP_RC=2"
goto finish
:missingHelper
echo ERROR: COMASP.ps1 must be beside COMASP.BAT.
set "COMASP_RC=2"
:finish
echo Exit code: %COMASP_RC%
if "%PAUSE_AT_END%"=="1" pause
endlocal & exit /b %COMASP_RC%
