@echo off
REM COMTCC.BAT version 1.0.0.0.9 - Run TCC program
REM Created with OpenAI ChatGPT; 2026-10-17.
REM Runs the source, rather than compiling it. Source commands take effect.
REM No helper program is used or generated.
REM
REM ==================== USER SETTINGS ====================
set "TCC_EXE=G:\UTILS\JPSoft\TCMD\tcc.exe"
set "COMTCC_PAUSE=1"
REM Set COMTCC_PAUSE above to 0 to suppress the final pause.
REM Optional executable override: set COMTCC_EXE before calling this file.
REM
REM PARAMETERS:
REM   1 = source filename, or TSE base name in the six-parameter form.
REM   2 = extension; 3 = full source filename; 4 = drive; 5 = path;
REM   6 = TSE output filename. This runner captures output there, then
REM displays it in the console and pauses before returning to TSE.
REM The rule must not redirect output a second time.
REM Examples (run from the directory containing COMTCC.BAT):
REM   COMTCC.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\helloworld.bat"
REM   COMTCC.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.bat"
REM Executable override, in either TCC or CMD:
REM   set "COMTCC_EXE=G:\UTILS\JPSoft\TCMD\tcc.exe"
REM
REM TEST FROM TCC (full paths also work when they contain spaces):
REM   G:\UTILS\JPSoft\TCMD\tcc.exe /A /I //CMDBatch=No /C call COMTCC.BAT helloworld.bat
REM   G:\UTILS\JPSoft\TCMD\tcc.exe /A /I //CMDBatch=No /C call COMTCC.BAT errorstest.bat
REM TEST FROM CMD:
REM   cmd.exe /D /C call COMTCC.BAT helloworld.bat
REM   cmd.exe /D /C call COMTCC.BAT errorstest.bat
REM Both tests must use TCC to execute the source. Expect Hello world or
REM three Unknown command errors at lines 7, 9 and 11; jump to each in TSE.
REM Column 1 is a fallback: TCC does not supply a token column here.
REM Six-parameter test:
REM   COMTCC.BAT "errorstest" ".bat" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.bat" "F:" "\BBC\TAAL\PROJ0200ERRORSMULTIPLE\" ""
REM ------------------------------------------------------------------------------
REM ==================== FIXED IMPLEMENTATION ====================
setlocal
if defined COMTCC_EXE set "TCC_EXE=%COMTCC_EXE%"
set "COMTCC_RC=1"
REM Re-enter this same BAT to capture diagnostics, without any helper file.
REM The private environment flag suppresses only the captured run's pause.
if defined COMTCC_CAPTURE goto captured_run
if "%~6"=="" goto captured_run
set "COMTCC_CAPTURE=1"
call "%~f0" "%~1" "%~2" "%~3" "%~4" "%~5" "" > "%~6" 2>&1
set "COMTCC_RC=%ERRORLEVEL%"
set "COMTCC_CAPTURE="
if not exist "%~6" goto capture_failed
type "%~6"
goto finish
:capture_failed
echo ERROR: could not create TSE output file: "%~6"
set "COMTCC_RC=1"
goto finish
:captured_run
if defined COMTCC_CAPTURE set "COMTCC_PAUSE=0"
echo COMTCC.BAT version 1.0.0.0.9
if "%~1"=="" goto usage
set "COMTCC_SOURCE=%~f1"
if not "%~3"=="" set "COMTCC_SOURCE=%~f3"
if not exist "%COMTCC_SOURCE%" goto missing
REM Do not test IF EXIST filename\ under TCC: it can match a file.
if defined _TCC goto tcc_directory_test
for %%D in ("%COMTCC_SOURCE%") do set "COMTCC_ATTR=%%~aD"
if /I "%COMTCC_ATTR:~0,1%"=="d" goto directory
 goto checked
:tcc_directory_test
if isdir "%COMTCC_SOURCE%" goto directory
:checked
if not exist "%TCC_EXE%" goto no_exe
REM filename and column metadata are consumed by the TSE rule.
echo filename=%COMTCC_SOURCE%
echo column=1
echo Running "%COMTCC_SOURCE%"
REM /I prevents startup scripts/plugins; CMDBatch=No forces native TCC.
REM CALL provides reliable handling of a quoted source pathname.
"%TCC_EXE%" /A /I //CMDBatch=No /C call "%COMTCC_SOURCE%" 2>&1
set "COMTCC_RC=%ERRORLEVEL%"
echo TCC exit code: %COMTCC_RC%
REM The final exit code alone does not count earlier nonfatal errors.
goto finish
:usage
echo Usage: COMTCC.BAT "source.bat"
echo Or: COMTCC.BAT "name" ".bat" "full source path" "drive" "path" "output"
goto finish
:missing
echo ERROR: source file not found: "%COMTCC_SOURCE%"
goto finish
:directory
echo ERROR: source is a directory: "%COMTCC_SOURCE%"
goto finish
:no_exe
echo ERROR: TCC executable not found: "%TCC_EXE%"
echo Edit TCC_EXE in the user settings, or set COMTCC_EXE.
:finish
if "%COMTCC_PAUSE%"=="1" pause
endlocal & exit /b %COMTCC_RC%
