@echo off
REM COMEIFFEL version 1.0.0.0.10 - OpenAI GPT-6
REM PART 1 below contains the user-specific settings.
REM Single-file test from native TCC:
REM   COMEIFFEL.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.e"
REM CMD test from either shell:
REM   cmd.exe /d /c COMEIFFEL.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.e"
REM Six-parameter TSE test:
REM   COMEIFFEL.BAT "errorstest" ".e" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.e" "F:" "\BBC\TAAL\PROJ0200ERRORSMULTIPLE\" "C:\TEMP\eiffel.err"
REM Parameters: %1=name, %2=extension, %3=full filename,
REM             %4=drive, %5=directory, %6=TSE error output file.
REM With one parameter, %1 is the full source filename.
REM Source must contain one executable root class with creation routine make.
REM No PowerShell, Python, or other diagnostic helper is used.
REM Raw diagnostics are retained beside the error file as .raw.
REM Validity errors without a reported column use column 1.
REM Source/build/output paths containing exclamation marks are unsupported.

REM ================= INSTALLATION AND USE =================
REM COMEIFFEL version 1.0.0.0.10 - OpenAI GPT-6
REM
REM 1. Place COMEIFFEL.BAT on your executable search path.
REM 2. PART 1 points to your existing eiffelknud.bat. That wrapper must
REM    forward all arguments to ec.exe with %* and return its exit code.
REM    It must not use START to launch ec.exe asynchronously.
REM 3. Save errorstest.e at:
REM    F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.e
REM 4. Save helloworld.e in the same directory.
REM 5. Enter the settings from comeiffelbatcompilersetting_e.txt into
REM    TSE's compiler configuration. It contains the .e
REM    rule. Message uses Tag=0.
REM
REM Native TCC test:
REM   COMEIFFEL.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.e"
REM
REM CMD test (can be entered from TCC):
REM   cmd.exe /d /c COMEIFFEL.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.e"
REM
REM Hello-world test:
REM   COMEIFFEL.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\helloworld.e"
REM
REM Six-parameter test:
REM   COMEIFFEL.BAT "errorstest" ".e" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.e" "F:" "\BBC\TAAL\PROJ0200ERRORSMULTIPLE\" "C:\TEMP\eiffel.err"
REM
REM Eiffel can report multiple validity errors. The error test contains three
REM intentional INTEGER/string assignment errors, on lines 17, 18, and 19.
REM Error recovery can differ for syntax errors; do not assume every later
REM error will be reported after an earlier syntax error.
REM
REM The compiler's multiline validity reports are converted by BAT built-ins
REM into TSE: line:column: error: code/message records. No helper program
REM is required. The original filename is retained for TSE jumping.
REM Column defaults to 1 when the report supplies only a line. A column on
REM the same Line: record is used if reported. Column 1 is a fallback, not
REM an exact compiler measurement. Configuration, C-toolchain and unrecognized
REM errors may use a fallback line 1 message; inspect the raw log in that case.
REM
REM This is a single-source runner, not a replacement for an existing ECF
REM project build. It copies the selected .e source to a private temporary folder,
REM preserving line numbers, and uses Eiffel's single-file
REM compilation mode. The root creation routine must be make.
REM Diagnostics in inherited/library classes are not mapped to separate files.
REM Temporary build folders are retained. SHOW_FULL_LOG=yes prints their
REM paths. Delete those comeiffel_* folders when no longer needed.
REM Paths containing ! are unsupported by the BAT diagnostic parser.
REM
REM ================= CONFIRMED TEST AND NEXT CHECKS =================
REM Eiffel 25.12 under native TCC detected all three VJAR errors on
REM lines 17, 18, and 19 in the user's version 7 test.
REM Version 8 uses TCC's built-in QUIT for CALL subroutine returns and
REM final termination. The leading asterisk bypasses a QUIT alias.
REM The TCC PAUSE call also bypasses a user alias. CMD uses EXIT /B.
REM The VD43 missing-precompiled-file warning is retained in the raw log.
REM It is separate from the three intentional VJAR source errors.
REM The user confirmed version 8 hello-world execution and TSE error jumping.
REM Version 9 keeps compiler progress and C build commands in the raw log.
REM Default console output: summary, source errors, exit codes and program output.
REM Set SHOW_FULL_LOG=yes in PART 1 to display the entire compilation log.
REM Version 10 skips diagnostic parsing after compile exit code 0.
REM This avoids TCC quote errors from quoted C build commands in the raw log.
REM Failure diagnostics retain the error parser used for TSE jumping.
REM ================= DOCUMENTATION END =================

setlocal DisableDelayedExpansion
REM ================= PART 1: USER SETTINGS =================
set "EIFFEL_COMMAND=G:\LANGUAGE\COMPUTER\EIFFEL\studio\spec\win64\bin\eiffelknud.bat"
set "BUILD_ROOT=%TEMP%"
set "PAUSE_AT_END=yes"
REM Set yes only when the complete compiler log is needed on screen.
set "SHOW_FULL_LOG=no"

REM ================= PART 2: STABLE LOGIC ==================
set "VERSION=1.0.0.0.10"
set "RESULT=1"
set "SOURCE=%~1"
set "ERRFILE="
set "BUILD="
if not "%~3"=="" set "SOURCE=%~3"
if not "%~6"=="" set "ERRFILE=%~6"
echo COMEIFFEL version %VERSION%
if "%SOURCE%"=="" goto usage
for %%F in ("%SOURCE%") do set "SOURCE=%%~fF"
if "%ERRFILE%"=="" set "ERRFILE=%SOURCE%.err"
for %%F in ("%ERRFILE%") do set "ERRFILE=%%~fF"
type nul > "%ERRFILE%"
if errorlevel 1 goto outputerror
if not exist "%SOURCE%" goto missing
REM Do not use IF EXIST "source\" under TCC.
if defined _TCC goto checktcc
for %%F in ("%SOURCE%") do set "ATTR=%%~aF"
if "%ATTR:~0,1%"=="d" goto missing
goto checked
:checktcc
if isdir "%SOURCE%" goto missing
:checked
if not exist "%EIFFEL_COMMAND%" goto compilererror
if not exist "%BUILD_ROOT%" goto builderror
:newbuild
set "BUILD=%BUILD_ROOT%\comeiffel_%RANDOM%_%RANDOM%"
if exist "%BUILD%" goto newbuild
mkdir "%BUILD%"
if errorlevel 1 goto builderror
REM Keep the source basename; Eiffel derives its system name from it.
for %%F in ("%SOURCE%") do set "BASE=%%~nF"
copy /y "%SOURCE%" "%BUILD%\%BASE%.e" >nul
if errorlevel 1 goto copyerror
pushd "%BUILD%"
if errorlevel 1 goto builderror
echo Compiling "%SOURCE%"
REM CALL returns from the user's wrapper, which must forward arguments with %%*.
call "%EIFFEL_COMMAND%" -batch -finalize -c_compile "%BASE%.e" > "%ERRFILE%.raw" 2>&1
set "RESULT=%ERRORLEVEL%"
popd
if /i "%SHOW_FULL_LOG%"=="yes" type "%ERRFILE%.raw"
echo Compile exit code: %RESULT%
> "%ERRFILE%" echo filename=%SOURCE%
REM A successful C build log contains quoted compiler commands, not errors.
REM Do not feed those commands through the diagnostic parser.
if "%RESULT%"=="0" goto compiled
setlocal EnableDelayedExpansion
set "CODE="
set "DETAIL="
set "FOUND=0"
for /f "usebackq tokens=1,2,*" %%A in ("%ERRFILE%.raw") do (
    set "WORD1=%%A"
    set "WORD2=%%B"
    set "TAIL=%%C"
    call :parse
)
if "!RESULT!"=="0" goto parsed
if "!FOUND!"=="0" (
    >> "!ERRFILE!" echo TSE: 1:1: error: Eiffel compilation failed; inspect "!ERRFILE!.raw"
    echo ERROR: Eiffel compilation failed; inspect "!ERRFILE!.raw"
)
:parsed
endlocal
:compiled
if not "%RESULT%"=="0" goto done
set "PROGRAM="
for /r "%BUILD%\EIFGENs" %%F in (*.exe) do call :executable "%%~fF"
if not defined PROGRAM goto noexe
echo Running %BASE%.e
"%PROGRAM%"
set "RESULT=%ERRORLEVEL%"
echo Run exit code: %RESULT%
goto done

:parse
if /i "!WORD1! !WORD2!"=="Error code:" (
    set "CODE=!TAIL!"
    set "DETAIL="
    goto subreturn
)
if not defined CODE goto subreturn
if /i "!WORD1!"=="Line:" goto lineerror
if /i "!WORD1!"=="Class:" goto subreturn
if /i "!WORD1!"=="Feature:" goto subreturn
if /i "!WORD1!"=="What" goto subreturn
if not defined DETAIL set "DETAIL=!WORD1! !WORD2! !TAIL!"
goto subreturn
:lineerror
set "LINENO=!WORD2!"
set "COLUMN=1"
REM Some reports use Line: N Column: M.
for /f "tokens=1,2" %%L in ("!TAIL!") do if /i "%%L"=="Column:" set "COLUMN=%%M"
set "LINENO=!LINENO:,=!"
set "COLUMN=!COLUMN:,=!"
>> "!ERRFILE!" echo TSE: !LINENO!:!COLUMN!: error: !CODE! !DETAIL!
if /i not "!SHOW_FULL_LOG!"=="yes" echo Line !LINENO!, column !COLUMN!: !CODE! !DETAIL!
set "FOUND=1"
set "CODE="
goto subreturn

:executable
REM Select the program whose filename matches the source/system name.
if /i "%~n1"=="%BASE%" set "PROGRAM=%~1"
goto subreturn
:subreturn
if defined _TCC *quit 0
exit /b 0

:noexe
echo ERROR: compilation succeeded but the expected executable was not found.
echo Build directory: "%BUILD%"
set "RESULT=1"
goto done
:usage
echo Usage: COMEIFFEL.BAT "full source filename"
goto done
:missing
echo ERROR: source file not found or is a directory: "%SOURCE%"
goto done
:compilererror
echo ERROR: Eiffel wrapper not found: "%EIFFEL_COMMAND%"
goto done
:outputerror
echo ERROR: cannot write the TSE error file: "%ERRFILE%"
goto done
:builderror
echo ERROR: cannot create or enter the build directory under "%BUILD_ROOT%"
goto done
:copyerror
echo ERROR: cannot copy the source into "%BUILD%"
:done
REM Build files are deliberately retained for diagnosing compiler/C-toolchain failures.
if /i "%SHOW_FULL_LOG%"=="yes" if defined BUILD echo Build directory: "%BUILD%"
if not "%RESULT%"=="0" if defined BUILD echo Full log: "%ERRFILE%.raw"
if /i not "%PAUSE_AT_END%"=="yes" goto finish
if defined _TCC goto pausetcc
pause
goto finish
:pausetcc
*pause
:finish
if defined _TCC goto finishtcc
endlocal & exit /b %RESULT%
:finishtcc
endlocal & *quit %RESULT%
