@echo off
REM COMDTD.BAT - Version 1.0.0.0.13 - 2026-10-30
REM DTD syntax checking with Python/lxml; no separate helper file.
REM PART 1 - USER SETTINGS AND USAGE
REM Change PYTHON_EXE below to your installed Python executable.
REM Install dependency with: "g:\language\computer\python\python\python.exe" -m pip install lxml
REM Direct use: COMDTD.BAT "full path\source.dtd"
REM TSE use: COMDTD.BAT "%1" "%2" "%3" "%4" "%5" "%6"
REM Arguments: 1=name, 2=extension, 3=full source, 4=drive, 5=path,
REM 6=diagnostic output file. Direct use needs only argument 1.
REM Run these tests from the folder containing COMDTD.BAT:
REM tcc.exe /c call COMDTD.BAT "helloworlddtd.dtd"
REM tcc.exe /c call COMDTD.BAT "errorstestdtd.dtd"
REM cmd.exe /d /c call COMDTD.BAT "helloworlddtd.dtd"
REM cmd.exe /d /c call COMDTD.BAT "errorstestdtd.dtd"
REM Expected exit codes: hello=0, errors=1. Check with echo %%errorlevel%%.
REM Repeat with full paths containing spaces and the six-argument TSE form:
REM COMDTD.BAT "errorstestdtd" ".dtd" "f:\bbc\taal\proj0200errorsmultiple\errorstestdtd.dtd" "f:" "\bbc\taal\proj0200errorsmultiple\" "c:\temp\dtd.err"
REM Also test a missing source and a directory: expected exit code 2.
REM File checks use Python is_file(), avoiding TCC IF EXIST file\ ambiguity.
REM Emits all ERROR/FATAL entries supplied by lxml; no forced recovery.
REM A fatal syntax error can stop parsing before later faults are reached.
REM Unsupported XML text-declaration versions receive an explicit diagnostic.
REM Checks DTD grammar, not an XML instance or all DTD validity constraints.
REM External parameter entities may be loaded while parsing a DTD.
REM Exit codes: 0=OK; 1=DTD errors; 2=configuration or file error.
setlocal
set "PYTHON_EXE=g:\language\computer\python\python\python.exe"
REM The console always pauses after each run.
REM PART 2 - FIXED LOGIC
set "COMDTD_SELF=%~f0"
set "COMDTD_SOURCE=%~1"
set "COMDTD_OUTPUT="
if not "%~3"=="" set "COMDTD_SOURCE=%~3"
if not "%~3"=="" set "COMDTD_OUTPUT=%~6"
if "%~1"=="" goto usage
if not exist "%PYTHON_EXE%" goto noengine
"%PYTHON_EXE%" -c "import os; p=os.environ['COMDTD_SELF']; t=open(p,encoding='ascii').read(); exec(compile(t.split('# COMDTD_'+'PYTHON_BEGIN',1)[1],p,'exec'))"
set "COMDTD_RESULT=%errorlevel%"
goto finish
:usage
echo COMDTD.BAT version 1.0.0.0.13
echo Usage: COMDTD.BAT "source.dtd"
set "COMDTD_RESULT=2"
goto finish
:noengine
echo ERROR: Python executable not found: "%PYTHON_EXE%"
set "COMDTD_RESULT=2"
goto finish
:finish
pause
exit /b %COMDTD_RESULT%
# COMDTD_PYTHON_BEGIN
import os, sys, re
from pathlib import Path
from urllib.parse import urlsplit, unquote
VERSION = "1.0.0.0.13"
lines = []
status = 2
source = Path(os.environ["COMDTD_SOURCE"]).absolute()
def native_filename(filename):
    if not filename or filename.startswith("<"):
        return str(source)
    if filename.lower().startswith("file:"):
        uri = urlsplit(filename)
        name = unquote(uri.path)
        if uri.netloc and uri.netloc.lower() != "localhost":
            name = "//" + uri.netloc + name
        elif re.match(r"^/[A-Za-z]:", name):
            name = name[1:]
        return name.replace("/", "\\") if os.name == "nt" else name
    return filename

def diagnostic(filename, row, col, message):
    filename = native_filename(filename)
    message = " ".join(str(message).splitlines())
    lines.append(f'TSE: "{filename}" line {max(1,row)} column {max(1,col)}: ERROR: {message}')
try:
    from lxml import etree
    if not source.is_file():
        raise OSError("Source file not found or is a directory: " + str(source))
    # An external DTD may start with an XML text declaration.
    # Inspect only that declaration; comments are never version markers.
    raw = source.read_bytes()
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        text = raw.decode("utf-16")
    elif raw.startswith(b"\x00<\x00?"):
        text = raw.decode("utf-16-be")
    elif raw.startswith(b"<\x00?\x00"):
        text = raw.decode("utf-16-le")
    else:
        text = raw.decode("utf-8-sig", errors="replace")
    decl = re.match(r"<\?xml(?=\s).*?\?>", text, re.S)
    version = None
    if decl:
        version = re.search(r"\bversion\s*=\s*(['\"])(.*?)\1", decl.group(), re.S)
    if version and version.group(2) != "1.0":
        pos = version.start(2)
        row = text.count("\n", 0, pos) + 1
        col = pos - text.rfind("\n", 0, pos)
        diagnostic(str(source), row, col,
                   "Unsupported XML version " + version.group(2) +
                   " in DTD text declaration. This checker supports XML 1.0 DTDs. "
                   "DTD has no separate language version number.")
        entries = []
        status = 1
        seen = {"unsupported-version"}
    else:
        seen = set()
    try:
        if status == 1:
            dtd = None
        else:
            dtd = etree.DTD(str(source))
        if dtd is not None:
            entries = list(dtd.error_log)
            status = 0
    except etree.DTDParseError as exc:
        entries = list(exc.error_log)
        status = 1
    for entry in entries:
        if entry.level_name not in ("ERROR", "FATAL"):
            continue
        filename = entry.filename
        if not filename or filename.startswith("<"):
            filename = str(source)
        key = (filename, entry.line, entry.column, entry.message)
        if key not in seen:
            seen.add(key)
            diagnostic(*key)
        status = 1
    if status == 0:
        lines.append("COMDTD.BAT version " + VERSION + ": DTD syntax OK: " + str(source))
    elif not seen:
        diagnostic(str(source), 1, 1, "DTD parsing failed without a location diagnostic")
except ImportError:
    lines.append("COMDTD configuration error: install lxml with the configured Python: python -m pip install lxml")
except Exception as exc:
    lines.append("COMDTD configuration error: " + str(exc))
for line in lines:
    print(line, flush=True)
output = os.environ.get("COMDTD_OUTPUT", "")
if output:
    try:
        Path(output).write_text("\n".join(lines) + "\n", encoding="ascii", errors="replace")
    except OSError as exc:
        print("COMDTD cannot write output: " + str(exc))
        status = 2
sys.exit(status)
