@echo off
REM COMAWK.BAT - Run an AWK program
REM Version 1.0.0.7 - 2026-10-05 - OpenAI GPT-6 (Codex)
REM Based on the COMAWK.BAT source embedded in BIBAWK.AWK.
REM
REM Usage (quote every filename or path):
REM   COMAWK.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.awk"
REM   COMAWK.BAT "ddd" "awk" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.awk" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\comawk_test.err"
REM TSE parameters: 1=name, 2=extension, 3=full source filename,
REM                 4=drive, 5=path, 6=diagnostics filename.
REM Parameters 1, 2, 4 and 5 are compatibility placeholders in TSE mode.
REM Optional parameter 7 overrides AWK_EXE; 8 supplies an input data file.
REM For single-file mode, configure AWK_EXE and INPUT_FILE below.
REM
REM TESTS: save this one-line program as ddd.awk:
REM   BEGIN { print "Hello from AWK"; exit 0 }
REM Run BOTH short and six-parameter calls above from a TCC prompt.
REM To launch a separate TCC, prefix either call with: tcc.exe /c
REM Run BOTH calls from a CMD prompt, or prefix with: cmd.exe /d /c
REM Expected: one Hello, exit code 0, filename= line in the saved output.
REM Repeat with a source path containing spaces and with a missing file.
REM Missing source must report an error and return exit code 1.
REM Test AWK failure with: BEGIN { exit 7 }
REM Expected: AWK exit code 7 and batch exit code 7.
REM To check the batch code, use echo %errorlevel% at the next prompt.
REM Test data input with: { print toupper($0) }
REM Supply an existing text file as parameter 8 in the TSE-style call.
REM Parameter 7 example: "G:\cygwin\bin\gawk.exe"
REM For unattended tests set PAUSE_AT_END=no below.
REM EXPLICIT SHELL TESTS (run from F:\BBC\TAAL):
REM   tcc.exe /c COMAWK.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.awk"
REM   tcc.exe /c COMAWK.BAT "ddd" "awk" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.awk" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "%TEMP%\comawk_tcc.err"
REM   cmd.exe /d /c COMAWK.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.awk"
REM   cmd.exe /d /c COMAWK.BAT "ddd" "awk" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.awk" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "%TEMP%\comawk_cmd.err"
REM Also test missing source, spaces in paths, input data, and exit code 7.
REM Windows shell tests must be run on your Windows machine.
REM Under TCC this batch delegates to Windows CMD and returns to TCC.
REM Version 1.0.0.7: normalized diagnostics are AWK(line,column): message.
REM Columns come from GNU AWK carets; otherwise use 1 (unavailable).
REM TSE mode writes parameter 6 and omits the pause for editor integration.
REM Install the matching comawkbatcompilersetting_awk.txt rule.
REM Use errorstest.awk to test several independent statement errors.
REM
REM TCC launches the CMD engine before any CMD parameter expansion.
if "%_cmdproc%"=="TCC" goto tcc_dispatch
if "%_cmdproc%"=="TCCLE" goto tcc_dispatch

setlocal EnableExtensions DisableDelayedExpansion
REM ==================================================================
REM PART 1 - USER SETTINGS: change only this section for your computer
REM ==================================================================
REM Full path to AWK executable; a name on PATH such as gawk.exe also works.
set "AWK_EXE=G:\cygwin\bin\gawk.exe"
REM Windows PowerShell converts GNU AWK caret diagnostics for TSE.
set "POWERSHELL_EXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
REM Use English diagnostic labels so conversion is independent of locale.
set "LC_ALL=C"
REM Optional input data filename. Empty means read NUL, preventing a wait
REM for keyboard input in the editor. BEGIN/END-only programs need no data.
set "INPUT_FILE="
REM Default output folder. Must exist; TSE parameter 6 overrides the file.
set "OUTPUT_DIRECTORY=%TEMP%"
REM Show a final pause: yes or no.
set "PAUSE_AT_END=yes"

REM ==================================================================
REM PART 2 - PROGRAM LOGIC: no local configuration required below here
REM ==================================================================
set "AWK_SOURCE=%~1"
set "AWK_LOG="
set "AWK_RC=1"
set "AWK_TSE=no"
if not "%~3"=="" goto tse_arguments
goto arguments_ready

:tse_arguments
set "AWK_TSE=yes"
set "AWK_SOURCE=%~3"
set "AWK_LOG=%~6"
if not "%~7"=="" set "AWK_EXE=%~7"
if not "%~8"=="" set "INPUT_FILE=%~8"

:arguments_ready
if "%AWK_SOURCE%"=="" goto usage
if not exist "%AWK_SOURCE%" goto missing_source
if exist "%AWK_SOURCE%\" goto missing_source
if "%AWK_LOG%"=="" set "AWK_LOG=%OUTPUT_DIRECTORY%\COMAWK_%RANDOM%_%RANDOM%.err"
REM Never overwrite the program or its input with diagnostics.
for %%I in ("%AWK_SOURCE%") do set "AWK_SOURCE=%%~fI"
for %%I in ("%AWK_LOG%") do set "AWK_LOG=%%~fI"
if /i "%AWK_SOURCE%"=="%AWK_LOG%" goto unsafe_output
if "%INPUT_FILE%"=="" goto input_ready
if not exist "%INPUT_FILE%" goto missing_input
if exist "%INPUT_FILE%\" goto missing_input
for %%I in ("%INPUT_FILE%") do set "INPUT_FILE=%%~fI"
if /i "%INPUT_FILE%"=="%AWK_LOG%" goto unsafe_output

:input_ready
>"%AWK_LOG%" echo filename=%AWK_SOURCE%
if errorlevel 1 goto output_failed
set "AWK_RAW=%TEMP%\COMAWK_%RANDOM%_%RANDOM%.raw"
echo Running "%AWK_SOURCE%"
if not "%INPUT_FILE%"=="" goto run_with_input
"%AWK_EXE%" -f "%AWK_SOURCE%" <nul >"%AWK_RAW%" 2>&1
set "AWK_RC=%errorlevel%"
goto show_output

:run_with_input
"%AWK_EXE%" -f "%AWK_SOURCE%" "%INPUT_FILE%" >"%AWK_RAW%" 2>&1
set "AWK_RC=%errorlevel%"

:show_output
REM Normalize each caret once; source excerpts are not duplicate errors.
"%POWERSHELL_EXE%" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $rows=New-Object 'System.Collections.Generic.List[string]'; $n=0; foreach($t in [IO.File]::ReadAllLines($env:AWK_RAW)){ $m=[regex]::Match($t,'^(?:gawk|awk)(?:\.exe)?: (.*):([0-9]+): ?(.*)$'); if($m.Success){ $line=$m.Groups[2].Value; $body=$m.Groups[3].Value; $c=[regex]::Match($body,'^([ \t]*)\^\s*(.*)$'); if($c.Success){ $col=$c.Groups[1].Length+1; $rows.Add(('AWK({0},{1}): {2}' -f $line,$col,$c.Groups[2].Value)); $n++ } elseif($body -match '^(?:fatal|error|warning):'){ $rows.Add(('AWK({0},1): {1} [column unavailable]' -f $line,$body)); $n++ } } else { $rows.Add($t) } }; if($env:AWK_RC -ne '0' -and $n -eq 0){ $rows.Add('AWK(1,1): AWK failed; see diagnostics above [location unavailable]') }; $w=New-Object IO.StreamWriter($env:AWK_LOG,$true,([Text.UTF8Encoding]::new($false))); try { $seen=New-Object 'System.Collections.Generic.HashSet[string]'; foreach($r in $rows){ if(-not $r.StartsWith('AWK(') -or $seen.Add($r)){ $w.WriteLine($r) } } } finally { $w.Dispose() }"
if errorlevel 1 goto conversion_failed
del /q "%AWK_RAW%" >nul 2>&1
goto display_output

:conversion_failed
>>"%AWK_LOG%" echo AWK(1,1): Diagnostic conversion failed; raw output follows.
type "%AWK_RAW%" >>"%AWK_LOG%"
echo Raw output retained at "%AWK_RAW%"
if "%AWK_RC%"=="0" set "AWK_RC=1"

:display_output
echo.
type "%AWK_LOG%"
echo.
echo AWK exit code: %AWK_RC%
echo Output and diagnostics saved to "%AWK_LOG%"
goto finish

:usage
echo Usage: COMAWK.BAT "source.awk"
echo Or: COMAWK.BAT "name" "awk" "source.awk" "drive" "path" "output.err" ["awk.exe"] ["input.txt"]
goto finish

:missing_source
echo ERROR: AWK program not found: "%AWK_SOURCE%"
goto finish

:missing_input
echo ERROR: Input data file not found: "%INPUT_FILE%"
goto finish

:unsafe_output
echo ERROR: Output filename must differ from the source and input filenames.
goto finish

:output_failed
echo ERROR: Cannot write output file: "%AWK_LOG%"
echo Check that its parent directory exists and is writable.

:finish
if /i "%AWK_TSE%"=="yes" goto return_code
if /i "%PAUSE_AT_END%"=="yes" pause
:return_code
endlocal & exit /b %AWK_RC%

:tcc_dispatch
REM These commands are reached only under TCC/TCCLE.
REM _batchname is the current full batch path; %$ is all original arguments.
REM The leading * on QUIT bypasses any user alias of that command.
"%SystemRoot%\System32\cmd.exe" /d /s /c ""%_batchname%" %$"
*quit %?
