@echo off
REM COMCLOJURE version 1.0.0.0.10 - Run Clojure program
REM Updated 2026-10-09. Prepared with OpenAI GPT-6 (Codex).
REM PART 1 contains all local configuration; PART 2 is stable logic.
REM No PowerShell, helper scripts, or nested TCC invocation is used.
REM Requires Java and Clojure 1.10.1 or newer, plus its dependency JARs.
REM Put clojure, spec.alpha and core.specs.alpha JARs in the JAR directory.
REM A clojure-tools uberjar can also be used as the classpath.
REM This runs standalone scripts; deps.edn dependencies are not resolved.
REM
REM Direct test in an already open TCC console or CMD console:
REM   COMCLOJURE.BAT "C:\sources with spaces\errorstest.clj"
REM TSE six-parameter test in either console:
REM   COMCLOJURE.BAT "errorstest" "clj" "C:\sources with spaces\errorstest.clj" "C" "\sources with spaces\" "C:\Temp\clojure.err"
REM Parameters: %%1 basename or direct filename, %%2 extension,
REM %%3 full source filename, %%4 drive, %%5 path, %%6 diagnostic file.
REM The full filename in %%3 is authoritative; %%4 and %%5 are unused.
REM CMD test from TCC: cmd.exe /d /c COMCLOJURE.BAT "C:\sources with spaces\errorstest.clj"
REM TCC test: run the same direct command in an existing TCC console.
REM Successful smoke test: comment out the three missing-name forms below.
REM Error test: first uncaught error stops execution; fix it and rerun.
REM Check each reported line and column by selecting it in TSE's error list.
REM The script runs ONCE. Diagnostics go to %%6 and are displayed afterwards.
REM
setlocal
REM ==================== PART 1: USER VARIABLES ====================
REM Explicit Java executable avoids JAVA_HOME values that already end in bin.
set "CCJ_JAVA=G:\LANGUAGE\COMPUTER\JAVA\jdk1.8.0_05_64\bin\java.exe"
REM JAR location: existing portable Clojure installation on USB.
REM Replace this with your actual JAR directory or explicit classpath.
set "CCJ_CLASSPATH=G:\LANGUAGE\COMPUTER\CLOJURE\jars\*"
REM Optional JVM options, e.g. -Xmx512m. Leave empty for Java defaults.
set "CCJ_JVM_OPTIONS="
REM Set to 0 to disable the final console pause.
set "CCJ_PAUSE=1"
REM ==================== PART 2: STABLE LOGIC =======================
set "CCJ_RC=1"
set "CCJ_SOURCE="
set "CCJ_OUTPUT="
set "CCJ_PUSHED=0"
set "CCJ_SHELL=CMD"
REM JPSoft documented detection: numeric in TCC, string comparison in CMD.
if 01 == 1 set "CCJ_SHELL=TCC"
echo COMCLOJURE version 1.0.0.0.10
echo Shell: %CCJ_SHELL%
if "%~1"=="" goto usage
set "CCJ_SOURCE=%~f1"
if not "%~3"=="" set "CCJ_SOURCE=%~f3"
set "CCJ_OUTPUT=%~6"
if not defined CCJ_OUTPUT set "CCJ_OUTPUT=%TEMP%\COMCLOJURE_%RANDOM%_%RANDOM%.err"
if not defined TEMP if "%~6"=="" set "CCJ_OUTPUT=%~dp0COMCLOJURE.err"
>"%CCJ_OUTPUT%" echo COMCLOJURE version 1.0.0.0.10
if errorlevel 1 goto outputfailed
>>"%CCJ_OUTPUT%" echo filename=%CCJ_SOURCE%
if not exist "%CCJ_SOURCE%" goto missing
if "%CCJ_SHELL%"=="TCC" goto checktcc
REM CMD directory attribute check avoids filename-backslash tests.
for %%A in ("%CCJ_SOURCE%") do set "CCJ_ATTR=%%~aA"
if /i "%CCJ_ATTR:~0,1%"=="d" goto missing
goto run
:checktcc
if isdir "%CCJ_SOURCE%" goto missing
:run
for %%A in ("%CCJ_SOURCE%") do set "CCJ_DIRECTORY=%%~dpA"
pushd "%CCJ_DIRECTORY%"
if errorlevel 1 goto directoryfailed
set "CCJ_PUSHED=1"
echo Running "%CCJ_SOURCE%"
"%CCJ_JAVA%" %CCJ_JVM_OPTIONS% -Dclojure.main.report=stderr -cp "%CCJ_CLASSPATH%;." clojure.main "%CCJ_SOURCE%" >>"%CCJ_OUTPUT%" 2>&1
set "CCJ_RC=%ERRORLEVEL%"
goto display
:missing
>>"%CCJ_OUTPUT%" echo ERROR: source file missing or is a directory: "%CCJ_SOURCE%"
goto display
:directoryfailed
>>"%CCJ_OUTPUT%" echo ERROR: cannot enter source directory: "%CCJ_DIRECTORY%"
goto display
:outputfailed
echo ERROR: cannot write diagnostic file: "%CCJ_OUTPUT%"
goto finish
:usage
echo Usage: COMCLOJURE.BAT "full source filename.clj"
echo Or: COMCLOJURE.BAT name clj "full source filename" drive path "diagnostic file"
goto finish
:display
if "%CCJ_PUSHED%"=="1" popd
type "%CCJ_OUTPUT%"
echo Diagnostics saved to "%CCJ_OUTPUT%"
echo Exit code: %CCJ_RC%
:finish
if "%CCJ_PAUSE%"=="1" pause
endlocal & exit /b %CCJ_RC%
