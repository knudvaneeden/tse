@echo off
REM COMTYPESCRIPT.BAT version 1.0.0.8 - OpenAI GPT-6
REM PART 1 - USER SETTINGS
REM Set Node.exe and TypeScript's installed lib\tsc.js here.
REM Install TypeScript with npm install -g typescript if necessary.
REM Run npm root -g to find the global node_modules directory.
REM We run Node + tsc.js directly: no npm .cmd launcher or nested TCC.
REM Direct test in a native TCC console:
REM   COMTYPESCRIPT.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.ts"
REM The same command works in a CMD console.
REM Six-parameter TSE call:
REM   COMTYPESCRIPT.BAT "errorstest" "ts" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.ts" "F" "BBC\TAAL\PROJ0200ERRORSMULTIPLE" "C:\TEMP\typescript.err"
REM %1 base name, %2 language (unused), %3 full source, %4 drive,
REM %5 directory (legacy; JavaScript emitted beside source), %6 error file.
REM Optional six-parameter overrides: %7 tsc.js, %8 Node.exe.
REM Direct mode writes diagnostics to TEMP\COMTYPESCRIPT.err.
REM To disable the final pause, set COMTYPESCRIPT_PAUSE=0 in the caller.
REM This is single-file compilation; it does not load tsconfig.json.
setlocal
set "CTS_VERSION=1.0.0.8"
set "CTS_NODE=node.exe"
set "CTS_COMPILER=%APPDATA%\npm\node_modules\typescript\lib\tsc.js"
set "CTS_DEFAULT_LOG=%TEMP%\COMTYPESCRIPT.err"
set "CTS_PAUSE=1"

REM PART 2 - COMMON LOGIC
set "CTS_RC=2"
set "CTS_TCC=0"
if /i "%_CMDPROC%"=="TCC" set "CTS_TCC=1"
if "%COMTYPESCRIPT_PAUSE%"=="0" set "CTS_PAUSE=0"
set "CTS_LOG=%CTS_DEFAULT_LOG%"
set "CTS_SOURCE=%~f1"
if not "%~3"=="" set "CTS_SOURCE=%~f3"
if not "%~6"=="" set "CTS_LOG=%~f6"
if not "%~7"=="" set "CTS_COMPILER=%~7"
if not "%~8"=="" set "CTS_NODE=%~8"
echo COMTYPESCRIPT.BAT version %CTS_VERSION%
if "%~1"=="" goto usage
if /i "%CTS_SOURCE%"=="%CTS_LOG%" goto unsafeLog
for %%F in ("%CTS_SOURCE%") do set "CTS_JS=%%~dpnF.js"
if /i "%CTS_JS%"=="%CTS_LOG%" goto unsafeLog
>"%CTS_LOG%" echo COMTYPESCRIPT.BAT version %CTS_VERSION%
if errorlevel 1 goto logError
REM Check the literal source filename; never append a backslash here.
if not exist "%CTS_SOURCE%" goto missingSource
if "%CTS_TCC%"=="1" goto tccSource
REM CMD-only directory check, kept off the TCC execution path.
if exist "%CTS_SOURCE%\." goto directorySource
goto sourceReady
:tccSource
if isdir "%CTS_SOURCE%" goto directorySource
:sourceReady
for %%F in ("%CTS_SOURCE%") do set "CTS_EXT=%%~xF"
if /i not "%CTS_EXT%"==".ts" goto wrongExtension
if not exist "%CTS_COMPILER%" goto missingCompiler
>>"%CTS_LOG%" echo filename=%CTS_SOURCE%
REM Plain errors retain filename(line,column); no ANSI colour sequences.
REM --noEmitOnError prevents running JavaScript from a failed compilation.
"%CTS_NODE%" "%CTS_COMPILER%" "%CTS_SOURCE%" --pretty false --noEmitOnError --module commonjs >>"%CTS_LOG%" 2>&1
set "CTS_RC=%errorlevel%"
>>"%CTS_LOG%" echo Compiler exit code: %CTS_RC%
if not "%CTS_RC%"=="0" goto showLog
if not exist "%CTS_JS%" goto missingJs
"%CTS_NODE%" "%CTS_JS%" >>"%CTS_LOG%" 2>&1
set "CTS_RC=%errorlevel%"
>>"%CTS_LOG%" echo Program exit code: %CTS_RC%
goto showLog
:missingSource
>>"%CTS_LOG%" echo ERROR: Source file not found: "%CTS_SOURCE%"
goto showLog
:directorySource
>>"%CTS_LOG%" echo ERROR: Source path is a directory: "%CTS_SOURCE%"
goto showLog
:wrongExtension
>>"%CTS_LOG%" echo ERROR: Expected a .ts source file: "%CTS_SOURCE%"
goto showLog
:missingCompiler
>>"%CTS_LOG%" echo ERROR: TypeScript compiler not found: "%CTS_COMPILER%"
>>"%CTS_LOG%" echo Set CTS_COMPILER in PART 1 to the installed lib\tsc.js file.
goto showLog
:missingJs
set "CTS_RC=2"
>>"%CTS_LOG%" echo ERROR: Compiler did not create "%CTS_JS%".
goto showLog
:showLog
type "%CTS_LOG%"
goto finish
:unsafeLog
echo ERROR: Error filename would overwrite source or JavaScript.
goto finish
:logError
echo ERROR: Cannot write diagnostics to "%CTS_LOG%".
goto finish
:usage
echo Usage: COMTYPESCRIPT.BAT "source.ts"
echo Or: COMTYPESCRIPT.BAT name ts "source.ts" drive directory "errors.err"
:finish
echo Exit code: %CTS_RC%
if "%CTS_PAUSE%"=="1" pause
if "%CTS_TCC%"=="1" goto tccExit
endlocal & exit /b %CTS_RC%
:tccExit
endlocal & quit %CTS_RC%
