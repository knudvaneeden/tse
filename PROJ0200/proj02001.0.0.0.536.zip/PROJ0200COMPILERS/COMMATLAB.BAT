@echo off
REM COMMATLAB version 1.0.0.0.9 - OpenAI GPT-6
REM No external helper scripts: Code Analyzer and execution run inside MATLAB.
REM Requires licensed MATLAB. checkcode requires R2011b+, batch R2019a+.
REM
REM PART 1 - USER SETTINGS
REM Tool override: SET COMMATLAB_EXE=C:\Program Files\MATLAB\R2026b\bin\matlab.exe
REM Default is legacy for MATLAB R2012a. Set COMMATLAB_MODE=batch for R2019a+.
REM TCC/CMD pause override: SET COMMATLAB_PAUSE=0 (automated tests only)
REM MATLAB window pause override: SET COMMATLAB_WINDOW_PAUSE=0
REM Default 1 waits for Enter in MATLAB before closing its legacy window.
REM Analyze override: SET COMMATLAB_ANALYZE=0 (execution without Code Analyzer)
REM All local settings are here; quoted SET syntax permits spaces in paths.
if 01 == 1 goto initTcc
setlocal DisableDelayedExpansion
goto settings
:initTcc
setlocal
:settings
if not defined COMMATLAB_EXE set "COMMATLAB_EXE=g:\math\matlab\bin\matlab.exe"
if not defined COMMATLAB_MODE set "COMMATLAB_MODE=legacy"
if not defined COMMATLAB_PAUSE set "COMMATLAB_PAUSE=1"
if not defined COMMATLAB_WINDOW_PAUSE set "COMMATLAB_WINDOW_PAUSE=1"
if not defined COMMATLAB_ANALYZE set "COMMATLAB_ANALYZE=1"
REM
REM TESTS: run these directly inside the named shell; never nest TCC in TCC.
REM TCC console: COMMATLAB.BAT "F:\sources with spaces\errorstest.m"
REM CMD console: COMMATLAB.BAT "F:\sources with spaces\errorstest.m"
REM CMD from TCC: cmd.exe /d /c call COMMATLAB.BAT "F:\sources with spaces\errorstest.m"
REM Direct form: %%1=full source, optional %%2=diagnostics file.
REM TSE form: %%1=name, %%2=extension, %%3=full source, %%4=drive,
REM           %%5=subpath, %%6=diagnostics file (required by TSE).
REM Example: COMMATLAB.BAT "errorstest" "m" "F:\work\errorstest.m" "F:" "\work\" "C:\Temp\matlab.err"
REM %%4 and %%5 are metadata, NOT executable or mode overrides.
REM Read the MATLAB window; press Enter there to return to the batch file.
REM Check diagnostics in console and %%6, then select each TSE error entry.
REM Code Analyzer reports multiple issues (warnings and errors); number and
REM positions can vary by MATLAB version. Runtime stops at first unhandled error.
REM Test missing file and directory inputs: both return 2, without launching MATLAB.
REM Use CALL from another BAT. To print exit code, use ECHO %%ERRORLEVEL%%
REM on the NEXT command line. Configure the executable above before testing.
REM Repair errorstest.m as its comments describe and rerun for a successful run.
REM
REM PART 2 - STABLE EXECUTION LOGIC
REM JPSoft documented shell detection: 01 == 1 is numeric in TCC,
REM but a false string comparison in CMD. IF DEFINED cannot test _4VER.
set "CM_VERSION=1.0.0.0.9"
set "CM_RC=2"
set "CM_SOURCE="
set "CM_ERR="
set "CM_SHELL=CMD"
echo COMMATLAB version %CM_VERSION%
if 01 == 1 goto shellTcc
set "CM_SHELL=CMD"
echo Shell: CMD
goto arguments
:shellTcc
set "CM_SHELL=TCC"
echo Shell: TCC
:arguments
if "%~1"=="" goto usage
if /i "%~1"=="--help" goto help
if /i "%~1"=="/?" goto help
if not "%~3"=="" goto tseArguments
set "CM_SOURCE=%~f1"
if not "%~2"=="" set "CM_ERR=%~f2"
goto prepareLog
:tseArguments
set "CM_SOURCE=%~f3"
if "%~6"=="" goto usage
set "CM_ERR=%~f6"
:prepareLog
if not defined TEMP set "TEMP=."
if defined CM_ERR goto openLog
if not defined TEMP set "TEMP=."
set "CM_ERR=%TEMP%\COMMATLAB_%RANDOM%_%RANDOM%.err"
:openLog
>"%CM_ERR%" echo COMMATLAB version %CM_VERSION%
if errorlevel 1 goto logFailure
>>"%CM_ERR%" echo filename=%CM_SOURCE%
if not exist "%CM_SOURCE%" goto missingSource
if 01 == 1 goto tccDirectory
REM CMD file attributes: do not append a backslash to the source filename.
for %%A in ("%CM_SOURCE%") do set "CM_ATTRIBUTES=%%~aA"
if /i "%CM_ATTRIBUTES:~0,1%"=="d" goto sourceDirectory
goto validateMode
:tccDirectory
if isdir "%CM_SOURCE%" goto sourceDirectory
:validateMode
if /i "%COMMATLAB_MODE%"=="batch" goto buildCode
if /i "%COMMATLAB_MODE%"=="legacy" goto buildCode
>>"%CM_ERR%" echo ERROR: COMMATLAB_MODE must be batch or legacy.
goto showLog
:buildCode
REM getenv avoids embedding filenames (including apostrophes) in MATLAB code.
REM Format uses char(37) and char(10), avoiding shell percent and escape rules.
REM Analyzer extents: jump to first column, and emit each reported source line.
set "CM_CODE=try; CM_file=getenv('CM_SOURCE'); CM_fmt=['TSE: ' char(37) 's:' char(37) 'd:' char(37) 'd: ' char(37) 's' char(10)]; if strcmp(getenv('COMMATLAB_ANALYZE'),'1'); CM_issues=checkcode(CM_file,'-struct'); for CM_i=1:numel(CM_issues); CM_issue=CM_issues(CM_i); CM_msg=regexprep(CM_issue.message,'[\r\n]+',' '); for CM_j=1:numel(CM_issue.line); CM_col=1; if ~isempty(CM_issue.column); CM_col=CM_issue.column(min(CM_j,size(CM_issue.column,1)),1); end; fprintf(CM_fmt,CM_file,CM_issue.line(CM_j),max(1,CM_col),CM_msg); end; end; end; run(CM_file); catch CM_exception; disp(getReport(CM_exception,'extended','hyperlinks','off')); CM_stack=CM_exception.stack; for CM_i=1:numel(CM_stack); fprintf(['TSE: ' char(37) 's:' char(37) 'd:1: Runtime (column unavailable): ' char(37) 's' char(10)],CM_stack(CM_i).file,max(1,CM_stack(CM_i).line),regexprep(CM_exception.message,'[\r\n]+',' ')); end; if strcmp(getenv('COMMATLAB_MODE'),'legacy'); if strcmp(getenv('COMMATLAB_WINDOW_PAUSE'),'1'); input('Press Enter to close MATLAB...','s'); end; end; exit(1); end; if strcmp(getenv('COMMATLAB_MODE'),'legacy'); if strcmp(getenv('COMMATLAB_WINDOW_PAUSE'),'1'); input('Press Enter to close MATLAB...','s'); end; end; exit(0);"
REM Keep the startup argument short: MATLAB reads CM_CODE from the environment.
REM No generated .m file or other helper program is used.
set "CM_STARTUP=disp('COMMATLAB 1.0.0.0.9: MATLAB command started'); try; eval(getenv('CM_CODE')); catch CM_outer; disp(getReport(CM_outer,'extended','hyperlinks','off')); if strcmp(getenv('COMMATLAB_MODE'),'legacy'); if strcmp(getenv('COMMATLAB_WINDOW_PAUSE'),'1'); input('Press Enter to close MATLAB...','s'); end; end; exit(1); end;"
echo Analyzing/running "%CM_SOURCE%"
if /i "%COMMATLAB_MODE%"=="legacy" goto runLegacy
"%COMMATLAB_EXE%" -wait -batch "%CM_STARTUP%" >>"%CM_ERR%" 2>&1
set "CM_RC=%ERRORLEVEL%"
goto showLog
:runLegacy
REM Old Windows MATLAB writes to its own command window, not shell stdout.
REM Capture that window via -logfile, then append it to the TSE diagnostics.
set "CM_MATLAB_LOG=%TEMP%\COMMATLAB_%RANDOM%_%RANDOM%_matlab.log"
if exist "%CM_MATLAB_LOG%" goto runLegacy
>"%CM_MATLAB_LOG%" echo.
if errorlevel 1 goto matlabLogFailure
"%COMMATLAB_EXE%" -wait -nosplash -nodesktop -logfile "%CM_MATLAB_LOG%" -r "%CM_STARTUP%" >>"%CM_ERR%" 2>&1
set "CM_RC=%ERRORLEVEL%"
if not exist "%CM_MATLAB_LOG%" goto matlabLogMissing
type "%CM_MATLAB_LOG%" >>"%CM_ERR%"
echo MATLAB window log retained in "%CM_MATLAB_LOG%"
goto showLog
:matlabLogFailure
>>"%CM_ERR%" echo ERROR: cannot create MATLAB window log "%CM_MATLAB_LOG%".
set "CM_RC=2"
goto showLog
:matlabLogMissing
>>"%CM_ERR%" echo ERROR: MATLAB did not create its window log.
if "%CM_RC%"=="0" set "CM_RC=2"
goto showLog
:missingSource
>>"%CM_ERR%" echo ERROR: source file not found: "%CM_SOURCE%"
goto showLog
:sourceDirectory
>>"%CM_ERR%" echo ERROR: source is a directory: "%CM_SOURCE%"
goto showLog
:showLog
type "%CM_ERR%"
echo Diagnostics saved to "%CM_ERR%"
echo MATLAB exit code: %CM_RC%
>>"%CM_ERR%" echo MATLAB exit code: %CM_RC%
goto finish
:logFailure
echo ERROR: cannot write diagnostics file "%CM_ERR%".
goto finish
:usage
echo ERROR: supply a source file or all six TSE parameters.
goto finish
:help
echo COMMATLAB.BAT "script.m" ["diagnostics.err"]
echo COMMATLAB.BAT name extension "script.m" drive subpath "diagnostics.err"
echo Executable, mode, analysis and pause settings are in PART 1.
set "CM_RC=0"
:finish
if "%COMMATLAB_PAUSE%"=="1" pause
if "%CM_SHELL%"=="TCC" goto finishTcc
endlocal & exit /b %CM_RC%
:finishTcc
endlocal & quit %CM_RC%
