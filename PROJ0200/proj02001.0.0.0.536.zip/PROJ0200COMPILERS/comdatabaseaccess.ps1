# COMDATABASEACCESS.PS1 version 1.0.0.0.7
# Access COM runs independently of PowerShell process bitness.
param([Parameter(Mandatory=$true)][string]$Source,
      [Parameter(Mandatory=$true)][string]$OutputFile,
      [string]$Database = '')
$ErrorActionPreference = 'Stop'
$lines = New-Object 'System.Collections.Generic.List[string]'
$app = $null; $db = $null; $tempDb = $null; $result = 1
try {
    $sourcePath = [IO.Path]::GetFullPath($Source)
    $outputPath = [IO.Path]::GetFullPath($OutputFile)
    if ([string]::Equals($sourcePath, $outputPath, [StringComparison]::OrdinalIgnoreCase)) { [Console]::Error.WriteLine('ERROR: source and output must be different files.'); exit 1 }
    if ($Database -and [string]::Equals([IO.Path]::GetFullPath($Database), $outputPath, [StringComparison]::OrdinalIgnoreCase)) { [Console]::Error.WriteLine('ERROR: database and output must be different files.'); exit 1 }
    $sql = [IO.File]::ReadAllText($sourcePath)
    # Remove only complete -- comment lines; preserve line and column counts.
    $sql = [regex]::Replace($sql, '(?m)^[ \t]*--[^\r\n]*', { param($m) ' ' * $m.Length })
    $app = New-Object -ComObject Access.Application
    if ($Database) {
        $dbPath = [IO.Path]::GetFullPath($Database)
        if (-not [IO.File]::Exists($dbPath)) { throw "Database not found: $dbPath" }
        $app.OpenCurrentDatabase($dbPath)
    } else {
        $tempDb = Join-Path ([IO.Path]::GetTempPath()) ('tse-access-' + [guid]::NewGuid().ToString('N') + '.accdb')
        $app.NewCurrentDatabase($tempDb)
    }
    $db = $app.CurrentDb()
    $statements = New-Object 'System.Collections.Generic.List[object]'
    $start = 0; $quote = [char]0; $bracket = $false; $date = $false
    for ($i=0; $i -lt $sql.Length; $i++) {
        $c = $sql[$i]
        if ($quote -ne [char]0) {
            if ($c -eq $quote) {
                if (($i+1 -lt $sql.Length) -and ($sql[$i+1] -eq $quote)) { $i++ } else { $quote = [char]0 }
            }
        } elseif ($bracket) { if ($c -eq ']') { $bracket = $false } }
        elseif ($date) { if ($c -eq '#') { $date = $false } }
        elseif ($c -eq "'" -or $c -eq '"') { $quote = $c }
        elseif ($c -eq '[') { $bracket = $true }
        elseif ($c -eq '#') { $date = $true }
        elseif ($c -eq ';') {
            $statements.Add(@($start, $sql.Substring($start, $i - $start)))
            $start = $i + 1
        }
    }
    if ($start -lt $sql.Length) { $statements.Add(@($start, $sql.Substring($start))) }
    $errors = 0; $count = 0
    foreach ($item in $statements) {
        $part = [string]$item[1]
        $match = [regex]::Match($part, '\S')
        if (-not $match.Success) { continue }
        $pos = [int]$item[0] + $match.Index
        $prefix = $sql.Substring(0, $pos)
        $lineNo = ([regex]::Matches($prefix, "`n")).Count + 1
        $lastNewline = $prefix.LastIndexOf("`n")
        $colNo = $pos - $lastNewline
        $statement = $part.Trim(); $count++
        try {
            if ($statement -match '^\s*(SELECT|TRANSFORM)\b') {
                $rs = $null
                try {
                    $rs = $db.OpenRecordset($statement, 4)
                    while (-not $rs.EOF) {
                        $values = for ($j=0; $j -lt $rs.Fields.Count; $j++) { [string]$rs.Fields.Item($j).Value }
                        $lines.Add(($values -join ' | '))
                        $rs.MoveNext()
                    }
                } finally { if ($null -ne $rs) { $rs.Close(); [void][Runtime.InteropServices.Marshal]::ReleaseComObject($rs) } }
            } else { $db.Execute($statement, 128) }
        } catch {
            $errors++
            $message = ($_.Exception.Message -replace '[\r\n]+', ' ')
            $lines.Add(('TSE: {0}:{1}:{2}: {3} (location is statement start)' -f $sourcePath,$lineNo,$colNo,$message))
        }
    }
    if ($count -eq 0) { throw 'No SQL statements found.' }
    if ($errors -eq 0) { $lines.Add("Access: $count statement(s) completed successfully."); $result = 0 }
    else { $lines.Add("Access: $errors statement(s) failed out of $count."); $result = 1 }
} catch {
    $lines.Add(('ERROR: ' + ($_.Exception.Message -replace '[\r\n]+', ' ')))
    $result = 1
} finally {
    if ($null -ne $db) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($db) }
    if ($null -ne $app) {
        try { $app.CloseCurrentDatabase() } catch {}
        try { $app.Quit() } catch {}
        [void][Runtime.InteropServices.Marshal]::ReleaseComObject($app)
    }
    if ($tempDb -and [IO.File]::Exists($tempDb)) { try { Remove-Item -LiteralPath $tempDb -Force } catch { $lines.Add("WARNING: could not remove temporary database: $tempDb") } }
}
try { [IO.File]::WriteAllLines([IO.Path]::GetFullPath($OutputFile), [string[]]$lines, [Text.Encoding]::Default) }
catch { [Console]::Error.WriteLine('ERROR: cannot write output file: ' + $_.Exception.Message); exit 1 }
exit $result
