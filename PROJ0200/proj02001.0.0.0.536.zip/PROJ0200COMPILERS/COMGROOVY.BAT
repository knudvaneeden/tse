@ECHO OFF
REM COMGROOVY version 1.0.0.0.10
REM Run GROOVY program
REM Prepared with OpenAI ChatGPT (Codex), 2026-10-14.
REM
REM PART 1 - USER SETTINGS AND TEST INSTRUCTIONS
REM Edit the paths below for your installation. No helper programs are used.
REM Groovy 4 requires Java 8 or later.
REM Direct use: COMGROOVY.BAT "C:\path\helloworld.groovy"
REM TSE use: COMGROOVY.BAT "name" ".groovy" "full source" "drive" "path" "output"
REM Optional direct overrides:
REM COMGROOVY.BAT "source.groovy" "groovy.bat" "Java home" "output.txt"
REM Parameters in direct mode: 1=source, 2=runner, 3=Java home, 4=output.
REM Parameters in TSE mode: 1=name, 2=extension, 3=source, 4=drive,
REM                         5=path, 6=output. Six-parameter mode takes priority.
REM Test in each console (replace the TCC path if necessary):
REM tcc.exe /c COMGROOVY.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\helloworld.groovy"
REM cmd.exe /d /c COMGROOVY.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\helloworld.groovy"
REM Repeat both tests with errorstest.groovy; expect three compilation errors.
REM Then test both files through the supplied TSE rule and jump to each error.
REM GROOVY_LAUNCH=native calls groovy.bat in the current TCC or CMD shell.
REM Default cmd: Groovy 4.0.8 startGroovy.bat uses CMD-specific syntax.
REM The wrapper runs in TCC; only the bundled Groovy launcher uses CMD.
REM Set native only if your installed launcher is known to support TCC.
REM COMGROOVY_PAUSE=yes pauses after output; no suits TSE's output window.
SETLOCAL
SET "GROOVY_RUNNER=G:\LANGUAGE\COMPUTER\GROOVY\groovy-4.0.8\bin\groovy.bat"
SET "JAVA_HOME=G:\LANGUAGE\COMPUTER\JAVA\jdk1.8.0_05_64"
SET "GROOVY_LAUNCH=cmd"
SET "COMGROOVY_PAUSE=yes"

REM PART 2 - GENERAL IMPLEMENTATION (NO USER CHANGES REQUIRED)
SET "SOURCE="
SET "OUTPUT="
SET "RUN_RC=1"
ECHO COMGROOVY version 1.0.0.0.10
IF NOT "%~6"=="" GOTO tseParameters
SET "SOURCE=%~1"
IF NOT "%~2"=="" SET "GROOVY_RUNNER=%~2"
IF NOT "%~3"=="" SET "JAVA_HOME=%~3"
SET "OUTPUT=%~4"
GOTO parametersReady

:tseParameters
SET "SOURCE=%~3"
SET "OUTPUT=%~6"

:parametersReady
IF "%SOURCE%"=="" GOTO usage
FOR %%F IN ("%SOURCE%") DO SET "SOURCE=%%~fF"
IF "%OUTPUT%"=="" SET "OUTPUT=%TEMP%\comgroovy-%RANDOM%-%RANDOM%.txt"
FOR %%F IN ("%OUTPUT%") DO SET "OUTPUT=%%~fF"
IF /I "%SOURCE%"=="%OUTPUT%" GOTO outputIsSource
>"%OUTPUT%" ECHO filename=%SOURCE%
IF ERRORLEVEL 1 GOTO outputFailed
IF NOT EXIST "%SOURCE%" GOTO sourceMissing
REM Do not use IF EXIST "filename\"; TCC may match an ordinary file.
IF DEFINED _TCC GOTO checkTccDirectory
REM CMD checks attributes without adding a trailing slash to the filename.
SET "SOURCE_ATTRIBUTES="
FOR %%F IN ("%SOURCE%") DO SET "SOURCE_ATTRIBUTES=%%~aF"
IF /I "%SOURCE_ATTRIBUTES:~0,1%"=="d" GOTO sourceDirectory
GOTO sourceReady

:checkTccDirectory
IF ISDIR "%SOURCE%" GOTO sourceDirectory

:sourceReady
IF NOT EXIST "%GROOVY_RUNNER%" GOTO runnerMissing
IF NOT EXIST "%JAVA_HOME%\bin\java.exe" GOTO javaMissing
ECHO Running "%SOURCE%"
REM Run relative script file operations in the source's directory.
FOR %%F IN ("%SOURCE%") DO PUSHD "%%~dpF"
IF ERRORLEVEL 1 GOTO directoryFailed
IF /I "%GROOVY_LAUNCH%"=="cmd" GOTO runWithCmd
CALL "%GROOVY_RUNNER%" "%SOURCE%" >>"%OUTPUT%" 2>&1
SET "RUN_RC=%ERRORLEVEL%"
GOTO runFinished

:runWithCmd
cmd.exe /d /c call "%GROOVY_RUNNER%" "%SOURCE%" >>"%OUTPUT%" 2>&1
SET "RUN_RC=%ERRORLEVEL%"

:runFinished
POPD
GOTO showOutput

:sourceMissing
>>"%OUTPUT%" ECHO ERROR: source file not found: "%SOURCE%"
GOTO showOutput
:sourceDirectory
>>"%OUTPUT%" ECHO ERROR: source path is a directory: "%SOURCE%"
GOTO showOutput
:runnerMissing
>>"%OUTPUT%" ECHO ERROR: Groovy launcher not found: "%GROOVY_RUNNER%"
GOTO showOutput
:javaMissing
>>"%OUTPUT%" ECHO ERROR: Java executable not found under JAVA_HOME: "%JAVA_HOME%"
GOTO showOutput
:directoryFailed
>>"%OUTPUT%" ECHO ERROR: cannot enter source directory.
GOTO showOutput
:outputIsSource
ECHO ERROR: output must not overwrite the source file.
GOTO finish
:outputFailed
ECHO ERROR: cannot write output file: "%OUTPUT%"
GOTO finish
:usage
ECHO Usage: COMGROOVY.BAT "source.groovy" ["groovy.bat" ["Java home" ["output.txt"]]]
GOTO finish

:showOutput
TYPE "%OUTPUT%"
ECHO Groovy exit code: %RUN_RC%
ECHO Diagnostics: "%OUTPUT%"
:finish
IF /I "%COMGROOVY_PAUSE%"=="yes" PAUSE
ENDLOCAL & EXIT /B %RUN_RC%
