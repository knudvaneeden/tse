@echo off
REM COMPHP.BAT version 1.0.0.7 - OpenAI GPT-6
REM PART 1 contains local settings; PART 2 contains shared logic.
REM Native TCC and CMD; no nested shell and no runtime helper program.
REM Direct: COMPHP.BAT "C:\My files\errorstest.php"
REM Direct override: COMPHP.BAT /run "source.php" "C:\PHP\php.exe" "C:\Temp\php.err"
REM TSE: %1=name %2=extension %3=source %4=drive %5=path %6=error file
REM Optional %7 overrides php.exe for a TSE call.
REM COMPHP.BAT errorstest php "F:\My files\errorstest.php" F "My files" "C:\Temp\php.err"
REM In an existing TCC console run the above commands directly.
REM In a separate CMD console run the same commands; do not nest TCC.
REM /? prints help. Set COMPHP_PAUSE=0 for unattended tests.
REM Test errorstest.php: two warning entries at lines 6 and 7; exit code 1.
REM Standard PHP diagnostics have no column. The rule leaves column unavailable.
REM Syntax checking stops at the first parse error per file; warnings may continue.
REM ================================================================
REM PART 1 - USER SETTINGS
REM ================================================================
setlocal
if not defined COMPHP_EXE set "COMPHP_EXE=g:\language\computer\php\php.exe"
if not defined COMPHP_LOG set "COMPHP_LOG=%TEMP%\comphp-output.err"
if not defined COMPHP_PAUSE set "COMPHP_PAUSE=1"
REM CLI diagnostics are the default. Optional Apache publishing follows success.
if not defined COMPHP_WEB set "COMPHP_WEB=0"
if not defined COMPHP_WEBROOT set "COMPHP_WEBROOT=g:\utils\apache\htdocs"
if not defined COMPHP_URL set "COMPHP_URL=http://localhost"
if not defined COMPHP_START_SERVER set "COMPHP_START_SERVER=0"
if not defined COMPHP_SERVER set "COMPHP_SERVER=g:\utils\apache\bin\httpd.exe"
if not defined COMPHP_BROWSER set "COMPHP_BROWSER=1"
if not defined COMPHP_COPY_OUTPUT set "COMPHP_COPY_OUTPUT=0"
if not defined COMPHP_COPY_LOG set "COMPHP_COPY_LOG=c:\temp\dddoutput.txt"
REM Set COMPHP_LINT=1 for syntax checking only, without executing the script.
if not defined COMPHP_LINT set "COMPHP_LINT=0"
REM ================================================================
REM PART 2 - SHARED LOGIC
REM ================================================================
set "CP_RC=1"
set "CP_OPTIONS="
set "CP_TCC=0"
if not "%_cmdproc%"=="" set "CP_TCC=1"
echo COMPHP version 1.0.0.7
if "%~1"=="" goto cp_help
if /i "%~1"=="/?" goto cp_help
if /i "%~1"=="/help" goto cp_help
if /i "%~1"=="/run" goto cp_direct
if not "%~3"=="" goto cp_tse
set "CP_SOURCE=%~1"
goto cp_validate
:cp_tse
set "CP_SOURCE=%~3"
if not "%~6"=="" set "COMPHP_LOG=%~6"
if not "%~7"=="" set "COMPHP_EXE=%~7"
goto cp_validate
:cp_direct
set "CP_SOURCE=%~2"
if not "%~3"=="" set "COMPHP_EXE=%~3"
if not "%~4"=="" set "COMPHP_LOG=%~4"
:cp_validate
if "%CP_SOURCE%"=="" goto cp_no_source
if "%CP_TCC%"=="1" goto cp_tcc_check
if not exist "%CP_SOURCE%" goto cp_no_source
REM CMD-only directory test. Never execute this test under TCC.
if exist "%CP_SOURCE%\" goto cp_no_source
if not exist "%COMPHP_EXE%" goto cp_no_php
if exist "%COMPHP_EXE%\" goto cp_no_php
goto cp_paths
:cp_tcc_check
REM TCC ISDIR distinguishes a directory from an existing source file.
if isdir "%CP_SOURCE%" goto cp_no_source
if not isfile "%CP_SOURCE%" goto cp_no_source
if isdir "%COMPHP_EXE%" goto cp_no_php
if not isfile "%COMPHP_EXE%" goto cp_no_php
:cp_paths
for %%F in ("%CP_SOURCE%") do set "CP_SOURCE=%%~fF"
for %%F in ("%COMPHP_LOG%") do set "COMPHP_LOG=%%~fF"
REM Protect the source from accidental truncation through an incorrect log path.
if /i "%CP_SOURCE%"=="%COMPHP_LOG%" goto cp_same_log
>"%COMPHP_LOG%" echo COMPHP version 1.0.0.7
if errorlevel 1 goto cp_no_log
>>"%COMPHP_LOG%" echo filename=%CP_SOURCE%
if "%COMPHP_LINT%"=="1" set "CP_OPTIONS=-l"
REM Force plain, visible diagnostics once, independent of php.ini defaults.
"%COMPHP_EXE%" -d display_errors=stderr -d display_startup_errors=1 -d html_errors=0 -d log_errors=0 -d error_reporting=2147483647 %CP_OPTIONS% -f "%CP_SOURCE%" >>"%COMPHP_LOG%" 2>&1
set "CP_RC=%ERRORLEVEL%"
>>"%COMPHP_LOG%" echo Exit code: %CP_RC%
type "%COMPHP_LOG%"
if not "%COMPHP_COPY_OUTPUT%"=="1" goto cp_after_copy
if /i "%COMPHP_LOG%"=="%COMPHP_COPY_LOG%" goto cp_after_copy
copy /y "%COMPHP_LOG%" "%COMPHP_COPY_LOG%" >nul
if not errorlevel 1 goto cp_after_copy
echo ERROR: Cannot copy log to "%COMPHP_COPY_LOG%".
if "%CP_RC%"=="0" set "CP_RC=1"
:cp_after_copy
if not "%CP_RC%"=="0" goto cp_finish
if "%COMPHP_LINT%"=="1" goto cp_finish
if not "%COMPHP_WEB%"=="1" goto cp_finish
if "%CP_TCC%"=="1" goto cp_tcc_web
if not exist "%COMPHP_WEBROOT%\." goto cp_no_webroot
goto cp_publish
:cp_tcc_web
if not isdir "%COMPHP_WEBROOT%" goto cp_no_webroot
:cp_publish
for %%F in ("%CP_SOURCE%") do set "CP_NAME=%%~nxF"
for %%F in ("%COMPHP_WEBROOT%\%CP_NAME%") do set "CP_DEST=%%~fF"
if /i "%CP_SOURCE%"=="%CP_DEST%" goto cp_web_ready
copy /y "%CP_SOURCE%" "%CP_DEST%" >nul
if errorlevel 1 goto cp_copy_failed
:cp_web_ready
if not "%COMPHP_START_SERVER%"=="1" goto cp_browser
if not exist "%COMPHP_SERVER%" goto cp_no_server
start "" "%COMPHP_SERVER%"
REM No readiness check: prefer Apache already running as a service.
:cp_browser
REM For filenames requiring URL encoding, set COMPHP_BROWSER=0.
if "%COMPHP_BROWSER%"=="1" start "" "%COMPHP_URL%/%CP_NAME%"
goto cp_finish
:cp_no_source
echo ERROR: source file not found or is a directory: "%CP_SOURCE%"
goto cp_finish
:cp_no_php
echo ERROR: PHP executable not found: "%COMPHP_EXE%"
goto cp_finish
:cp_same_log
echo ERROR: Source and error log must be different files.
goto cp_finish
:cp_no_log
echo ERROR: Cannot create error log: "%COMPHP_LOG%"
goto cp_finish
:cp_no_webroot
echo ERROR: Apache document directory not found: "%COMPHP_WEBROOT%"
set "CP_RC=1"
goto cp_finish
:cp_no_server
echo ERROR: Apache executable not found: "%COMPHP_SERVER%"
set "CP_RC=1"
goto cp_finish
:cp_copy_failed
echo ERROR: Cannot copy source to "%CP_DEST%"
set "CP_RC=1"
goto cp_finish
:cp_help
echo Usage: COMPHP.BAT "source.php"
echo Or: COMPHP.BAT /run "source.php" "php.exe" "error log"
echo TSE: COMPHP.BAT name php "source.php" drive path "error log"
set "CP_RC=0"
:cp_finish
if "%COMPHP_PAUSE%"=="1" pause
endlocal & exit /b %CP_RC%
