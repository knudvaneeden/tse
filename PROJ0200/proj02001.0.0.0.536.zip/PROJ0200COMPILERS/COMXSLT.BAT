@echo off
REM COMXSLT.BAT - Version 1.0.0.0.0 - 2026-11-01
REM PART 1 - USER SETTINGS AND USAGE
REM Change PYTHON_EXE below to your installed Python executable.
REM Install lxml: "g:\language\computer\python\python\python.exe" -m pip install lxml
REM Direct use: COMXSLT.BAT "full path\source.xslt"
REM TSE arguments: 1=name, 2=extension, 3=full source, 4=drive, 5=path,
REM 6=diagnostic output file. Direct use requires only argument 1.
REM Checks XML syntax, compiles XSLT 1.0, then transforms a built-in
REM <example><greeting>Hello, world!</greeting></example> input document.
REM No separate helper or input XML file is needed for the supplied tests.
REM XSLT 2.0/3.0 features require another processor such as Saxon.
REM Local xsl:include/import are resolved relative to the stylesheet.
REM Network loading, document() file/network access and writes are disabled.
REM Error test: three invalid XPath expressions on three separate lines.
REM One XPath error can produce several compiler diagnostics.
REM XML fatal errors may prevent later stylesheet checks.
REM ASCII console and diagnostics; file/line/column format for TSE jumping.
REM XSLT diagnostics without a column use column 1.
REM Run in cmd.exe and TCC: call COMXSLT.BAT "helloworldxslt.xslt"
REM Then: call COMXSLT.BAT "errorstestxslt.xslt"
REM Exit codes: 0=OK; 1=XML/XSLT error; 2=configuration/file error.
REM The console always pauses after each run.
setlocal
set "PYTHON_EXE=g:\language\computer\python\python\python.exe"
REM PART 2 - FIXED LOGIC
set "COMXSLT_SELF=%~f0"
set "COMXSLT_SOURCE=%~1"
set "COMXSLT_OUTPUT="
if not "%~3"=="" set "COMXSLT_SOURCE=%~3"
if not "%~3"=="" set "COMXSLT_OUTPUT=%~6"
if "%~1"=="" goto usage
if not exist "%PYTHON_EXE%" goto noengine
"%PYTHON_EXE%" -c "import os; p=os.environ['COMXSLT_SELF']; t=open(p,encoding='ascii').read(); exec(compile(t.split('# COMXSLT_'+'PYTHON_BEGIN',1)[1],p,'exec'))"
set "COMXSLT_RESULT=%errorlevel%"
goto finish
:usage
echo COMXSLT.BAT version 1.0.0.0.0
echo Usage: COMXSLT.BAT "source.xslt"
set "COMXSLT_RESULT=2"
goto finish
:noengine
echo ERROR: Python executable not found: "%PYTHON_EXE%"
set "COMXSLT_RESULT=2"
goto finish
:finish
pause
exit /b %COMXSLT_RESULT%
# COMXSLT_PYTHON_BEGIN
import os, sys, re
from pathlib import Path
from urllib.parse import urlsplit, unquote
VERSION = "1.0.0.0.0"
lines = []
status = 2
source = Path(os.environ["COMXSLT_SOURCE"]).absolute()
def native_filename(filename):
    if not filename or filename.startswith("<"):
        return str(source)
    if filename.lower().startswith("file:"):
        uri = urlsplit(filename)
        name = unquote(uri.path)
        if uri.netloc and uri.netloc.lower() != "localhost":
            name = "//" + uri.netloc + name
        elif re.match(r"^/[A-Za-z]:", name):
            name = name[1:]
        return name.replace("/", "\\") if os.name == "nt" else name
    return filename

def diagnostic(filename, row, col, message):
    message = " ".join(str(message).splitlines())
    lines.append(f'TSE: "{native_filename(filename)}" line {max(1,row)} column {max(1,col)}: ERROR: {message}')
try:
    from lxml import etree
    if not source.is_file():
        raise OSError("Source file not found or is a directory: " + str(source))
    parser = etree.XMLParser(no_network=True, resolve_entities=False, load_dtd=False, recover=False)
    try:
        doc = etree.parse(str(source), parser)
        transform = etree.XSLT(doc, access_control=etree.XSLTAccessControl.DENY_ALL)
        result = transform(etree.XML(b'<example><greeting>Hello, world!</greeting></example>'))
        lines.append("COMXSLT.BAT version " + VERSION + ": XSLT 1.0 compiled and transformed: " + str(source))
        lines.append("Transformation result:")
        lines.extend(str(result).splitlines())
        status = 0
    except (etree.XMLSyntaxError, etree.XSLTParseError, etree.XSLTApplyError) as exc:
        status = 1
        seen = set()
        entries = list(exc.error_log)
        # Prefer located diagnostics: generic XPath entries have line 0.
        located = [e for e in entries if e.line > 0 and e.level_name in ("ERROR", "FATAL")]
        for entry in located or entries:
            if entry.level_name not in ("ERROR", "FATAL"):
                continue
            key = (native_filename(entry.filename), entry.line, entry.column, entry.message)
            if key not in seen:
                seen.add(key)
                diagnostic(*key)
        if not seen:
            diagnostic(str(source), 1, 1, str(exc))
except ImportError:
    lines.append("COMXSLT configuration error: install lxml with the configured Python: python -m pip install lxml")
except Exception as exc:
    lines.append("COMXSLT configuration error: " + str(exc))
lines = [line.encode("ascii", errors="replace").decode("ascii") for line in lines]
for line in lines:
    print(line, flush=True)
output = os.environ.get("COMXSLT_OUTPUT", "")
if output:
    try:
        Path(output).write_text("\n".join(lines) + "\n", encoding="ascii")
    except OSError as exc:
        print("COMXSLT cannot write output: " + str(exc))
        status = 2
sys.exit(status)
