@echo off
REM COMDATABASEINTERBASE.BAT version 1.0.0.0.11
REM PART 1 - USER SETTINGS AND TESTS
REM Set ibDatabase to an existing test database before running either test.
REM Existing ISC_USER and ISC_PASSWORD are used; otherwise the BAT prompts.
REM Password input is visible on screen. Values exist only in this local BAT scope.
REM Do not save a password in this BAT file. See InterBase documentation.
REM The SQL is executed, not merely checked. Use a disposable test database.
REM Supply credentials through your InterBase environment or configuration.
REM Do not put a password in this file or on the command line.
REM Short form: COMDATABASEINTERBASE.BAT "source.sql" "output.err"
REM TSE form: %1=name %2=extension %3=source %4=drive %5=path %6=output
REM TCC: COMDATABASEINTERBASE.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstestdatabaseinterbase.sql" "C:\temp\interbase-tcc.err"
REM CMD: cmd.exe /d /c COMDATABASEINTERBASE.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstestdatabaseinterbase.sql" "C:\temp\interbase-cmd.err"
REM Repeat both tests with helloworlddatabaseinterbase.sql.
REM Examine the .err file and its accompanying .interbase.raw file.
REM Version 1.0.0.0.11: native TCC token mapping; Windows testing required.
REM Successful output produces an empty error file. Error locations are unverified.
REM The diagnostic at line 1 is a fallback, not a verified error location.
setlocal
set "ibExe=C:\program files (x86)\embarcadero\rad studio\12.0\interbasexe3\bin\isql.exe"
set "ibDatabase=localhost:G:\DATABASE\EXAMPLE\INTERBASE\employee.gdb"
set "ibPause=1"
REM PART 2 - SYSTEM CODE
set "ibSource=%~1"
set "ibOutput=%~2"
if not "%~3"=="" goto tseArguments
goto argumentsReady
:tseArguments
set "ibSource=%~3"
set "ibOutput=%~6"
:argumentsReady
if not defined ibSource goto usage
if not defined ibOutput set "ibOutput=%ibSource%.err"
for %%I in ("%ibSource%") do set "ibSource=%%~fI"
for %%I in ("%ibOutput%") do set "ibOutput=%%~fI"
if /i "%ibSource%"=="%ibOutput%" goto sameFile
set "ibRaw=%ibOutput%.interbase.raw"
if /i "%ibSource%"=="%ibRaw%" goto sameFile
set "ibRc=1"
echo COMDATABASEINTERBASE.BAT version 1.0.0.0.11
if not exist "%ibSource%" goto sourceMissing
if "%@eval[2+2]"=="4" goto checkTccDirectory
if exist "%ibSource%\NUL" goto sourceMissing
goto checkSettings
:checkTccDirectory
if isdir "%ibSource%" goto sourceMissing
:checkSettings
if not exist "%ibExe%" goto exeMissing
if not defined ibDatabase goto dbMissing
if not defined ISC_USER set "ISC_USER=SYSDBA"
if not defined ISC_PASSWORD set /p ISC_PASSWORD=InterBase password (visible): 
if not defined ISC_PASSWORD goto passwordMissing
"%ibExe%" -echo -merge_stderr -input "%ibSource%" "%ibDatabase%" > "%ibRaw%" 2>&1
set "ibRc=%errorlevel%"
type "%ibRaw%"
type nul > "%ibOutput%"
if errorlevel 1 goto outputFailed
REM XE3 errors have statement-relative line numbers. File-line mapping is not
REM yet implemented. Keep the complete isql output for diagnosis.
findstr /i /c:"Statement failed" /c:"SQL error code" /c:"unsuccessful execution" /c:"error:" "%ibRaw%" > nul
if not errorlevel 1 goto sqlFailure
if not "%ibRc%"=="0" goto sqlFailure
goto finish
:sqlFailure
if "%@eval[2+2]"=="4" goto tccLocations
> "%ibOutput%" echo TSE: %ibSource%:1:1: InterBase error; source location unavailable. See %ibRaw%.
set "ibRc=1"
goto finish
:tccLocations
REM Native TCC parser. Match source records in order against -echo output.
REM Only a token uniquely found on the last matched source line is located.
REM Other forms and CMD retain the explicit unlocated-error fallback.
set ibRead=%@fileopen["%ibRaw%",r]
if %ibRead% LT 0 goto locationFallback
set ibSrc=%@fileopen["%ibSource%",r]
if %ibSrc% LT 0 goto closeRawFallback
set ibWrite=%@fileopen["%ibOutput%",w]
if %ibWrite% LT 0 goto closeSourceFallback
set ibNumber=0
set ibMatched=0
set ibCount=0
set ibFailures=0
set ibNeedToken=0
setdos /x-568
:nextSourceRecord
set ibExpected=%@fileread[%ibSrc%]
if "%ibExpected%"=="**EOF**" goto readRawRecord
set ibNumber=%@eval[%ibNumber%+1]
if "%ibExpected%"=="" goto nextSourceRecord
:readRawRecord
set ibRecord=%@fileread[%ibRead%]
if "%ibRecord%"=="**EOF**" goto locationsDone
if "%ibRecord%"=="%ibExpected%" goto matchedSourceRecord
if "%@left[16,%ibRecord%]"=="Statement failed" set ibFailures=%@eval[%ibFailures%+1]
if "%ibNeedToken%"=="1" goto tokenRecord
if "%@left[14,%ibRecord%]"=="-Token unknown" set ibNeedToken=1
goto readRawRecord
:matchedSourceRecord
set ibMatched=%ibNumber%
set ibLast=%ibExpected%
goto nextSourceRecord
:tokenRecord
set ibNeedToken=0
if %ibMatched% LE 0 goto readRawRecord
if not "%@left[1,%ibRecord%]"=="-" goto readRawRecord
set ibToken=%@instr[1,,%ibRecord%]
if "%ibToken%"=="" goto readRawRecord
REM Quotes and separators in SQL tokens are not handled by this first parser.
if "%@index[%ibToken%,^,]" GE 0 goto readRawRecord
if "%@index[%ibLast%,^,]" GE 0 goto readRawRecord
set ibHits=%@index[%ibLast%,%ibToken%,0]
if not "%ibHits%"=="1" goto readRawRecord
set ibColumn=%@eval[%@index[%ibLast%,%ibToken%]+1]
if %ibColumn% LE 0 goto readRawRecord
set ibDiscard=%@filewrite[%ibWrite%,TSE: %ibSource%:%ibMatched%:%ibColumn%: SQLCODE -104: Token unknown: %ibToken%]
set ibCount=%@eval[%ibCount%+1]
goto readRawRecord
:locationsDone
if %ibCount% LT %ibFailures% set ibDiscard=%@filewrite[%ibWrite%,TSE: %ibSource%:1:1: Additional InterBase errors have no mapped location. See %ibRaw%.]
if %ibCount% EQ 0 set ibDiscard=%@filewrite[%ibWrite%,TSE: %ibSource%:1:1: InterBase error location unavailable. See %ibRaw%.]
set ibDiscard=%@fileclose[%ibWrite%]
set ibDiscard=%@fileclose[%ibSrc%]
set ibDiscard=%@fileclose[%ibRead%]
setdos /x0
set "ibRc=1"
goto finish
:closeSourceFallback
set ibDiscard=%@fileclose[%ibSrc%]
:closeRawFallback
set ibDiscard=%@fileclose[%ibRead%]
:locationFallback
> "%ibOutput%" echo TSE: %ibSource%:1:1: InterBase error location unavailable. See %ibRaw%.
set "ibRc=1"
goto finish
:sourceMissing
> "%ibOutput%" echo TSE: %ibSource%:1:1: ERROR: Source missing or is a directory.
goto showFailure
:exeMissing
> "%ibOutput%" echo TSE: %ibSource%:1:1: ERROR: InterBase isql.exe not found: %ibExe%
goto showFailure
:passwordMissing
> "%ibOutput%" echo TSE: %ibSource%:1:1: ERROR: No InterBase password was supplied.
goto showFailure
:dbMissing
> "%ibOutput%" echo TSE: %ibSource%:1:1: ERROR: Set ibDatabase to an existing test database in the BAT file.
:showFailure
type "%ibOutput%"
goto finish
:outputFailed
echo ERROR: Cannot write output file: "%ibOutput%"
goto finish
:sameFile
echo ERROR: Source and output files must be different.
endlocal & exit /b 2
:usage
echo Usage: COMDATABASEINTERBASE.BAT "source.sql" "output.err"
set "ibRc=2"
:finish
echo Exit code: %ibRc%
if not "%ibPause%"=="0" pause
endlocal & exit /b %ibRc%
