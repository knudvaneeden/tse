@echo off
rem COMRUST.BAT version 1.0.0.0.8
rem Updated 2026-10-01 - OpenAI GPT-6
rem
rem PURPOSE: Build and run a Rust source file, preserving TSE error output.
rem
rem MANUAL TEST: Run the following as ONE command in CMD or TCC.
rem Adapt the batch path, source path, and error-file path to your system.
rem "F:\BBC\TAAL\COMRUST.BAT" "ddd" "unused" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.rs" "unused" "unused" "C:\TEMP\comrust_test.err"
rem
rem EXTERNAL ARGUMENTS - keep all six positions, including placeholders:
rem   Argument 1 (%1): Project directory name, for example ddd.
rem   Argument 2 (%2): Unused by this batch; supply "unused" for testing.
rem   Argument 3 (%3): Full path to the Rust source file, including .rs.
rem   Argument 4 (%4): Unused by this batch; supply "unused" for testing.
rem   Argument 5 (%5): Unused by this batch; supply "unused" for testing.
rem   Argument 6 (%6): Full path to the TSE error/output file.
rem Cargo.exe is configured below; it is NOT an external argument.
rem The parent directory of the argument 6 file must already exist.
rem Quote file paths, especially when they contain spaces.
rem When invoking from ANOTHER batch file, prefix the command with CALL.
rem Expected output for the sample ddd.rs: Hello from Rust.
rem The batch pauses at the end and returns 0 for success or 1 for failure.
rem
setlocal
rem ================================================================
rem PART 1 - USER CONFIGURATION: Adapt these local system paths.
rem ================================================================
rem Full path to Cargo. USERPROFILE normally locates the current user.
set "rustCargo=%USERPROFILE%\.cargo\bin\cargo.exe"
rem Base directory for temporary Cargo projects. No trailing backslash.
set "rustProjectBase=C:\TEMP"
rem Additional copy of the TSE error/output file. Parent must exist.
set "rustOutputCopy=C:\TEMP\dddoutput.txt"
rem
rem ================================================================
rem PART 2 - PROGRAM LOGIC: No user changes normally required below.
rem ================================================================
set "rustProject=%rustProjectBase%\%~1"
set "rustSource=%~f3"
set "rustErrors=%~f6"
if "%~1"=="" goto badargs
if "%~3"=="" goto badargs
if "%~6"=="" goto badargs
echo filename=%~3 >"%rustErrors%"
if not exist "%rustSource%" goto nosource
if not exist "%rustCargo%" goto nocargo
if not exist "%rustProjectBase%\" mkdir "%rustProjectBase%" >>"%rustErrors%" 2>&1
if errorlevel 1 goto failed
if exist "%rustProject%\Cargo.toml" goto ready
if exist "%rustProject%\" goto initialize
"%rustCargo%" new "%rustProject%" --bin --vcs none >>"%rustErrors%" 2>&1
if errorlevel 1 goto failed
goto ready
:initialize
"%rustCargo%" init "%rustProject%" --bin --vcs none >>"%rustErrors%" 2>&1
if errorlevel 1 goto failed
:ready
if not exist "%rustProject%\Cargo.toml" goto nomanifest
pushd "%rustProject%"
if errorlevel 1 goto failed
rem Cargo init may have adopted main.rs in the project root.
if exist "main.rs" goto rootsource
if not exist "src\" mkdir "src"
if errorlevel 1 goto failedpop
copy /Y "%rustSource%" "src\main.rs" >>"%rustErrors%" 2>&1
if errorlevel 1 goto failedpop
goto run
:rootsource
copy /Y "%rustSource%" "main.rs" >>"%rustErrors%" 2>&1
if errorlevel 1 goto failedpop
:run
rem Cargo rebuilds changed source automatically; cargo clean is unnecessary.
"%rustCargo%" run --message-format short --color never >>"%rustErrors%" 2>&1
if errorlevel 1 goto failedpop
popd
set "rustResult=0"
goto display
:failedpop
popd
:failed
set "rustResult=1"
goto display
:nosource
echo ERROR: Rust source not found: "%rustSource%" >>"%rustErrors%"
goto failed
:nocargo
echo ERROR: Cargo not found: "%rustCargo%" >>"%rustErrors%"
goto failed
:nomanifest
echo ERROR: Cargo.toml was not created in "%rustProject%". >>"%rustErrors%"
goto failed
:display
type "%rustErrors%"
copy /Y "%rustErrors%" "%rustOutputCopy%" >nul
echo.
pause
endlocal & exit /b %rustResult%
:badargs
echo ERROR: Expected project name in argument 1, source in argument 3,
echo and TSE error filename in argument 6.
pause
endlocal & exit /b 1
