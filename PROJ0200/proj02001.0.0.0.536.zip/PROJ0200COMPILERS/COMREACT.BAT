@echo off
REM COMREACT.BAT - version 1.0.0.0.8 - 2026-11-06
REM Check JSX, then optionally copy it to an existing React app and start npm.
REM No custom helper program. Diagnostics are parsed by the TSE rule.
REM
REM PART 1 - USER SETTINGS AND TEST INSTRUCTIONS
REM Existing project retained from the original BAT; npm start must work there.
REM Install project dependencies first. This BAT requires ESLint 8.x:
REM   cd /d G:\language\computer\react\my-app
REM   npm install --save-dev --save-exact eslint@8.57.1
REM NODE_EXE can be a full path to node.exe, or node.exe on PATH.
REM ESLINT_JS is resolved below relative to PROJECT_DIR.
REM START_APP=yes copies successful input to APP_FILE and launches npm start.
REM START_APP=no performs checking only. No build/type checking is implied.
REM Existing APP_FILE is backed up once as APP_FILE.comreact.bak before copying.
REM Stop an existing server before launching another. React renders in a browser.
REM
REM TSE arguments: %%1=name %%2=extension %%3=full source path
REM                %%4=drive %%5=directory %%6=error output path
REM Optional overrides: %%7=node.exe %%8=project directory %%9=yes or no
REM Direct invocation also accepts just a full JSX pathname as %%1.
REM Empty %%6 uses a unique temporary report, displayed then deleted.
REM
REM Run BOTH tests below from their corresponding native shells.
REM Replace C:\TEMP and the TCC executable path with your own locations.
REM TCC test (enter in TCC, or launch tcc.exe /c with this CALL command):
REM   call COMREACT.BAT "errorstestreact" ".jsx" "F:\bbc\taal\proj0200errorsmultiple\errorstestreact.jsx" "" "" "C:\TEMP\react-tcc.err" "" "" "no"
REM CMD test (enter in cmd.exe /d, or launch cmd.exe /d /c with this CALL):
REM   call COMREACT.BAT "errorstestreact" ".jsx" "F:\bbc\taal\proj0200errorsmultiple\errorstestreact.jsx" "" "" "C:\TEMP\react-cmd.err" "" "" "no"
REM Expected for each: 3 diagnostics with line/column, exit code 1.
REM Repeat with helloworldreact.jsx: zero diagnostics, exit code 0.
REM Run hello with final argument yes to test browser launch too.
REM Test source/report/project paths containing spaces; test missing source.
REM Check ERRORLEVEL immediately after return. Reports remain for comparison.
REM Pause is controlled here because TSE's rule does not prompt after shell.
setlocal
set "NODE_EXE=node.exe"
set "PROJECT_DIR=G:\language\computer\react\my-app"
set "APP_FILE=src\App.js"
set "START_APP=yes"
set "PAUSE_AT_END=yes"

REM PART 2 - FIXED LOGIC - NO USER EDITS REQUIRED BELOW
set "RC=2"
set "PUSHED=no"
set "DELETE_REPORT=no"
if not "%~7" == "" set "NODE_EXE=%~7"
if not "%~8" == "" set "PROJECT_DIR=%~8"
if not "%~9" == "" set "START_APP=%~9"
set "SOURCE=%~3"
if not defined SOURCE set "SOURCE=%~1"
if not defined SOURCE goto usage
for %%F in ("%SOURCE%") do set "SOURCE=%%~fF"
if not exist "%SOURCE%" goto missing
REM TCC can match a file in IF EXIST filename\: never use that test in TCC.
REM _4VER is an internal variable, not an environment variable.
REM Expand its value instead of testing it with IF DEFINED.
if not "%_4VER%" == "" goto tcc_directory_test
if exist "%SOURCE%\" goto missing
goto source_ok
:tcc_directory_test
if isdir "%SOURCE%" goto missing
:source_ok
set "REPORT=%~6"
if not defined REPORT goto temporary_report
for %%F in ("%REPORT%") do set "REPORT=%%~fF"
goto report_ready
:temporary_report
set "REPORT=%TEMP%\comreact_%RANDOM%_%RANDOM%.err"
set "DELETE_REPORT=yes"
:report_ready
if /i "%SOURCE%" == "%REPORT%" goto same_report
REM Probe report access before invoking tools; diagnostics must reach TSE.
type nul > "%REPORT%"
if errorlevel 1 goto report_failed
 echo COMREACT.BAT version 1.0.0.0.8
if /i "%START_APP%" == "yes" goto settings_ok
if /i "%START_APP%" == "no" goto settings_ok
 echo ERROR: START_APP must be yes or no. >> "%REPORT%"
goto show_report
:settings_ok
pushd "%PROJECT_DIR%"
if errorlevel 1 goto project_failed
set "PUSHED=yes"
set "ESLINT_JS=%CD%\node_modules\eslint\bin\eslint.js"
if not exist "%ESLINT_JS%" goto eslint_missing
REM Explicit legacy mode: this command intentionally targets ESLint 8.x.
set "ESLINT_USE_FLAT_CONFIG=false"
"%NODE_EXE%" "%ESLINT_JS%" --version > "%REPORT%" 2>&1
if errorlevel 1 goto show_report
findstr /b /l "v8." "%REPORT%" >nul
if errorlevel 1 goto eslint_version
REM LEVN options avoid shell-dependent escaped JSON quoting.
REM --stdin prevents ignore rules from skipping a source outside the project.
"%NODE_EXE%" "%ESLINT_JS%" --no-eslintrc --no-ignore --env browser,es2022 --parser-options "ecmaVersion:2022,sourceType:module,ecmaFeatures:{jsx:true}" --rule "no-undef:error" --rule "no-dupe-keys:error" --rule "no-unreachable:error" --format unix --stdin --stdin-filename "%SOURCE%" < "%SOURCE%" > "%REPORT%" 2>&1
set "RC=%ERRORLEVEL%"
if not "%RC%" == "0" goto show_report
 echo JSX checks passed.
if /i "%START_APP%" == "no" goto show_report
for %%F in ("%APP_FILE%") do set "TARGET=%%~fF"
if /i "%SOURCE%" == "%TARGET%" goto start_app
if not exist "%TARGET%" goto copy_source
if exist "%TARGET%.comreact.bak" goto copy_source
copy /y "%TARGET%" "%TARGET%.comreact.bak" >nul
if errorlevel 1 goto copy_failed
:copy_source
copy /y "%SOURCE%" "%TARGET%" >nul
if errorlevel 1 goto copy_failed
:start_app
REM Launch only the dev server separately; the BAT itself runs in native shell.
start "React development server" npm.cmd start
if errorlevel 1 goto launch_failed
 echo npm start launched. Check the server window for startup/runtime errors.
 echo Later server/browser errors are not captured in this TSE report.
goto show_report
:eslint_missing
 echo ERROR: ESLint missing. In the project run npm install --save-dev --save-exact eslint@8.57.1 > "%REPORT%"
goto show_report
:eslint_version
 echo ERROR: This BAT requires ESLint 8.x for the unix formatter and CLI options. > "%REPORT%"
goto show_report
:project_failed
 echo ERROR: Cannot enter project directory: %PROJECT_DIR% >> "%REPORT%"
goto show_report
:copy_failed
set "RC=2"
 echo ERROR: Cannot back up or copy App.js. >> "%REPORT%"
goto show_report
:launch_failed
set "RC=2"
 echo ERROR: Cannot launch npm.cmd start. Check npm on PATH. >> "%REPORT%"
:show_report
type "%REPORT%"
if /i "%DELETE_REPORT%" == "yes" del "%REPORT%" >nul 2>&1
goto finish
:missing
 echo ERROR: source file not found or is a directory: "%SOURCE%"
goto finish
:usage
 echo Usage: COMREACT.BAT "full-source.jsx"
 echo Or use the six TSE parameters documented above.
goto finish
:same_report
 echo ERROR: Source and error report must be different files.
goto finish
:report_failed
 echo ERROR: Cannot write error report: "%REPORT%"
:finish
if /i "%PUSHED%" == "yes" popd
if /i "%PAUSE_AT_END%" == "yes" pause
endlocal & exit /b %RC%
