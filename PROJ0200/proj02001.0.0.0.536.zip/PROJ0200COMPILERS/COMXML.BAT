@echo off
REM COMXML.BAT - Version 1.0.0.0.0 - 2026-11-01
REM XML well-formedness checking with Python/lxml; no separate helper file.
REM PART 1 - USER SETTINGS AND USAGE
REM Change PYTHON_EXE below to your installed Python executable.
REM Install dependency with: "g:\language\computer\python\python\python.exe" -m pip install lxml
REM Direct use: COMXML.BAT "full path\source.xml"
REM TSE use: COMXML.BAT "%1" "%2" "%3" "%4" "%5" "%6"
REM Arguments: 1=name, 2=extension, 3=full source, 4=drive, 5=path,
REM 6=diagnostic output file. Direct use needs only argument 1.
REM Run these tests from the folder containing COMXML.BAT:
REM tcc.exe /c call COMXML.BAT "helloworldxml.xml"
REM tcc.exe /c call COMXML.BAT "errorstestxml.xml"
REM cmd.exe /d /c call COMXML.BAT "helloworldxml.xml"
REM cmd.exe /d /c call COMXML.BAT "errorstestxml.xml"
REM Expected exit codes: hello=0, errors=1. Check with echo %%errorlevel%%.
REM Repeat with full paths containing spaces and the six-argument TSE form:
REM COMXML.BAT "errorstestxml" ".xml" "f:\bbc\taal\proj0200errorsmultiple\errorstestxml.xml" "f:" "\bbc\taal\proj0200errorsmultiple\" "c:\temp\xml.err"
REM Also test a missing source and a directory: expected exit code 2.
REM File checks use Python is_file(), avoiding TCC IF EXIST file\ ambiguity.
REM Checks well-formedness only; does not validate against a DTD or XSD.
REM Reports all parser ERROR/FATAL entries; fatal errors may stop later checks.
REM External DTDs are not loaded and external entities are not expanded.
REM Exit codes: 0=OK; 1=XML errors; 2=configuration or file error.
setlocal
set "PYTHON_EXE=g:\language\computer\python\python\python.exe"
REM The console always pauses after each run.
REM PART 2 - FIXED LOGIC
set "COMXML_SELF=%~f0"
set "COMXML_SOURCE=%~1"
set "COMXML_OUTPUT="
if not "%~3"=="" set "COMXML_SOURCE=%~3"
if not "%~3"=="" set "COMXML_OUTPUT=%~6"
if "%~1"=="" goto usage
if not exist "%PYTHON_EXE%" goto noengine
"%PYTHON_EXE%" -c "import os; p=os.environ['COMXML_SELF']; t=open(p,encoding='ascii').read(); exec(compile(t.split('# COMXML_'+'PYTHON_BEGIN',1)[1],p,'exec'))"
set "COMXML_RESULT=%errorlevel%"
goto finish
:usage
echo COMXML.BAT version 1.0.0.0.0
echo Usage: COMXML.BAT "source.xml"
set "COMXML_RESULT=2"
goto finish
:noengine
echo ERROR: Python executable not found: "%PYTHON_EXE%"
set "COMXML_RESULT=2"
goto finish
:finish
pause
exit /b %COMXML_RESULT%
# COMXML_PYTHON_BEGIN
import os, sys, re
from pathlib import Path
from urllib.parse import urlsplit, unquote
VERSION = "1.0.0.0.0"
lines = []
status = 2
source = Path(os.environ["COMXML_SOURCE"]).absolute()
def native_filename(filename):
    if not filename or filename.startswith("<"):
        return str(source)
    if filename.lower().startswith("file:"):
        uri = urlsplit(filename)
        name = unquote(uri.path)
        if uri.netloc and uri.netloc.lower() != "localhost":
            name = "//" + uri.netloc + name
        elif re.match(r"^/[A-Za-z]:", name):
            name = name[1:]
        return name.replace("/", "\\") if os.name == "nt" else name
    return filename

def diagnostic(filename, row, col, message):
    filename = native_filename(filename)
    message = " ".join(str(message).splitlines())
    lines.append(f'TSE: "{filename}" line {max(1,row)} column {max(1,col)}: ERROR: {message}')
try:
    from lxml import etree
    if not source.is_file():
        raise OSError("Source file not found or is a directory: " + str(source))
    parser = etree.XMLParser(no_network=True, resolve_entities=False, load_dtd=False, recover=False)
    entries = []
    try:
        doc = etree.parse(str(source), parser)
        status = 0
    except etree.XMLSyntaxError as exc:
        entries = list(exc.error_log)
        status = 1
    seen = set()
    for entry in entries:
        if entry.level_name not in ("ERROR", "FATAL"):
            continue
        key = (native_filename(entry.filename), entry.line, entry.column, entry.message)
        if key not in seen:
            seen.add(key)
            diagnostic(*key)
        status = 1
    if status == 0:
        lines.append("COMXML.BAT version " + VERSION + ": XML well-formed: " + str(source))
    elif not seen:
        diagnostic(str(source), 1, 1, "XML parsing failed without a location diagnostic")
except ImportError:
    lines.append("COMXML configuration error: install lxml with the configured Python: python -m pip install lxml")
except Exception as exc:
    lines.append("COMXML configuration error: " + str(exc))
# Keep console and TSE diagnostics ASCII.
lines = [line.encode("ascii", errors="replace").decode("ascii") for line in lines]
for line in lines:
    print(line, flush=True)
output = os.environ.get("COMXML_OUTPUT", "")
if output:
    try:
        Path(output).write_text("\n".join(lines) + "\n", encoding="ascii")
    except OSError as exc:
        print("COMXML cannot write output: " + str(exc))
        status = 2
sys.exit(status)
