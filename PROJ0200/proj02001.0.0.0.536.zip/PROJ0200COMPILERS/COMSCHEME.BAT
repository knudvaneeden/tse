@echo off
REM COMSCHEME version 1.0.0.0.11 - OpenAI GPT-6
REM Chez Scheme runner. Native TCC and Microsoft CMD; no helper scripts.
REM PART 1 contains all local settings. PART 2 is shared logic.
REM Direct: COMSCHEME.BAT "C:\src\helloworld.scm"
REM Override: COMSCHEME.BAT --run "C:\src\helloworld.scm" "G:\Scheme\scheme.exe"
REM TSE: COMSCHEME.BAT name scm "full-source" drive subpath "error-file"
REM %1=name, %2=extension, %3=source, %4=drive, %5=subpath, %6=diagnostics.
REM A nonempty %3 uses the TSE interface, except when %1 is --run.
REM Do not use %4/%5 for tool overrides in the TSE interface.
REM Test each shell from its own console, without nesting TCC:
REM   tcc.exe /c call COMSCHEME.BAT "C:\src\helloworld.scm"
REM   cmd.exe /d /c call COMSCHEME.BAT "C:\src\helloworld.scm"
REM Repeat both tests with errorstest.scm and the six-parameter interface.
REM Example: COMSCHEME.BAT test scm "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.scm" F: "\BBC\TAAL\PROJ0200ERRORSMULTIPLE\" "%TEMP%\scheme-errors.txt"
REM Diagnostics are retained in %6, or a temporary file, and shown on screen.
REM Chez Scheme runs source files with --script and exits afterward.
REM Diagnostics are retained for the TSE compiler rule.
REM stdin is closed for noninteractive execution.
REM ================= PART 1: USER SETTINGS ===========================
setlocal
set "SCHEMEHEAPDIRS=G:\LANGUAGE\COMPUTER\SCHEME\boot\ta6nt"
set "CS_EXE=G:\LANGUAGE\COMPUTER\SCHEME\bin\ta6nt\scheme.exe"
set "CS_PAUSE=1"
REM Set CS_PAUSE=0 for unattended tests.
REM ================= PART 2: SHARED LOGIC ============================
set "CS_RC=0"
set "CS_PUSHED=0"
set "CS_SOURCE=%~1"
set "CS_LOG="
if /i "%~1"=="--help" goto help
if /i "%~1"=="/?" goto help
if /i "%~1"=="--run" goto directOverride
if "%~3"=="" goto resolve
set "CS_SOURCE=%~3"
set "CS_LOG=%~6"
REM Use drive and subpath only when parameter 3 is not already accessible.
if exist "%CS_SOURCE%" goto resolve
set "CS_SOURCE=%~4%~5%~3"
goto resolve
:directOverride
set "CS_SOURCE=%~2"
if not "%~3"=="" set "CS_EXE=%~3"
:resolve
if "%CS_LOG%"=="" set "CS_LOG=%TEMP%\comscheme-%RANDOM%-%RANDOM%.txt"
if "%CS_SOURCE%"=="" goto missing
if not exist "%CS_SOURCE%" goto missing
REM TCC's file existence behavior differs from CMD for a trailing backslash.
if defined _TCCVER goto tccCheck
for %%G in ("%CS_SOURCE%") do set "CS_ATTR=%%~aG"
if /i "%CS_ATTR:~0,1%"=="d" goto missing
goto checked
:tccCheck
if isdir "%CS_SOURCE%" goto missing
:checked
for %%G in ("%CS_SOURCE%") do set "CS_SOURCE=%%~fG"
for %%G in ("%CS_LOG%") do set "CS_LOG=%%~fG"
if /i "%CS_SOURCE%"=="%CS_LOG%" goto sameFile
REM Prove that the diagnostics file is writable before running Scheme.
>"%CS_LOG%" echo filename=%CS_SOURCE%
if errorlevel 1 goto logFailed
for %%G in ("%CS_SOURCE%") do pushd "%%~dpG"
if errorlevel 1 goto directoryFailed
set "CS_PUSHED=1"
echo COMSCHEME version 1.0.0.0.11
echo Running "%CS_SOURCE%"
REM Chez Scheme --script executes the source and exits.
REM Do not CALL an EXE: this avoids CALL's second expansion of source paths.
"%CS_EXE%" --script "%CS_SOURCE%" <nul >>"%CS_LOG%" 2>&1
set "CS_RC=%errorlevel%"
if not "%CS_RC%"=="0" >>"%CS_LOG%" echo ERROR: Scheme process exit code %CS_RC%; source location unavailable.
popd
set "CS_PUSHED=0"
type "%CS_LOG%"
echo Scheme exit code: %CS_RC%
echo Diagnostics: "%CS_LOG%"
goto finish
:missing
set "CS_RC=2"
>"%CS_LOG%" echo ERROR: source file not found or is a directory: "%CS_SOURCE%"
type "%CS_LOG%"
goto finish
:sameFile
set "CS_RC=2"
echo ERROR: source and diagnostics must be different files.
goto finish
:logFailed
set "CS_RC=2"
echo ERROR: cannot write diagnostics file "%CS_LOG%".
goto finish
:directoryFailed
set "CS_RC=2"
>>"%CS_LOG%" echo ERROR: cannot enter the source directory.
type "%CS_LOG%"
goto finish
:help
echo COMSCHEME version 1.0.0.0.11
echo COMSCHEME.BAT "source.scm"
echo COMSCHEME.BAT --run "source.scm" "scheme.exe"
echo COMSCHEME.BAT name scm "source.scm" drive subpath "diagnostics.txt"
:finish
if "%CS_PUSHED%"=="1" popd
if "%CS_PAUSE%"=="1" pause
endlocal & exit /b %CS_RC%
