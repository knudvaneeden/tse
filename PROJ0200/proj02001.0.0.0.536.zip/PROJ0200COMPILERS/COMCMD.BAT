@echo off
REM COMCMD.BAT version 1.0.0.0.8 - Run CMD program
REM OpenAI ChatGPT - 2026-10-17.
REM Runs real batch commands; this is not a compiler or syntax-only check.
REM No helper program is used or generated.
REM
REM ==================== USER SETTINGS ====================
set "CMD_EXE=%SystemRoot%\System32\cmd.exe"
set "COMCMD_PAUSE=1"
REM Change CMD_EXE for another Windows installation if necessary.
REM Set COMCMD_PAUSE to 0 above to disable the final pause.
REM Optional external override: set "COMCMD_EXE=C:\Windows\System32\cmd.exe"
REM The source ALWAYS runs in CMD, including when this runner starts in TCC.
REM
REM PARAMETERS:
REM   1=source filename, or TSE base name in the six-parameter form.
REM   2=extension; 3=full source filename; 4=drive; 5=path;
REM   6=TSE output filename. Leave empty for console-only use.
REM Output is captured internally, displayed, then paused before TSE returns.
REM Do not add another redirection to the compiler rule.
REM
REM TESTS: change to the folder containing these three BAT files first.
REM From a native TCC console:
REM   call COMCMD.BAT "helloworld.bat"
REM   call COMCMD.BAT "errorstest.bat"
REM Explicit TCC launch:
REM   G:\UTILS\JPSoft\TCMD\tcc.exe /A /I //CMDBatch=No /C call COMCMD.BAT helloworld.bat
REM   G:\UTILS\JPSoft\TCMD\tcc.exe /A /I //CMDBatch=No /C call COMCMD.BAT errorstest.bat
REM Explicit CMD launch:
REM   cmd.exe /D /C call COMCMD.BAT helloworld.bat
REM   cmd.exe /D /C call COMCMD.BAT errorstest.bat
REM Six-parameter test from either console:
REM   COMCMD.BAT "errorstest" ".bat" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.bat" "F:" "\BBC\TAAL\PROJ0200ERRORSMULTIPLE\" ""
REM To test an executable override, first enter:
REM   set "COMCMD_EXE=C:\Windows\System32\cmd.exe"
REM Then repeat either test. Clear override with: set "COMCMD_EXE="
REM Expect Hello world, or three located errors at lines 7, 10, 13 column 1.
REM Test TSE jumps with the supplied rule and errorstest.bat.
REM
REM CMD does not normally report a batch error's source line or column.
REM For EACH error the source emits four consecutive lines:
REM filename=full-path
REM line=N
REM column=N
REM CMD: ERROR: message
REM The rule reads the nearest metadata preceding each error independently.
REM Other sources must emit this convention themselves for reliable jumps.
REM Never guess source locations from localized native error messages.
REM Fatal syntax errors can stop CMD before later commands are executed.
REM ------------------------------------------------------------------------------
REM ==================== FIXED IMPLEMENTATION ====================
setlocal
if defined COMCMD_EXE set "CMD_EXE=%COMCMD_EXE%"
set "COMCMD_RC=1"
if defined COMCMD_CAPTURE goto captured_run
if "%~6"=="" goto captured_run
set "COMCMD_CAPTURE=1"
call "%~f0" "%~1" "%~2" "%~3" "%~4" "%~5" "" > "%~6" 2>&1
set "COMCMD_RC=%ERRORLEVEL%"
set "COMCMD_CAPTURE="
if not exist "%~6" goto capture_failed
type "%~6"
goto finish
:capture_failed
echo ERROR: could not create TSE output file: "%~6"
set "COMCMD_RC=1"
goto finish
:captured_run
if defined COMCMD_CAPTURE set "COMCMD_PAUSE=0"
echo COMCMD.BAT version 1.0.0.0.8
if "%~1"=="" goto usage
set "COMCMD_SOURCE=%~f1"
if not "%~3"=="" set "COMCMD_SOURCE=%~f3"
if not exist "%COMCMD_SOURCE%" goto missing
REM TCC can match files with IF EXIST filename\; use ISDIR instead.
if defined _TCC goto tcc_directory_test
for %%D in ("%COMCMD_SOURCE%") do set "COMCMD_ATTR=%%~aD"
if /I "%COMCMD_ATTR:~0,1%"=="d" goto directory
goto checked
:tcc_directory_test
if isdir "%COMCMD_SOURCE%" goto directory
:checked
if not exist "%CMD_EXE%" goto no_exe
echo filename=%COMCMD_SOURCE%
echo Running "%COMCMD_SOURCE%" with "%CMD_EXE%"
REM /D disables AutoRun; /V:OFF disables delayed expansion in CMD.
REM CALL handles the quoted source pathname, including spaces.
"%CMD_EXE%" /D /E:ON /V:OFF /C call "%COMCMD_SOURCE%" 2>&1
set "COMCMD_RC=%ERRORLEVEL%"
echo CMD exit code: %COMCMD_RC%
if not "%COMCMD_RC%"=="0" echo ERROR: CMD returned a nonzero exit code; use located diagnostics above when supplied.
goto finish
:usage
echo Usage: COMCMD.BAT "source.bat"
echo Or: COMCMD.BAT "name" ".bat" "full source path" "drive" "path" "output"
goto finish
:missing
echo ERROR: source file not found: "%COMCMD_SOURCE%"
goto finish
:directory
echo ERROR: source is a directory: "%COMCMD_SOURCE%"
goto finish
:no_exe
echo ERROR: CMD executable not found: "%CMD_EXE%"
echo Edit CMD_EXE in the settings or set COMCMD_EXE.
:finish
if "%COMCMD_PAUSE%"=="1" pause
endlocal & exit /b %COMCMD_RC%
