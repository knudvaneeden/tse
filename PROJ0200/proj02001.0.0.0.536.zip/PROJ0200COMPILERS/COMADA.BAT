@echo off
REM COMADA.BAT - version 1.0.0.0.8
REM Updated 2026-10-06 02:22 +0200. Author: OpenAI GPT-6 / Codex.
REM Compile and run an Ada main source file with GNAT gprbuild.
REM Launch from JPSoft TCC or Microsoft CMD. The main logic uses CMD.
REM
REM PART 1 - USER SETTINGS: change only the settings below.
REM Keep quotes in SET assignments; do not put quotes inside values.
REM Compiler options are trusted command-line switches.
REM
REM Parameters:
REM   One argument: full source filename.
REM   TSE arguments: %%1=name, %%2=extension, %%3=full source filename,
REM                  %%4=drive, %%5=directory, %%6=diagnostics filename.
REM   Source is taken from %%3 in TSE mode; %%1, %%2, %%4, %%5 are unused.
REM   Quote filenames. The source must be the Ada main compilation unit.
REM   No executable argument is required: configure ADA_BUILDER below.
REM
REM Tests from a TCC prompt (adjust paths; C:\TEMP must exist):
REM   COMADA.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.adb"
REM   COMADA.BAT "ddd" "adb" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.adb" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\comada_tcc.err"
REM Tests from either prompt using CMD explicitly:
REM   cmd.exe /d /c COMADA.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.adb"
REM   cmd.exe /d /c COMADA.BAT "ddd" "adb" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.adb" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\comada_cmd.err"
REM Error test: COMADA.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\errorstest.adb"
REM CMD test: cmd.exe /d /c COMADA.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\errorstest.adb"
REM Expect several file:line:column diagnostics and no program execution.
REM Success: compiler exit code 0, program output, program exit code.
REM Also test a missing source, an Ada syntax error, and paths with spaces.
REM Both failures must stop without running an earlier executable.
REM
REM This small launcher avoids differing TCC/CMD quote expansion rules.
@if "%COMADA_ENGINE%"=="CMD" goto COMADA_MAIN
@set COMADA_ENGINE=CMD
@cmd.exe /d /c call %0 %*
@set COMADA_RESULT=%errorlevel%
@set COMADA_ENGINE=
@exit /b %COMADA_RESULT%

:COMADA_MAIN
setlocal EnableExtensions DisableDelayedExpansion
set "COMADA_ENGINE="
set "ADA_BUILDER=G:\LANGUAGE\COMPUTER\ADA\GNAT\BIN\gprbuild.exe"
set "ADA_OPTIONS=-q"
REM Full paths, all errors, and a generous diagnostics limit.
set "ADA_COMPILER_OPTIONS=-gnatef -gnatf -gnatm9999"
REM Empty build root uses TEMP. Each invocation gets its own subdirectory.
set "ADA_BUILD_ROOT="
REM Optional extra diagnostics copy; empty disables it.
set "ADA_DIAGNOSTICS_COPY="
REM YES pauses at completion; NO supports unattended calls.
set "ADA_PAUSE=YES"

REM PART 2 - PROGRAM LOGIC: no local system changes needed below.
set "RESULT=1"
set "BUILD_DIR="
set "PUSHED="
set "SOURCE=%~1"
set "DIAGNOSTICS=%~6"
if not "%~3"=="" set "SOURCE=%~3"
if not defined SOURCE goto USAGE
for %%F in ("%SOURCE%") do set "SOURCE=%%~fF"
if not exist "%SOURCE%" goto MISSING_SOURCE
for %%F in ("%SOURCE%") do set "SOURCE_DIR=%%~dpF"
for %%F in ("%SOURCE%") do set "SOURCE_NAME=%%~nxF"
if not defined DIAGNOSTICS set "DIAGNOSTICS=%TEMP%\COMADA_%RANDOM%_%RANDOM%.err"
for %%F in ("%DIAGNOSTICS%") do set "DIAGNOSTICS=%%~fF"
if /i "%DIAGNOSTICS%"=="%SOURCE%" goto BAD_DIAGNOSTICS
>"%DIAGNOSTICS%" echo filename=%SOURCE%
if errorlevel 1 goto LOG_ERROR
if not exist "%ADA_BUILDER%" goto MISSING_BUILDER
for %%F in ("%ADA_BUILDER%") do set "PATH=%%~dpF;%PATH%"
if not defined ADA_BUILD_ROOT set "ADA_BUILD_ROOT=%TEMP%"
:NEW_BUILD
set "BUILD_DIR=%ADA_BUILD_ROOT%\COMADA_%RANDOM%_%RANDOM%"
if exist "%BUILD_DIR%" goto NEW_BUILD
mkdir "%BUILD_DIR%" >nul 2>&1
if errorlevel 1 goto BUILD_ERROR
pushd "%BUILD_DIR%"
if errorlevel 1 goto BUILD_ERROR
set "PUSHED=YES"
echo Compiling "%SOURCE%"
REM GPRbuild uses Source_Dirs in a project, not a command-line -I switch.
REM Use forward slashes in the generated project paths.
set "GPR_SOURCE_DIR=%SOURCE_DIR:\=/%"
>"%BUILD_DIR%\comada.gpr" echo project Comada is
>>"%BUILD_DIR%\comada.gpr" echo    for Languages use ^("Ada"^);
>>"%BUILD_DIR%\comada.gpr" echo    for Source_Dirs use ^("%GPR_SOURCE_DIR%."^);
>>"%BUILD_DIR%\comada.gpr" echo    for Object_Dir use ".";
>>"%BUILD_DIR%\comada.gpr" echo    for Exec_Dir use ".";
>>"%BUILD_DIR%\comada.gpr" echo    for Main use ^("%SOURCE_NAME%"^);
>>"%BUILD_DIR%\comada.gpr" echo end Comada;
if errorlevel 1 goto PROJECT_ERROR
"%ADA_BUILDER%" %ADA_OPTIONS% -P "%BUILD_DIR%\comada.gpr" -o "program.exe" -cargs:Ada %ADA_COMPILER_OPTIONS% >>"%DIAGNOSTICS%" 2>&1
set "RESULT=%errorlevel%"
type "%DIAGNOSTICS%"
echo.
echo Compiler exit code: %RESULT%
if not "%RESULT%"=="0" goto FINISH
if not exist "%BUILD_DIR%\program.exe" goto NO_PROGRAM
REM Run in source directory so relative program data paths work.
popd
set "PUSHED="
pushd "%SOURCE_DIR%"
if errorlevel 1 goto RUN_DIRECTORY_ERROR
set "PUSHED=YES"
echo.
echo Running "%BUILD_DIR%\program.exe"
"%BUILD_DIR%\program.exe"
set "RESULT=%errorlevel%"
echo.
echo Program exit code: %RESULT%
goto FINISH

:USAGE
echo Usage: COMADA.BAT "full-path-to-main.adb"
echo Or: COMADA.BAT "name" "adb" "full-path-to-main.adb" "drive" "directory" "diagnostics-file"
goto FINISH
:MISSING_SOURCE
echo ERROR: Ada source not found: "%SOURCE%"
goto FINISH
:BAD_DIAGNOSTICS
echo ERROR: Diagnostics filename must differ from the source filename.
goto FINISH
:LOG_ERROR
echo ERROR: Cannot write diagnostics: "%DIAGNOSTICS%"
goto FINISH
:MISSING_BUILDER
echo ERROR: Compiler not found: "%ADA_BUILDER%"
>>"%DIAGNOSTICS%" echo ERROR: Compiler not found: "%ADA_BUILDER%"
goto FINISH
:BUILD_ERROR
echo ERROR: Cannot create or enter build directory: "%BUILD_DIR%"
goto FINISH
:PROJECT_ERROR
echo ERROR: Cannot write temporary GPR project.
set "RESULT=1"
goto FINISH
:NO_PROGRAM
echo ERROR: Compiler did not create program.exe.
set "RESULT=1"
goto FINISH
:RUN_DIRECTORY_ERROR
echo ERROR: Cannot enter source directory.
set "RESULT=1"
:FINISH
if defined PUSHED popd
if not defined BUILD_DIR goto COPY_LOG
if exist "%BUILD_DIR%" rmdir /s /q "%BUILD_DIR%"
if exist "%BUILD_DIR%" echo WARNING: Temporary build directory could not be removed: "%BUILD_DIR%"
:COPY_LOG
if not defined DIAGNOSTICS goto DONE
if not exist "%DIAGNOSTICS%" goto DONE
echo Diagnostics saved to "%DIAGNOSTICS%"
if not defined ADA_DIAGNOSTICS_COPY goto DONE
copy /y "%DIAGNOSTICS%" "%ADA_DIAGNOSTICS_COPY%" >nul
if errorlevel 1 echo WARNING: Could not copy diagnostics.
:DONE
if /i "%ADA_PAUSE%"=="YES" pause
endlocal & exit /b %RESULT%
