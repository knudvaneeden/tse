@ECHO OFF
REM JPSoft numeric comparison distinguishes TCC from CMD.
IF 01 == 1 GOTO tcc_start
SETLOCAL
SET RUNNING_TCC=false
GOTO settings
:tcc_start
SETLOCAL
SET RUNNING_TCC=true
:settings
REM COMKOTLIN.BAT - version 1.0.0.11 - 2026-10-07
REM Updated with OpenAI GPT-6 / Codex.
REM Compile one Kotlin JVM .kt file with main(), then run its temporary JAR.
REM
REM USAGE (quote paths, especially paths containing spaces):
REM   COMKOTLIN.BAT "C:\My sources\hello.kt"
REM   COMKOTLIN.BAT "name" "unused" "source.kt" "drive" "directory" "errors.txt"
REM TSE format: %%1=name, %%2=unused, %%3=full source path, %%4=drive,
REM %%5=directory, %%6=diagnostics file. Full %%3 is authoritative;
REM %%4 and %%5 are retained for compatibility and are not used.
REM Optional %%7 locates kotlinc.bat; %%8 overrides java.exe.
REM kotlinc.bat is NOT executed. Its directory locates the compiler JARs.
REM Java runs K2JVMCompiler directly, with no CMD subprocess in TCC.
REM For overrides with the short format, leave parameters 2 through 6 empty.
REM   COMKOTLIN.BAT "C:\My sources\hello.kt" "" "" "" "" "" "C:\Kotlin\bin\kotlinc.bat" "C:\Java\bin\java.exe"
REM
REM WINDOWS TESTS: run from the directory containing this BAT.
REM Regression test in the existing TCC console (no nested tcc.exe):
REM   DIR "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.kt"
REM   COMKOTLIN.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.kt"
REM Expected: Compiling, then three compiler errors; no false source-not-found.
REM Repeat through TSE to verify the diagnostics file and three jump entries.
REM Create hello.kt containing: fun main() { println("Hello from Kotlin") }
REM In an existing TCC session, invoke the BAT directly (do not nest TCC):
REM   COMKOTLIN.BAT "C:\My sources\hello.kt"
REM   COMKOTLIN.BAT "hello" "unused" "C:\My sources\hello.kt" "C" "My sources" "C:\TEMP\comkotlin_tcc.err"
REM In Microsoft CMD:
REM   cmd.exe /d /c COMKOTLIN.BAT "C:\My sources\hello.kt"
REM   cmd.exe /d /c COMKOTLIN.BAT "hello" "unused" "C:\My sources\hello.kt" "C" "My sources" "C:\TEMP\comkotlin_cmd.err"
REM Expected: Hello from Kotlin, program exit code 0, diagnostics retained.
REM Repeat in BOTH shells with a missing source and a syntax error: nonzero
REM exit code, clear error, and no attempt to execute an old JAR.
REM Test tool overrides using parameters 7 and 8 as documented above.
REM Diagnostics parent directory must exist. No Windows shells were available
REM during this revision, so these are supplied tests, not claimed test passes.
REM
REM =====================================================================
REM PART 1 - USER SETTINGS: change these values for your local installation.
REM Use full paths without embedded quotation marks in the values.
REM Kotlin and Java versions must be compatible. Java must be a JDK for kotlinc.
REM =====================================================================
SET KOTLIN_COMPILER=G:\language\computer\kotlin\kotlinc\bin\kotlinc.bat
REM JAVA_HOME is the JDK root, without a trailing bin directory.
SET JAVA_HOME=G:\language\computer\java\jdk-11.0.15
SET JAVA_EXE=%JAVA_HOME%\bin\java.exe
REM Empty WORK_ROOT uses TEMP, then the current directory if TEMP is empty.
SET WORK_ROOT=
REM Optional extra compiler options, for example: -jvm-target 1.8
SET KOTLIN_OPTIONS=
REM Optional JVM options, for example: -Xmx512m
SET JAVA_OPTIONS=
REM Optional diagnostics copy for an existing TSE integration; empty disables.
SET DIAGNOSTICS_COPY=
REM Set PAUSE_AT_END to false for automated tests; true keeps output visible.
SET PAUSE_AT_END=true

REM =====================================================================
REM PART 2 - EXECUTION LOGIC: normally no user changes are needed below here.
REM =====================================================================
ECHO COMKOTLIN version 1.0.0.11
SET RESULT=1
SET BUILD_DIR=
IF "%RUNNING_TCC%"=="true" GOTO tcc_arguments
SET SOURCE=%~1
IF NOT "%~3"=="" SET SOURCE=%~3
IF NOT "%~7"=="" SET KOTLIN_COMPILER=%~7
IF NOT "%~8"=="" SET JAVA_EXE=%~8
SET DIAGNOSTICS=%~6
GOTO arguments_done
:tcc_arguments
SET SOURCE=%@unquote[%1]
IF NOT "%@unquote[%3]"=="" SET SOURCE=%@unquote[%3]
IF NOT "%@unquote[%7]"=="" SET KOTLIN_COMPILER=%@unquote[%7]
IF NOT "%@unquote[%8]"=="" SET JAVA_EXE=%@unquote[%8]
SET DIAGNOSTICS=%@unquote[%6]
:arguments_done
IF "%SOURCE%"=="" GOTO usage
IF NOT EXIST "%SOURCE%" GOTO missing_source
REM TCC treats EXIST file-with-trailing-backslash differently from CMD.
REM Keep the two directory tests isolated by shell.
IF "%RUNNING_TCC%"=="true" GOTO tcc_source_type
IF EXIST "%SOURCE%\" GOTO source_is_directory
GOTO source_type_done
:tcc_source_type
IF ISDIR "%SOURCE%" GOTO source_is_directory
:source_type_done
IF NOT EXIST "%KOTLIN_COMPILER%" GOTO missing_compiler
IF NOT EXIST "%JAVA_EXE%" GOTO missing_java
IF "%WORK_ROOT%"=="" SET WORK_ROOT=%TEMP%
IF "%WORK_ROOT%"=="" SET WORK_ROOT=%CD%
IF "%RUNNING_TCC%"=="true" GOTO tcc_paths
FOR %%I IN ("%SOURCE%") DO SET SOURCE=%%~fI
FOR %%I IN ("%SOURCE%") DO SET SOURCE_DIR=%%~dpI
FOR %%I IN ("%KOTLIN_COMPILER%") DO SET KOTLIN_HOME=%%~dpI..
FOR %%I IN ("%JAVA_EXE%") DO SET JAVA_HOME=%%~dpI..
FOR %%I IN ("%WORK_ROOT%") DO SET WORK_ROOT=%%~fI
GOTO paths_done
:tcc_paths
SET SOURCE=%@full["%SOURCE%"]
SET SOURCE_DIR=%@path["%SOURCE%"]
SET KOTLIN_HOME=%@path["%KOTLIN_COMPILER%"]..
SET JAVA_HOME=%@path["%JAVA_EXE%"]..
SET WORK_ROOT=%@full["%WORK_ROOT%"]
:paths_done
IF NOT EXIST "%KOTLIN_HOME%\lib\kotlin-compiler.jar" GOTO missing_compiler_jar
IF "%DIAGNOSTICS%"=="" SET DIAGNOSTICS=%WORK_ROOT%\COMKOTLIN_%RANDOM%_%RANDOM%.err
IF "%RUNNING_TCC%"=="true" GOTO tcc_diagnostics
FOR %%I IN ("%DIAGNOSTICS%") DO SET DIAGNOSTICS=%%~fI
GOTO diagnostics_done
:tcc_diagnostics
SET DIAGNOSTICS=%@full["%DIAGNOSTICS%"]
:diagnostics_done
>"%DIAGNOSTICS%" ECHO filename=%SOURCE%
IF ERRORLEVEL 1 GOTO bad_diagnostics
:choose_directory
SET BUILD_DIR=%WORK_ROOT%\COMKOTLIN_%RANDOM%_%RANDOM%
IF EXIST "%BUILD_DIR%" GOTO choose_directory
MD "%BUILD_DIR%" >NUL 2>&1
IF ERRORLEVEL 1 GOTO bad_directory
SET JAR_FILE=%BUILD_DIR%\program.jar
REM Run from the source directory so relative program data paths work.
PUSHD "%SOURCE_DIR%"
IF ERRORLEVEL 1 GOTO bad_directory
ECHO Compiling "%SOURCE%"
REM Invoke the JVM compiler directly with the distribution's bundled JARs.
"%JAVA_EXE%" %JAVA_OPTIONS% -cp "%KOTLIN_HOME%\lib\*" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -kotlin-home "%KOTLIN_HOME%" "%SOURCE%" %KOTLIN_OPTIONS% -include-runtime -d "%JAR_FILE%" >>"%DIAGNOSTICS%" 2>&1
IF "%RUNNING_TCC%"=="true" GOTO tcc_compile_status
SET RESULT=%ERRORLEVEL%
GOTO compile_status_done
:tcc_compile_status
SET RESULT=%?
:compile_status_done
ECHO Compiler exit code: %RESULT%
TYPE "%DIAGNOSTICS%"
IF NOT "%RESULT%"=="0" GOTO compile_failed
IF NOT EXIST "%JAR_FILE%" GOTO missing_jar
ECHO.
ECHO Running "%SOURCE%"
"%JAVA_EXE%" %JAVA_OPTIONS% -jar "%JAR_FILE%" 2>>"%DIAGNOSTICS%"
IF "%RUNNING_TCC%"=="true" GOTO tcc_program_status
SET RESULT=%ERRORLEVEL%
GOTO program_status_done
:tcc_program_status
SET RESULT=%?
:program_status_done
ECHO.
ECHO Program exit code: %RESULT%
IF NOT "%RESULT%"=="0" TYPE "%DIAGNOSTICS%"
GOTO pop_directory
:compile_failed
ECHO ERROR: Kotlin compilation failed with exit code %RESULT%.
GOTO pop_directory
:missing_jar
SET RESULT=1
ECHO ERROR: Compiler reported success but did not create the JAR.
:pop_directory
POPD
GOTO finish
:usage
ECHO Usage: COMKOTLIN.BAT "source.kt"
ECHO Or: COMKOTLIN.BAT "name" "unused" "source.kt" "drive" "directory" "errors.txt"
GOTO end
:source_is_directory
ECHO ERROR: Kotlin source path is a directory: "%SOURCE%"
GOTO end
:missing_source
ECHO ERROR: Kotlin source file not found: "%SOURCE%"
GOTO end
:missing_compiler
ECHO ERROR: Kotlin compiler not found: "%KOTLIN_COMPILER%"
GOTO end
:missing_compiler_jar
ECHO ERROR: Kotlin compiler JAR not found: "%KOTLIN_HOME%\lib\kotlin-compiler.jar"
GOTO end
:missing_java
ECHO ERROR: Java executable not found: "%JAVA_EXE%"
GOTO end
:bad_diagnostics
ECHO ERROR: Cannot write diagnostics: "%DIAGNOSTICS%"
GOTO end
:bad_directory
ECHO ERROR: Cannot create or enter the working directory.
GOTO finish
:finish
IF "%BUILD_DIR%"=="" GOTO report
IF EXIST "%BUILD_DIR%\program.jar" DEL /Q "%BUILD_DIR%\program.jar" >NUL 2>&1
IF EXIST "%BUILD_DIR%" RD "%BUILD_DIR%" >NUL 2>&1
:report
ECHO Diagnostics saved to "%DIAGNOSTICS%"
IF "%DIAGNOSTICS_COPY%"=="" GOTO end
COPY /Y "%DIAGNOSTICS%" "%DIAGNOSTICS_COPY%" >NUL 2>&1
IF ERRORLEVEL 1 ECHO WARNING: Could not copy diagnostics to "%DIAGNOSTICS_COPY%".
:end
IF /I "%PAUSE_AT_END%"=="true" PAUSE
IF "%RUNNING_TCC%"=="true" QUIT %RESULT%
ENDLOCAL & EXIT /B %RESULT%
