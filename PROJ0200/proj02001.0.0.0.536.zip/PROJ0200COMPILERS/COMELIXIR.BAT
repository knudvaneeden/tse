@echo off
REM COMELIXIR.BAT version 1.0.0.0.11 - updated 2026-10-09 - OpenAI GPT-6
REM Run ELIXIR program
REM Runs a standalone .ex or .exs once; no external helper scripts.
REM PART 1 contains local settings. PART 2 normally needs no changes.
REM Direct: COMELIXIR.BAT "F:\sources with spaces\errorstest.ex"
REM TSE: COMELIXIR.BAT "name" "ex" "full source" "drive" "path" "error file"
REM %1=name, %2=extension, %3=source, %4=drive, %5=path, %6=diagnostics.
REM With one argument, %1 is the source and diagnostics go into TEMP.
REM All paths must be quoted. The executable is configured below, not in %1.
REM Test shell handling, without pause or compiler:
REM   In the existing TCC console: COMELIXIR.BAT --testshell
REM   cmd.exe /d /c COMELIXIR.BAT --testshell
REM Test compiler installation: COMELIXIR.BAT --version
REM Successful small program: COMELIXIR.BAT --hello
REM Error test in either shell: COMELIXIR.BAT "full path\errorstest.ex"
REM TSE test: compile errorstest.ex and select each diagnostic in its list.
REM Expected intentional errors: lines 6, 9, 12; column 5 on modern Elixir.
REM Elixir 1.15+ supports multiple compiler errors; syntax errors may stop early.
REM Older Elixir may supply only a line, in which case column is unavailable.
REM The TSE rule extracts locations directly; Message uses Tag=0.
REM Its printable-ASCII Message pattern skips Unicode drawing prefixes.
REM Vendor elixir.bat runs under CMD because vendor batch syntax can fail in TCC.
REM This COMELIXIR wrapper itself stays in the invoking TCC or CMD shell.
REM Exit code is preserved, including after the final pause.

REM ================= PART 1: USER SETTINGS =================
setlocal
REM Elixir 1.20.4 launcher at the confirmed installation path.
if not defined CEL_ELIXIR set "CEL_ELIXIR=G:\language\computer\elixir\bin\elixir.bat"
REM Erlang/OTP 29 bin directory; this takes priority over older Erlang on PATH.
if not defined CEL_ERLANG_BIN set "CEL_ERLANG_BIN=G:\language\computer\erlang\bin"
REM true pauses at the end; set CEL_PAUSE=false externally for automation.
if not defined CEL_PAUSE set "CEL_PAUSE=true"

REM ================= PART 2: STABLE LOGIC ===================
set "CEL_VERSION=1.0.0.0.11"
set "CEL_RESULT=0"
set "CEL_PUSHED=false"
set "CEL_SHELL=CMD"
REM Internal variables are not environment variables: do not use IF DEFINED.
if /i "%_CMDPROC%"=="TCC" set "CEL_SHELL=TCC"
if /i "%_CMDPROC%"=="TCC/LE" set "CEL_SHELL=TCC"
if /i "%_CMDPROC%"=="4NT" set "CEL_SHELL=TCC"
echo COMELIXIR version %CEL_VERSION%
echo Shell: %CEL_SHELL%
if /i "%~1"=="--testshell" goto testShell
if /i "%~1"=="--version" goto compilerVersion
if /i "%~1"=="--hello" goto hello
if "%~1"=="" goto usage
set "CEL_SOURCE=%~f1"
if not "%~3"=="" set "CEL_SOURCE=%~f3"
set "CEL_ERRFILE=%TEMP%\COMELIXIR_%RANDOM%_%RANDOM%.err"
if not "%~6"=="" set "CEL_ERRFILE=%~f6"
>"%CEL_ERRFILE%" echo COMELIXIR version %CEL_VERSION%
if errorlevel 1 goto outputError
>>"%CEL_ERRFILE%" echo filename=%CEL_SOURCE%
if not exist "%CEL_SOURCE%" goto sourceError
if /i "%CEL_SHELL%"=="TCC" goto checkTccDirectory
for %%A in ("%CEL_SOURCE%") do set "CEL_ATTRIBUTES=%%~aA"
if /i "%CEL_ATTRIBUTES:~0,1%"=="d" goto directoryError
goto sourceReady
:checkTccDirectory
if isdir "%CEL_SOURCE%" goto directoryError
:sourceReady
if not exist "%CEL_ELIXIR%" goto compilerError
if not "%CEL_ERLANG_BIN%"=="" set "PATH=%CEL_ERLANG_BIN%;%PATH%"
for %%A in ("%CEL_SOURCE%") do set "CEL_SOURCE_DIR=%%~dpA"
pushd "%CEL_SOURCE_DIR%"
if errorlevel 1 goto directoryAccessError
set "CEL_PUSHED=true"
echo Running "%CEL_SOURCE%"
REM Pass the source directly: -e would treat it as expression arguments.
REM Run once; stdout and stderr both go into the exact TSE error file.
"%SystemRoot%\System32\cmd.exe" /d /s /c ""%CEL_ELIXIR%" "%CEL_SOURCE%"" >>"%CEL_ERRFILE%" 2>&1
set "CEL_RESULT=%ERRORLEVEL%"
popd
set "CEL_PUSHED=false"
type "%CEL_ERRFILE%"
echo.
echo Diagnostics saved to "%CEL_ERRFILE%"
echo Elixir exit code: %CEL_RESULT%
goto finish
:sourceError
>>"%CEL_ERRFILE%" echo ERROR: source file not found: "%CEL_SOURCE%"
set "CEL_RESULT=2"
goto showFailure
:directoryError
>>"%CEL_ERRFILE%" echo ERROR: source is a directory: "%CEL_SOURCE%"
set "CEL_RESULT=2"
goto showFailure
:directoryAccessError
>>"%CEL_ERRFILE%" echo ERROR: cannot enter source directory: "%CEL_SOURCE_DIR%"
set "CEL_RESULT=2"
goto showFailure
:compilerError
>>"%CEL_ERRFILE%" echo ERROR: Elixir launcher not found: "%CEL_ELIXIR%"
>>"%CEL_ERRFILE%" echo Edit CEL_ELIXIR in PART 1. Erlang must also be installed.
set "CEL_RESULT=2"
:showFailure
type "%CEL_ERRFILE%"
echo Diagnostics saved to "%CEL_ERRFILE%"
echo Exit code: %CEL_RESULT%
goto finish
:outputError
echo ERROR: cannot write diagnostics: "%CEL_ERRFILE%"
echo The output directory must already exist and be writable.
set "CEL_RESULT=2"
goto finish
:compilerVersion
if not exist "%CEL_ELIXIR%" goto missingLauncher
if not "%CEL_ERLANG_BIN%"=="" set "PATH=%CEL_ERLANG_BIN%;%PATH%"
"%SystemRoot%\System32\cmd.exe" /d /s /c ""%CEL_ELIXIR%" --version"
set "CEL_RESULT=%ERRORLEVEL%"
echo Elixir exit code: %CEL_RESULT%
goto finish
:hello
if not exist "%CEL_ELIXIR%" goto missingLauncher
if not "%CEL_ERLANG_BIN%"=="" set "PATH=%CEL_ERLANG_BIN%;%PATH%"
"%SystemRoot%\System32\cmd.exe" /d /s /c ""%CEL_ELIXIR%" -e "IO.puts(:hello_from_elixir); IO.puts(:version_1_0_0_0_11)""
set "CEL_RESULT=%ERRORLEVEL%"
echo Elixir exit code: %CEL_RESULT%
goto finish
:missingLauncher
echo ERROR: Elixir launcher not found: "%CEL_ELIXIR%"
echo Edit CEL_ELIXIR in PART 1.
set "CEL_RESULT=2"
goto finish
:testShell
REM Exercise the same file/directory checks on this existing batch file.
set "CEL_SOURCE=%~f0"
if not exist "%CEL_SOURCE%" goto testFailed
if /i "%CEL_SHELL%"=="TCC" goto testTcc
for %%A in ("%CEL_SOURCE%") do set "CEL_ATTRIBUTES=%%~aA"
if /i "%CEL_ATTRIBUTES:~0,1%"=="d" goto testFailed
for %%A in ("%TEMP%") do set "CEL_ATTRIBUTES=%%~aA"
if /i not "%CEL_ATTRIBUTES:~0,1%"=="d" goto testFailed
goto testPassed
:testTcc
if isdir "%CEL_SOURCE%" goto testFailed
if not isdir "%TEMP%" goto testFailed
:testPassed
echo PASS: existing file accepted and TEMP directory recognized in %CEL_SHELL%.
set "CEL_RESULT=0"
goto returnBatch
:testFailed
echo FAIL: shell file/directory checks failed.
set "CEL_RESULT=1"
goto returnBatch
:usage
echo Usage: COMELIXIR.BAT "full source.ex"
echo Or: COMELIXIR.BAT "name" "ex" "source" "drive" "path" "error file"
echo Tests: --testshell, --version, --hello
set "CEL_RESULT=2"
:finish
if /i "%CEL_PUSHED%"=="true" popd
if /i "%CEL_PAUSE%"=="true" pause
:returnBatch
if /i "%CEL_SHELL%"=="TCC" goto returnTcc
endlocal & exit /b %CEL_RESULT%
:returnTcc
REM TCC restores outstanding SETLOCAL scopes when this batch ends.
quit %CEL_RESULT%
