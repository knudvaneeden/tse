@echo off
setlocal EnableDelayedExpansion
REM COMROCQ.BAT version 1.0.0.0.9 - OpenAI GPT-6
REM PART 1 - USER SETTINGS. No permanent Windows environment changes.
set "ROCQ_EXE=G:\LANGUAGE\COMPUTER\ROCQ\bin\rocq.exe"
REM Optional library paths: leave empty to preserve inherited settings/autodetect.
set "ROCQ_LIBRARY="
set "ROCQ_RUNTIME_LIBRARY="
REM Pause both standalone and TSE runs so the console stays readable.
REM Set to 0 only if you want the console to close automatically.
set "PAUSE_AT_END=1"
REM Standalone: COMROCQ.BAT "F:\BBC\TAAL\helloworld.v"
REM Override executable: COMROCQ.BAT "file.v" "X:\Rocq\bin\rocq.exe"
REM TSE six arguments: name extension fullfilename drive path outputfile.
REM With six arguments, argument 3 is authoritative; argument 6 gets output.
REM CMD test: cmd.exe /d /c COMROCQ.BAT --testformat
REM TCC test: tcc.exe /c COMROCQ.BAT --testformat
REM Run both tests again with helloworld.v and errorstest.v as argument.
REM --testformat checks diagnostic parsing without needing Rocq installed.
REM Native TCC execution; no CMD trampoline, PowerShell, or helper program.
REM Compile the original .v source directly; Rocq output stays beside it.
REM Normal batch compilation stops at its first error. Fix and rerun.
REM Successful compilation keeps .vo and other Rocq products beside the source.
REM Local project dependencies must already be available through Rocq paths.
REM Delayed expansion is enabled; avoid exclamation marks in file paths.
REM Full compiler output is printed before the TSE diagnostic summary.
REM PART 2 - IMPLEMENTATION. No installation-specific edits below this line.
set "VERSION=1.0.0.0.9"
set "RC=1"
set "WORK="
set "OUTPUT="
if /i "%~1"=="--testformat" goto testformat
if "%~1"=="" goto usage
set "SOURCE=%~f1"
if not "%~3"=="" set "SOURCE=%~f3"
if not "%~3"=="" set "OUTPUT=%~6"
if "%~3"=="" if not "%~2"=="" set "ROCQ_EXE=%~2"
if defined _4VER goto tccsource
for %%I in ("%SOURCE%") do set "ATTR=%%~aI"
if "%ATTR:~0,1%"=="d" goto missing
 goto checksource
:tccsource
if isdir "%SOURCE%" goto missing
:checksource
if not exist "%SOURCE%" goto missing
if not exist "%ROCQ_EXE%" goto noexe
if defined ROCQ_LIBRARY set "ROCQLIB=%ROCQ_LIBRARY%"
if defined ROCQ_LIBRARY set "COQLIB=%ROCQ_LIBRARY%"
if defined ROCQ_RUNTIME_LIBRARY set "ROCQRUNTIMELIB=%ROCQ_RUNTIME_LIBRARY%"
for %%I in ("%ROCQ_EXE%") do set "PATH=%%~dpI;%PATH%"
call :workspace
if errorlevel 1 goto workerror
call :run >"%WORK%\report.txt" 2>&1
type "%WORK%\report.txt"
if defined OUTPUT copy /b "%WORK%\report.txt" "%OUTPUT%" >nul
if errorlevel 1 if defined OUTPUT echo ERROR: Could not write TSE output file.
goto cleanup
:run
echo COMROCQ version %VERSION%
echo filename=%SOURCE%
"%ROCQ_EXE%" compile -color off "%SOURCE%" >"%WORK%\raw.txt" 2>&1
set "RC=%ERRORLEVEL%"
REM Keep complete multi-line messages visible, including blank lines.
type "%WORK%\raw.txt"
call :process
if not "%RC%"=="0" if "%FOUND%"=="0" echo TSE:1:1:ERROR: Rocq failed without a source position; see full output above.
echo Rocq exit code: %RC%
exit /b 0
:process
set "FOUND=0"
set "NLINE="
set "NCOL="
set "MESSAGE="
for /f "usebackq delims=" %%L in ("%WORK%\raw.txt") do (
 set "RAWLINE=%%L"
 call :parse
)
call :emit
exit /b 0
:parse
if not "!RAWLINE:~0,5!"=="File " goto body
REM File "...", line N, characters A-B: (A is zero-based).
set "L="
set "C="
for /f "tokens=2,3 delims=," %%A in ("!RAWLINE!") do (
 for /f "tokens=2" %%N in ("%%A") do set "L=%%N"
 for /f "tokens=2 delims= -:" %%N in ("%%B") do set "C=%%N"
)
if not defined L goto ignore
if not defined C goto ignore
set /a C=C+1 >nul 2>&1
set "NEWLINE=!L!"
set "NEWCOL=!C!"
call :emit
set "NLINE=%NEWLINE%"
set "NCOL=%NEWCOL%"
set "MESSAGE="
set "FOUND=1"
exit /b 0
:body
if not defined NLINE goto ignore
if defined MESSAGE (set "MESSAGE=!MESSAGE! !RAWLINE!") else set "MESSAGE=!RAWLINE!"
REM Cap the jump-list summary; raw output above is never truncated.
set "MESSAGE=!MESSAGE:~0,3000!"
REM MESSAGE remains in the same environment under both TCC and CMD.
exit /b 0
:ignore
exit /b 0
:emit
if not defined NLINE exit /b 0
if not defined MESSAGE set "MESSAGE=Rocq diagnostic; see full output above."
echo TSE:!NLINE!:!NCOL!:!MESSAGE!
exit /b 0
:workspace
set "WORK=%TEMP%\comrocq-%RANDOM%-%RANDOM%"
if exist "%WORK%" goto workspace
mkdir "%WORK%" >nul 2>&1
exit /b %ERRORLEVEL%
:testformat
call :workspace
if errorlevel 1 goto workerror
set "SOURCE=F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.v"
>"%WORK%\raw.txt" echo File "tse_rocq_input.v", line 7, characters 4-12:
>>"%WORK%\raw.txt" echo Error: Unknown identifier missing_one.
>>"%WORK%\raw.txt" echo Continued diagnostic text.
echo COMROCQ version %VERSION% diagnostic self-test
echo filename=%SOURCE%
call :process
set "RC=1"
if "%NLINE%:%NCOL%"=="7:5" set "RC=0"
if not "!MESSAGE!"=="Error: Unknown identifier missing_one. Continued diagnostic text." set "RC=1"
if "%RC%"=="0" (echo PASS: line 7, column 5 and complete message.) else echo FAIL: diagnostic parser.
goto cleanup
:usage
echo COMROCQ version %VERSION%
echo Usage: COMROCQ.BAT "source.v" ["rocq.exe"]
echo Or: COMROCQ.BAT name extension fullfilename drive path outputfile
echo Test: COMROCQ.BAT --testformat
goto cleanup
:missing
echo ERROR: source file not found or is a directory: "%SOURCE%"
goto cleanup
:noexe
echo ERROR: Rocq executable not found: "%ROCQ_EXE%"
goto cleanup
:workerror
echo ERROR: Cannot create temporary working directory.
goto cleanup
:copyerror
echo ERROR: Cannot copy source into temporary working directory.
:cleanup
if defined WORK if exist "%WORK%" rmdir /s /q "%WORK%" >nul 2>&1
if "%PAUSE_AT_END%"=="1" pause
endlocal & exit /b %RC%
