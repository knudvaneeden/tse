@ECHO OFF
REM COMJSON.BAT version 1.0.0.0.7 - OpenAI ChatGPT
REM Validate JSON with Python 3.6 or later; JSON is data, not a program.
REM PART 1 below contains all installation-dependent settings.
REM Usage: COMJSON.BAT "full path to source.json"
REM TSE: COMJSON.BAT "name" ".json" "full source" "drive" "path" "output"
REM Source is parameter 3 in TSE mode, otherwise parameter 1.
REM Parameter 6 is the optional output log. Other parameters are compatibility.
REM Overrides (in either shell):
REM   set "COMJSON_EXE=G:\language\computer\python\python\python.exe"
REM   set "COMJSON_PAUSE=NO"
REM Tests from the directory containing these four downloaded files:
REM   tcc.exe /c COMJSON.BAT "helloworldjson.json"
REM   tcc.exe /c COMJSON.BAT "errorstestjson.json"
REM   cmd.exe /d /c COMJSON.BAT "helloworldjson.json"
REM   cmd.exe /d /c COMJSON.BAT "errorstestjson.json"
REM Expect exit 0 and Hello world for the valid file; exit 1, line 4 column 14
REM for the error file. Fix tru to true; rerun, fix 012 to 12; rerun,
REM remove the comma after "last". Then expect exit 0.
REM Also test a filename containing spaces and a missing file (exit 2).
REM For automated tests set COMJSON_PAUSE=NO; default pauses for reading.
REM JSON comments are forbidden: versions are ordinary JSON string members.
REM Python stops at the first syntax error; rerun after fixing it.
REM No IF EXIST filename\ directory test: Python is_file handles both shells.
REM The embedded helper needs no separate .py file or third-party packages.
SETLOCAL
REM =====================================================================
REM PART 1 - USER SETTINGS
REM =====================================================================
SET "CJ_EXE=g:\language\computer\python\python\python.exe"
SET "CJ_PAUSE=YES"
REM =====================================================================
REM PART 2 - EXECUTION LOGIC - normally no changes needed
REM =====================================================================
IF NOT "%COMJSON_EXE%"=="" SET "CJ_EXE=%COMJSON_EXE%"
IF NOT "%COMJSON_PAUSE%"=="" SET "CJ_PAUSE=%COMJSON_PAUSE%"
SET "CJ_SOURCE=%~3"
IF "%CJ_SOURCE%"=="" SET "CJ_SOURCE=%~1"
SET "CJ_LOG=%~6"
SET "CJ_SELF=%~f0"
"%CJ_EXE%" -c "import os; p=os.environ['CJ_SELF']; exec(''.join(s[7:] for s in open(p,encoding='ascii') if s.startswith('REM PY ')))"
SET "CJ_RC=%ERRORLEVEL%"
IF /I "%CJ_PAUSE%"=="NO" GOTO CJ_END
PAUSE
:CJ_END
ENDLOCAL & EXIT /B %CJ_RC%
REM Embedded Python; executed only by Python, never by the batch interpreter.
REM PY import json, os, sys
REM PY from pathlib import Path
REM PY VERSION = "1.0.0.0.7"
REM PY source = os.environ.get("CJ_SOURCE", "")
REM PY log = os.environ.get("CJ_LOG", "")
REM PY rc = 2
REM PY lines = ["COMJSON version " + VERSION]
REM PY def diagnostic(name, line, col, msg):
REM PY     return "TSE: {}:{}:{}: Error: {}".format(name, line, col, msg)
REM PY try:
REM PY     if not source:
REM PY         raise OSError('Usage: COMJSON.BAT "source.json"')
REM PY     name = str(Path(source).resolve())
REM PY     if log and Path(log).resolve() == Path(source).resolve():
REM PY         print("ERROR: output log must differ from source")
REM PY         sys.exit(2)
REM PY     if not Path(source).is_file():
REM PY         raise OSError("Source is not a regular file: " + source)
REM PY     raw = Path(source).read_bytes()
REM PY     text = raw.decode("utf-8-sig")
REM PY     # Reject the non-JSON constants accepted by Python by default.
REM PY     def reject_constant(token):
REM PY         # Find the token outside quoted strings for an accurate location.
REM PY         import re
REM PY         pattern = r'"(?:[^"\\]|\\.)*"|NaN|-?Infinity'
REM PY         for m in re.finditer(pattern, text):
REM PY             if m.group() == token:
REM PY                 raise json.JSONDecodeError("Invalid JSON constant " + token, text, m.start())
REM PY         raise ValueError("Invalid JSON constant " + token)
REM PY     data = json.loads(text, parse_constant=reject_constant)
REM PY     lines.append("JSON validation successful.")
REM PY     lines.append(json.dumps(data, indent=2, ensure_ascii=True))
REM PY     rc = 0
REM PY except json.JSONDecodeError as e:
REM PY     lines.append(diagnostic(name, e.lineno, e.colno, e.msg))
REM PY     rc = 1
REM PY except UnicodeDecodeError as e:
REM PY     prefix = raw[:e.start].decode("utf-8-sig", errors="replace")
REM PY     lines.append(diagnostic(name, prefix.count("\n") + 1, len(prefix.rsplit("\n", 1)[-1]) + 1, "Invalid UTF-8 encoding"))
REM PY     rc = 1
REM PY except (OSError, ValueError, RecursionError) as e:
REM PY     lines.append("ERROR: " + str(e))
REM PY lines.append("Exit code: " + str(rc))
REM PY output = "\n".join(lines) + "\n"
REM PY if log:
REM PY     try:
REM PY         Path(log).write_text(output, encoding="utf-8")
REM PY     except OSError as e:
REM PY         lines.append("ERROR: cannot write output log: " + str(e))
REM PY         rc = 2
REM PY for line in lines:
REM PY     print(line.encode(sys.stdout.encoding or "utf-8", errors="backslashreplace").decode(sys.stdout.encoding or "utf-8"))
REM PY sys.exit(rc)
