@echo off
REM COMVERILOG version 1.0.0.0.10 - OpenAI GPT-6
REM Compile Verilog and run only after successful compilation.
REM Direct test: COMVERILOG.BAT "C:\TEMP\helloworld.v"
REM Error test: COMVERILOG.BAT "C:\TEMP\errorstest.v"
REM TSE parameters: %1=name %2=extension %3=full filename
REM                 %4=drive %5=subpath %6=diagnostics filename
REM Six-parameter test:
REM COMVERILOG.BAT "errorstest" ".v" "C:\TEMP\errorstest.v" "C:" "\TEMP\" "C:\TEMP\verilog.err"
REM Runs directly under TCC or CMD. No nested TCC invocation.
setlocal

REM ============================================================
REM PART 1 - USER VARIABLES
REM ============================================================
set "VERILOG_EXE=G:\LANGUAGE\COMPUTER\VERILOG\bin\iverilog.exe"
set "VVP_EXE=G:\LANGUAGE\COMPUTER\VERILOG\bin\vvp.exe"
set "VERILOG_FLAGS=-g2005 -grelative-include"

REM ============================================================
REM PART 2 - STABLE LOGIC
REM ============================================================
set "COMVERILOG_VERSION=1.0.0.0.10"
set "SOURCE="
set "ERRFILE="
set "RC=1"
set "COMPILED="
if "%~1"=="" goto usage
if "%~3"=="" goto direct
set "SOURCE=%~f3"
set "ERRFILE=%~6"
goto prepare

:direct
set "SOURCE=%~f1"

:prepare
if not defined ERRFILE set "ERRFILE=%TEMP%\COMVERILOG_%RANDOM%.err"
echo COMVERILOG version %COMVERILOG_VERSION%
echo Compiling "%SOURCE%"
if not exist "%SOURCE%" goto missing_source
if not exist "%VERILOG_EXE%" goto missing_compiler
:choose_output
set "COMPILED=%TEMP%\COMVERILOG_%RANDOM%_%RANDOM%.vvp"
if exist "%COMPILED%" goto choose_output
"%VERILOG_EXE%" %VERILOG_FLAGS% -o "%COMPILED%" "%SOURCE%" > "%ERRFILE%" 2>&1
set "RC=%ERRORLEVEL%"
goto report

:missing_source
> "%ERRFILE%" echo %SOURCE%:1: error: Source file not found.
goto report

:missing_compiler
> "%ERRFILE%" echo %SOURCE%:1: error: Compiler not found at "%VERILOG_EXE%".
goto report

:report
type "%ERRFILE%"
echo Compile exit code: %RC%
echo Diagnostics: "%ERRFILE%"
if not "%RC%"=="0" goto cleanup
echo Compilation successful.
if not exist "%VVP_EXE%" goto missing_runner
echo Running "%SOURCE%"
"%VVP_EXE%" "%COMPILED%"
set "RC=%ERRORLEVEL%"
echo Run exit code: %RC%
goto cleanup

:missing_runner
set "RC=1"
echo Runner not found at "%VVP_EXE%".
>> "%ERRFILE%" echo %SOURCE%:1: error: Runner not found at "%VVP_EXE%".

:cleanup
if not defined COMPILED goto finish
if exist "%COMPILED%" del /q "%COMPILED%"
goto finish

:usage
echo COMVERILOG version %COMVERILOG_VERSION%
echo Usage: COMVERILOG.BAT "full filename.v"
echo Or supply the six TSE parameters described in the header.

:finish
pause
endlocal & exit /b %RC%
