@echo off
REM COMLOGO.BAT version 1.0.0.0.9 - OpenAI GPT-6
REM Run LOGO program - Berkeley Logo CATCH/ERROR experiment.
REM Native TCC/CMD; no extra executable, PS1, or Logo wrapper is generated.
REM Error handling is embedded in the supplied Logo test program itself.
REM
REM DIRECT: COMLOGO.BAT "source.logo" ["ucblogo.exe"] [yes/no]
REM TSE: COMLOGO.BAT name ext fullsource drive path output [exe] [yes/no]
REM %1=name %2=extension %3=full source %4=drive %5=path %6=output in TSE.
REM Optional executable: direct %2 / TSE %7 / COMLOGO_EXE environment.
REM Optional pause: direct %3 / TSE %8 / COMLOGO_PAUSE=yes or no.
REM Direct reports are saved beside the source: source.logo.comlogo.log.
REM TSE reports use the output filename provided by TSE.
REM
REM Run these from the folder containing COMLOGO.BAT and the samples:
REM "G:\UTILS\JPSoft\TCMD\tcc.exe" /c COMLOGO.BAT /test
REM cmd.exe /d /c COMLOGO.BAT /test
REM "G:\UTILS\JPSoft\TCMD\tcc.exe" /c COMLOGO.BAT /testerrors
REM cmd.exe /d /c COMLOGO.BAT /testerrors
REM /test loads helloworld.logo; /testerrors loads errorstest.logo.
REM Samples close Logo with BYE after closing their report file.
REM If Logo stops at a prompt, type BYE or close it to return to the BAT.
REM
REM REAL capture: errorstest.logo uses separate CATCH "ERROR blocks.
REM Its line/column values are explicit, verified test annotations.
REM They are not general-purpose source mapping from UCBLogo ERROR.
REM An arbitrary source must implement the same report protocol to export
REM errors: arguments after - supply source filename and report filename.
REM Write TSE: filename:line:column: Error: message for each caught error,
REM then COMLOGO_DONE: errors or COMLOGO_DONE: success and close the report.
REM Normal Logo source needs no extra code to run. Its result is UNKNOWN
REM unless it implements the report protocol. Missing completion is exported
REM as a TSE diagnostic at fallback 1:1, never as a verified successful run.
REM FINDSTR is the standard Windows utility, not an added helper program.
REM
REM ================= PART 1: USER SETTINGS ==============================
setlocal
set "LOGO_DEFAULT_EXE=G:\language\computer\logo\ucblogo.exe"
set "LOGO_DEFAULT_PAUSE=yes"
REM ================= PART 2: RUNNER =====================================
set "LOGO_RC=0"
set "LOGO_SOURCE=%~1"
set "LOGO_REPORT="
set "LOGO_EXE=%LOGO_DEFAULT_EXE%"
set "LOGO_PAUSE=%LOGO_DEFAULT_PAUSE%"
if defined COMLOGO_EXE set "LOGO_EXE=%COMLOGO_EXE%"
if defined COMLOGO_PAUSE set "LOGO_PAUSE=%COMLOGO_PAUSE%"
if /i "%~1"=="/test" goto testhello
if /i "%~1"=="/testerrors" goto testerrors
if "%~1"=="" goto usage
if not "%~6"=="" goto tseargs
if not "%~2"=="" set "LOGO_EXE=%~2"
if not "%~3"=="" set "LOGO_PAUSE=%~3"
goto ready
:tseargs
set "LOGO_SOURCE=%~3"
set "LOGO_REPORT=%~6"
if not "%~7"=="" set "LOGO_EXE=%~7"
if not "%~8"=="" set "LOGO_PAUSE=%~8"
goto ready
:testhello
set "LOGO_SOURCE=%~dp0helloworld.logo"
if not "%~2"=="" set "LOGO_EXE=%~2"
goto ready
:testerrors
set "LOGO_SOURCE=%~dp0errorstest.logo"
if not "%~2"=="" set "LOGO_EXE=%~2"
:ready
for %%I in ("%LOGO_SOURCE%") do set "LOGO_SOURCE=%%~fI"
if "%LOGO_REPORT%"=="" set "LOGO_REPORT=%LOGO_SOURCE%.comlogo.log"
for %%I in ("%LOGO_REPORT%") do set "LOGO_REPORT=%%~fI"
echo COMLOGO version 1.0.0.0.9
if /i "%LOGO_SOURCE%"=="%LOGO_REPORT%" goto samefile
if /i "%LOGO_EXE%"=="%LOGO_REPORT%" goto samefile
if not exist "%LOGO_SOURCE%" goto missingfile
REM Never use IF EXIST filename\ as a directory test in TCC.
for %%I in ("%LOGO_SOURCE%") do set "LOGO_ATTR=%%~aI"
if /i "%LOGO_ATTR:~0,1%"=="d" goto missingfile
if not exist "%LOGO_EXE%" goto missingexe
for %%I in ("%LOGO_EXE%") do set "LOGO_ATTR=%%~aI"
if /i "%LOGO_ATTR:~0,1%"=="d" goto missingexe
if not exist "%SystemRoot%\System32\findstr.exe" goto nofindstr
REM Truncate old diagnostics so a previous successful run cannot mask failure.
>"%LOGO_REPORT%" echo COMLOGO_PENDING: 1.0.0.0.9
if errorlevel 1 goto outputfailed
REM Forward slashes avoid Logo treating Windows backslashes as escapes.
set "LOGO_SOURCE_ARG=%LOGO_SOURCE:\=/%"
set "LOGO_REPORT_ARG=%LOGO_REPORT:\=/%"
echo Loading "%LOGO_SOURCE%"
echo Samples should write their report and exit automatically.
echo If Logo stops at a prompt, type BYE or close its window.
start "" /wait "%LOGO_EXE%" "%LOGO_SOURCE%" - "%LOGO_SOURCE_ARG%" "%LOGO_REPORT_ARG%"
set "LOGO_PROCESS_RC=%errorlevel%"
echo.
type "%LOGO_REPORT%"
echo.
if not "%LOGO_PROCESS_RC%"=="0" goto processfailed
"%SystemRoot%\System32\findstr.exe" /x /c:"COMLOGO_DONE: errors" "%LOGO_REPORT%" >nul
if not errorlevel 1 goto caught
"%SystemRoot%\System32\findstr.exe" /x /c:"COMLOGO_DONE: success" "%LOGO_REPORT%" >nul
if errorlevel 1 goto incomplete
echo Logo report completed successfully.
goto finish
:caught
set "LOGO_RC=1"
echo Real Logo errors were captured. Use TSE's error list to jump.
goto finish
:incomplete
echo ERROR: no completed Logo report. Capture is unverified for this source.
echo Check the Logo window for startup, command.line, or file-write errors.
set "LOGO_MESSAGE=Result unknown: no completed error report. Check the Logo window. Ordinary Logo source does not export errors automatically. Actual error location unavailable; using line 1 column 1."
goto reportfailure
:processfailed
echo ERROR: Logo process returned %LOGO_PROCESS_RC%.
set "LOGO_MESSAGE=Logo process failed. Check the Logo window. Actual error location unavailable; using line 1 column 1."
goto reportfailure
:reportfailure
set "LOGO_RC=2"
echo TSE: %LOGO_SOURCE%:1:1: Error: %LOGO_MESSAGE%
>>"%LOGO_REPORT%" echo TSE: %LOGO_SOURCE%:1:1: Error: %LOGO_MESSAGE%
if errorlevel 1 echo ERROR: could not save the TSE diagnostic to the report.
goto finish
:missingfile
echo ERROR: source file is missing or is a directory: "%LOGO_SOURCE%"
set "LOGO_RC=2"
goto finish
:missingexe
echo ERROR: executable is missing or is a directory: "%LOGO_EXE%"
set "LOGO_RC=2"
goto finish
:nofindstr
echo ERROR: standard Windows FINDSTR utility is unavailable.
set "LOGO_RC=2"
goto finish
:samefile
echo ERROR: report path equals source or executable. No file was overwritten.
set "LOGO_RC=2"
goto finish
:outputfailed
echo ERROR: cannot write report "%LOGO_REPORT%".
set "LOGO_RC=2"
goto finish
:usage
echo Usage: COMLOGO.BAT "source.logo" ["ucblogo.exe"] [yes/no]
echo Tests: COMLOGO.BAT /test or COMLOGO.BAT /testerrors
set "LOGO_RC=2"
:finish
echo Exit code: %LOGO_RC%
if /i "%LOGO_PAUSE%"=="yes" pause
endlocal & exit /b %LOGO_RC%
