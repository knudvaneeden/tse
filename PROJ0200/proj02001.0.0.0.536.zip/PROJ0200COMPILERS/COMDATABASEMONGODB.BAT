@echo off
rem COMDATABASEMONGODB.BAT version 1.0.0.0.14
rem OpenAI ChatGPT
rem Runs one MongoDB shell MongoDB script file and writes output to parameter 6.
rem Parameters 1, 2, 4 and 5 are accepted for TSE compatibility and ignored.
rem Parameter 3: source file. Parameter 6: output/error file.
rem Test in cmd.exe:
rem   cmd.exe /c COMDATABASEMONGODB.BAT x x "C:\test\helloworlddatabasemongodb.mongodb" x x "C:\temp\mongo-output.txt"
rem Test in tcc.exe:
rem   tcc.exe /c COMDATABASEMONGODB.BAT x x "C:\test\helloworlddatabasemongodb.mongodb" x x "C:\temp\mongo-output.txt"
rem Start mongod separately before running this file. The script runs once.
rem Do not put a password in this file or in the connection URI.
rem
rem PART 1: USER SETTINGS
setlocal
set "MONGOSH_EXE=G:\database\server\mongodb\bin\mongosh.exe"
set "MONGODB_URI=mongodb://127.0.0.1:27017"
rem Set to 0 to disable the pause.
set "MONGODB_PAUSE=1"
rem
echo COMDATABASEMONGODB.BAT version 1.0.0.0.14
rem PART 2: IMPLEMENTATION
set "MONGO_SOURCE=%~3"
set "MONGO_OUTPUT=%~6"
if not defined MONGO_SOURCE goto usage
if not defined MONGO_OUTPUT goto usage
if /i "%MONGO_SOURCE%"=="%MONGO_OUTPUT%" goto same_file
if not exist "%MONGOSH_EXE%" goto no_mongosh
if not exist "%MONGO_SOURCE%" goto no_source
rem TCC's IF ISDIR avoids its IF EXIST file-with-trailing-slash behavior.
if not "%_4ver%"=="" goto tcc_directory_check
if exist "%MONGO_SOURCE%\NUL" goto no_source
goto run_mongosh
:tcc_directory_check
if isdir "%MONGO_SOURCE%" goto no_source
:run_mongosh
>"%MONGO_OUTPUT%" echo filename=%MONGO_SOURCE%
"%MONGOSH_EXE%" "%MONGODB_URI%" --file "%MONGO_SOURCE%" >>"%MONGO_OUTPUT%" 2>&1
set "MONGO_RESULT=%ERRORLEVEL%"
type "%MONGO_OUTPUT%"
if not "%MONGO_RESULT%"=="0" echo MongoDB shell failed with exit code %MONGO_RESULT%.
if "%MONGODB_PAUSE%"=="1" pause
endlocal & exit /b %MONGO_RESULT%
:no_mongosh
echo ERROR: MongoDB shell executable not found: %MONGOSH_EXE%
if defined MONGO_OUTPUT >"%MONGO_OUTPUT%" echo ERROR: MongoDB shell executable not found: %MONGOSH_EXE%
if "%MONGODB_PAUSE%"=="1" pause
endlocal & exit /b 1
:no_source
echo ERROR: source file not found or is a directory: %MONGO_SOURCE%
if defined MONGO_OUTPUT >"%MONGO_OUTPUT%" echo ERROR: source file not found or is a directory: %MONGO_SOURCE%
if "%MONGODB_PAUSE%"=="1" pause
endlocal & exit /b 1
:same_file
echo ERROR: source and output must be different files.
if "%MONGODB_PAUSE%"=="1" pause
endlocal & exit /b 1
:usage
echo ERROR: supply the source file as parameter 3 and output file as parameter 6.
if "%MONGODB_PAUSE%"=="1" pause
endlocal & exit /b 1
