@echo off
REM COMZIG version 1.0.0.0.9 - Created with OpenAI GPT-6
REM Compile and run a Zig source file. No helper script is required.
REM Direct test in a native TCC console:
REM   COMZIG.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.zig"
REM Direct test in a CMD console:
REM   COMZIG.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.zig"
REM From another shell, test CMD with:
REM   cmd.exe /d /c COMZIG.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.zig"
REM TSE six-parameter test, in either console:
REM   COMZIG.BAT errorstest .zig "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.zig" F: "\BBC\TAAL\PROJ0200ERRORSMULTIPLE\" "C:\TEMP\zig-errors.txt"
REM Parameters: %1=name, %2=extension, %3=source, %4=drive,
REM             %5=directory, %6=TSE diagnostic output file.
REM With one parameter, %1 is the source filename instead.
REM zig.exe is configured below, not supplied as a positional argument.
REM Set showErrors=false in errorstest.zig for a successful Hello World test.
REM Expected error mode: three errors with line and column information.

setlocal
REM ==================================================================
REM PART 1 - USER VARIABLES: adapt these to your local installation.
REM ==================================================================
set "ZIG_EXE=G:\LANGUAGE\COMPUTER\zig-x86_64-windows-0.18.0-dev.4+5a23bf4b2\zig.exe"
set "ZIG_OPTIONS=-O Debug"
REM Leave blank to use TEMP for standalone diagnostic output.
set "ZIG_LOG_DIRECTORY="
REM Pause at the end: YES or NO.
set "ZIG_PAUSE=YES"

REM ==================================================================
REM PART 2 - STABLE LOGIC: normally no changes are needed below.
REM ==================================================================
set "ZIG_VERSION=1.0.0.0.9"
set "ZIG_SHELL=CMD"
if not "%_CMDPROC%"=="" set "ZIG_SHELL=TCC"
set "ZIG_RC=1"
set "ZIG_SOURCE=%~1"
set "ZIG_LOG="
if not "%~3"=="" set "ZIG_SOURCE=%~3"
if not "%~6"=="" set "ZIG_LOG=%~6"
if "%ZIG_LOG_DIRECTORY%"=="" set "ZIG_LOG_DIRECTORY=%TEMP%"
if "%ZIG_LOG_DIRECTORY%"=="" set "ZIG_LOG_DIRECTORY=."
if "%ZIG_LOG%"=="" set "ZIG_LOG=%ZIG_LOG_DIRECTORY%\comzig-errors-%RANDOM%-%RANDOM%.txt"
echo COMZIG version %ZIG_VERSION%
echo Shell: %ZIG_SHELL%
>"%ZIG_LOG%" echo COMZIG version %ZIG_VERSION%
if errorlevel 1 goto logFailed
if "%ZIG_SOURCE%"=="" goto usage
for %%I in ("%ZIG_SOURCE%") do set "ZIG_SOURCE=%%~fI"
>>"%ZIG_LOG%" echo filename=%ZIG_SOURCE%
if not exist "%ZIG_SOURCE%" goto sourceMissing
if "%ZIG_SHELL%"=="TCC" goto checkTccSource
REM The trailing-backslash directory test is used ONLY under CMD.
if exist "%ZIG_SOURCE%\" goto sourceDirectory
goto sourceChecked
:checkTccSource
if isdir "%ZIG_SOURCE%" goto sourceDirectory
:sourceChecked
if not exist "%ZIG_EXE%" goto compilerMissing
REM Use a unique temporary executable; never run an older source executable.
set "ZIG_PROGRAM=%TEMP%\comzig-run-%RANDOM%-%RANDOM%.exe"
if "%TEMP%"=="" set "ZIG_PROGRAM=%ZIG_LOG_DIRECTORY%\comzig-run-%RANDOM%-%RANDOM%.exe"
if exist "%ZIG_PROGRAM%" goto outputExists
echo Compiling "%ZIG_SOURCE%"
"%ZIG_EXE%" build-exe "%ZIG_SOURCE%" %ZIG_OPTIONS% --color off "-femit-bin=%ZIG_PROGRAM%" >>"%ZIG_LOG%" 2>&1
set "ZIG_RC=%ERRORLEVEL%"
echo Compile exit code: %ZIG_RC%
if not "%ZIG_RC%"=="0" goto showLog
if not exist "%ZIG_PROGRAM%" goto executableMissing
echo Running "%ZIG_SOURCE%"
"%ZIG_PROGRAM%" >>"%ZIG_LOG%" 2>&1
set "ZIG_RC=%ERRORLEVEL%"
echo Run exit code: %ZIG_RC%
goto showLog
:usage
>>"%ZIG_LOG%" echo ERROR: supply a source filename or the six TSE parameters.
goto showLog
:sourceMissing
>>"%ZIG_LOG%" echo ERROR: source file not found: "%ZIG_SOURCE%"
goto showLog
:sourceDirectory
>>"%ZIG_LOG%" echo ERROR: source is a directory: "%ZIG_SOURCE%"
goto showLog
:compilerMissing
>>"%ZIG_LOG%" echo ERROR: zig.exe not found: "%ZIG_EXE%"
goto showLog
:outputExists
>>"%ZIG_LOG%" echo ERROR: temporary executable already exists. Run again.
set "ZIG_PROGRAM="
goto showLog
:executableMissing
>>"%ZIG_LOG%" echo ERROR: compilation returned success but no executable exists.
set "ZIG_RC=1"
:showLog
type "%ZIG_LOG%"
echo Diagnostics: "%ZIG_LOG%"
if "%ZIG_PROGRAM%"=="" goto finish
if exist "%ZIG_PROGRAM%" del /q "%ZIG_PROGRAM%" >nul 2>&1
if exist "%ZIG_PROGRAM%.obj" del /q "%ZIG_PROGRAM%.obj" >nul 2>&1
if exist "%ZIG_PROGRAM%.pdb" del /q "%ZIG_PROGRAM%.pdb" >nul 2>&1
goto finish
:logFailed
echo ERROR: cannot write diagnostics to "%ZIG_LOG%".
echo Check that the output directory exists and is writable.
:finish
echo Exit code: %ZIG_RC%
if /i "%ZIG_PAUSE%"=="YES" pause
endlocal & exit /b %ZIG_RC%
