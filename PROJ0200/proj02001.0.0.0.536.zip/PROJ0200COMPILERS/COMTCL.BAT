@echo off
REM COMTCL.BAT - version 1.0.0.0.7 - 2026-11-04
REM Run TCL program. Native TCC preferred; also designed for cmd.exe.
REM No helper program. The Tcl source is executed ONCE.
REM TSE arguments: %1=name %2=extension %3=source %4=drive %5=path
REM                %6=output file %7=optional tclsh.exe %8=optional pause
REM Quote every argument. Use a source path different from the output path.
REM External BAT test: save the following CALL line in your own test BAT:
REM call COMTCL.BAT "helloworldtcl" ".tcl" "f:\bbc\taal\proj0200\helloworldtcl.tcl" "f:" "f:\bbc\taal\proj0200\" "c:\temp\tclhello.err" "g:\language\computer\tcl\bin\tclsh85.exe" "yes"
REM For errors, replace source with the full path to errorstesttcl.tcl.
REM TCC test: start tcc.exe, then CALL your test BAT for each source.
REM CMD test: start cmd.exe /d, then CALL the same test BAT for each source.
REM Expected hello: Hello world from Tcl! and exit code 0.
REM Expected errors: one unhandled error, nonzero exit code, file/line trace.
REM In both shells, repeat with spaces in the source/output paths.
REM Test a missing source and a directory: both must be rejected.
REM Existing output directory required. Check ERRORLEVEL after CALL returns.
REM In TSE import comtclbatcompilersetting_tcl.txt; test next-error jumping.
REM Tcl stops at the first unhandled error. Fix it and rerun for the next.
REM Native Tcl traces report lines, NOT precise columns. Column=1 below
REM is only the start-of-line navigation fallback, not a measured column.
REM Nested procedure traces can identify the outer call site in the file.
REM ------------------------------------------------------------------
REM PART 1 - USER SETTINGS: change only these installation/preferences.
setlocal
set "TCL_EXE=g:\language\computer\tcl\bin\tclsh85.exe"
set "TCL_PAUSE=yes"
REM PART 2 - FIXED LOGIC: no installation-specific edits below here.
if not "%~7"=="" set "TCL_EXE=%~7"
if not "%~8"=="" set "TCL_PAUSE=%~8"
set "TCL_RC=1"
set "TCL_SOURCE=%~3"
set "TCL_OUTPUT=%~6"
echo COMTCL.BAT version 1.0.0.0.7
if "%TCL_SOURCE%"=="" goto usage
if "%TCL_OUTPUT%"=="" goto usage
if /i "%~f3"=="%~f6" goto samefile
REM Keep TCC-only syntax on a separate, conditionally reached line.
if defined _4VER goto tcc_check
REM cmd.exe directory check: NUL device, never IF EXIST filename\.
if exist "%TCL_SOURCE%\NUL" goto badsource
goto source_check
:tcc_check
if isdir "%TCL_SOURCE%" goto badsource
:source_check
if not exist "%TCL_SOURCE%" goto badsource
if not exist "%TCL_EXE%" goto badexe
>"%TCL_OUTPUT%" echo COMTCL.BAT version 1.0.0.0.7
if errorlevel 1 goto badoutput
>>"%TCL_OUTPUT%" echo column=1
"%TCL_EXE%" "%TCL_SOURCE%" >>"%TCL_OUTPUT%" 2>&1
set "TCL_RC=%errorlevel%"
type "%TCL_OUTPUT%"
goto finish
:usage
echo ERROR: expected six TSE arguments; see REM examples above.
goto finish
:samefile
echo ERROR: source and output paths must be different.
goto finish
:badsource
echo ERROR: source file missing or is a directory: "%TCL_SOURCE%"
goto finish
:badexe
echo ERROR: Tcl executable not found: "%TCL_EXE%"
goto finish
:badoutput
echo ERROR: cannot write output file: "%TCL_OUTPUT%"
goto finish
:finish
if /i "%TCL_PAUSE%"=="yes" pause
endlocal & exit /b %TCL_RC%
