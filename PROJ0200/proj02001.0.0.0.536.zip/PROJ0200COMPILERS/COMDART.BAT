@ECHO OFF
REM COMDART.BAT version 1.0.0.0.8 - 2026-10-09
REM Updated with OpenAI GPT-6 / Codex.
REM Compile Dart to a temporary kernel, then run once only on success.
REM Native Dart diagnostics are retained for TSE: file:line:column: message.
REM No PowerShell, external parser, or helper program is used.
REM
REM Parameters: %1 name, %2 extension, %3 full source, %4 drive,
REM             %5 directory, %6 TSE diagnostics, %7 optional dart.exe override.
REM If %3 is empty, %1 is the source. %2/%4/%5 are reserved, not forwarded.
REM Quote paths. The log directory must exist. Logs are retained after return.
REM
REM TEST FROM AN EXISTING TCC PROMPT (do not start nested tcc.exe):
REM   COMDART.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.dart"
REM   COMDART.BAT "errorstest" "dart" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.dart" "F" "BBC\TAAL\PROJ0200ERRORSMULTIPLE" "C:\TEMP\comdart_tcc.err"
REM TEST FROM CMD OR TCC USING CMD:
REM   cmd.exe /d /c COMDART.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.dart"
REM   cmd.exe /d /c COMDART.BAT "errorstest" "dart" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.dart" "F" "BBC\TAAL\PROJ0200ERRORSMULTIPLE" "C:\TEMP\comdart_cmd.err"
REM OPTIONAL TOOL OVERRIDE: append "g:\language\computer\dart\dart-sdk\bin\dart.exe" as %7.
REM Expected: three compiler diagnostics at 6:3, 9:3, 12:3, no execution.
REM In TSE, import the supplied .dart rule, compile errorstest.dart, and
REM select each diagnostic to check the corresponding line and column.
REM Success test: void main() { print('Hello from Dart'); }
REM Expected: Hello from Dart once, exit code 0.
REM Missing source or a directory argument returns 2 under both shells.
REM These Windows shell tests must be run on Windows; not executed here.

SETLOCAL
REM ======================================================================
REM PART 1 - USER CONFIGURATION
REM ======================================================================
SET "DART_EXE=g:\language\computer\dart\dart-sdk\bin\dart.exe"
REM Optional trusted compiler options (for example, --enable-asserts).
SET "COMPILE_OPTIONS="
REM Optional trusted Dart VM options.
SET "RUN_OPTIONS="
REM Existing scratch directory. Empty uses TEMP, then the current directory.
SET "WORK_DIRECTORY="
REM Pause at the end: 1=yes, 0=no.
SET "PAUSE_AT_END=1"

REM ======================================================================
REM PART 2 - STABLE EXECUTION LOGIC
REM ======================================================================
SET "VERSION=1.0.0.0.8"
SET "RESULT=2"
SET "KERNEL="
SET "SHELL_NAME=CMD"
IF NOT "%_TCCVER%" == "" SET "SHELL_NAME=TCC"
ECHO COMDART version %VERSION%
ECHO Shell: %SHELL_NAME%
REM Strip quotes explicitly instead of relying on CMD-only path modifiers.
SET "SOURCE=%3"
SET "SOURCE=%SOURCE:"=%"
IF NOT "%SOURCE%" == "" GOTO source_ready
SET "SOURCE=%1"
SET "SOURCE=%SOURCE:"=%"
:source_ready
SET "DIAGNOSTICS=%6"
SET "DIAGNOSTICS=%DIAGNOSTICS:"=%"
SET "DART_OVERRIDE=%7"
SET "DART_OVERRIDE=%DART_OVERRIDE:"=%"
IF NOT "%DART_OVERRIDE%" == "" SET "DART_EXE=%DART_OVERRIDE%"
IF "%SOURCE%" == "" GOTO usage_error
IF NOT EXIST "%SOURCE%" GOTO source_error
IF "%SHELL_NAME%" == "TCC" GOTO tcc_source_check
REM The trailing-backslash directory test is used only by CMD.
IF EXIST "%SOURCE%\" GOTO directory_error
GOTO source_checked
:tcc_source_check
REM TCC IF EXIST "file\" can match a file. Use the native ISDIR test.
IF ISDIR "%SOURCE%" GOTO directory_error
:source_checked
IF NOT EXIST "%DART_EXE%" GOTO dart_error
IF NOT "%WORK_DIRECTORY%" == "" GOTO work_ready
SET "WORK_DIRECTORY=%TEMP%"
IF "%WORK_DIRECTORY%" == "" SET "WORK_DIRECTORY=."
:work_ready
IF NOT EXIST "%WORK_DIRECTORY%\." GOTO work_error
SET "RUN_ID=%RANDOM%_%RANDOM%"
IF NOT "%DIAGNOSTICS%" == "" GOTO log_ready
SET "DIAGNOSTICS=%WORK_DIRECTORY%\COMDART_%RUN_ID%.err"
:log_ready
IF /I "%DIAGNOSTICS%" == "%SOURCE%" GOTO unsafe_log
IF /I "%DIAGNOSTICS%" == "%DART_EXE%" GOTO unsafe_log
>"%DIAGNOSTICS%" ECHO COMDART version %VERSION%
IF ERRORLEVEL 1 GOTO log_error
>>"%DIAGNOSTICS%" ECHO filename=%SOURCE%
REM Allocate a new directory so existing kernels are never overwritten.
SET "BUILD_DIRECTORY=%WORK_DIRECTORY%\COMDART_%RUN_ID%"
IF EXIST "%BUILD_DIRECTORY%" GOTO work_error
MKDIR "%BUILD_DIRECTORY%" >NUL 2>&1
IF NOT EXIST "%BUILD_DIRECTORY%\." GOTO work_error
SET "KERNEL=%BUILD_DIRECTORY%\program.dill"
ECHO Compiling "%SOURCE%"
"%DART_EXE%" compile kernel %COMPILE_OPTIONS% "%SOURCE%" -o "%KERNEL%" >>"%DIAGNOSTICS%" 2>&1
SET "RESULT=%ERRORLEVEL%"
TYPE "%DIAGNOSTICS%"
ECHO Compiler exit code: %RESULT%
IF NOT "%RESULT%" == "0" GOTO finish
IF NOT EXIST "%KERNEL%" GOTO kernel_error
ECHO.
ECHO Running "%SOURCE%"
REM Keep stdout visible; save stderr and preserve the real program exit code.
"%DART_EXE%" %RUN_OPTIONS% "%KERNEL%" 2>>"%DIAGNOSTICS%"
SET "RESULT=%ERRORLEVEL%"
ECHO.
ECHO Program exit code: %RESULT%
REM Show the complete log, including any runtime stderr, without rerunning.
ECHO Diagnostics:
TYPE "%DIAGNOSTICS%"
GOTO finish
:usage_error
ECHO Usage: COMDART.BAT "source.dart"
GOTO finish
:source_error
ECHO ERROR: source file not found: "%SOURCE%"
GOTO finish
:directory_error
ECHO ERROR: source is a directory: "%SOURCE%"
GOTO finish
:dart_error
ECHO ERROR: Dart executable not found: "%DART_EXE%"
ECHO Edit DART_EXE in Part 1 or supply parameter 7.
GOTO finish
:work_error
ECHO ERROR: Cannot create a new temporary build directory in "%WORK_DIRECTORY%".
GOTO finish
:unsafe_log
ECHO ERROR: Diagnostics must not overwrite the source or Dart executable.
GOTO finish
:log_error
ECHO ERROR: Cannot write diagnostics: "%DIAGNOSTICS%"
GOTO finish
:kernel_error
SET "RESULT=2"
ECHO ERROR: Compiler returned success without creating the kernel.
:finish
IF NOT "%KERNEL%" == "" DEL /Q "%KERNEL%" >NUL 2>&1
IF NOT "%KERNEL%" == "" RMDIR "%BUILD_DIRECTORY%" >NUL 2>&1
IF NOT "%DIAGNOSTICS%" == "" ECHO Diagnostics saved to "%DIAGNOSTICS%"
ECHO Exit code: %RESULT%
IF "%PAUSE_AT_END%" == "1" PAUSE
IF "%SHELL_NAME%" == "TCC" GOTO finish_tcc
ENDLOCAL & EXIT /B %RESULT%
:finish_tcc
REM QUIT restores SETLOCAL automatically and preserves the supplied exit code.
QUIT %RESULT%
