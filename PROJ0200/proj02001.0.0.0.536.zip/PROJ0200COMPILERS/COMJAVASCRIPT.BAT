@echo off
REM COMJAVASCRIPT version 1.0.0.7 - OpenAI GPT-6 - 2026-10-06
REM PART 1 - USER SETTINGS
setlocal
REM Node executable: full path, or node.exe when available on PATH.
set "nodeExe=node.exe"
REM Helper must be stored next to this BAT.
set "helper=%~dp0comjavascript_check.cjs"
REM 1 pauses at the end; 0 returns immediately.
set "pauseAtEnd=1"
REM 0 checks only (safe for browser scripts); 1 runs with Node after success.
set "runAfterCheck=0"
REM
REM Short form: COMJAVASCRIPT.BAT "C:\my scripts\errorstest.js"
REM TSE form: COMJAVASCRIPT.BAT "errorstest" "js" "C:\my scripts\errorstest.js" "C" "my scripts" "C:\TEMP\js.err"
REM 1=source or TSE basename; 2=extension; 3=full source; 4=drive;
REM 5=directory; 6=diagnostic file; 7=optional Node EXE; 8=NOPAUSE.
REM Parameters 4 and 5 are retained for compatibility; parameter 3 takes priority.
REM Diagnostics go to parameter 6 and are also displayed. Parent must exist.
REM Tests (run both; use your actual TCC executable path):
REM tcc.exe /c COMJAVASCRIPT.BAT "errorstest.js"
REM cmd.exe /d /c COMJAVASCRIPT.BAT "errorstest.js"
REM tcc.exe /c COMJAVASCRIPT.BAT "errorstest" "js" "C:\my scripts\errorstest.js" "C" "my scripts" "C:\TEMP\js-tcc.err" "C:\Program Files\nodejs\node.exe" "NOPAUSE"
REM cmd.exe /d /c COMJAVASCRIPT.BAT "errorstest" "js" "C:\my scripts\errorstest.js" "C" "my scripts" "C:\TEMP\js-cmd.err" "C:\Program Files\nodejs\node.exe" "NOPAUSE"
REM Expected first error: line 3, column 15. Fix it to const first = 1;
REM Expected next error: line 4, column 16. Fix it to const second = 2;
REM Then syntax checking should succeed. Check the exit code and TSE jumps.
REM Missing source should return 2. Node setup failure should return 2.
REM Syntax checking finds the first parse error only, not runtime/type errors.
REM Browser APIs such as document require a browser, not Node execution.
REM
REM PART 2 - STABLE EXECUTION LOGIC
set "sourceFile=%~1"
if not "%~3"=="" set "sourceFile=%~3"
set "diagnosticFile=%~6"
if not "%~7"=="" set "nodeExe=%~7"
if /i "%~8"=="NOPAUSE" set "pauseAtEnd=0"
set "result=2"
echo COMJAVASCRIPT version 1.0.0.7
if "%diagnosticFile%"=="" set "diagnosticFile=%TEMP%\COMJAVASCRIPT_%RANDOM%_%RANDOM%.err"
if "%TEMP%"=="" if "%~6"=="" set "diagnosticFile=%CD%\COMJAVASCRIPT_%RANDOM%_%RANDOM%.err"
REM Initialize diagnostics so a failed launch cannot display a stale error file.
>"%diagnosticFile%" echo ERROR: Node or helper unavailable; check user settings.
if errorlevel 1 goto setup_failed
REM The helper writes the complete error file, including setup failures.
"%nodeExe%" "%helper%" "%sourceFile%" "%diagnosticFile%" >nul 2>&1
set "result=%errorlevel%"
if not exist "%diagnosticFile%" goto setup_failed
type "%diagnosticFile%"
if not "%result%"=="0" goto finish
if not "%runAfterCheck%"=="1" goto finish
echo Running "%sourceFile%"
REM Runtime output stays on the console; the TSE rule parses syntax errors only.
"%nodeExe%" "%sourceFile%"
set "result=%errorlevel%"
goto finish
:setup_failed
echo ERROR: Cannot check JavaScript or write diagnostics.
echo Check Node path, helper file, and diagnostic directory.
set "result=2"
:finish
echo Diagnostics: "%diagnosticFile%"
echo Exit code: %result%
if "%pauseAtEnd%"=="1" pause
endlocal & exit /b %result%
