@ECHO OFF
REM COMASSEMBLERNASM.BAT version 1.0.0.0.10
REM Updated 2026-10-08. LLM: OpenAI GPT-6.
REM Session: Run ASSEMBLER NASM program
REM Assemble, link and run a Windows x64 NASM program. TCC and CMD syntax.
REM
REM TESTS: run each command in the indicated shell.
REM Native TCC prompt: COMASSEMBLERNASM.BAT "C:\NASM tests\hello.nasm"
REM cmd.exe /d /c COMASSEMBLERNASM.BAT "C:\NASM tests\hello.nasm"
REM Native TCC prompt: COMASSEMBLERNASM.BAT "hello" "nasm" "C:\NASM tests\hello.nasm" "C" "NASM tests" "C:\NASM tests\tcc.err"
REM cmd.exe /d /c COMASSEMBLERNASM.BAT "hello" "nasm" "C:\NASM tests\hello.nasm" "C" "NASM tests" "C:\NASM tests\cmd.err"
REM Parameters: one argument = source file; six arguments = TSE convention:
REM 1=name, 2=extension, 3=source file, 4=drive, 5=path, 6=diagnostics.
REM Parameters 1,2,4,5 are accepted for compatibility. Source is parameter 3.
REM Quote ALL paths in TSE's compiler command:
REM COMASSEMBLERNASM.BAT "&name&" "&ext&" "&fn&" "&drive&" "&path&" "&output&"
REM Optional parameters 7 and 8 override NASM_EXE and LINK_EXE in six-arg mode.
REM Example: append "G:\cygwin\bin\nasm.exe" "C:\Tools\link.exe".
REM Output: source directory, source basename with .exe and .obj extensions.
REM Test missing source, invalid assembly, unresolved symbol and paths with spaces.
REM Build failures must return nonzero and must never run an old executable.
REM Compiler logs start with filename= for TSE's error parser.

SETLOCAL
ECHO COMASSEMBLERNASM version 1.0.0.0.10
REM ======================================================================
REM PART 1 - USER SETTINGS: edit this section for your local installation.
REM Use full executable paths to avoid a different link.exe on PATH.
REM These defaults retain the installation paths in the supplied document.
REM Libraries must be x64 and compatible with the selected Microsoft linker.
REM LIB_DIRECTORY may be empty to retain the existing LIB environment.
REM ======================================================================
SET "NASM_EXE=G:\cygwin\bin\nasm.exe"
SET "LINK_EXE=C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Tools\MSVC\14.44.35207\bin\Hostx64\x64\link.exe"
SET "LIB_DIRECTORY=G:\LANGUAGE\COMPUTER\ASSEMBLER\NASM\LIB"
SET "NASM_OPTIONS=-f win64 -Xgnu"
SET "LINK_OPTIONS=/nologo /machine:x64 /subsystem:console /entry:main"
SET "LINK_LIBRARIES=kernel32.lib ucrt.lib legacy_stdio_definitions.lib"
SET "PAUSE_AT_END=true"
SET "KEEP_OBJECT=false"

REM ======================================================================
REM PART 2 - COMMON LOGIC: no installation-specific edits required below.
REM Shell-specific directory tests and returns are reached only in that shell.
REM No helper script and no nested TCC invocation.
REM NASM reports line numbers but no column numbers.
REM Linker and libraries are checked only after successful assembly.
REM The rule extracts each diagnostic filename directly, including include files.
REM ======================================================================
SET "SOURCE=%1"
SET "SOURCE=%SOURCE:"=%"
SET "LOG_FILE="
SET "RESULT=1"
SET "DIR_PUSHED=false"
SET "ARG3=%3"
SET "ARG3=%ARG3:"=%"
IF "%ARG3%" == "" GOTO ARGUMENTS_READY
SET "SOURCE=%ARG3%"
SET "LOG_FILE=%6"
SET "LOG_FILE=%LOG_FILE:"=%"
SET "ARG7=%7"
SET "ARG7=%ARG7:"=%"
IF "%ARG7%" == "" GOTO CHECK_LINK_OVERRIDE
SET "NASM_EXE=%ARG7%"
:CHECK_LINK_OVERRIDE
SET "ARG8=%8"
SET "ARG8=%ARG8:"=%"
IF "%ARG8%" == "" GOTO ARGUMENTS_READY
SET "LINK_EXE=%ARG8%"
:ARGUMENTS_READY
IF "%SOURCE%" == "" GOTO USAGE
IF NOT EXIST "%SOURCE%" GOTO SOURCE_MISSING
IF /I "%_CMDPROC%" == "TCC" GOTO SOURCE_TCC
IF EXIST "%SOURCE%\NUL" GOTO SOURCE_MISSING
GOTO SOURCE_FILE_READY
:SOURCE_TCC
IF ISDIR "%SOURCE%" GOTO SOURCE_MISSING
:SOURCE_FILE_READY
REM FOR modifiers apply to FOR variables, supported by both target shells.
FOR %%F IN ("%SOURCE%") DO SET "SOURCE=%%~fF"
FOR %%F IN ("%SOURCE%") DO SET "SOURCE_DIR=%%~dpF"
FOR %%F IN ("%SOURCE%") DO SET "OBJECT_FILE=%%~dpnF.obj"
FOR %%F IN ("%SOURCE%") DO SET "EXE_FILE=%%~dpnF.exe"
IF NOT "%LOG_FILE%" == "" GOTO HAVE_LOG
SET "LOG_FILE=%TEMP%\COMASSEMBLERNASM_%RANDOM%_%RANDOM%.err"
:HAVE_LOG
FOR %%F IN ("%LOG_FILE%") DO SET "LOG_FILE=%%~fF"
IF /I "%LOG_FILE%" == "%SOURCE%" GOTO UNSAFE_LOG
IF /I "%LOG_FILE%" == "%OBJECT_FILE%" GOTO UNSAFE_LOG
IF /I "%LOG_FILE%" == "%EXE_FILE%" GOTO UNSAFE_LOG
>"%LOG_FILE%" ECHO filename=%SOURCE%
IF ERRORLEVEL 1 GOTO LOG_FAILED
IF NOT EXIST "%NASM_EXE%" GOTO NASM_MISSING
PUSHD "%SOURCE_DIR%"
IF ERRORLEVEL 1 GOTO DIRECTORY_FAILED
SET "DIR_PUSHED=true"
IF EXIST "%EXE_FILE%" DEL /Q "%EXE_FILE%"
IF EXIST "%EXE_FILE%" GOTO DELETE_FAILED
IF EXIST "%OBJECT_FILE%" DEL /Q "%OBJECT_FILE%"
IF EXIST "%OBJECT_FILE%" GOTO DELETE_FAILED
ECHO Assembling "%SOURCE%"
"%NASM_EXE%" %NASM_OPTIONS% -o "%OBJECT_FILE%" "%SOURCE%" >>"%LOG_FILE%" 2>&1
SET "RESULT=%ERRORLEVEL%"
IF NOT "%RESULT%" == "0" GOTO BUILD_FAILED
IF NOT EXIST "%OBJECT_FILE%" GOTO OUTPUT_MISSING
IF NOT EXIST "%LINK_EXE%" GOTO LINK_MISSING
IF "%LIB_DIRECTORY%" == "" GOTO LIB_READY
IF NOT EXIST "%LIB_DIRECTORY%\." GOTO LIB_MISSING
SET "LIB=%LIB_DIRECTORY%"
:LIB_READY
ECHO Linking "%EXE_FILE%"
"%LINK_EXE%" "%OBJECT_FILE%" %LINK_OPTIONS% /out:"%EXE_FILE%" %LINK_LIBRARIES% >>"%LOG_FILE%" 2>&1
SET "RESULT=%ERRORLEVEL%"
IF NOT "%RESULT%" == "0" GOTO BUILD_FAILED
IF NOT EXIST "%EXE_FILE%" GOTO OUTPUT_MISSING
TYPE "%LOG_FILE%"
ECHO.
ECHO Running "%EXE_FILE%"
"%EXE_FILE%"
SET "RESULT=%ERRORLEVEL%"
ECHO.
ECHO Program exit code: %RESULT%
GOTO FINISH
:USAGE
ECHO Usage: COMASSEMBLERNASM.BAT "source.nasm"
ECHO Or: COMASSEMBLERNASM.BAT "name" "nasm" "source.nasm" "drive" "path" "diagnostics.err"
GOTO FINISH
:SOURCE_MISSING
ECHO ERROR: NASM source not found: "%SOURCE%"
GOTO FINISH
:UNSAFE_LOG
ECHO ERROR: Diagnostics path must differ from source, object and executable.
GOTO FINISH
:LOG_FAILED
ECHO ERROR: Cannot write diagnostics: "%LOG_FILE%"
ECHO Create the parent directory first.
GOTO FINISH
:NASM_MISSING
>>"%LOG_FILE%" ECHO ERROR: NASM executable not found: "%NASM_EXE%"
GOTO CONFIG_FAILED
:LINK_MISSING
>>"%LOG_FILE%" ECHO ERROR: Microsoft linker not found: "%LINK_EXE%"
GOTO CONFIG_FAILED
:LIB_MISSING
>>"%LOG_FILE%" ECHO ERROR: Library directory not found: "%LIB_DIRECTORY%"
GOTO CONFIG_FAILED
:DIRECTORY_FAILED
>>"%LOG_FILE%" ECHO ERROR: Cannot enter source directory.
GOTO CONFIG_FAILED
:DELETE_FAILED
>>"%LOG_FILE%" ECHO ERROR: Cannot remove previous build output.
GOTO CONFIG_FAILED
:OUTPUT_MISSING
SET "RESULT=1"
>>"%LOG_FILE%" ECHO ERROR: Tool reported success but build output is missing.
GOTO BUILD_FAILED
:CONFIG_FAILED
SET "RESULT=1"
:BUILD_FAILED
TYPE "%LOG_FILE%"
ECHO Build failed. Exit code: %RESULT%
:FINISH
IF /I "%DIR_PUSHED%" == "true" GOTO CLEAN_OBJECT
GOTO REPORT
:CLEAN_OBJECT
IF /I "%KEEP_OBJECT%" == "true" GOTO RESTORE_DIRECTORY
IF EXIST "%OBJECT_FILE%" DEL /Q "%OBJECT_FILE%"
:RESTORE_DIRECTORY
POPD
:REPORT
IF NOT "%LOG_FILE%" == "" ECHO Diagnostics saved to "%LOG_FILE%"
IF /I "%PAUSE_AT_END%" == "true" PAUSE
REM Native TCC returns with QUIT, without starting another shell.
IF /I "%_CMDPROC%" == "TCC" GOTO RETURN_TCC
ENDLOCAL & EXIT /B %RESULT%
:RETURN_TCC
ENDLOCAL & QUIT %RESULT%
