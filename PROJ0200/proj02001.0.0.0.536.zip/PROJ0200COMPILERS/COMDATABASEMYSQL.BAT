@echo off
rem COMDATABASEMYSQL.BAT version 1.0.0.7
rem Updated 2026-10-05 by OpenAI Codex
rem Executes a MySQL SQL file once, displays results, and preserves exit code.
rem MySQL server must already be running. Password is prompted once.
rem SQL scripts must select their database with USE, as ddd.sql does.
rem
rem TEST 1 - Direct call: argument 1 is the SQL filename.
rem COMDATABASEMYSQL.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.sql"
rem
rem TEST 2 - Same six external parameters supplied by TSE:
rem COMDATABASEMYSQL.BAT "ddd" "unused" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.sql" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\comdatabase_test.err"
rem Parameter mapping for the six-parameter call:
rem   1 = source basename, for example ddd; unused by this runner.
rem   2 = unused placeholder; retain its position.
rem   3 = full SQL filename; used as input.
rem   4 = drive supplied by TSE; unused by this runner.
rem   5 = directory supplied by TSE; unused by this runner.
rem   6 = full output/error filename; used for captured results.
rem Quote each parameter, including placeholders for unused parameters.
rem The directory containing the parameter 6 file must already exist.
rem The mysql.exe path is configured below, not supplied as a parameter.
rem Look for Hello and MySQL exit code: 0 after entering your password.
rem
rem ======================================================================
rem PART 1 - USER SETTINGS: adapt these values to your own computer.
rem ======================================================================
setlocal
rem Full path to the MySQL CLIENT executable, not mysqld.exe.
set "MYSQL_EXE=G:\DATABASE\SERVER\MYSQL\mysql-9.4.0-winx64\bin\mysql.exe"
rem Server address, classic MySQL TCP port, and MySQL account.
set "MYSQL_HOST=127.0.0.1"
set "MYSQL_PORT=3306"
set "MYSQL_USER=root"
rem Used only when external parameter 6 is absent. Directory must exist.
set "DEFAULT_OUTPUT_DIRECTORY=%TEMP%"
rem Optional extra output copy. Set to empty to disable this copy.
set "CONVENIENCE_OUTPUT_FILE=C:\temp\dddoutput.txt"
rem true keeps the console open until a key is pressed; false skips pause.
set "PAUSE_AT_END=true"
rem true reports errors in later statements too; later SQL WILL execute.
rem Set false to stop at the first SQL error.
set "CONTINUE_ON_SQL_ERROR=true"

rem ======================================================================
rem PART 2 - PROGRAM: no user changes required below this line.
rem ======================================================================
rem Use Windows CMD explicitly, including when called from TCC.
if /i "%~1"=="--cmd" goto cmdEntry
"%SystemRoot%\System32\cmd.exe" /d /c ""%~f0" --cmd %*"
endlocal & exit /b %errorlevel%

:cmdEntry
shift
setlocal EnableExtensions DisableDelayedExpansion
set "SQL_FILE=%~3"
if not defined SQL_FILE set "SQL_FILE=%~1"
set "OUTPUT_FILE=%~6"
if not defined OUTPUT_FILE set "OUTPUT_FILE=%DEFAULT_OUTPUT_DIRECTORY%\COMDATABASEMYSQL_%RANDOM%_%RANDOM%.txt"
set "RUN_CODE=1"

if not defined SQL_FILE goto usage
if not exist "%SQL_FILE%" goto missingSql
if not exist "%MYSQL_EXE%" goto missingMysql
for %%F in ("%SQL_FILE%") do set "SQL_FILE=%%~fF"
for %%F in ("%OUTPUT_FILE%") do set "OUTPUT_FILE=%%~fF"
if /i "%SQL_FILE%"=="%OUTPUT_FILE%" goto sameFile

>"%OUTPUT_FILE%" echo filename=%SQL_FILE%
if errorlevel 1 goto outputError
set "MYSQL_FORCE_OPTION="
if /i "%CONTINUE_ON_SQL_ERROR%"=="true" set "MYSQL_FORCE_OPTION=--force"
rem Execute the SQL file exactly once, using one authenticated connection.
echo Enter your MySQL password when prompted.
"%MYSQL_EXE%" --protocol=TCP --host="%MYSQL_HOST%" --port="%MYSQL_PORT%" --user="%MYSQL_USER%" --password --table %MYSQL_FORCE_OPTION% <"%SQL_FILE%" >>"%OUTPUT_FILE%" 2>&1
set "RUN_CODE=%errorlevel%"
rem --force can return success despite SQL errors; report failure to TSE.
"%SystemRoot%\System32\findstr.exe" /r /c:"^ERROR [0-9]" "%OUTPUT_FILE%" >nul
if not errorlevel 1 set "RUN_CODE=1"

:showOutput
echo.
type "%OUTPUT_FILE%"
echo.
echo MySQL exit code: %RUN_CODE%
echo Output saved to "%OUTPUT_FILE%"
if not "%RUN_CODE%"=="0" echo Check the error above. For connection errors, ensure the MySQL server is running.
rem Optional convenience copy. The main output remains the TSE argument 6 file.
if not defined CONVENIENCE_OUTPUT_FILE goto finish
if /i "%SQL_FILE%"=="%CONVENIENCE_OUTPUT_FILE%" goto finish
if /i "%OUTPUT_FILE%"=="%CONVENIENCE_OUTPUT_FILE%" goto finish
for %%F in ("%CONVENIENCE_OUTPUT_FILE%") do if not exist "%%~dpF" mkdir "%%~dpF" >nul 2>&1
copy /y "%OUTPUT_FILE%" "%CONVENIENCE_OUTPUT_FILE%" >nul 2>&1
if errorlevel 1 echo WARNING: Could not write convenience copy "%CONVENIENCE_OUTPUT_FILE%".
goto finish

:usage
echo Usage: COMDATABASEMYSQL.BAT "full path\ddd.sql"
echo TSE usage: SQL filename in argument 3 and output filename in argument 6.
goto finish
:missingSql
echo ERROR: SQL file not found: "%SQL_FILE%"
goto finish
:missingMysql
echo ERROR: MySQL client not found: "%MYSQL_EXE%"
echo Edit MYSQL_EXE in this batch file to match your installation.
goto finish
:sameFile
echo ERROR: SQL input and output filenames must be different.
goto finish
:outputError
echo ERROR: Cannot write output file: "%OUTPUT_FILE%"
echo Ensure its directory exists and is writable.
goto finish
:finish
echo.
if /i "%PAUSE_AT_END%"=="true" pause
endlocal & endlocal & exit /b %RUN_CODE%
