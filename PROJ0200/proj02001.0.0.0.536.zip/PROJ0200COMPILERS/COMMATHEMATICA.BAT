@echo off
setlocal
REM COMMATHEMATICA version 1.0.0.0.9 - OpenAI GPT-6
REM Run MATHEMATICA program
REM No additional script or helper program is required.
REM
REM PART 1 - USER SETTINGS: change the kernel path for your installation.
set "COMMATHEMATICA_EXE=C:\Program Files\Wolfram Research\Mathematica\9.0\math.exe"
REM Pause at the end: 1=yes, 0=no.
set "COMMATHEMATICA_PAUSE=1"
REM
REM TESTS - run these in the indicated console, with this BAT on PATH.
REM Native TCC console:
REM   COMMATHEMATICA.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.wl"
REM Microsoft CMD console:
REM   cmd.exe /d /c COMMATHEMATICA.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.wl"
REM Six-parameter call, usable in either console:
REM   COMMATHEMATICA.BAT "errorstest" "wl" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.wl" "F:" "\BBC\TAAL\PROJ0200ERRORSMULTIPLE" "F:\BBC\TAAL\mathematica.err"
REM %1=name, %2=extension, %3=full source filename,
REM %4=drive, %5=directory, %6=TSE diagnostic output filename.
REM With one parameter, %1 is the full source filename.
REM %7 optionally overrides the executable path for a six-parameter call.
REM Quote all paths. Do not include quotes inside the SET values above.
REM A successful sample: Print["Hello from Mathematica 1.0.0.0.9"];
REM
REM PART 2 - STABLE LOGIC: normally no changes are needed below here.
set "COMMATHEMATICA_VERSION=1.0.0.0.9"
set "COMMATHEMATICA_RC=1"
set "COMMATHEMATICA_SHELL=CMD"
if /i "%_CMDPROC%" == "TCC" set "COMMATHEMATICA_SHELL=TCC"
if /i "%_CMDPROC%" == "TCCLE" set "COMMATHEMATICA_SHELL=TCC"
if /i "%_CMDPROC%" == "TCC-RT" set "COMMATHEMATICA_SHELL=TCC"
set "COMMATHEMATICA_SOURCE=%~1"
if not "%~3" == "" set "COMMATHEMATICA_SOURCE=%~3"
if not "%~7" == "" set "COMMATHEMATICA_EXE=%~7"
set "COMMATHEMATICA_ERR=%~6"
if not "%COMMATHEMATICA_ERR%" == "" goto output_ready
set "COMMATHEMATICA_ERR=%TEMP%\COMMATHEMATICA_%RANDOM%_%RANDOM%.err"
:output_ready
for %%F in ("%COMMATHEMATICA_ERR%") do set "COMMATHEMATICA_ERR=%%~fF"
echo COMMATHEMATICA version %COMMATHEMATICA_VERSION%
echo Shell: %COMMATHEMATICA_SHELL%
if "%COMMATHEMATICA_SOURCE%" == "" goto usage
REM Canonicalize the source path, including spaces.
for %%F in ("%COMMATHEMATICA_SOURCE%") do set "COMMATHEMATICA_SOURCE=%%~fF"
if /i "%COMMATHEMATICA_SOURCE%" == "%COMMATHEMATICA_ERR%" goto same_file
>"%COMMATHEMATICA_ERR%" echo COMMATHEMATICA version %COMMATHEMATICA_VERSION%
if errorlevel 1 goto output_failed
>>"%COMMATHEMATICA_ERR%" echo filename=%COMMATHEMATICA_SOURCE%
>>"%COMMATHEMATICA_ERR%" echo column=1
if not exist "%COMMATHEMATICA_SOURCE%" goto source_missing
if "%COMMATHEMATICA_SHELL%" == "TCC" goto tcc_directory
REM CMD directory attribute test; never use IF EXIST "filename" here.
for %%F in ("%COMMATHEMATICA_SOURCE%") do set "COMMATHEMATICA_ATTR=%%~aF"
if /i "%COMMATHEMATICA_ATTR:~0,1%" == "d" goto source_missing
goto source_ready
:tcc_directory
if isdir "%COMMATHEMATICA_SOURCE%" goto source_missing
:source_ready
if not exist "%COMMATHEMATICA_EXE%" goto kernel_missing
echo Running "%COMMATHEMATICA_SOURCE%"
REM Environment[] passes the Windows filename without Wolfram escaping.
REM Get runs the file once. Mathematica 9 stops at the first syntax error.
REM Fix that syntax error and rerun to reach the next one.
REM Check returns failure if any message was issued, after Get finishes.
REM Exit prevents the text kernel from waiting for interactive input.
"%COMMATHEMATICA_EXE%" -noprompt -run "Check[Get[Environment[FromCharacterCode[{67,79,77,77,65,84,72,69,77,65,84,73,67,65,95,83,79,85,82,67,69}]]],Exit[1]];Exit[0]" >>"%COMMATHEMATICA_ERR%" 2>&1
set "COMMATHEMATICA_RC=%ERRORLEVEL%"
goto show_output
:source_missing
>>"%COMMATHEMATICA_ERR%" echo ERROR: source file not found or is a directory: "%COMMATHEMATICA_SOURCE%"
goto show_output
:kernel_missing
>>"%COMMATHEMATICA_ERR%" echo ERROR: Mathematica kernel not found: "%COMMATHEMATICA_EXE%"
>>"%COMMATHEMATICA_ERR%" echo Change COMMATHEMATICA_EXE in PART 1.
goto show_output
:show_output
type "%COMMATHEMATICA_ERR%"
echo Kernel exit code: %COMMATHEMATICA_RC%
echo Diagnostics saved to "%COMMATHEMATICA_ERR%"
goto finish
:usage
echo Usage: COMMATHEMATICA.BAT "C:\TEMP\program.wl"
echo Or supply the six TSE parameters documented above.
goto finish
:same_file
echo ERROR: source and diagnostics must be different files.
goto finish
:output_failed
echo ERROR: cannot write diagnostics to "%COMMATHEMATICA_ERR%".
:finish
if "%COMMATHEMATICA_PAUSE%" == "1" pause
endlocal & exit /b %COMMATHEMATICA_RC%
