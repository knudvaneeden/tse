@echo off
@if "%@eval[2+2]" == "4" goto run_using_cmd
setlocal EnableExtensions DisableDelayedExpansion
REM COMPYTHON.BAT - version 1.0.0.0.11
REM Updated 2026-10-04 by OpenAI GPT-6.1 / Codex.
REM Run a Python script once, from its own directory.
REM Direct TCC calls automatically delegate to CMD.EXE before parsing paths.
REM The initial TCC expression stays literal in CMD, so CMD does not delegate.
REM
REM TESTS (replace the example paths with your own):
REM   cmd.exe /d /c COMPYTHON.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.py"
REM   cmd.exe /d /c COMPYTHON.BAT "ddd" "unused" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.py" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\compython_test.err"
REM   tcc.exe /c COMPYTHON.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.py"
REM   tcc.exe /c COMPYTHON.BAT "ddd" "py" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.py" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\compython_tcc_test.err"
REM Expect Hello from Python and Python exit code: 0 in all four tests.
REM Error test: put raise ValueError("test error") in a separate test.py,
REM then run the same commands with test.py: expect a traceback and code 1.
REM Example ddd.py content: print("Hello from Python")
REM Direct call: %%1 = script filename; no script arguments are forwarded.
REM PROJ0200 call: %%1 = stem, %%2 = unused, %%3 = script filename,
REM                %%4 = drive, %%5 = directory, %%6 = diagnostics filename.
REM Only %%3 and %%6 are used in the six-parameter form.
REM Quote filenames, especially those containing spaces.
REM Exit status: Python's exit code, or 1 for wrapper/setup errors.
REM Standard output and input remain connected to the console.
REM Standard error is saved, then displayed after Python finishes.
REM Diagnostic formatting is embedded below; no separate PY helper is needed.
REM The TSE rule uses Message Tag 0 to display the entire location message.
REM If Python provides no caret, the reported column defaults to 1.
REM Diagnostics are retained. Each call overwrites the selected log file.
REM
REM ====================================================================
REM PART 1 - USER SETTINGS: change only this section for your system.
REM ====================================================================
REM Full path to python.exe. Alternatively use python.exe from PATH.
set "PYTHON_EXE=G:\LANGUAGE\COMPUTER\PYTHON\PYTHON\python.exe"
REM Pause at the end: 1 = yes, 0 = no (use 0 for automated callers).
set "PAUSE_AT_END=1"
REM Default diagnostics directory; must already exist. TEMP is portable.
set "LOG_DIRECTORY=%TEMP%"
REM Optional compatibility copy, e.g. C:\TEMP\dddoutput.txt.
REM Leave empty to disable. Parent directory must already exist.
REM This copy contains diagnostics, not standard output.
set "DIAGNOSTICS_COPY="

REM ====================================================================
REM PART 2 - EXECUTION: normally no user changes are needed below here.
REM ====================================================================
set "RESULT=1"
set "DID_PUSHD=0"
set "SCRIPT_FILE="
set "LOG_FILE="
if not "%~7"=="" goto usage
if not "%~6"=="" goto project_arguments
if not "%~2"=="" goto usage
set "SCRIPT_FILE=%~1"
goto arguments_ready

:project_arguments
set "SCRIPT_FILE=%~3"
set "LOG_FILE=%~f6"

:arguments_ready
if not defined SCRIPT_FILE goto usage
for %%I in ("%SCRIPT_FILE%") do set "SCRIPT_FILE=%%~fI"
if not exist "%SCRIPT_FILE%" goto missing_script
if exist "%SCRIPT_FILE%\" goto missing_script
if not defined LOG_FILE set "LOG_FILE=%LOG_DIRECTORY%\COMPYTHON_%RANDOM%_%RANDOM%.txt"
if /i "%SCRIPT_FILE%"=="%LOG_FILE%" goto unsafe_log
for %%I in ("%LOG_FILE%") do if not exist "%%~dpI." goto missing_log_directory
if exist "%PYTHON_EXE%" goto python_ready
where "%PYTHON_EXE%" >nul 2>&1
if errorlevel 1 goto missing_python

:python_ready
>"%LOG_FILE%" echo filename=%SCRIPT_FILE%
if errorlevel 1 goto log_failed
for %%I in ("%SCRIPT_FILE%") do pushd "%%~dpI"
if errorlevel 1 goto directory_failed
set "DID_PUSHD=1"
echo Running "%SCRIPT_FILE%"
echo.
"%PYTHON_EXE%" -u "%SCRIPT_FILE%" 2>>"%LOG_FILE%"
set "RESULT=%ERRORLEVEL%"
REM Read the embedded Python code from this BAT; no helper file is created.
"%PYTHON_EXE%" -c "import sys; p=sys.argv.pop(1); exec('\n'.join(x[8:] for x in open(p,encoding='ascii').read().splitlines() if x.startswith('REM PY| ')))" "%~f0" "%LOG_FILE%"
if errorlevel 1 echo WARNING: Could not format Python diagnostics.
:diagnostics_ready
echo.
echo Python diagnostics:
type "%LOG_FILE%"
echo.
echo Python exit code: %RESULT%
echo Diagnostics saved to "%LOG_FILE%"
if not defined DIAGNOSTICS_COPY goto finish
if /i "%DIAGNOSTICS_COPY%"=="%SCRIPT_FILE%" goto unsafe_copy
copy /y "%LOG_FILE%" "%DIAGNOSTICS_COPY%" >nul
if errorlevel 1 echo WARNING: Could not copy diagnostics to "%DIAGNOSTICS_COPY%".
goto finish

:usage
echo Usage: COMPYTHON.BAT "script.py"
echo    or: COMPYTHON.BAT "stem" "unused" "script.py" "drive" "directory" "diagnostics.err"
goto finish
:missing_script
echo ERROR: Python script not found: "%SCRIPT_FILE%"
goto finish
:missing_python
echo ERROR: Python interpreter not found: "%PYTHON_EXE%"
echo Change PYTHON_EXE in PART 1.
goto finish
:missing_log_directory
echo ERROR: Diagnostics directory does not exist for "%LOG_FILE%".
goto finish
:unsafe_log
echo ERROR: Diagnostics filename must differ from the Python script.
goto finish
:log_failed
echo ERROR: Cannot write diagnostics file "%LOG_FILE%".
goto finish
:directory_failed
echo ERROR: Cannot enter the Python script directory.
goto finish
:unsafe_copy
echo WARNING: Diagnostics copy skipped because it would overwrite the script.

:finish
if "%DID_PUSHD%"=="1" popd
if "%PAUSE_AT_END%"=="1" pause
endlocal & exit /b %RESULT%

:run_using_cmd
REM Only TCC reaches this label; CMD handles the complete original call.
@"%SystemRoot%\System32\cmd.exe" /d /s /c ""%~f0" %*"
@exit /b %errorlevel%

REM Embedded diagnostics code - maintained with PART 2.
REM PY| # Version 1.0.0.0.11 - 2026-10-04 - OpenAI GPT-6.1 / Codex
REM PY| """Add source locations to Python error messages for the TSE compiler rule."""
REM PY| import pathlib
REM PY| import re
REM PY| import sys
REM PY| import tokenize
REM PY| 
REM PY| 
REM PY| def normalize(text):
REM PY|     lines = text.splitlines()
REM PY|     result = []
REM PY|     filename = None
REM PY|     number = 1
REM PY|     column = 1
REM PY|     source_indent = 0
REM PY|     for line in lines:
REM PY|         frame = re.match(r'^\s*File "(.+)", line (\d+)', line)
REM PY|         if frame:
REM PY|             filename, number = frame.group(1), int(frame.group(2))
REM PY|             column = 1
REM PY|             source_indent = 0
REM PY|             try:
REM PY|                 with tokenize.open(filename) as stream:
REM PY|                     source = stream.readlines()[number - 1].rstrip('\r\n')
REM PY|                 source_indent = len(source) - len(source.lstrip())
REM PY|             except (OSError, UnicodeError, IndexError, SyntaxError):
REM PY|                 pass
REM PY|         elif filename and re.fullmatch(r'\s*[~^]+\s*', line) and '^' in line:
REM PY|             # Tracebacks indent the stripped source and its markers by 4 spaces.
REM PY|             column = max(1, line.index('^') - 4 + source_indent + 1)
REM PY|         if re.match(r'^\w+(?:Error|Exception):', line) and filename:
REM PY|             message = 'line {}, column {}: {}'.format(number, column, line)
REM PY|             result.extend(['filename=' + filename, 'line=' + str(number),
REM PY|                            'column=' + str(column), message])
REM PY|             line = 'PythonError: ' + message
REM PY|         result.append(line)
REM PY|     return '\n'.join(result) + '\n'
REM PY| 
REM PY| 
REM PY| if __name__ == '__main__':
REM PY|     log = pathlib.Path(sys.argv[1])
REM PY|     # Read with the interpreter's stderr encoding, also used for the original log.
REM PY|     encoding = sys.stderr.encoding or 'utf-8'
REM PY|     text = log.read_bytes().decode(encoding, errors='replace')
REM PY|     log.write_bytes(normalize(text).replace('\n', '\r\n').encode(encoding, errors='replace'))
