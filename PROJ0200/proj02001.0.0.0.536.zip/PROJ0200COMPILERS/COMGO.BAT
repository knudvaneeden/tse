@echo off
@if "%@eval[2+2]" == "4" goto run_using_cmd
setlocal EnableExtensions DisableDelayedExpansion
REM COMGO.BAT - version 1.0.0.0.11
REM Updated 2026-10-04 03:14:43 by OpenAI GPT-6.1 / Codex.
REM Compile one Go source file once, then run it only if compilation succeeds.
REM Direct TCC calls delegate to CMD before parsing filenames.
REM TSE Description: 1.0.0.0.11 Go: COMGO.BAT
REM TSE Command: COMGO.BAT "&name&" "&ext&" "&fn&" "&drive&" "&path&" "&output&"
REM TSE Output: Don't Clear Screen or Prompt After Shell
REM Compiler diagnostics are written directly to parameter 6.
REM The Go rule reads native filename:line:column: message diagnostics.
REM No diagnostic formatter or PowerShell helper is required.
REM Console output goes to CON to avoid replay into TSE's redirected log.
REM
REM TESTS (replace paths with your own):
REM   cmd.exe /d /c COMGO.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.go"
REM   cmd.exe /d /c COMGO.BAT "ddd" "go" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.go" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\comgo_test.err"
REM   tcc.exe /c COMGO.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.go"
REM   tcc.exe /c COMGO.BAT "ddd" "go" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.go" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\comgo_tcc_test.err"
REM In your existing TCC console, also test COMGO.BAT "full source.go".
REM Expect Hello from Go and Program exit code: 0.
REM Error test: use separate bad.go containing an undefined identifier.
REM Expect compilation failure, diagnostics in parameter 6, no program run.
REM Direct call: %%1 = source filename. No program arguments are forwarded.
REM PROJ0200: %%1 = stem, %%2 = extension, %%3 = source filename,
REM           %%4 = drive, %%5 = directory, %%6 = compiler diagnostics file.
REM Only %%3 and %%6 are used in the six-parameter form.
REM Quote all paths. Diagnostics parent directories must already exist.
REM Example ddd.go (save these three lines without the REM prefix):
REM package main
REM import "fmt"
REM func main() { fmt.Println("Hello from Go") }
REM Exit status: compiler/program exit code, or 1 for setup errors.
REM Compiler output is saved and displayed. Program input/output uses console.
REM Logs are retained; the selected log is overwritten on each invocation.
REM The temporary executable is removed afterwards. Source is never copied.
REM This builds a single file, not all files in a multi-file Go package.
REM
REM ====================================================================
REM PART 1 - USER SETTINGS: change only this section for your system.
REM ====================================================================
REM Full path to go.exe; alternatively use go.exe to search PATH.
set "GO_EXE=G:\LANGUAGE\COMPUTER\GO\BIN\go.exe"
REM Temporary executable directory. Created if missing.
REM If your security software blocks execution in TEMP, choose an approved
REM build directory here. This script does not change security settings.
set "BUILD_DIRECTORY=%TEMP%"
REM Diagnostics directory; must already exist.
set "LOG_DIRECTORY=%TEMP%"
REM Pause at the end: 1 = yes, 0 = no for automated callers.
set "PAUSE_AT_END=1"
REM Optional compatibility copy, e.g. C:\TEMP\dddoutput.txt; empty disables.
REM Parent directory must exist. Contains compiler diagnostics only.
set "DIAGNOSTICS_COPY="

REM ====================================================================
REM PART 2 - EXECUTION: normally no user changes are needed below here.
REM ====================================================================
set "RESULT=1"
set "DID_PUSHD=0"
set "SOURCE_FILE="
set "LOG_FILE="
set "WORK_DIRECTORY="
set "PROGRAM_FILE="
if not "%~7"=="" goto usage
if not "%~6"=="" goto project_arguments
if not "%~2"=="" goto usage
set "SOURCE_FILE=%~1"
goto arguments_ready

:project_arguments
set "SOURCE_FILE=%~3"
set "LOG_FILE=%~f6"

:arguments_ready
if not defined SOURCE_FILE goto usage
for %%I in ("%SOURCE_FILE%") do set "SOURCE_FILE=%%~fI"
if not exist "%SOURCE_FILE%" goto missing_source
if exist "%SOURCE_FILE%\" goto missing_source
if not defined LOG_FILE set "LOG_FILE=%LOG_DIRECTORY%\COMGO_%RANDOM%_%RANDOM%.txt"
for %%I in ("%LOG_FILE%") do set "LOG_FILE=%%~fI"
if /i "%SOURCE_FILE%"=="%LOG_FILE%" goto unsafe_log
for %%I in ("%LOG_FILE%") do if not exist "%%~dpI." goto missing_log_directory
if exist "%GO_EXE%" goto go_ready
where "%GO_EXE%" >nul 2>&1
if errorlevel 1 goto missing_go

:go_ready
if not defined BUILD_DIRECTORY goto build_directory_failed
for %%I in ("%BUILD_DIRECTORY%") do set "BUILD_DIRECTORY=%%~fI"
if not exist "%BUILD_DIRECTORY%\." mkdir "%BUILD_DIRECTORY%" >nul 2>&1
if not exist "%BUILD_DIRECTORY%\." goto build_directory_failed
set "WORK_DIRECTORY=%BUILD_DIRECTORY%\COMGO_%RANDOM%_%RANDOM%"
REM Never reuse a pre-existing directory or executable.
if exist "%WORK_DIRECTORY%" goto build_directory_failed
mkdir "%WORK_DIRECTORY%" >nul 2>&1
if errorlevel 1 goto build_directory_failed
set "PROGRAM_FILE=%WORK_DIRECTORY%\program.exe"
>"%LOG_FILE%" echo filename=%SOURCE_FILE%
if errorlevel 1 goto log_failed
for %%I in ("%SOURCE_FILE%") do pushd "%%~dpI"
if errorlevel 1 goto directory_failed
set "DID_PUSHD=1"
echo Compiling "%SOURCE_FILE%" >CON
"%GO_EXE%" build -v -o "%PROGRAM_FILE%" "%SOURCE_FILE%" >>"%LOG_FILE%" 2>&1
set "RESULT=%ERRORLEVEL%"
type "%LOG_FILE%" >CON
echo. >CON
echo Compiler diagnostics saved to "%LOG_FILE%" >CON
if not defined DIAGNOSTICS_COPY goto copy_done
for %%I in ("%DIAGNOSTICS_COPY%") do set "DIAGNOSTICS_COPY=%%~fI"
if /i "%DIAGNOSTICS_COPY%"=="%SOURCE_FILE%" goto unsafe_copy
if /i "%DIAGNOSTICS_COPY%"=="%PROGRAM_FILE%" goto unsafe_copy
if /i "%DIAGNOSTICS_COPY%"=="%LOG_FILE%" goto copy_done
copy /y "%LOG_FILE%" "%DIAGNOSTICS_COPY%" >nul
if errorlevel 1 echo WARNING: Could not copy diagnostics to "%DIAGNOSTICS_COPY%". >CON
goto copy_done
:unsafe_copy
echo WARNING: Diagnostics copy skipped because it would overwrite source or executable. >CON
:copy_done
if not "%RESULT%"=="0" goto compile_failed
if not exist "%PROGRAM_FILE%" goto missing_program
echo. >CON
echo Running "%PROGRAM_FILE%" >CON
"%PROGRAM_FILE%" >CON 2>CON
set "RESULT=%ERRORLEVEL%"
echo. >CON
echo Program exit code: %RESULT% >CON
goto finish

:compile_failed
echo Compilation failed with exit code %RESULT%. Program was not run. >CON
goto finish
:missing_program
set "RESULT=1"
echo ERROR: Compiler did not create an executable. Source must be package main. >CON
goto finish
:usage
echo Usage: COMGO.BAT "source.go" >CON
echo    or: COMGO.BAT "stem" "extension" "source.go" "drive" "directory" "diagnostics.err" >CON
goto finish
:missing_source
echo ERROR: Go source file not found: "%SOURCE_FILE%" >CON
goto finish
:missing_go
echo ERROR: Go compiler not found: "%GO_EXE%" >CON
echo Change GO_EXE in PART 1. >CON
goto finish
:missing_log_directory
echo ERROR: Diagnostics directory does not exist for "%LOG_FILE%". >CON
goto finish
:unsafe_log
echo ERROR: Diagnostics filename must differ from the source filename. >CON
goto finish
:build_directory_failed
echo ERROR: Cannot create a fresh build directory under "%BUILD_DIRECTORY%". >CON
goto finish
:log_failed
echo ERROR: Cannot write diagnostics file "%LOG_FILE%". >CON
goto finish
:directory_failed
echo ERROR: Cannot enter the source directory. >CON

:finish
if "%DID_PUSHD%"=="1" popd
if defined PROGRAM_FILE if exist "%PROGRAM_FILE%" del /q "%PROGRAM_FILE%" >nul 2>&1
if defined PROGRAM_FILE if exist "%PROGRAM_FILE%" echo WARNING: Could not remove "%PROGRAM_FILE%". >CON
REM Remove only our empty directory, never recursively delete its contents.
if defined PROGRAM_FILE rd "%WORK_DIRECTORY%" >nul 2>&1
if "%PAUSE_AT_END%"=="1" pause >CON
endlocal & exit /b %RESULT%

:run_using_cmd
REM Only TCC reaches here. Preserve the original filename and arguments.
@"%SystemRoot%\System32\cmd.exe" /d /s /c ""%~f0" %*"
@exit /b %errorlevel%
