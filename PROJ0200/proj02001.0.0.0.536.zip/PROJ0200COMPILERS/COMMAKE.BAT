@echo off
REM COMMAKE.BAT version 1.0.0.0.8 - OpenAI ChatGPT / Codex
REM Borland MAKE runner for .mk files. bcc32.exe is NOT the MAKE executable.
REM Requires make.exe, normally beside bcc32.exe in the Borland bin directory.
REM No helper programs or generated scripts are used by this runner.
REM
REM Direct: COMMAKE.BAT "full-source.mk" [target] ["make.exe"] ["error-file"]
REM   %1 source makefile; %2 optional target; %3 optional MAKE executable;
REM   %4 optional error output. Use "" to retain an optional default.
REM TSE: COMMAKE.BAT "&name&" "&ext&" "&fn&" "&drive&" "&path&" "&output&"
REM Six arguments select TSE mode: %3 full source filename, %6 error file.
REM Use CALL when invoking this BAT from another BAT.
REM External overrides, set BEFORE invoking this BAT in either shell:
REM   set "COMMAKE_EXE=G:\language\computer\cpp\embarcadero\borland\bcc55\bin\make.exe"
REM   set "COMMAKE_TARGET="
REM   set "COMMAKE_PAUSE=0"
REM PAUSE=1 keeps the console readable; PAUSE=0 supports automated calls.
REM
REM Test BOTH shells, using --test to check the supplied files and missing file:
REM   "G:\UTILS\JPSoft\TCMD\tcc.exe" /c call COMMAKE.BAT --test
REM   cmd.exe /d /c call COMMAKE.BAT --test
REM Test specific files in either shell:
REM   COMMAKE.BAT "F:\BBC\TAAL\PROJ0200HELLOWORLD\helloworldmake.mk"
REM   COMMAKE.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstestmake.mk"
REM Select the second/third fatal-error case without editing the source:
REM   set "COMMAKE_OPTIONS=-DCASE=2"
REM   COMMAKE.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstestmake.mk"
REM Repeat with -DCASE=3; clear afterwards: set "COMMAKE_OPTIONS="
REM Options are trusted MAKE arguments; do not add shell operators.
REM --test accepts optional %2 hello path, %3 error path, %4 MAKE executable.
REM --testformat tests the diagnostic parser without needing MAKE installed.
REM
REM Output: TSE: full-filename:line:column: original diagnostic
REM Borland MAKE does not normally report columns; column 1 is the fallback.
REM MAKE 5.2 reports the following line for an Error directive diagnostic.
REM COMMAKE_ERROR_OFFSET=1 corrects that case only; set 0 to disable.
REM Fatal parse errors stop at the first error; CASE=1/2/3 test distinct lines.
REM Native compiler diagnostics from recipe commands remain in the raw log;
REM unsupported diagnostic formats produce a line-1 build-failure summary.
REM Delayed-expansion parser limitation: literal ! in diagnostics/paths.
REM Error output is always created/truncated; an empty file means success.
REM Raw output is retained beside it as .raw.log, including successful output.
REM ======================================================================
REM PART 1 - USER SETTINGS. All machine-dependent settings are here.
REM ======================================================================
setlocal DisableDelayedExpansion
if not defined COMMAKE_EXE set "COMMAKE_EXE=G:\language\computer\cpp\embarcadero\borland\bcc55\bin\make.exe"
if not defined COMMAKE_ERROR_OFFSET set "COMMAKE_ERROR_OFFSET=1"
if not defined COMMAKE_PAUSE set "COMMAKE_PAUSE=1"
if not defined COMMAKE_HELLO set "COMMAKE_HELLO=F:\BBC\TAAL\PROJ0200HELLOWORLD\helloworldmake.mk"
if not defined COMMAKE_ERRORS set "COMMAKE_ERRORS=F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstestmake.mk"
REM Optional COMMAKE_TARGET and COMMAKE_OPTIONS default to empty.
REM ======================================================================
REM PART 2 - ENGINE. No machine-dependent changes required below.
REM ======================================================================
set "rc=1"
set "source=%~1"
set "target=%COMMAKE_TARGET%"
set "errorOutput="
set "count=0"
if /i "%~1"=="--test" goto test
if /i "%~1"=="--testformat" goto testformat
if not "%~6"=="" goto tseargs
if not "%~2"=="" set "target=%~2"
if not "%~3"=="" set "COMMAKE_EXE=%~3"
set "errorOutput=%~4"
goto argsdone
:tseargs
set "source=%~3"
set "errorOutput=%~6"
:argsdone
echo COMMAKE.BAT version 1.0.0.0.8
if not defined errorOutput set "errorOutput=%TEMP%\COMMAKE_%RANDOM%_%RANDOM%.err"
for %%F in ("%errorOutput%") do set "errorOutput=%%~fF"
type nul >"%errorOutput%"
if errorlevel 1 goto badoutput
set "log=%errorOutput%.raw.log"
if not defined source goto usage
for %%F in ("%source%") do set "source=%%~fF"
if not exist "%source%" goto missing
REM Never test IF EXIST "filename\"; TCC can match ordinary files.
if defined _4VER goto tccdir
for %%F in ("%source%") do set "attributes=%%~aF"
if /i "%attributes:~0,1%"=="d" goto missing
goto checked
:tccdir
if isdir "%source%" goto missing
:checked
if not exist "%COMMAKE_EXE%" goto nomake
for %%F in ("%COMMAKE_EXE%") do set "COMMAKE_EXE=%%~fF"
for %%F in ("%COMMAKE_EXE%") do set "makeBin=%%~dpF"
set "PATH=%makeBin%;%PATH%"
for %%F in ("%source%") do set "sourceDir=%%~dpF"
for %%F in ("%source%") do set "sourceName=%%~nxF"
pushd "%sourceDir%"
if errorlevel 1 goto baddir
"%COMMAKE_EXE%" -f "%sourceName%" %COMMAKE_OPTIONS% %target% >"%log%" 2>&1
REM IF ERRORLEVEL works in both TCC and CMD; normalize status to 0 or 1.
set "rc=0"
if errorlevel 1 set "rc=1"
type "%log%"
setlocal EnableDelayedExpansion
for /f "usebackq delims=" %%L in ("!log!") do (
  set "entry=%%L"
  call :parse
)
if not "!count!"=="0" if "!rc!"=="0" set "rc=1"
if not "!rc!"=="0" if "!count!"=="0" (
  set "entry=MAKE failed; see raw log: !log!"
  set "file=!source!"
  set "line=1"
  call :emit
)
REM Keep the parser environment active until this BAT returns.
REM This avoids losing rc across ENDLOCAL in native TCC.
popd
goto finish
:parse
set "severity="
for /f "tokens=1" %%A in ("!entry!") do set "severity=%%A"
if /i "!severity!"=="Error" goto location
if /i "!severity!"=="Fatal" goto location
exit /b
:location
set "file=!source!"
set "line=1"
REM Split the first colon-space, leaving drive-letter colons intact.
set "parts=!entry:: =|!"
set "head="
for /f "tokens=1 delims=|" %%A in ("!parts!") do set "head=%%A"
set "rest="
for /f "tokens=1,*" %%A in ("!head!") do set "rest=%%B"
set "previous="
set "reportedFile="
:nextword
set "word="
set "tail="
for /f "tokens=1,*" %%A in ("!rest!") do (
  set "word=%%A"
  set "tail=%%B"
)
if not defined word goto located
if defined previous (
  if defined reportedFile (set "reportedFile=!reportedFile! !previous!") else set "reportedFile=!previous!"
)
set "previous=!word!"
set "rest=!tail!"
goto nextword
:located
if not defined previous goto emit
set "badNumber="
for /f "delims=0123456789" %%N in ("!previous!") do set "badNumber=%%N"
if defined badNumber goto emit
if "!previous!"=="0" goto emit
if not defined reportedFile goto emit
set "line=!previous!"
set "reportedFile=!reportedFile:"=!"
for %%F in ("!reportedFile!") do set "file=%%~fF"
REM Correct Borland 5.2 Error directive locations only.
if "!COMMAKE_ERROR_OFFSET!"=="1" if not "!entry:Error directive:=!"=="!entry!" if !line! GTR 1 set /a line-=1 >nul
:emit
set /a count+=1 >nul
echo TSE: !file!:!line!:1: !entry!
>>"!errorOutput!" echo TSE: !file!:!line!:1: !entry!
exit /b
:missing
set "message=Source file not found or is a directory"
goto failure
:nomake
set "message=Borland make.exe not found: %COMMAKE_EXE%"
goto failure
:baddir
set "message=Cannot enter source directory"
goto failure
:usage
set "source=%~f0"
set "message=Usage: COMMAKE.BAT source.mk [target] [make.exe] [error-file]"
:failure
setlocal EnableDelayedExpansion
set "entry=!message!"
set "file=!source!"
set "line=1"
call :emit
endlocal
set "rc=1"
goto finish
:badoutput
echo ERROR: Cannot create error output "%errorOutput%".
set "rc=1"
:finish
echo Exit code: %rc%
if "%COMMAKE_PAUSE%"=="1" pause
if not "%rc%"=="0" goto returnfailed
endlocal
exit /b 0
:returnfailed
endlocal
exit /b 1

:testformat
set "COMMAKE_PAUSE=0"
set "COMMAKE_ERROR_OFFSET=1"
set "source=%~f0"
set "errorOutput=%TEMP%\COMMAKE_format_%RANDOM%.err"
type nul >"%errorOutput%"
setlocal EnableDelayedExpansion
set "entry=Error errorstestmake.mk 12: Command syntax error"
call :parse
if not "!line!"=="12" goto formatfailed
set "entry=Fatal C:\My Project\example.mk 27: Error directive: deliberate"
call :parse
if not "!line!"=="26" goto formatfailed
if not "!file!"=="C:\My Project\example.mk" goto formatfailed
if not "!count!"=="2" goto formatfailed
del "!errorOutput!" >nul 2>&1
echo PASS: diagnostic parser, filenames with spaces, line and column.
endlocal
endlocal & exit /b 0
:formatfailed
echo FAIL: diagnostic parser. Retained: !errorOutput!
endlocal
endlocal & exit /b 1
:test
set "COMMAKE_PAUSE=0"
set "COMMAKE_TARGET="
set "COMMAKE_ERROR_OFFSET=1"
set "COMMAKE_OPTIONS="
if not "%~2"=="" set "COMMAKE_HELLO=%~2"
if not "%~3"=="" set "COMMAKE_ERRORS=%~3"
if not "%~4"=="" set "COMMAKE_EXE=%~4"
set "testOutput=%TEMP%\COMMAKE_test_%RANDOM%_%RANDOM%.err"
call "%~f0" --testformat
if errorlevel 1 goto testfailed
call "%~f0" "%COMMAKE_HELLO%" "" "%COMMAKE_EXE%" "%testOutput%"
if errorlevel 1 goto testfailed
for %%F in ("%testOutput%") do if not "%%~zF"=="0" goto testfailed
for %%C in (1 2 3) do (
  set "testCase=%%C"
  call :testcase
  if errorlevel 1 goto testfailed
)
call "%~f0" "%testOutput%.missing.mk" "" "%COMMAKE_EXE%" "%testOutput%"
if not errorlevel 1 goto testfailed
del "%testOutput%" "%testOutput%.raw.log" >nul 2>&1
echo PASS: hello, three fatal-error locations, parser, missing-file handling.
endlocal & exit /b 0
:testcase
set "COMMAKE_OPTIONS=-DCASE=%testCase%"
call "%~f0" "%COMMAKE_ERRORS%" "" "%COMMAKE_EXE%" "%testOutput%"
if not errorlevel 1 exit /b 1
set "expectedLine="
if "%testCase%"=="1" set "expectedLine=10"
if "%testCase%"=="2" set "expectedLine=13"
if "%testCase%"=="3" set "expectedLine=16"
"%SystemRoot%\System32\findstr.exe" /l /c:":%expectedLine%:1:" "%testOutput%" >nul
exit /b %errorlevel%
:testfailed
echo FAIL: inspect console and "%testOutput%".
endlocal & exit /b 1
