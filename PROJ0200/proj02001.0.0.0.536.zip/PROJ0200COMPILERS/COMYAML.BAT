@echo off
REM COMYAML.BAT - Version 1.0.0.0.0 - 2026-11-01
REM PART 1 - USER SETTINGS AND USAGE
REM Change PYTHON_EXE below to your installed Python executable.
REM Install PyYAML: "g:\language\computer\python\python\python.exe" -m pip install PyYAML
REM Direct use: COMYAML.BAT "full path\source.yaml"
REM TSE arguments: 1=name, 2=extension, 3=full source, 4=drive, 5=path,
REM 6=diagnostic output file. Direct use requires only argument 1.
REM Checks YAML syntax and duplicate mapping keys using Python/PyYAML.
REM Supports multiple YAML documents and .yaml or .yml filenames.
REM Uses SafeLoader: standard YAML tags only; no Python object execution.
REM PyYAML uses YAML 1.1 scalar resolution; this is not a YAML 1.2 checker.
REM No application-specific schema validation is performed.
REM Duplicate explicit keys are errors; merge-key overrides are allowed.
REM Error test: three duplicate keys; all three are reported in one run.
REM A syntax/construction error can prevent subsequent checks.
REM Success displays normalized YAML, including the example greeting.
REM ASCII console and diagnostics; file/line/column format for TSE jumping.
REM Run in cmd.exe and TCC: call COMYAML.BAT "helloworldyaml.yaml"
REM Then: call COMYAML.BAT "errorstestyaml.yaml"
REM Exit codes: 0=OK; 1=YAML error; 2=configuration/file error.
REM The console always pauses after each run.
setlocal
set "PYTHON_EXE=g:\language\computer\python\python\python.exe"
REM PART 2 - FIXED LOGIC
set "COMYAML_SELF=%~f0"
set "COMYAML_SOURCE=%~1"
set "COMYAML_OUTPUT="
if not "%~3"=="" set "COMYAML_SOURCE=%~3"
if not "%~3"=="" set "COMYAML_OUTPUT=%~6"
if "%~1"=="" goto usage
if not exist "%PYTHON_EXE%" goto noengine
"%PYTHON_EXE%" -c "import os; p=os.environ['COMYAML_SELF']; t=open(p,encoding='ascii').read(); exec(compile(t.split('# COMYAML_'+'PYTHON_BEGIN',1)[1],p,'exec'))"
set "COMYAML_RESULT=%errorlevel%"
goto finish
:usage
echo COMYAML.BAT version 1.0.0.0.0
echo Usage: COMYAML.BAT "source.yaml"
set "COMYAML_RESULT=2"
goto finish
:noengine
echo ERROR: Python executable not found: "%PYTHON_EXE%"
set "COMYAML_RESULT=2"
goto finish
:finish
pause
exit /b %COMYAML_RESULT%
# COMYAML_PYTHON_BEGIN
import os, sys
from pathlib import Path
VERSION = "1.0.0.0.0"
lines = []
status = 2
source = Path(os.environ["COMYAML_SOURCE"]).absolute()
def diagnostic(row, col, message):
    message = " ".join(str(message).splitlines())
    lines.append(f'TSE: "{source}" line {max(1,row)} column {max(1,col)}: ERROR: {message}')
try:
    import yaml
    class CheckedLoader(yaml.SafeLoader):
        def construct_mapping(self, node, deep=False):
            seen = {}
            for key_node, value_node in node.value:
                if key_node.tag == "tag:yaml.org,2002:merge":
                    continue
                key = self.construct_object(key_node, deep=deep)
                try:
                    if key in seen:
                        mark = key_node.start_mark
                        diagnostic(mark.line + 1, mark.column + 1,
                                   "Duplicate mapping key " + repr(key) +
                                   " (first defined at line " + str(seen[key]) + ")")
                    else:
                        seen[key] = key_node.start_mark.line + 1
                except TypeError:
                    pass  # SafeLoader reports an unhashable key with its mark.
            return super().construct_mapping(node, deep=deep)
    if not source.is_file():
        raise OSError("Source file not found or is a directory: " + str(source))
    try:
        with source.open("rb") as stream:
            documents = list(yaml.load_all(stream, Loader=CheckedLoader))
        if lines:
            status = 1
        else:
            lines.append("COMYAML.BAT version " + VERSION + ": YAML OK: " + str(source))
            lines.append("Documents checked: " + str(len(documents)))
            lines.append("Normalized YAML:")
            lines.extend(yaml.safe_dump_all(documents, allow_unicode=False, sort_keys=False).splitlines())
            status = 0
    except yaml.YAMLError as exc:
        mark = getattr(exc, "problem_mark", None) or getattr(exc, "context_mark", None)
        diagnostic(mark.line + 1 if mark else 1, mark.column + 1 if mark else 1,
                   getattr(exc, "problem", None) or str(exc))
        status = 1
except ImportError:
    lines.append("COMYAML configuration error: install PyYAML with the configured Python: python -m pip install PyYAML")
except Exception as exc:
    lines.append("COMYAML configuration error: " + str(exc))
lines = [line.encode("ascii", errors="replace").decode("ascii") for line in lines]
for line in lines:
    print(line, flush=True)
output = os.environ.get("COMYAML_OUTPUT", "")
if output:
    try:
        Path(output).write_text("\n".join(lines) + "\n", encoding="ascii")
    except OSError as exc:
        print("COMYAML cannot write output: " + str(exc))
        status = 2
sys.exit(status)
