@echo off
REM COMVISUALBASIC.BAT version 1.0.0.0.9
REM OpenAI GPT-6 / Codex - 2026-10-19
REM Visual Basic .NET console programs; .bas is accepted as a source filename.
REM This is not a Visual Basic 6 compiler or a VBScript runner.
REM No helper scripts/programs are generated. Only compiler output is parsed.
REM
REM Direct usage:
REM   COMVISUALBASIC.BAT "F:\BBC\TAAL\PROJ0200HELLOWORLD\helloworldvisualbasic.bas"
REM   COMVISUALBASIC.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstestvisualbasic.bas"
REM Optional second argument: full compiler executable path (direct usage only).
REM TSE six arguments: name, extension, full filename, drive, path, output log.
REM In this interface source=argument 3 and output log=argument 6.
REM
REM Test separately in these two consoles; batch executes natively in each:
REM   "G:\UTILS\JPSoft\TCMD\tcc.exe"
REM   "%SystemRoot%\System32\cmd.exe" /d
REM In EACH console run the two direct commands above.
REM Expected: Hello world and exit 0; errorstest has three errors and exit 1.
REM In TSE compile errorstestvisualbasic.bas and select each error to verify row/column.
REM --testformat prints three synthetic diagnostics without compiling/running.
REM   COMVISUALBASIC.BAT --testformat
REM This checks TSE's rule only, not compiler availability or compiler parsing.
REM To suppress the final pause: set "COMVISUALBASIC_PAUSE=0" before calling.
REM
REM ================= PART 1: USER SETTINGS ================================
setlocal DisableDelayedExpansion
if not defined COMVISUALBASIC_EXE set "COMVISUALBASIC_EXE=C:\Program Files\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\Roslyn\vbc.exe"
REM Framework directory supplies mscorlib.dll and Microsoft.VisualBasic.dll.
if not defined COMVISUALBASIC_SDK set "COMVISUALBASIC_SDK=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319"
if not defined COMVISUALBASIC_PAUSE set "COMVISUALBASIC_PAUSE=1"
if not defined COMVISUALBASIC_RUN set "COMVISUALBASIC_RUN=1"
REM Set RUN=0 for compile-only. Programs are built in a private TEMP directory.
REM ================= PART 2: FIXED IMPLEMENTATION =========================
set "result=1"
set "source=%~3"
if not defined source set "source=%~1"
if /i "%~1"=="--testformat" goto testformat
if not defined source goto usage
if not "%~3"=="" goto haveCompiler
if not "%~2"=="" set "COMVISUALBASIC_EXE=%~2"
:haveCompiler
for %%F in ("%source%") do set "source=%%~fF"
set "log=%~6"
if defined log goto haveLog
set "log=%TEMP%\COMVISUALBASIC_%RANDOM%_%RANDOM%.log"
:haveLog
REM TCC's directory test must use ISDIR, not IF EXIST filename\.
if defined _TCC goto checkTccDirectory
for %%F in ("%source%") do set "attributes=%%~aF"
if "%attributes:~0,1%"=="d" goto missing
 goto checkFile
:checkTccDirectory
if isdir "%source%" goto missing
:checkFile
if not exist "%source%" goto missing
if not exist "%COMVISUALBASIC_EXE%" goto missingCompiler
if not exist "%COMVISUALBASIC_SDK%\Microsoft.VisualBasic.dll" goto missingSdk
set "work=%TEMP%\COMVISUALBASIC_%RANDOM%_%RANDOM%"
if exist "%work%" goto workFailed
md "%work%"
if errorlevel 1 goto workFailed
call :build >"%log%" 2>&1
set "result=%errorlevel%"
type "%log%"
rd /s /q "%work%"
goto finish

:build
echo COMVISUALBASIC.BAT version 1.0.0.0.9
echo filename=%source%
echo Compiling "%source%"
"%COMVISUALBASIC_EXE%" /nologo /noconfig /target:exe /optionexplicit+ /optionstrict+ /preferreduilang:en-US /sdkpath:"%COMVISUALBASIC_SDK%" /reference:"%COMVISUALBASIC_SDK%\System.dll" /out:"%work%\program.exe" "%source%" >"%work%\compiler.log" 2>&1
set "compileResult=%errorlevel%"
set "pendingRow="
set "errors=0"
REM Delayed expansion is off when reading, preserving exclamation marks.
for /f "usebackq delims=" %%L in ("%work%\compiler.log") do (
  set "raw=%%L"
  call :parseLine
)
if defined pendingRow call :fallback
if not "%compileResult%"=="0" goto buildFailed
if not exist "%work%\program.exe" goto noExecutable
echo Compilation succeeded.
if "%COMVISUALBASIC_RUN%"=="0" exit /b 0
echo Running program:
"%work%\program.exe"
set "programResult=%errorlevel%"
echo Program exit code: %programResult%
exit /b %programResult%
:buildFailed
if "%errors%"=="0" echo TSE: %source%(1,1): error: Compiler failed; see raw diagnostics above. No source position supplied.
exit /b %compileResult%
:noExecutable
echo TSE: %source%(1,1): error: Compiler reported success but produced no executable.
exit /b 1

:parseLine
setlocal EnableDelayedExpansion
echo(!raw!
REM The prefix is the absolute source path passed to vbc, followed by (line).
set "tail=!raw:%source%=!"
if not "!tail:~0,1!"=="(" goto checkMarker
for /f "tokens=1 delims=()" %%N in ("!tail!") do set "row=%%N"
set "message=!tail:*) : =!"
if not "!message:~0,8!"=="error BC" goto ignoreLine
endlocal & set "newRow=%row%" & set "newMessage=%message%"
if defined pendingRow call :fallback
set "pendingRow=%newRow%"
set "pendingMessage=%newMessage%"
exit /b 0
:checkMarker
if not defined pendingRow goto ignoreLine
set "marker=!raw: =!"
if not "!marker:~0,1!"=="~" goto ignoreLine
set /a visual=0
:countSpaces
if not "!raw:~0,1!"==" " goto gotVisual
set /a visual+=1
set "raw=!raw:~1!"
goto countSpaces
:gotVisual
REM Map the compiler's four-spaces-per-tab display back to source characters.
set "original="
for /f "tokens=1,* delims=:" %%A in ('findstr /n "^" "%source%"') do if "%%A"=="!pendingRow!" set "original=%%B"
set /a column=1, displayed=0
:mapColumn
if !displayed! geq !visual! goto emit
if not defined original goto emit
set "character=!original:~0,1!"
set "original=!original:~1!"
set /a displayed+=1, column+=1
if "!character!"=="	" set /a displayed+=3
goto mapColumn
:emit
echo TSE: !source!(!pendingRow!,!column!): !pendingMessage!
endlocal & set "pendingRow=" & set /a errors+=1
exit /b 0
:ignoreLine
endlocal
exit /b 0
:fallback
setlocal EnableDelayedExpansion
echo TSE: !source!(!pendingRow!,1): !pendingMessage! [column unavailable; using 1]
endlocal & set "pendingRow=" & set /a errors+=1
exit /b 0

:testformat
set "source=F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstestvisualbasic.bas"
echo COMVISUALBASIC.BAT version 1.0.0.0.9
echo TSE: %source%(7,9): error BC30451: 'missingOne' is not declared.
echo TSE: %source%(8,9): error BC30451: 'missingTwo' is not declared.
echo TSE: %source%(9,9): error BC30451: 'missingThree' is not declared.
goto finish
:usage
echo Usage: COMVISUALBASIC.BAT "source.bas" ["vbc.exe"]
goto finish
:missing
echo ERROR: Source file not found or is a directory: "%source%"
goto finish
:missingCompiler
echo ERROR: Compiler not found: "%COMVISUALBASIC_EXE%"
goto finish
:missingSdk
echo ERROR: Framework runtime assemblies not found in "%COMVISUALBASIC_SDK%".
echo Set COMVISUALBASIC_SDK to the directory containing Microsoft.VisualBasic.dll.
goto finish
:workFailed
echo ERROR: Cannot create private build directory in TEMP.
:finish
echo Exit code: %result%
if not "%COMVISUALBASIC_PAUSE%"=="0" pause
endlocal & exit /b %result%
