@echo off
REM COMSLICKC.BAT version 1.0.0.0.9
REM Date: 2026-11-01
REM Compile a Slick-C source once; return diagnostics to TSE.
REM Compile to bytecode, then optionally execute a defmain batch macro.
REM Runtime output is written by the macro, then displayed with TYPE.
REM The runtime passes one argument: the absolute output-text filename.
REM Batch sources need defmain(); _command-only modules are not batch programs.
REM Runtime failures are shown in the console, not parsed as compile errors.
REM A fresh SlickEdit instance is used; the current editor is not closed.
REM No helper programs required. Save this BAT in a directory on PATH.
REM
REM TSE parameters: 1=name 2=extension 3=full source 4=drive 5=directory
REM                 6=diagnostic output 7=optional translator EXE
REM                 8=optional pause override: yes or no
REM                 9=optional runtime EXE
REM Set SLICKC_RUN=no below for compile-only operation.
REM vs.exe -p runs the compiled batch module and exits.
REM The Hello World test should display: Hello world from Slick-C!
REM A .run.txt file and .runtime.log remain beside the diagnostic output.
REM The compiled module is source.sli.ex; no temporary source copy is made.
REM Parameters 1, 2, 4 and 5 are retained for the standard TSE interface.
REM Quote all file arguments. The source must be saved before compiling.
REM
REM Tests: run the following CALL commands separately in native TCC and CMD.
REM Open TCC: "C:\Program Files\JPSoft\TCC\tcc.exe"
REM Open CMD: cmd.exe /d
REM Adjust the TCC installation path if necessary.
REM Successful compile: expect exit code 0 and no error entries in TSE.
REM call COMSLICKC.BAT "helloworldslickc" ".sli" "f:\bbc\taal\helloworldslickc.sli" "f:" "f:\bbc\taal\" "f:\bbc\taal\hello_slickc.err"
REM Error test: expect nonzero exit code and translator diagnostics.
REM call COMSLICKC.BAT "errorstestslickc" ".sli" "f:\bbc\taal\proj0200errorsmultiple\errorstestslickc.sli" "f:" "f:\bbc\taal\proj0200errorsmultiple\" "f:\bbc\taal\errors_slickc.err"
REM Immediately after each CALL: echo %errorlevel%
REM Optional overrides: append "G:\your installation\win\vst.exe" "no"
REM Repeat with source/output paths containing spaces, and a missing source.
REM In TSE: compile both supplied sources, then test error-list navigation.
REM The rule expects the native format: module-name LINE COLUMN: message.
REM If your translator emits another format, retain its output for adjustment.
REM
REM ======================================================================
REM PART 1 - USER SETTINGS: adapt these installation-dependent values only.
REM ======================================================================
setlocal
set "SLICKC_EXE=g:\wordproc\slickedit\slickeditv15.0.1\win\vst.exe"
set "SLICKC_PAUSE=yes"
set "SLICKC_RUNTIME=g:\wordproc\slickedit\slickeditv15.0.1\win\vs.exe"
set "SLICKC_RUN=yes"
REM ======================================================================
REM PART 2 - FIXED BODY: no user changes normally required below this line.
REM ======================================================================
if not defined _4VER setlocal DisableDelayedExpansion
if not "%~7"=="" set "SLICKC_EXE=%~7"
if not "%~8"=="" set "SLICKC_PAUSE=%~8"
if not "%~9"=="" set "SLICKC_RUNTIME=%~9"
set "SLICKC_RC=2"
set "SLICKC_SOURCE=%~3"
set "SLICKC_OUTPUT=%~6"
echo COMSLICKC.BAT version 1.0.0.0.9
if not defined SLICKC_SOURCE goto usage
for %%I in ("%SLICKC_SOURCE%") do set "SLICKC_SOURCE=%%~fI"
if not defined SLICKC_OUTPUT set "SLICKC_OUTPUT=%SLICKC_SOURCE%.err"
for %%I in ("%SLICKC_OUTPUT%") do set "SLICKC_OUTPUT=%%~fI"
if /i "%SLICKC_SOURCE%"=="%SLICKC_OUTPUT%" goto samefile
if /i "%SLICKC_EXE%"=="%SLICKC_OUTPUT%" goto samefile
REM Do not use IF EXIST "source\" in TCC: it can match regular files.
if defined _4VER goto tcc_source
if exist "%SLICKC_SOURCE%\NUL" goto directory
 goto source_exists
:tcc_source
if isdir "%SLICKC_SOURCE%" goto directory
:source_exists
if not exist "%SLICKC_SOURCE%" goto missing_source
if not exist "%SLICKC_EXE%" goto missing_compiler
>"%SLICKC_OUTPUT%" echo filename=%SLICKC_SOURCE%
if errorlevel 1 goto output_failed
set "SLICKC_MODULE=%SLICKC_SOURCE%.ex"
echo Compiling "%SLICKC_SOURCE%" ...
"%SLICKC_EXE%" "%SLICKC_SOURCE%" "%SLICKC_MODULE%" >>"%SLICKC_OUTPUT%" 2>&1
set "SLICKC_RC=%errorlevel%"
type "%SLICKC_OUTPUT%"
echo.
echo Translator exit code: %SLICKC_RC%
echo Diagnostic file: "%SLICKC_OUTPUT%"
if not "%SLICKC_RC%"=="0" goto finish
if /i not "%SLICKC_RUN%"=="yes" goto finish
if not exist "%SLICKC_MODULE%" goto missing_module
if not exist "%SLICKC_RUNTIME%" goto missing_runtime
set "SLICKC_RUNOUTPUT=%SLICKC_OUTPUT%.run.txt"
set "SLICKC_RUNLOG=%SLICKC_OUTPUT%.runtime.log"
REM Remove old text so a failed run cannot display an earlier greeting.
if exist "%SLICKC_RUNOUTPUT%" del /q "%SLICKC_RUNOUTPUT%"
if exist "%SLICKC_RUNOUTPUT%" goto stale_output
echo.
echo Running Slick-C batch program ...
REM In batch mode invoke directly and wait; no shell-specific START syntax.
"%SLICKC_RUNTIME%" +new -p "%SLICKC_MODULE%" "%SLICKC_RUNOUTPUT%" >"%SLICKC_RUNLOG%" 2>&1
set "SLICKC_RC=%errorlevel%"
type "%SLICKC_RUNLOG%"
echo SlickEdit process exit code: %SLICKC_RC%
if not exist "%SLICKC_RUNOUTPUT%" goto no_runoutput
echo.
echo ---------------- Program output ----------------
type "%SLICKC_RUNOUTPUT%"
echo.
echo ------------------------------------------------
echo Program output file: "%SLICKC_RUNOUTPUT%"
goto finish
:missing_module
echo ERROR: translator returned success but no compiled module was created.
set "SLICKC_RC=2"
goto finish
:missing_runtime
echo ERROR: SlickEdit runtime not found: "%SLICKC_RUNTIME%"
set "SLICKC_RC=2"
goto finish
:stale_output
echo ERROR: cannot remove previous program output: "%SLICKC_RUNOUTPUT%"
set "SLICKC_RC=2"
goto finish
:no_runoutput
echo ERROR: program did not create its output file.
echo The source must define defmain and write to the filename in arg(1).
echo Runtime log: "%SLICKC_RUNLOG%"
if "%SLICKC_RC%"=="0" set "SLICKC_RC=1"
goto finish
:missing_source
set "SLICKC_ERROR=source file not found: %SLICKC_SOURCE%"
goto report
:directory
set "SLICKC_ERROR=source is a directory: %SLICKC_SOURCE%"
goto report
:missing_compiler
set "SLICKC_ERROR=translator not found: %SLICKC_EXE%"
goto report
:report
echo ERROR: %SLICKC_ERROR%
>"%SLICKC_OUTPUT%" echo filename=%SLICKC_SOURCE%
if errorlevel 1 goto output_failed
>>"%SLICKC_OUTPUT%" echo ERROR: %SLICKC_ERROR%
goto finish
:output_failed
echo ERROR: cannot write diagnostic file: "%SLICKC_OUTPUT%"
goto finish
:samefile
echo ERROR: diagnostic output must differ from source and translator.
goto finish
:usage
echo Usage: CALL COMSLICKC.BAT "name" ".sli" "source" "drive" "directory" "output.err" ["vst.exe"] ["yes/no"] ["vs.exe"]
:finish
if /i "%SLICKC_PAUSE%"=="yes" pause
REM EXIT /B preserves the invoking TCC or CMD console.
exit /b %SLICKC_RC%
