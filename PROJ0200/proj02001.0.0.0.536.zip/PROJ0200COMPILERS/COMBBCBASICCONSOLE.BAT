@echo off
REM COMBBCBASICCONSOLE.BAT - version 1.0.0.10
REM Updated 2026-10-06 with OpenAI GPT-6 / Codex.
REM Requires tokenised basrun.bbc version 1.0.0.0.2 for physical line numbers.
REM Native diagnostics report lines; no source column is supplied.
REM Unhandled BASIC errors stop execution at the first error.
REM Run BBC BASIC console programs through the existing basrun.bbc launcher.
REM
REM PART 1 - USER SETTINGS AND TEST INSTRUCTIONS
REM Set paths below without surrounding quotes; commands quote them when used.
REM The launcher is a required external file; this batch does not replace it.
REM Output is captured and displayed after execution: intended for programs
REM without interactive keyboard input. The BASIC program runs only once.
REM
REM Short form: COMBBCBASICCONSOLE.BAT "full source filename.bas"
REM TSE form: COMBBCBASICCONSOLE.BAT "name" "extension" "full source" "drive" "directory" "diagnostics"
REM In TSE form, parameters 1, 2, 4 and 5 are retained for compatibility.
REM Parameter 3 selects the source; parameter 6 is TSE's &Output& error file.
REM TSE Compiler Command (the batch file must be on PATH):
REM COMBBCBASICCONSOLE.BAT "&Name&" "&Ext&" "&Fn&" "&Drive&" "&Path&" "&Output&"
REM TSE Output: Don't Clear Screen or Prompt After Shell.
REM The batch writes &Output& itself. Console displays go directly to CON
REM so they are not replayed into the same redirected TSE error file.
REM Captured output is also displayed in the console, followed by a pause.
REM Pause defaults to yes for BOTH direct and TSE calls; parameter 9 = no
REM disables it for unattended tests.
REM Both BASIC stdout and stderr are captured because errors may use stdout.
REM Batch validation errors are appended to the same error file.
REM The BBC BASIC exit code is appended to this same file, including zero.
REM Native diagnostics with a line number take precedence over the fallback.
REM Nonzero exit codes without such diagnostics use line 1 (location unavailable).
REM This is a general failure marker, not the actual offending source line.
REM TSE Error/Line rule:
REM ^{.*} at line {[0-9]#}.*$
REM Filename search empty, Filename Tag=-1; Line search empty, Line Tag=2.
REM Message search empty, Message Tag=0; Error Options=x.
REM filename= is retained for existing TSE filename rules. Native BASIC error
REM text is retained; line/column navigation depends on your compiler Rules.
REM With no parameter 6, a separate temporary log is used.
REM Optional 7 = BBC BASIC executable, 8 = basrun.bbc, 9 = pause yes/no.
REM To use overrides with short form, leave parameters 2 through 6 empty.
REM Empty overrides use the settings below. Extra arguments are not forwarded.
REM
REM WINDOWS TESTS - run from the folder containing this batch file.
REM Use a known BASIC sample that prints Hello and terminates.
REM 1. First command: run directly in your existing TCC console.
REM Second command: explicit CMD test from the same console.
REM COMBBCBASICCONSOLE.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.bas"
REM cmd.exe /d /c COMBBCBASICCONSOLE.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.bas"
REM 2. TSE form, explicit executable/launcher and no pause (create C:\TEMP first):
REM COMBBCBASICCONSOLE.BAT "ddd" "bas" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.bas" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\bbcbasic_tcc.err" "G:\LANGUAGE\COMPUTER\BASIC\BBCBASICCONSOLE\bbcbasic.exe" "F:\BBC\TAAL\basrun.bbc" "no"
REM cmd.exe /d /c COMBBCBASICCONSOLE.BAT "ddd" "bas" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.bas" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\bbcbasic_cmd.err" "G:\LANGUAGE\COMPUTER\BASIC\BBCBASICCONSOLE\bbcbasic.exe" "F:\BBC\TAAL\basrun.bbc" "no"
REM Expected: Hello displayed once; log begins filename=; exit code 0.
REM Repeat with source/launcher/executable paths containing spaces.
REM 3. Missing source: repeat test 2 with a nonexistent source; expect code 2
REM and filename= plus ERROR in the parameter-6 file, without stale output.
REM 4. Missing executable/launcher: change parameter 7/8; expect code 3/4.
REM 5. Unwritable log: change parameter 6; expect code 5 and no execution.
REM 6. BASIC runtime error: use a failing sample; inspect captured diagnostics.
REM The interpreter/launcher may report BASIC errors without a nonzero exit
REM code, so diagnostics must also be checked. Test under BOTH shells.
REM Exit codes: 1 usage, 2 source, 3 executable, 4 launcher, 5 log,
REM otherwise the BBC BASIC process exit code.

REM TCC entry uses CMD for consistent parameter, quoting and file checks.
REM No additional TCC process is started. CMD receives the original arguments.
if /i "%_CMDPROC%"=="TCC" goto tcc_entry
if /i "%_CMDPROC%"=="TCC/LE" goto tcc_entry
if /i "%_CMDPROC%"=="TCC-RT" goto tcc_entry
goto cmd_entry
:tcc_entry
"%SystemRoot%\System32\cmd.exe" /d /e:on /v:off /s /c ""%~f0" %$"
quit %?
:cmd_entry
setlocal EnableExtensions DisableDelayedExpansion
set BBC_EXE=G:\LANGUAGE\COMPUTER\BASIC\BBCBASICCONSOLE\bbcbasic.exe
set BBC_LAUNCHER=F:\BBC\TAAL\basrun.bbc
set BBC_OPTIONS=-quit
set BBC_PAUSE=yes
REM Optional second copy of the output; blank disables the old fixed copy.
set BBC_OUTPUT_COPY=
REM Example: set BBC_OUTPUT_COPY=C:\TEMP\dddoutput.txt

REM PART 2 - GENERAL LOGIC (NO LOCAL SETTINGS BELOW THIS LINE)
set BBC_RC=0
set BBC_LOG_READY=no
set BBC_MESSAGE=
set BBC_SOURCE=%~1
if not "%~3"=="" set BBC_SOURCE=%~3
set BBC_LOG=%~6
if not "%~7"=="" set BBC_EXE=%~7
if not "%~8"=="" set BBC_LAUNCHER=%~8
if not "%~9"=="" set BBC_PAUSE=%~9
if not "%BBC_LOG%"=="" goto log_ready
if "%TEMP%"=="" goto temp_missing
set BBC_LOG=%TEMP%\COMBBCBASICCONSOLE_%RANDOM%_%RANDOM%.err
:log_ready
REM Reject a log that would overwrite source, interpreter or launcher.
for %%F in ("%BBC_SOURCE%") do set BBC_SOURCE=%%~fF
for %%F in ("%BBC_EXE%") do set BBC_EXE=%%~fF
for %%F in ("%BBC_LAUNCHER%") do set BBC_LAUNCHER=%%~fF
for %%F in ("%BBC_LOG%") do set BBC_LOG=%%~fF
if /i "%BBC_LOG%"=="%BBC_SOURCE%" goto unsafe_log
if /i "%BBC_LOG%"=="%BBC_EXE%" goto unsafe_log
if /i "%BBC_LOG%"=="%BBC_LAUNCHER%" goto unsafe_log
>"%BBC_LOG%" echo filename=%BBC_SOURCE%
if errorlevel 1 goto log_failed
set BBC_LOG_READY=yes
if "%BBC_SOURCE%"=="" goto usage
if not exist "%BBC_SOURCE%" goto source_missing
if exist "%BBC_SOURCE%\*" goto source_missing
if not exist "%BBC_EXE%" goto exe_missing
if exist "%BBC_EXE%\*" goto exe_missing
if not exist "%BBC_LAUNCHER%" goto launcher_missing
if exist "%BBC_LAUNCHER%\*" goto launcher_missing
echo Running "%BBC_SOURCE%" >CON
"%BBC_EXE%" "%BBC_LAUNCHER%" "%BBC_SOURCE%" %BBC_OPTIONS% >>"%BBC_LOG%" 2>&1
set BBC_RC=%ERRORLEVEL%
if "%BBC_RC%"=="0" >>"%BBC_LOG%" echo BBC BASIC exit code: 0
if "%BBC_RC%"=="0" goto display_output
REM Match native diagnostics before adding any synthetic location.
"%SystemRoot%\System32\findstr.exe" /r /c:" at line [0-9][0-9]*$" "%BBC_LOG%" >nul
if not errorlevel 1 goto native_location
>>"%BBC_LOG%" echo BBC BASIC exit code: %BBC_RC% at line 1 (source location unavailable)
goto display_output
:native_location
>>"%BBC_LOG%" echo BBC BASIC exit code: %BBC_RC%
:display_output
echo. >CON
type "%BBC_LOG%" >CON
echo. >CON
echo Output saved to "%BBC_LOG%" >CON
if "%BBC_OUTPUT_COPY%"=="" goto finish
REM Avoid overwriting input files when optional copying is enabled.
for %%F in ("%BBC_OUTPUT_COPY%") do set BBC_OUTPUT_COPY=%%~fF
if /i "%BBC_OUTPUT_COPY%"=="%BBC_LOG%" goto finish
if /i "%BBC_OUTPUT_COPY%"=="%BBC_SOURCE%" goto copy_unsafe
if /i "%BBC_OUTPUT_COPY%"=="%BBC_EXE%" goto copy_unsafe
if /i "%BBC_OUTPUT_COPY%"=="%BBC_LAUNCHER%" goto copy_unsafe
copy /y "%BBC_LOG%" "%BBC_OUTPUT_COPY%" >nul
if errorlevel 1 echo WARNING: Output copy failed: "%BBC_OUTPUT_COPY%" >CON
goto finish
:copy_unsafe
echo WARNING: Output copy skipped because it would overwrite an input file. >CON
goto finish
:usage
set BBC_MESSAGE=ERROR: No BASIC source filename supplied.
echo Usage: COMBBCBASICCONSOLE.BAT "full source filename.bas" >CON
echo See the REM header for TSE parameters and executable overrides. >CON
set BBC_RC=1
goto finish
:source_missing
set BBC_MESSAGE=ERROR: BASIC source file not found: "%BBC_SOURCE%"
set BBC_RC=2
goto finish
:exe_missing
set BBC_MESSAGE=ERROR: BBC BASIC executable not found: "%BBC_EXE%"
set BBC_RC=3
goto finish
:launcher_missing
set BBC_MESSAGE=ERROR: BASIC launcher not found: "%BBC_LAUNCHER%"
set BBC_RC=4
goto finish
:temp_missing
set BBC_MESSAGE=ERROR: TEMP is unset. Supply an output filename in parameter 6.
set BBC_RC=5
goto finish
:unsafe_log
set BBC_MESSAGE=ERROR: Output log would overwrite an input file: "%BBC_LOG%"
set BBC_RC=5
goto finish
:log_failed
set BBC_MESSAGE=ERROR: Cannot write output log: "%BBC_LOG%"
echo Create its parent directory and check write permissions. >CON
set BBC_RC=5
:finish
if "%BBC_MESSAGE%"=="" goto pause_finish
echo %BBC_MESSAGE% >CON
if not "%BBC_LOG_READY%"=="yes" goto pause_finish
>>"%BBC_LOG%" echo %BBC_MESSAGE%
echo Diagnostics saved to "%BBC_LOG%" >CON
:pause_finish
if /i "%BBC_PAUSE%"=="yes" pause >CON <CON
endlocal & exit /b %BBC_RC%
