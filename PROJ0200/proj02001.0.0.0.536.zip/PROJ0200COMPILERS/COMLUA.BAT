@echo off
REM COMLUA.BAT version 1.0.0.7 - OpenAI GPT-6
REM PART 1 contains local settings; PART 2 contains the runner logic.
REM Lua stops at the first syntax or unprotected runtime error.
REM Lua has no error column: reported column 1 is a navigation fallback.
REM No separate helper script is needed; Lua formats its own diagnostics.
REM
REM Parameters: %%1 source file, or base name for the TSE interface.
REM %%2 extension; %%3 full source; %%4 drive; %%5 directory (reserved).
REM %%6 diagnostics file; %%7 optional full path to lua.exe.
REM Script arguments are not forwarded. Quote paths containing spaces.
REM
REM In an existing TCC console run directly (do not start another TCC):
REM   COMLUA.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.lua"
REM   COMLUA.BAT "errorstest" "lua" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.lua" "F" "BBC\TAAL\PROJ0200ERRORSMULTIPLE" "C:\TEMP\comlua_test.err"
REM For a CMD test from either console:
REM   cmd.exe /d /c COMLUA.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.lua"
REM Test both interfaces, paths with spaces, and a missing source file.
REM Expected sample result: line 7, column 1 (fallback), nonzero exit code.
REM Fix line 7, rerun: the next error is on line 10.
REM Fix both lines: Hello from Lua is printed.

REM =====================================================================
REM PART 1 - USER CONFIGURATION
REM =====================================================================
setlocal
set "LUA_EXE=g:\cygwin\bin\lua5.3.exe"
set "OUTPUT_COPY=c:\temp\dddoutput.txt"
set "PAUSE_AT_END=1"
REM Set OUTPUT_COPY empty to disable the optional diagnostic copy.
REM Set COMLUA_PAUSE=0 or COMLUA_COPY=0 externally for automated tests.
if "%COMLUA_PAUSE%"=="0" set "PAUSE_AT_END=0"
if "%COMLUA_COPY%"=="0" set "OUTPUT_COPY="

REM =====================================================================
REM PART 2 - STABLE LOGIC
REM =====================================================================
echo COMLUA.BAT version 1.0.0.7
set "RC=1"
set "SCRIPT=%~1"
if not "%~3"=="" set "SCRIPT=%~3"
if not "%~7"=="" set "LUA_EXE=%~7"
if "%SCRIPT%"=="" goto usage
for %%I in ("%SCRIPT%") do set "SCRIPT=%%~fI"
set "DIAG=%~6"
if not "%DIAG%"=="" goto haveDiagnostics
if "%TEMP%"=="" goto noTemp
set "DIAG=%TEMP%\COMLUA_%RANDOM%_%RANDOM%.err"
:haveDiagnostics
>"%DIAG%" echo filename=%SCRIPT%
if errorlevel 1 goto cannotWrite
REM TCC's ISDIR avoids the false file rejection from IF EXIST "file\".
if defined _TCC goto checkTccDirectory
REM CMD uses the NUL device test only in its own branch.
if exist "%SCRIPT%\NUL" goto missingSource
goto checkSource
:checkTccDirectory
if isdir "%SCRIPT%" goto missingSource
:checkSource
if not exist "%SCRIPT%" goto missingSource
if not exist "%LUA_EXE%" goto missingInterpreter
set "COMLUA_SOURCE=%SCRIPT%"
echo Running "%SCRIPT%"
REM Preserve full source path even when Lua abbreviates long source names.
REM loadfile checks syntax; pcall executes once and catches the first error.
"%LUA_EXE%" -e "local s=os.getenv('COMLUA_SOURCE'); local f,e=loadfile(s); local ok=false; if f then ok,e=pcall(f) end; if not ok then local t=tostring(e); local n,m=t:match(':(%%d+):%%s*(.*)'); io.stderr:write(s..'('..(n or '1')..',1): Error: '..(m or t)..' [column unavailable; using 1]\n'); os.exit(1) end; os.exit(0)" >>"%DIAG%" 2>&1
set "RC=%ERRORLEVEL%"
goto display
:missingSource
>>"%DIAG%" echo %SCRIPT%(1,1): Error: Source file missing or is a directory; location unavailable.
set "RC=2"
goto display
:missingInterpreter
>>"%DIAG%" echo %SCRIPT%(1,1): Error: Lua interpreter not found: "%LUA_EXE%"; location unavailable.
goto display
:display
type "%DIAG%"
echo.
echo Lua exit code: %RC%
echo Diagnostics saved to "%DIAG%"
if "%OUTPUT_COPY%"=="" goto finish
if /i "%DIAG%"=="%OUTPUT_COPY%" goto finish
copy /y "%DIAG%" "%OUTPUT_COPY%" >nul
if not errorlevel 1 goto finish
echo WARNING: Could not copy diagnostics to "%OUTPUT_COPY%".
goto finish
:usage
echo Usage: COMLUA.BAT "source.lua"
set "RC=2"
goto finish
:noTemp
echo ERROR: TEMP is empty; supply parameter 6.
goto finish
:cannotWrite
echo ERROR: Cannot write diagnostics: "%DIAG%"
:finish
if "%PAUSE_AT_END%"=="1" pause
endlocal & exit /b %RC%
