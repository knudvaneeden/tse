@echo off
setlocal EnableExtensions DisableDelayedExpansion
REM COMPERL.BAT - version 1.0.0.0.13
REM Updated: 2026-10-05 21:58:27 +02:00
REM Adapted with OpenAI GPT-6 / Codex.
REM Run a Perl script once, display its output, and save diagnostics.
REM Target shell: JPSoft TCC; Microsoft CMD is also supported.
REM TCC test: COMPERL.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.pl"
REM TCC TSE test: COMPERL.BAT "ddd" "pl" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.pl" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\comperl_test.err"
REM
REM TEST 1 - direct filename, automatic diagnostics file:
REM cmd.exe /d /c COMPERL.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.pl"
REM TEST 2 - direct filename and explicit diagnostics file:
REM cmd.exe /d /c COMPERL.BAT "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.pl" "C:\TEMP\comperl_test.err"
REM TEST 3 - TSE / PROJ0200 six-parameter format:
REM cmd.exe /d /c COMPERL.BAT "ddd" "pl" "F:\BBC\TAAL\PROJ0200\CTAGSEXAMPLES\ddd.pl" "F" "BBC\TAAL\PROJ0200\CTAGSEXAMPLES" "C:\TEMP\comperl_test.err"
REM
REM Direct format: %1 = script filename; %2 = optional diagnostics file.
REM TSE format: %1 = base name; %2 = extension; %3 = full script filename;
REM             %4 = drive; %5 = directory; %6 = diagnostics file.
REM In TSE format only %3 and %6 are used. No arguments are passed to Perl.
REM The interpreter EXE is configured below, not supplied as a BAT parameter.
REM Exit code: Perl's exit code, or 1 for setup errors.
REM Output is displayed after execution; interactive scripts are not intended.
REM
REM ======================================================================
REM PART 1 - USER SETTINGS: edit only this section for your local system.
REM ======================================================================
REM Full path to perl.exe, or perl.exe alone to search the Windows PATH.
set "PERL_EXE=G:\LANGUAGE\COMPUTER\PERL\STRAWBERRY\PERL\BIN\perl.exe"
REM Empty means use the Windows TEMP directory.
set "DIAGNOSTICS_DIR="
REM Optional additional output copy. Empty disables it.
REM Example: set "OUTPUT_COPY=C:\TEMP\dddoutput.txt"
set "OUTPUT_COPY="
REM Set to 0 to disable the final pause.
set "PAUSE_AT_END=1"

REM ======================================================================
REM PART 2 - COMMON LOGIC: normally no user changes are needed below.
REM ======================================================================
set "RUN_EXIT=1"
set "SOURCE_FILE="
set "DIAGNOSTICS_FILE="
set "WORK_DIR_PUSHED=0"
if "%~1"=="" goto Usage
if not "%~3"=="" goto TseArguments
set "SOURCE_FILE=%~f1"
if not "%~2"=="" set "DIAGNOSTICS_FILE=%~f2"
goto ArgumentsReady

:TseArguments
set "SOURCE_FILE=%~f3"
if not "%~6"=="" set "DIAGNOSTICS_FILE=%~f6"

:ArgumentsReady
if not exist "%SOURCE_FILE%" goto MissingSource
if not defined PERL_EXE goto MissingPerl
REM Test an explicit path directly; use WHERE only for a PATH lookup.
if exist "%PERL_EXE%" goto ResolvePerlPath
if not "%PERL_EXE:\=%"=="%PERL_EXE%" goto MissingPerl
if not "%PERL_EXE:/=%"=="%PERL_EXE%" goto MissingPerl
if not "%PERL_EXE::=%"=="%PERL_EXE%" goto MissingPerl
set "FOUND_PERL="
for /f "delims=" %%I in ('where "%PERL_EXE%" 2^>nul') do if not defined FOUND_PERL set "FOUND_PERL=%%I"
if not defined FOUND_PERL goto MissingPerl
set "PERL_EXE=%FOUND_PERL%"
goto PerlReady
:ResolvePerlPath
for %%I in ("%PERL_EXE%") do set "PERL_EXE=%%~fI"
:PerlReady
if defined DIAGNOSTICS_FILE goto DiagnosticsReady
if not defined DIAGNOSTICS_DIR set "DIAGNOSTICS_DIR=%TEMP%"
if not defined DIAGNOSTICS_DIR set "DIAGNOSTICS_DIR=%CD%"
for %%I in ("%DIAGNOSTICS_DIR%") do set "DIAGNOSTICS_DIR=%%~fI"
:ChooseDiagnostics
set "DIAGNOSTICS_FILE=%DIAGNOSTICS_DIR%\COMPERL_%RANDOM%_%RANDOM%.err"
if exist "%DIAGNOSTICS_FILE%" goto ChooseDiagnostics

:DiagnosticsReady
if /i "%SOURCE_FILE%"=="%DIAGNOSTICS_FILE%" goto OutputIsSource
if defined OUTPUT_COPY for %%I in ("%OUTPUT_COPY%") do set "OUTPUT_COPY=%%~fI"
if /i "%SOURCE_FILE%"=="%OUTPUT_COPY%" goto OutputIsSource
for %%I in ("%DIAGNOSTICS_FILE%") do set "DIAGNOSTICS_PARENT=%%~dpI"
if not exist "%DIAGNOSTICS_PARENT%" mkdir "%DIAGNOSTICS_PARENT%" >nul 2>&1
if not exist "%DIAGNOSTICS_PARENT%" goto DiagnosticsError
>"%DIAGNOSTICS_FILE%" echo filename=%SOURCE_FILE%
if errorlevel 1 goto DiagnosticsError
REM Run from the script directory so relative script data paths work.
for %%I in ("%SOURCE_FILE%") do set "SOURCE_DIR=%%~dpI"
pushd "%SOURCE_DIR%" >nul 2>&1
if errorlevel 1 goto DirectoryError
set "WORK_DIR_PUSHED=1"
echo Running "%SOURCE_FILE%"
echo.
"%PERL_EXE%" "%SOURCE_FILE%" >>"%DIAGNOSTICS_FILE%" 2>&1
set "RUN_EXIT=%ERRORLEVEL%"
popd
set "WORK_DIR_PUSHED=0"
REM Put the line number first so it is visible in the TSE error list.
REM Preserve the original diagnostic text for Filename and Line searches.
"%PERL_EXE%" -pe "s/^(.+ at .+ line ([0-9]+)[.,].*)$/line $2: $1/" "%DIAGNOSTICS_FILE%" >"%DIAGNOSTICS_FILE%.formatted" 2>nul
if errorlevel 1 goto FormatFailed
move /y "%DIAGNOSTICS_FILE%.formatted" "%DIAGNOSTICS_FILE%" >nul 2>&1
if errorlevel 1 goto FormatFailed
goto FormatReady
:FormatFailed
if exist "%DIAGNOSTICS_FILE%.formatted" del "%DIAGNOSTICS_FILE%.formatted" >nul 2>&1
echo Warning: could not prefix diagnostic line numbers; original output retained.
:FormatReady
type "%DIAGNOSTICS_FILE%"
echo.
echo Perl exit code: %RUN_EXIT%
echo Diagnostics saved to "%DIAGNOSTICS_FILE%"
if not defined OUTPUT_COPY goto Finish
if /i "%OUTPUT_COPY%"=="%DIAGNOSTICS_FILE%" goto Finish
copy /y "%DIAGNOSTICS_FILE%" "%OUTPUT_COPY%" >nul 2>&1
if errorlevel 1 echo Warning: could not copy output to "%OUTPUT_COPY%".
goto Finish

:Usage
echo Usage: COMPERL.BAT "script.pl" ["diagnostics.err"]
echo Or: COMPERL.BAT "name" "extension" "full script path" "drive" "directory" "diagnostics.err"
goto Finish
:MissingSource
echo ERROR: Perl script not found: "%SOURCE_FILE%"
goto Finish
:MissingPerl
echo ERROR: Perl interpreter not found: "%PERL_EXE%"
echo Edit PERL_EXE in PART 1, or configure the Windows PATH.
goto Finish
:OutputIsSource
echo ERROR: An output filename must not be the Perl script filename.
goto Finish
:DiagnosticsError
echo ERROR: Cannot create diagnostics file: "%DIAGNOSTICS_FILE%"
goto Finish
:DirectoryError
echo ERROR: Cannot enter the script directory: "%SOURCE_DIR%"
goto Finish
:Finish
if "%WORK_DIR_PUSHED%"=="1" popd
echo.
if "%PAUSE_AT_END%"=="1" pause
endlocal & exit /b %RUN_EXIT%
