@echo off
rem COMDATABASEPOSTGRESQL.BAT version 1.0.0.0.8
rem OpenAI ChatGPT GPT-6.1
rem Run a PostgreSQL SQL file once; save psql output for TSE.
rem TSE arguments: %1 name, %2 extension, %3 full input filename,
rem %4 drive, %5 path, %6 full output filename.
rem Example tests from a TCC or CMD console (adjust paths first):
rem   tcc.exe /c call COMDATABASEPOSTGRESQL.BAT "hello" ".sql" "C:\test\helloworldDATABASEPOSTGRESQL.sql" "C:" "\test\" "C:\test\postgresql.err"
rem   cmd.exe /c call COMDATABASEPOSTGRESQL.BAT "hello" ".sql" "C:\test\helloworldDATABASEPOSTGRESQL.sql" "C:" "\test\" "C:\test\postgresql.err"
rem Repeat with errorstestDATABASEPOSTGRESQL.sql to test multiple errors.
rem psql asks for a password unless another authentication method is used.
rem SQL scripts execute against the configured database and can change data.
rem
rem PART 1: USER SETTINGS
setlocal
set "PG_PSQL=G:\database\server\postgresql\bin\psql.exe"
set "PG_HOST=localhost"
set "PG_PORT=5432"
set "PG_USER=postgres"
set "PG_DATABASE=postgres"
rem Set to -W to force a password prompt, or leave empty for psql defaults.
set "PG_PROMPT="
rem Set to yes to keep the console open until a key is pressed.
set "PG_PAUSE=yes"
rem
rem PART 2: IMPLEMENTATION
rem No directory check using a trailing backslash: TCC can match a file.
if "%~3"=="" goto usage
if "%~6"=="" goto usage
if not exist "%~3" goto missing_source
if not exist "%PG_PSQL%" goto missing_psql
rem Make the input absolute so psql reports a full path for TSE.
rem Do not use ON_ERROR_STOP: process subsequent independent statements.
rem The client output is captured once; do not execute the SQL twice.
"%PG_PSQL%" -X -v ON_ERROR_STOP=off -h "%PG_HOST%" -p "%PG_PORT%" -U "%PG_USER%" -d "%PG_DATABASE%" %PG_PROMPT% -f "%~f3" > "%~6" 2>&1
set "PG_RESULT=%errorlevel%"
type "%~6"
if /i "%PG_PAUSE%"=="yes" pause
rem With ON_ERROR_STOP off, psql may return 0 even when SQL statements fail.
rem Inspect the output file for SQL errors; exit status covers client failures.
endlocal & exit /b %PG_RESULT%
:missing_source
> "%~6" echo ERROR: source file not found: %~3
echo ERROR: source file not found: %~3
if /i "%PG_PAUSE%"=="yes" pause
endlocal & exit /b 1
:missing_psql
> "%~6" echo ERROR: psql.exe not found: %PG_PSQL%
echo ERROR: psql.exe not found: %PG_PSQL%
if /i "%PG_PAUSE%"=="yes" pause
endlocal & exit /b 1
:usage
echo Usage: COMDATABASEPOSTGRESQL.BAT name ext "source.sql" drive path "output.err"
if /i "%PG_PAUSE%"=="yes" pause
endlocal & exit /b 1
