@echo off
REM COMAUTOHOTKEY.BAT version 1.0.0.0.10
REM Run AUTOHOTKEY program - AutoHotkey v2 only.
REM Maintained with OpenAI ChatGPT (GPT-6), 2026-10-16.
REM No helper programs or generated scripts are used.
REM
REM PART 1: USER SETTINGS - edit these installation-dependent values.
setlocal
set "AHK_EXE=G:\MACRORECORDER\AUTOHOTKEY\AUTOHOTKEY64.EXE"
set "AHK_MODE=run"
set "AHK_PAUSE=yes"
REM MODE: run executes the program; check uses /Validate without running it.
REM PAUSE: yes keeps the console visible; no is useful for automation.
REM
REM Direct call: COMAUTOHOTKEY.BAT "source.ahk" ["exe"] [run/check] [yes/no]
REM TSE call: name ext fullfilename drive path output [exe] [mode] [pause]
REM The full filename in parameter 3 is used in the six-parameter TSE call.
REM Parameters 4 and 5 are accepted for compatibility.
REM Parameter 6 receives the diagnostics file required by TSE.
REM
REM TESTS - run these from the directory containing this BAT:
REM CMD hello:
REM cmd.exe /d /k call COMAUTOHOTKEY.BAT "helloworld.ahk"
REM CMD syntax error:
REM cmd.exe /d /k call COMAUTOHOTKEY.BAT "errorstest.ahk" "G:\MACRORECORDER\AUTOHOTKEY\AUTOHOTKEY64.EXE" check no
REM Native TCC hello:
REM tcc.exe /k COMAUTOHOTKEY.BAT "helloworld.ahk"
REM Native TCC syntax error:
REM tcc.exe /k COMAUTOHOTKEY.BAT "errorstest.ahk" "G:\MACRORECORDER\AUTOHOTKEY\AUTOHOTKEY64.EXE" check no
REM Repeat with a source path containing spaces. Expected: no false missing-file error.
REM Hello: Hello world message box, then exit code 0 after closing it.
REM Error test: first syntax error with its filename and line; column unavailable.
REM Fix the first invalid assignment and repeat to expose the next error.
REM
REM PART 2: COMMON ENGINE - normally no user changes below this line.
set "AHK_RC=2"
set "AHK_OUTPUT="
set "AHK_SOURCE=%~1"
if "%~6"=="" goto direct
set "AHK_SOURCE=%~3"
set "AHK_OUTPUT=%~6"
REM Create the file even when validation below fails.
type NUL >"%AHK_OUTPUT%"
if not "%~7"=="" set "AHK_EXE=%~7"
if not "%~8"=="" set "AHK_MODE=%~8"
if not "%~9"=="" set "AHK_PAUSE=%~9"
goto configured
:direct
if not "%~2"=="" set "AHK_EXE=%~2"
if not "%~3"=="" set "AHK_MODE=%~3"
if not "%~4"=="" set "AHK_PAUSE=%~4"
:configured
echo COMAUTOHOTKEY version 1.0.0.0.10
if "%AHK_SOURCE%"=="" goto usage
if /i "%AHK_MODE%"=="run" goto modeok
if /i "%AHK_MODE%"=="check" goto modeok
echo ERROR: mode must be run or check.
goto finish
:modeok
if not exist "%AHK_SOURCE%" goto missing
REM TCC must use ISDIR, never IF EXIST "file\".
if "%@eval[1+1]"=="2" goto tccdir
if exist "%AHK_SOURCE%\NUL" goto missing
goto fileok
:tccdir
if isdir "%AHK_SOURCE%" goto missing
:fileok
if not exist "%AHK_EXE%" goto noexe
set "AHK_LOG=%TEMP%\comautohotkey-%RANDOM%-%RANDOM%.txt"
if /i "%AHK_MODE%"=="check" goto check
"%AHK_EXE%" /ErrorStdOut=CP0 "%AHK_SOURCE%" >"%AHK_LOG%" 2>&1
set "AHK_RC=%ERRORLEVEL%"
goto results
:check
"%AHK_EXE%" /ErrorStdOut=CP0 /Validate "%AHK_SOURCE%" >"%AHK_LOG%" 2>&1
set "AHK_RC=%ERRORLEVEL%"
:results
REM Preserve raw diagnostics: ECHO would parse the ==> marker in TCC.
type "%AHK_LOG%"
if defined AHK_OUTPUT copy /y "%AHK_LOG%" "%AHK_OUTPUT%" >NUL
echo AutoHotkey exit code: %AHK_RC%
echo Diagnostics: "%AHK_LOG%"
goto finish
:missing
echo ERROR: source file missing or a directory: "%AHK_SOURCE%"
goto finish
:noexe
echo ERROR: AutoHotkey v2 executable not found: "%AHK_EXE%"
echo Edit AHK_EXE in Part 1 or supply an executable override.
goto finish
:usage
echo Usage: COMAUTOHOTKEY.BAT "source.ahk" ["exe"] [run/check] [yes/no]
:finish
if /i "%AHK_PAUSE%"=="yes" pause
endlocal & exit /b %AHK_RC%
