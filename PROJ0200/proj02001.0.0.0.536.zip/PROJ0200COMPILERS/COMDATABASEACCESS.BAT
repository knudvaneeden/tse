@echo off
rem COMDATABASEACCESS.BAT version 1.0.0.0.8
rem Run Access SQL using the companion PowerShell helper and Access COM.
rem Arguments: %1 name, %2 extension, %3 SQL file, %4 drive, %5 path,
rem            %6 TSE output file. Arguments 1, 2, 4 and 5 are ignored.
rem Test in TCC (adjust paths):
rem tcc.exe /c call COMDATABASEACCESS.BAT x x "C:\test\helloworlddatabaseaccess.sql" x x "C:\test\access.err"
rem Test in CMD (adjust paths):
rem cmd.exe /c call COMDATABASEACCESS.BAT x x "C:\test\helloworlddatabaseaccess.sql" x x "C:\test\access.err"
rem Replace helloworlddatabaseaccess.sql with errorstestdatabaseaccess.sql
rem to test three independent errors and TSE jumping.
rem Keep comdatabaseaccess.ps1 beside this BAT file.
rem
rem PART 1: USER SETTINGS
setlocal
rem Access is started through COM registration, not by invoking this path.
rem This path documents your installation; COM must be correctly registered.
set "ACCESS_EXE=C:\program files (x86)\microsoft office\root\office16\msaccess.exe"
rem 32-bit PowerShell matches the installed 32-bit Access / DAO components.
set "ACCESS_POWERSHELL=%SystemRoot%\SysWOW64\WindowsPowerShell\v1.0\powershell.exe"
rem On 32-bit Windows, use the normal System32 location instead.
if not exist "%ACCESS_POWERSHELL%" set "ACCESS_POWERSHELL=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
rem Empty: create a temporary empty database and delete it after the run.
rem Or specify an EXISTING .accdb or .mdb. SQL can modify that database.
set "ACCESS_DATABASE="
rem Set to 0 to disable the console pause.
set "ACCESS_PAUSE=1"
rem
rem PART 2: IMPLEMENTATION
set "ACCESS_SOURCE=%~3"
set "ACCESS_OUTPUT=%~6"
set "ACCESS_HELPER=%~dp0comdatabaseaccess.ps1"
echo COMDATABASEACCESS.BAT version 1.0.0.0.8
if not defined ACCESS_SOURCE goto usage
if not defined ACCESS_OUTPUT goto usage
if /i "%~f3"=="%~f6" goto same_file
if not exist "%ACCESS_SOURCE%" goto no_source
if not "%_4ver%"=="" goto check_tcc
if exist "%ACCESS_SOURCE%\NUL" goto no_source
goto checked
:check_tcc
if isdir "%ACCESS_SOURCE%" goto no_source
:checked
if not exist "%ACCESS_POWERSHELL%" goto no_powershell
if not exist "%ACCESS_HELPER%" goto no_helper
rem Output is written only once. The helper checks source/output equivalence.
"%ACCESS_POWERSHELL%" -NoProfile -ExecutionPolicy Bypass -File "%ACCESS_HELPER%" -Source "%~f3" -OutputFile "%~f6" -Database "%ACCESS_DATABASE%"
set "ACCESS_RESULT=%ERRORLEVEL%"
if exist "%ACCESS_OUTPUT%" type "%ACCESS_OUTPUT%"
if "%ACCESS_PAUSE%"=="1" pause
endlocal & exit /b %ACCESS_RESULT%
:no_source
echo TSE: %ACCESS_SOURCE%:1:1: source file not found or is a directory
if defined ACCESS_OUTPUT >"%ACCESS_OUTPUT%" echo TSE: %ACCESS_SOURCE%:1:1: source file not found or is a directory
goto failure
:no_powershell
echo TSE: %ACCESS_SOURCE%:1:1: PowerShell not found: %ACCESS_POWERSHELL%
>"%ACCESS_OUTPUT%" echo TSE: %ACCESS_SOURCE%:1:1: PowerShell not found: %ACCESS_POWERSHELL%
goto failure
:no_helper
echo TSE: %ACCESS_SOURCE%:1:1: helper not found: %ACCESS_HELPER%
>"%ACCESS_OUTPUT%" echo TSE: %ACCESS_SOURCE%:1:1: helper not found: %ACCESS_HELPER%
goto failure
:same_file
echo ERROR: source and output must be different files.
goto failure
:usage
echo Usage: COMDATABASEACCESS.BAT name ext "source.sql" drive path "output.err"
:failure
if "%ACCESS_PAUSE%"=="1" pause
endlocal & exit /b 1
