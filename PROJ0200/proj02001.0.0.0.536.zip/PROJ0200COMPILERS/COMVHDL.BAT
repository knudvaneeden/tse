@echo off
REM COMVHDL version 1.0.0.0.8 - OpenAI GPT-6
REM Compile and run VHDL using standalone GHDL mcode.
REM No PowerShell, helper scripts, or nested TCC process are used.
REM
REM Direct test in an existing TCC console:
REM   COMVHDL.BAT "C:\TEMP\helloworld.vhd"
REM   COMVHDL.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.vhd"
REM CMD test from either console:
REM   cmd.exe /d /c COMVHDL.BAT "C:\TEMP\helloworld.vhd"
REM   cmd.exe /d /c COMVHDL.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.vhd"
REM Six-parameter TSE test in TCC or CMD:
REM   COMVHDL.BAT "errorstest" ".vhd" "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.vhd" "F:" "\BBC\TAAL\PROJ0200ERRORSMULTIPLE\" "C:\TEMP\vhdl.err"
REM Parameters: %%1=name, %%2=extension, %%3=source filename,
REM             %%4=drive, %%5=directory, %%6=diagnostics file.
REM A single parameter is the source filename. The compiler EXE is set below.
REM For running, the top entity must match the source filename without extension,
REM unless VHDL_TOP_ENTITY below is set explicitly.
REM Successful compilation creates work-obj08.cf in the source directory.
REM All four package files use version 1.0.0.0.8.

REM ================= PART 1: USER SETTINGS =================
setlocal
set "VHDL_EXE=G:\LANGUAGE\COMPUTER\VHDL\bin\ghdl.exe"
set "VHDL_STANDARD=08"
REM Set to 0 for compile-only; set to 1 for compile and run.
set "VHDL_RUN=1"
REM Leave empty to use the source filename as the top entity name.
set "VHDL_TOP_ENTITY="
REM Limit simulations so a repeating clock cannot run indefinitely.
set "VHDL_STOP_TIME=1us"
REM Set to 0 to omit the final console pause.
set "VHDL_PAUSE=1"

REM ================= PART 2: STABLE LOGIC =================
set "VHDL_VERSION=1.0.0.0.8"
set "VHDL_RESULT=1"
set "VHDL_PUSHED=0"
set "VHDL_SOURCE=%~1"
set "VHDL_ERRFILE=%TEMP%\comvhdl.err"
if not "%~3"=="" set "VHDL_SOURCE=%~3"
if not "%~6"=="" set "VHDL_ERRFILE=%~6"
for %%I in ("%VHDL_ERRFILE%") do set "VHDL_ERRFILE=%%~fI"
echo COMVHDL version %VHDL_VERSION%
if not "%_cmdproc%"=="" goto tcc_shell
echo Shell: CMD
goto arguments
:tcc_shell
echo Shell: TCC
:arguments
if "%VHDL_SOURCE%"=="" goto usage
if exist "%VHDL_SOURCE%" goto source_exists
REM Some TSE configurations supply a relative %%3; try drive/path/name/ext.
if "%~3"=="" goto missing_source
set "VHDL_SOURCE=%~4%~5%~1%~2"
if not exist "%VHDL_SOURCE%" goto missing_source
:source_exists
if not "%_cmdproc%"=="" goto tcc_directory_test
REM CMD: inspect attributes, avoiding IF EXIST "filename\".
for %%I in ("%VHDL_SOURCE%") do set "VHDL_ATTRIBUTES=%%~aI"
if /i "%VHDL_ATTRIBUTES:~0,1%"=="d" goto source_directory
goto valid_source
:tcc_directory_test
if isdir "%VHDL_SOURCE%" goto source_directory
:valid_source
for %%I in ("%VHDL_SOURCE%") do set "VHDL_SOURCE=%%~fI"
for %%I in ("%VHDL_SOURCE%") do set "VHDL_SOURCE_DIR=%%~dpI"
for %%I in ("%VHDL_SOURCE%") do set "VHDL_ENTITY=%%~nI"
if not "%VHDL_TOP_ENTITY%"=="" set "VHDL_ENTITY=%VHDL_TOP_ENTITY%"
if not exist "%VHDL_EXE%" goto missing_compiler
for %%I in ("%VHDL_EXE%") do set "VHDL_BIN=%%~dpI"
set "PATH=%VHDL_BIN%;%PATH%"
REM Verify the diagnostic file can be created before invoking GHDL.
type nul > "%VHDL_ERRFILE%"
if errorlevel 1 goto diagnostics_failed
pushd "%VHDL_SOURCE_DIR%"
if errorlevel 1 goto directory_failed
set "VHDL_PUSHED=1"
echo Compiling "%VHDL_SOURCE%"
"%VHDL_EXE%" -a --std=%VHDL_STANDARD% "%VHDL_SOURCE%" > "%VHDL_ERRFILE%" 2>&1
set "VHDL_RESULT=%ERRORLEVEL%"
type "%VHDL_ERRFILE%"
echo Compile exit code: %VHDL_RESULT%
if not "%VHDL_RESULT%"=="0" goto finish
if not "%VHDL_RUN%"=="1" goto finish
echo Running entity "%VHDL_ENTITY%"
"%VHDL_EXE%" -r --std=%VHDL_STANDARD% "%VHDL_ENTITY%" --stop-time=%VHDL_STOP_TIME% >> "%VHDL_ERRFILE%" 2>&1
set "VHDL_RESULT=%ERRORLEVEL%"
type "%VHDL_ERRFILE%"
echo Run exit code: %VHDL_RESULT%
goto finish
:usage
echo Usage: COMVHDL.BAT "full-path-to-source.vhd"
goto finish
:missing_source
echo ERROR: source file not found: "%VHDL_SOURCE%"
echo ERROR: source file not found: "%VHDL_SOURCE%" > "%VHDL_ERRFILE%"
goto finish
:source_directory
echo ERROR: source is a directory: "%VHDL_SOURCE%"
echo ERROR: source is a directory: "%VHDL_SOURCE%" > "%VHDL_ERRFILE%"
goto finish
:missing_compiler
echo ERROR: GHDL executable not found: "%VHDL_EXE%"
echo ERROR: GHDL executable not found: "%VHDL_EXE%" > "%VHDL_ERRFILE%"
goto finish
:diagnostics_failed
echo ERROR: cannot write diagnostics: "%VHDL_ERRFILE%"
goto finish
:directory_failed
echo ERROR: cannot enter source directory: "%VHDL_SOURCE_DIR%"
echo ERROR: cannot enter source directory: "%VHDL_SOURCE_DIR%" > "%VHDL_ERRFILE%"
:finish
if "%VHDL_PUSHED%"=="1" popd
echo Diagnostics: "%VHDL_ERRFILE%"
if "%VHDL_PAUSE%"=="1" pause
endlocal & exit /b %VHDL_RESULT%
