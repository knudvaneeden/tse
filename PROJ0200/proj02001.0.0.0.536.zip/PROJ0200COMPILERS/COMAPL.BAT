@echo off
REM COMAPL.BAT version 1.0.0.0.10 - GNU APL runner for TSE
REM Usage: COMAPL.BAT name ext "source.apl" drive path "output.err"
REM Or: COMAPL.BAT "source.apl" ["output.err"]
REM Optional executable override: set "COMAPL_EXE=G:\CYGWIN\bin\apl.exe"
REM Set COMAPL_PAUSE=0 for unattended tests; default is 1.
REM Test in native TCC (replace its installation path if necessary):
REM "G:\UTILS\JPSoft\TCMD\tcc.exe" /c F:\BBC\TAAL\COMAPL.BAT "F:\BBC\TAAL\PROJ0200HELLOWORLD\helloworldapl.apl" "C:\Temp\apl-tcc.err"
REM cmd.exe /d /c F:\BBC\TAAL\COMAPL.BAT "F:\BBC\TAAL\PROJ0200HELLOWORLD\helloworldapl.apl" "C:\Temp\apl-cmd.err"
REM Repeat both commands with PROJ0200ERRORSMULTIPLE\errorstestapl.apl.
REM Expect Hello World and exit 0, then three diagnostics and exit 1.
REM Supplied APL examples are 7-bit ASCII, suitable for TSE.
REM GNU APL accepts # comments and displays bare expressions automatically.
REM TCC runs APL and parses diagnostics natively. CMD has its own parser path.
REM No helper script or program is created; no shell handoff is used.
REM Unique top-level expressions map to source lines; ambiguous expressions
REM and function frames remain raw. Columns come from GNU APL caret markers.
REM ================= PART 1: USER SETTINGS =================
setlocal
if not defined COMAPL_EXE set "COMAPL_EXE=G:\CYGWIN\bin\apl.exe"
if not defined COMAPL_PAUSE set "COMAPL_PAUSE=1"
set "APL_OPTIONS=--noSV --noCIN --silent --noCONT --noColor --OFF"
REM ---------------- END USER SETTINGS ---------------------
REM ================= PART 2: FIXED LOGIC ===================
set "src=%~1"
set "out=%~2"
if not "%~3"=="" set "src=%~3"
if not "%~3"=="" set "out=%~6"
if not defined src goto usage
for %%F in ("%src%") do set "src=%%~fF"
if not defined out set "out=%src%.err"
for %%F in ("%out%") do set "out=%%~fF"
if /i "%src%"=="%out%" goto samefile
set "rc=1"
if not exist "%src%" goto missing
REM TCC's IF EXIST file\ is NOT a safe directory test.
if "%@eval[2+2]"=="4" goto tccdir
for %%F in ("%src%") do set "attrs=%%~aF"
if /i "%attrs:~0,1%"=="d" goto missing
goto checked
:tccdir
if isdir "%src%" goto missing
:checked
if not exist "%COMAPL_EXE%" goto noexe
REM Keep Cygwin DLLs reachable and avoid consuming console input at EOF.
for %%F in ("%COMAPL_EXE%") do set "PATH=%%~dpF;%PATH%"
set "raw=%out%.comapl-raw"
if exist "%raw%" goto collision
REM Use a real file as stdin rather than script mode's implicit -f -.
"%COMAPL_EXE%" %APL_OPTIONS% < "%src%" > "%raw%" 2>&1
set "rc=%errorlevel%"
copy /y "%raw%" "%out%" >nul
if errorlevel 1 goto writefailed
if "%@eval[2+2]"=="4" goto tccparse
goto cmdparse
:parsedone
type "%out%"
del /q "%raw%" >nul 2>&1
goto finish
:tccparse
REM All processing here uses native TCC file and string functions.
set th=%@fileopen["%raw%",r]
if %th% LT 0 goto parserfailed
set oh=%@fileopen["%out%",a]
if %oh% LT 0 goto tccclosefail
REM Keep nested expansion enabled for function arguments.
setdos /x-568
set state=0
:tccread
set record=%@fileread[%th%]
if "%record%"=="**EOF**" goto tccdone
if %state% EQ 1 goto tccexpr
if %state% EQ 2 goto tccpointer
if "%record%"=="" goto tccread
set withoutError=%@replace[ERROR,,%record%]
if "%withoutError%"=="%record%" goto tccread
set rc=1
set message=%record%
set state=1
goto tccread
:tccexpr
set expr=%@trim[%record%]
set state=2
goto tccread
:tccpointer
set state=0
set trimmed=%@ltrim[" ",%record%]
set first=%@left[1,%trimmed%]
if "%first%" NE "^" goto tccread
set plen=%@len[%record%]
set tlen=%@len[%trimmed%]
set col=%@eval[%plen%-%tlen%-5]
if %col% LT 1 set col=1
set sh=%@fileopen["%src%",r]
if %sh% LT 0 goto tccread
set row=0
set matches=0
:tccsource
set candidate=%@fileread[%sh%]
if "%candidate%"=="**EOF**" goto tccsourceend
set row=%@eval[%row%+1]
set clean=%@trim[%candidate%]
if "%clean%" NE "%expr%" goto tccsource
set matches=%@eval[%matches%+1]
set hitrow=%row%
set leftclean=%@ltrim[" ",%candidate%]
set clen=%@len[%candidate%]
set llen=%@len[%leftclean%]
set hitcol=%@eval[%col%+%clen%-%llen%]
goto tccsource
:tccsourceend
set discard=%@fileclose[%sh%]
if %matches% NE 1 goto tccread
set discard=%@filewrite[%oh%,TSE: %src%:%hitrow%:%hitcol%: %message%]
goto tccread
:tccdone
set discard=%@fileclose[%th%]
set discard=%@fileclose[%oh%]
setdos /x0
goto parsedone
:tccclosefail
set discard=%@fileclose[%th%]
:parserfailed
echo ERROR: Cannot open files for diagnostic parsing.
set rc=1
goto parsedone
:cmdparse
setlocal EnableDelayedExpansion
set "state=0"
set "errors=0"
for /f "usebackq delims=" %%L in ("%raw%") do (
 set "record=%%L"
 call :parse
)
if !errors! GTR 0 set "rc=1"
for %%R in (!rc!) do endlocal & set "rc=%%R"
goto parsedone
:parse
if "!state!"=="1" (
 for /f "tokens=*" %%E in ("!record!") do set "expr=%%E"
 set "state=2"
 exit /b
)
if "!state!"=="2" (
 set "state=0"
 set "col=1"
 set "pointer=!record!"
 set /a offset=0
 REM Find the first caret in the diagnostic pointer line.
 for /l %%C in (0,1,2047) do if "!pointer:~%%C,1!"=="^" if !offset! EQU 0 set /a offset=%%C+1
 if !offset! GTR 6 set /a col=offset-6
 set "matches=0"
 set "row=0"
 for /f "usebackq tokens=1,* delims=:" %%N in (`findstr /n /r ".*" "%src%"`) do (
  set "candidate=%%O"
  set "untrimmed=%%O"
  for /f "tokens=*" %%E in ("!candidate!") do set "candidate=%%E"
  if "!candidate!"=="!expr!" (
   set /a matches+=1
   set "row=%%N"
   set "indent=0"
   for /l %%I in (0,1,2047) do if "!untrimmed:~%%I,1!"==" " if !indent! EQU %%I set /a indent+=1
  )
 )
 if !matches! EQU 1 (
  set /a col+=indent
  >>"%out%" echo TSE: %src%:!row!:!col!: !message!
 )
 exit /b
)
if not "!record: ERROR=!"=="!record!" (
 set /a errors+=1
 set "message=!record!"
 set "state=1"
)
exit /b
:missing
>"%out%" echo TSE: %src%:1:1: ERROR: source file not found or is a directory.
type "%out%"
goto finish
:noexe
>"%out%" echo TSE: %src%:1:1: ERROR: APL executable not found: %COMAPL_EXE%
type "%out%"
goto finish
:collision
echo ERROR: Refusing to overwrite existing capture file "%raw%".
goto finish
:writefailed
echo ERROR: Cannot write "%out%". Raw output retained in "%raw%".
set "rc=1"
goto finish
:samefile
echo ERROR: Source and output paths must differ.
endlocal & exit /b 2
:usage
echo Usage: COMAPL.BAT "source.apl" ["output.err"]
endlocal & exit /b 2
:finish
echo COMAPL.BAT version 1.0.0.0.10 - Exit code: %rc%
if not "%COMAPL_PAUSE%"=="0" pause
endlocal & exit /b %rc%
