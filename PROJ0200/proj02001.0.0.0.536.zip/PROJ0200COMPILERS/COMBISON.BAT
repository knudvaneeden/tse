@echo off
REM COMBISON.BAT version 1.0.0.0.10 - OpenAI ChatGPT GPT-6
REM Run BISON program
REM No PowerShell, scripts, Flex, or diagnostic-conversion helpers required.
REM Bison generates C; Borland C++ 5.5 then builds it and the resulting program runs.
REM Requires Cygwin Bison and m4, plus Borland C++ 5.5.
REM The Hello world sample includes its lexer; no separate .l file is needed.
REM
REM Direct: COMBISON.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.y"
REM Direct: COMBISON.BAT "C:\TEMP\helloworld.y"
REM TSE: COMBISON.BAT "&name&" "&ext&" "&fn&" "&drive&" "&path&" "&output&"
REM Parameters: 1=source (or stem), 2=extension, 3=full source filename,
REM 4=drive, 5=directory, 6=TSE output file (BAT writes and displays diagnostics),
REM 7=optional Bison executable, 8=optional Borland bcc32 executable, 9=run or generate.
REM Overrides: COMBISON.BAT "C:\TEMP\helloworld.y" "" "" "" "" "" "G:\CYGWIN\bin\bison.exe" "G:\LANGUAGE\COMPUTER\CPP\EMBARCADERO\BORLAND\BCC55\bin\bcc32.exe" run
REM Generation only: same command with generate as parameter 9.
REM Native TCC test (enter in TCC):
REM   COMBISON.BAT "C:\TEMP\helloworld.y"
REM   COMBISON.BAT "F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.y"
REM CMD test (enter in CMD): use the same two commands.
REM To launch CMD explicitly from TCC:
REM   cmd.exe /d /c COMBISON.BAT "C:\TEMP\helloworld.y"
REM Expected: Hello world; exit 0. Error test: three errors; nonzero exit.
REM In TSE load the supplied rule, compile errorstest.y and test all jumps.
REM --testformat prints three synthetic locations without invoking Bison.
REM Generated .combison.c, .combison.obj and .combison.exe stay beside source.
REM The compiler is invoked directly; no TCC alias or source copy is needed.
REM Borland linker tools are found by adding its bin directory to PATH.
REM An existing output with that specific name is overwritten on success.
REM C compiler errors remain unmodified; this TSE rule targets Bison locations.

setlocal
REM ================= PART 1: USER SETTINGS =============================
set "BISON_EXE=G:\CYGWIN\bin\bison.exe"
set "CC_EXE=G:\LANGUAGE\COMPUTER\CPP\EMBARCADERO\BORLAND\BCC55\bin\bcc32.exe"
set "BISON_OPTIONS=--color=never -fno-caret -Wall"
set "CC_INCLUDE=G:\LANGUAGE\COMPUTER\CPP\EMBARCADERO\BORLAND\BCC55\include"
set "CC_LIBRARY=G:\LANGUAGE\COMPUTER\CPP\EMBARCADERO\BORLAND\BCC55\lib"
set "CC_OPTIONS=-w"
set "BUILD_MODE=run"
set "PAUSE_AFTER_RUN=yes"
REM Set PAUSE_AFTER_RUN=no to return immediately after a run.
REM Set BUILD_MODE=generate to use Bison without requiring Borland.
REM ================= PART 2: SHARED IMPLEMENTATION =====================
REM Capture the complete run before displaying it, including early failures.
REM Resolve the output filename before the worker changes directories.
set "OUTPUT_FILE=%~6"
if "%OUTPUT_FILE%"=="" goto consoleonly
for %%I in ("%OUTPUT_FILE%") do set "OUTPUT_FILE=%%~fI"
call :main %1 %2 %3 %4 %5 %6 %7 %8 %9 > "%OUTPUT_FILE%" 2>&1
set "FINAL_RESULT=%ERRORLEVEL%"
if not exist "%OUTPUT_FILE%" goto capturefailed
type "%OUTPUT_FILE%"
goto afterrun
:consoleonly
call :main %1 %2 %3 %4 %5 %6 %7 %8 %9
set "FINAL_RESULT=%ERRORLEVEL%"
goto afterrun
:capturefailed
echo ERROR: cannot create TSE output file: "%OUTPUT_FILE%"
set "FINAL_RESULT=2"
:afterrun
if /i "%PAUSE_AFTER_RUN%"=="yes" pause
endlocal & exit /b %FINAL_RESULT%

:main
set "COMBISON_VERSION=1.0.0.0.10"
echo COMBISON version %COMBISON_VERSION%
if "%~1"=="--testformat" goto testformat
if "%~1"=="" goto usage
if not "%~7"=="" set "BISON_EXE=%~7"
if not "%~8"=="" set "CC_EXE=%~8"
if not "%~9"=="" set "BUILD_MODE=%~9"
if /i "%BUILD_MODE%"=="run" goto modeok
if /i "%BUILD_MODE%"=="generate" goto modeok
echo ERROR: mode must be run or generate.
exit /b 2
:modeok
set "SOURCE=%~1"
if not "%~3"=="" set "SOURCE=%~3"
if exist "%SOURCE%" goto sourcefound
if not "%~2"=="" set "SOURCE=%~1%~2"
if not exist "%SOURCE%" goto missing
:sourcefound
REM Never test IF EXIST "filename\" under TCC: it can match a file.
if defined _TCC goto tccdir
for %%I in ("%SOURCE%") do set "SOURCE_ATTR=%%~aI"
if /i "%SOURCE_ATTR:~0,1%"=="d" goto directory
 goto dirchecked
:tccdir
if isdir "%SOURCE%" goto directory
:dirchecked
for %%I in ("%SOURCE%") do set "SOURCE=%%~fI"
for %%I in ("%SOURCE%") do set "SOURCE_DIR=%%~dpI"
for %%I in ("%SOURCE%") do set "SOURCE_NAME=%%~nxI"
for %%I in ("%SOURCE%") do set "SOURCE_STEM=%%~nI"
if not exist "%BISON_EXE%" goto nobison
for %%I in ("%BISON_EXE%") do set "BISON_BIN=%%~dpI"
set "PATH=%BISON_BIN%;%PATH%"
set "LC_ALL=C"
set "LANG=C"
set "TERM=dumb"
set "COLUMNS=4096"
pushd "%SOURCE_DIR%"
if errorlevel 1 goto pushfailed
echo filename=%SOURCE%
echo Generating parser for "%SOURCE%"
REM Pass only local filenames to Cygwin tools; avoid Windows drive parsing.
"%BISON_EXE%" %BISON_OPTIONS% -o "%SOURCE_STEM%.combison.c" "%SOURCE_NAME%" 2>&1
set "RESULT=%ERRORLEVEL%"
echo Bison exit code: %RESULT%
if not "%RESULT%"=="0" goto finish
if /i "%BUILD_MODE%"=="generate" goto finish
if not exist "%CC_EXE%" goto nocc
for %%I in ("%CC_EXE%") do set "CC_BIN=%%~dpI"
set "PATH=%CC_BIN%;%PATH%"
"%CC_EXE%" %CC_OPTIONS% -I"%CC_INCLUDE%" -L"%CC_LIBRARY%" -e"%SOURCE_STEM%.combison.exe" "%SOURCE_STEM%.combison.c" 2>&1
set "RESULT=%ERRORLEVEL%"
echo C compiler exit code: %RESULT%
if not "%RESULT%"=="0" goto finish
echo Running "%SOURCE_STEM%.combison.exe"
".\%SOURCE_STEM%.combison.exe"
set "RESULT=%ERRORLEVEL%"
echo Program exit code: %RESULT%
:finish
popd
exit /b %RESULT%
:nocc
echo ERROR: C compiler not found: "%CC_EXE%"
echo Check Borland CC_EXE, CC_INCLUDE and CC_LIBRARY, or use generate mode.
set "RESULT=2"
goto finish
:nobison
echo ERROR: Bison executable not found: "%BISON_EXE%"
exit /b 2
:missing
echo ERROR: source file not found: "%SOURCE%"
exit /b 2
:directory
echo ERROR: source is a directory: "%SOURCE%"
exit /b 2
:pushfailed
echo ERROR: cannot enter source directory: "%SOURCE_DIR%"
exit /b 2
:usage
echo Usage: COMBISON.BAT "full-source.y"
echo See REM instructions at the top for TSE and executable overrides.
exit /b 2
:testformat
echo filename=F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.y
echo errorstest.y:6.5-15: error: symbol 'missing_one' is used, but is not defined as a token and has no rules
echo errorstest.y:7.5-15: error: symbol 'missing_two' is used, but is not defined as a token and has no rules
echo errorstest.y:8.5-17: error: symbol 'missing_three' is used, but is not defined as a token and has no rules
exit /b 0
