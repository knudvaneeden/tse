/*
  Macro           CmdLineParameter
  Author          Carlo.Hogeveen@xs4all.nl
  Compatibility   TSE Pro 4.0 upwards.
  Version         v1.0 - 19 Dec 2019

  This extension lets macros receive parameters from the command line,
  without TSE trying to load them as files.

  Command line format:
    g32 [...] [-e<MyMacroName>] -p [<parameter>]... [-p- [...]]
  If executed this way, then TSE itself will ignore the parameters, and they
  will be stored as global buffer strings under the name
    "CmdLineParameter:<MyMacroName>:<n>"
  where <n> is a positive integer indicating the n-th parameter.

  More details further on.


  INSTALLATION

  Put this file in TSE's "mac" folder.
  Compile it there:
    Opening the file in TSE, and then apply the Macro, Compile menu.
  After compiling the macro add it to TSE's Macro AutoLoad List:
    Open the Macro AutoLoad List menu, press the <Insert> key,
    enter the macro's name "CmdLineParameter",
    and press the <Enter> key twice.
  Close TSE.


  DETAILED DESCRIPTION

  A macro can retrieve these kind of parameters with GetGlobalStr().
  For example, if the following command line was executed:
    g32 -eTest -p Hello World
  then TSE itself ignores the "-p" and everything after it, and the macro
  "Test.s" can retrieve the two parameters "Hello" and "World" with:
    string greeting  [255] = GetGlobalStr('CmdLineParameter:Test:1')
    string addressee [255] = GetGlobalStr('CmdLineParameter:Test:2')

  Anything between "-p" on its left side and "-p-" or the end of the command
  line on its right side, and separated by spaces, is considered a parameter.
  For example, this command line has three parameters and executes no macro:
    g32 -p Hello World -eTest

  A parameter may be double quoted, and must be double quoted if it contains a
  space. Parameters are stored without these double quotes.
  For example, this command line has only one parameter:
    g32 -eTest -p "Hello World"

  For compatibility with other TSE command line switches the first parameter
  may be attached to the "-p" without a space, and the opening quote may occur
  before the "-p".
  For example, these three command lines have the same result:
    g32 -eTest -p "Hello World"
    g32 -eTest -p"Hello World"
    g32 -eTest "-pHello World"

  In the unlikely but possible situation that you do not supply a macro to
  execute, or if you supply the parameters before the executable macro,
  then the parameter names will not contain a macro name, and be stored
  with the name "CmdLineParameter::<n>".
  For example, if either of these command lines was executed:
    g32 -p Hello World
    g32 -p Hello World -p- -eTest
  then the macro "Test.s" could retrieve these two parameters with:
    string greeting  [255] = GetGlobalStr('CmdLineParameter::1')
    string addressee [255] = GetGlobalStr('CmdLineParameter::2')

  Equally unlikely but possible: Any macro can read any command line parameters
  with GetGlobalStr() provided it knows or can guess their names.
  There is no way to list the stored parameter names.

  It is OK to supply a "-p" without parameters: It will just be ignored.


  INNER WORKINGS

  Technical note for macro programmers about the inner workings:
  Autoloaded macros are executed before command line macros
  and before TSE itself loads files from the command line.


  HISTORY

  v1.0 - 19 Dec 2019
    Initial release.
*/

proc WhenLoaded()
  string  cmd_macro_name [MAXSTRINGLEN] = ''
  integer DosCmdLine_is_changed         = FALSE
  integer i                             = 0
  string  my_macro_name  [MAXSTRINGLEN] = SplitPath(CurrMacroFilename(), _NAME_)
  string  new_DosCmdLine [MAXSTRINGLEN] = ''
  integer next_tokens_are_parameters    = FALSE
  integer next_token_is_macro_name      = FALSE
  string  old_DosCmdLine [MAXSTRINGLEN] = Query(DosCmdLine)
  string  parameter      [MAXSTRINGLEN] = ''
  integer parameter_index               = 0
  string  token          [MAXSTRINGLEN] = ''
  for i = 1 to NumFileTokens(old_DosCmdLine)
    token = GetFileToken(old_DosCmdLine, i)
    if Lower(token) == '-p-'
      next_tokens_are_parameters = FALSE
      DosCmdLine_is_changed      = TRUE
      cmd_macro_name             = ''
      parameter_index            = 0
    elseif next_token_is_macro_name
      cmd_macro_name           = token
      next_token_is_macro_name = FALSE
      new_DosCmdLine           = new_DosCmdLine + ' ' + QuotePath(token)
    elseif next_tokens_are_parameters
      parameter_index       = parameter_index + 1
      parameter             = token
      DosCmdLine_is_changed = TRUE
    elseif Lower(token[1:2]) == '-e'
      if Length(token) > 2
        cmd_macro_name = token[3:MAXSTRINGLEN]
      else
        next_token_is_macro_name = TRUE
      endif
      new_DosCmdLine = new_DosCmdLine + ' ' + QuotePath(token)
    elseif Lower(token[1:2]) == '-p'
      next_tokens_are_parameters = TRUE
      if Length(token) > 2
        parameter_index = parameter_index + 1
        parameter       = token[3:MAXSTRINGLEN]
      endif
      DosCmdLine_is_changed = TRUE
    else
      new_DosCmdLine = new_DosCmdLine + ' ' + QuotePath(token)
    endif
    if parameter <> ''
      SetGlobalStr(Format(my_macro_name, ':', cmd_macro_name, ':',
                          parameter_index),
                   parameter)
    endif
  endfor
  if DosCmdLine_is_changed
    Set(DosCmdLine, new_DosCmdLine)
  endif
  PurgeMacro(my_macro_name)
end WhenLoaded

