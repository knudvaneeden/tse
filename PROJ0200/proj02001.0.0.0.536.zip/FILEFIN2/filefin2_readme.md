# FILEFIN2 Win32 DLL port

**Version:** 1.0.0.0.50  
**Date:** 2026-11-14  
**Time:** 13:19 CET (UTC+01:00)  
**LLM:** OpenAI Codex  

## Version 1.0.0.0.50 — reliable persistent Ask history

- Retains the existing dedicated filename and directory histories.
- Explicitly promotes each accepted value immediately, so cancelling the later prompt does not lose the earlier accepted answer.
- Preserves all older history entries.
- This source package has not been compiled with the user's SAL compiler here.

## Version 1.0.0.0.49 - clean result-row rendering

- The result highlighting callback now follows GREPZIPTSE's run-based
  `PutStr()` rendering and finishes every displayed row with `ClrEol()`. Text
  from a previously longer result row can therefore no longer remain visible
  beside shorter header or result lines.
- Renamed the packaged SAL source from `FF.S` to lowercase `ff.s` and retained
  lowercase naming for the package and all other supplied files.

## Version 1.0.0.0.43 - result viewer, timing, and latest Ask values

- The filename and top-directory prompts now always present their newest
  dedicated-history values. INI values seed an empty history on first use.
- The result buffer now identifies the FILEFIN2 version, reports elapsed
  search time, lists navigation help, and initially selects the first found
  result instead of the query header.
- Results-only syntax highlighting colors the filename that was actually
  found, rather than the wildcard query.
- Right-click and **Ctrl+Alt+G** return to the latest result buffer.
- Full display refreshes no longer occur for every ordinary filesystem entry;
  archive handoffs and final result rendering still refresh immediately.


## Version 1.0.0.0.42 - renamed search defaults, logging, and return key

- Renamed `[Search]` to `[SearchDefaults]`.
- Renamed `topdirectory` to `topdirectories` and `searcharchive` to
  `searcharchives` throughout the INI reader, validation, documentation, and
  supplied configuration.
- Added validated `[Logging]` settings `CreateLog` and `LogDirectory`.
  Optional logs are named `filefin2_YYYYMMDDHHMMSS.log` and record the search
  parameters, every match, and the final match count.
- Added `<CtrlAlt G>` for returning to the latest FILEFIN2 results buffer.

## Version 1.0.0.0.41 - archive executable defaults

- Renamed the `[ArchiveTools]` parameters to `SevenZipExecutable` and
  `RarExecutable` in `filefin2.ini`, `ff.s`, the PowerShell archive helper,
  validation messages, and this documentation.
- Set their distributed defaults to `C:\Program Files\7-Zip\7z.exe` and
  `C:\Program Files\WinRAR\Rar.exe`.


## Version 1.0.0.0.40 - dedicated Ask histories

- The filename-mask prompt now uses the named history
  `FILEFIN2:filename`.
- The top-directory-list prompt now uses the separate named history
  `FILEFIN2:topdirectories`.
- If an INI prompt value is blank, the newest value from the corresponding
  dedicated history becomes the initial text. A nonempty INI value still has
  priority as the initial text.
- Escape and accepted empty input still stop the macro before the archive menu
  or search starts.


## Version 1.0.0.0.39 - DLL detach crash mitigation

- Removed `FindClose()` and `close_tree()` operations from `ff.dll`'s
  `DllEntryPoint` on DLL_PROCESS_DETACH. A user-reported crash at `ff.dll`
  offset `0x18CE` was disassembled and mapped to the initial read in this
  cleanup loop. The underlying `0xC0000006` in-page error remains unconfirmed.
- Removed `close_context()` cleanup from `zip.dll`'s `DllEntryPoint`,
  avoiding resource cleanup under the Windows loader lock.
- Normal cleanup paths, including `FF_TreeClose()` and `ZIP_Close()`, remain
  unchanged. DLL exports and TSE SAL calling interface are unchanged.
- IMPORTANT: Source-only release. The previously uploaded binary DLLs are **not**
  rebuilt by this archive. Run `build.bat` on your Windows Borland BCC 5.5.1
  environment, verify compiler success, and then replace the DLLs with TSE closed.
- To reproduce/diagnose any remaining `0xC0000006` in-page errors, preserve
  the matching Windows crash dump and inspect its exception information.

## Description

This package ports the 1994 FILEFIN2 macro to 32-bit TSE Pro 4.50 on Windows 11. The unsupported SAL `binary` declarations have been removed. Their DOS `.BIN` modules are replaced by two Win32 DLLs whose source can be compiled with Borland C++ command-line compiler 5.5.1.

- `ff.dll` replaces `FF.BIN` and uses the Win32 file-search API.
- `zip.dll` replaces the old `LOWLEVEL.BIN`-based ZIP reader. It reads ZIP and JAR central directories directly and delegates TAR, TGZ, RAR, 7z, and mixed nested archives to the included helper.
- Modern ZIP support includes data-descriptor archives, UTF-8 member names, and ZIP64 sizes and offsets.
- ZIP member masks are evaluated once per central-directory entry in `zip.dll`; the former SAL repeat-search loop and its duplicate output are removed.
- Directory traversal is recursive below the supplied starting directory and includes normal, read-only, hidden, and system directories while avoiding reparse-point loops.
- Complete depth-first directory traversal now runs inside `ff.dll`. Win32 search handles remain on an internal stack until every sibling branch has been visited; traversal no longer depends on recursive SAL locals or temporary-buffer queue positioning.
- The DLL sources use Win32 functions only and do not require unresolved Borland C runtime functions such as `strlen`, `memcpy`, `atol`, or `sprintf`.
- The reserved SAL names `FindFirst` and `FindNext` are replaced by `FNFindFirstI` and `FNFindNextI`.
- Separate DLL search contexts preserve recursive searches.
- The search input is split into two prompts: first the filename or wildcard mask, then the top directory list. Each prompt uses its own named TSE history: `FILEFIN2:filename` and `FILEFIN2:topdirectories`.
- Search defaults come from `filefin2.ini`. When `searcharchives` is nonempty, its first character is queued with `PushKey()` and acts as the menu accelerator, automatically choosing **Yes** or **No**.
- `ff.s` is standalone: its DLL declarations and ZIP helper are embedded directly, so compiling it does not open or retain include-file editor buffers.
- Double quotes are ignored in both inputs. For example, `FF.S` and `"FF.S"`, or `C:\TEMP` and `"C:\TEMP"`, produce the same search.
- Pressing **Ctrl+Alt+Shift+F** runs the FILEFIN2 search prompt directly while the compiled macro is loaded.
- Filename masks accept `*` or `.*` anywhere for zero or more characters and `?` anywhere for exactly one character. This applies identically to ordinary filenames and members of ZIP, JAR, TAR, TGZ, RAR, and 7z archives.
- Archive masks are matched against the final member filename, not its internal directory prefix. Thus `FF.S` can find `folder/FF.S`, while the complete internal path remains visible in the results.
- Result columns use a right-aligned ten-character size field and explicit two-space separators between size, date, time, and filename. Full-width values can no longer run into the following date.
- Archive searching supports `.zip`, `.jar`, `.tar`, `.tgz`, `.rar`, and `.7z`, including mixed nesting. Nested entries use a `::` separator, such as `inner.7z::source.tar::folder/FF.S  <-  outer.rar`.
- ZIP and JAR top-level members are read directly by `zip.dll`. TAR, TGZ, RAR, 7z, and nested archive members are read by `zip_nested.ps1` through Windows PowerShell. RAR and 7z decoding uses the external 7-Zip command-line program.
- Before scanning an archive, the message bar displays `Scanning archive:` followed by its path and immediately refreshes the TSE display.
- While `zip.dll` waits for the PowerShell helper, it services Windows paint and synchronous message traffic so TSE can repaint instead of appearing frozen or **Not Responding**.

## Files

| File | Purpose |
|---|---|
| `ff.s` | Updated main TSE SAL macro |
| `ff_dll.c` | Borland C source for `ff.dll` |
| `zip_dll.c` | Borland C source for `zip.dll`, including ZIP/JAR central-directory support and archive-helper integration |
| `zip_nested.ps1` | PowerShell helper for recursively reading ZIP, JAR, TAR, TGZ, RAR, and 7z members |
| `filefin2.ini` | Editable defaults for the two search prompts, archive-menu choice, and external archive-tool paths |
| `build.bat` | Builds both 32-bit DLLs |

## Build the DLLs

1. Open a Windows command prompt.
2. Make the Borland C++ 5.5.1 `Bin` directory available through `PATH`, or run `build.bat` from a command prompt in which `bcc32.exe` is already available.
3. Change to the extracted FILEFIN2 directory.
4. Run:

   ```bat
   build.bat
   ```

5. A successful build ends with:

   ```text
   Build completed: ff.dll and zip.dll
   ```

The batch file locates `bcc32.exe` in the current directory or on `PATH`,
derives the Borland installation directory from that executable, and supplies
the `Include` and `Lib` directories explicitly:

```bat
bcc32 -I"<bcc-root>\include" -L"<bcc-root>\lib" -tWD -O2 -u- -eff.dll ff_dll.c
bcc32 -I"<bcc-root>\include" -L"<bcc-root>\lib" -tWD -O2 -u- -ezip.dll zip_dll.c
```

`-tWD` creates a Win32 DLL. `-u-` disables Borland's leading underscore on exported C names so TSE can resolve the exact names declared in the SAL `dll` blocks. The exported functions use the Pascal/WinAPI calling convention required by 32-bit TSE DLL calls.

This explicit path handling avoids dependence on `bcc32.cfg`. If the compiler
cannot find `windows.h`, version 38 reports the exact expected header path and
stops before producing the cascade of secondary declaration errors.

## Compile the SAL macro

After both DLLs build successfully, compile the updated macro with the TSE SAL Compiler:

```bat
sc32 ff.s
```

No `.INC` files are required. Version 1.0.0.0.9 embeds the declarations directly in `ff.s`.

## Install and run

1. Put the compiled `FF.MAC` where TSE loads macros.
2. Keep `ff.dll`, `zip.dll`, `zip_nested.ps1`, and `filefin2.ini` together with the FILEFIN2 macro package in a directory from which Windows can load the DLLs.
3. Restart TSE after replacing either DLL, because Windows/TSE may retain a loaded DLL in memory.
4. Execute the `FF` macro, or press **Ctrl+Alt+Shift+F** while it is loaded. The macro creates and displays a dedicated results buffer. Press **Ctrl+Alt+G** to return to the latest FILEFIN2 results buffer after navigating elsewhere.
5. At the first prompt, enter the filename or wildcard mask only, such as `FF.S`, `*.S`, `e.*list`, `elist.?`, or `FILE?.TXT`.
6. At the second prompt, enter one top directory or a semicolon-separated list, such as `C:\TEMP` or `C:\TEMP;F:\WORDPROC\tse32_v45024\MACDOWNLO;G:\ARCHIVE`. Empty items between semicolons are ignored.
7. Choose whether member names inside ZIP, JAR, TAR, TGZ, RAR, and 7z files, including nested and mixed archives, should also be searched. With the distributed blank `searcharchives=` setting, the menu remains visible for this choice.

Both prompts retain their own dedicated TSE history. When the corresponding
INI value is blank, the newest value in that prompt's history is used as its
initial text. A nonempty INI value has priority as the initial text, while the
user's accepted prompt input remains final. Pressing Escape in either
`Ask()` prompt immediately returns from the macro without displaying the
archive menu, creating a results buffer, or starting a search. An accepted but
empty input also stops the operation.

The macro recursively appends matching filenames, sizes, dates, and times to its dedicated results buffer. Each supplied top directory and all of its ordinary subdirectories are searched in list order. When archive searching is enabled, supported archives found anywhere below every top directory are searched too.

The results header includes `Filename matching: DOS wildcards,
case-insensitive`. FILEFIN2 does not use TSE SAL regular expressions or TSE
search-option letters. Its `*`, `.*`, and `?` filename matching is
case-insensitive for both ordinary files and archive members.

The results header also records the effective archive-menu choice as either
`Search archive files: Yes` or `Search archive files: No`. This shows whether
the listed directory trees were searched only as ordinary files or also inside
supported archive files.

## Search defaults in `filefin2.ini`

The `[SearchDefaults]` section supplies the editable initial values displayed by the
two `Ask()` prompts and the archive menu:

```ini
[SearchDefaults]
filename=*foobar*
topdirectories=c:\temp\
searcharchives=
```

- `filename` may contain the supported `*`, `.*`, and `?` wildcards.
- `topdirectories` is the initial recursive-search directory or a semicolon-separated list of top directories. The complete value is limited to 255 characters by TSE's SAL string size.
- The distributed default is `searcharchives=` so no key is queued and the user
  can choose normally. Setting `searcharchives=yes` queues the `y` accelerator,
  while `searcharchives=no` queues `n`. TSE immediately activates the matching
  entry; no separate `<Enter>` is queued or required, and the menu might not be
  visibly displayed.

`ff.s` first establishes its built-in defaults. Only nonempty INI values
override those initial values. Blank keys let the two prompts use their own
latest dedicated-history values and preserve the archive-menu history. The user can still edit either
`Ask()` value or choose another menu entry, so interactive input is final.

FILEFIN2 validates every active line in `filefin2.ini`. It reports unknown
sections, unknown or empty parameter names, missing equals signs, duplicate
parameters, parameters in the wrong section, and invalid `searcharchives` or
`CreateLog` values in one consolidated warning. The obsolete names
`topdirectory`, `searcharchive`, and `opdirectory` are reported with suggestions
to use the new plural parameter names. Comments beginning with `;` are
ignored. Valid settings remain available after the warning is dismissed.

Accepted nonempty `searcharchives` values are `yes`, `y`, `no`, and `n`, without
regard to letter case. A blank value continues to show the archive menu and
lets the user choose normally.

## Optional logging

The distributed logging settings are:

```ini
[Logging]
; true: create a timestamped log (optional, disabled by default).
CreateLog=false
; Empty: create the log beside the running filefin2.mac file.
; Absolute paths are accepted. Relative paths resolve under the macro directory.
; If unwritable, falls back to macro directory, then CurrDir().
LogDirectory=
```

Set `CreateLog=true`, `yes`, `1`, or `on` to create a timestamped
`filefin2_YYYYMMDDHHMMSS.log`. The values `false`, `no`, `0`, `off`, or an
empty value disable logging. With an empty `LogDirectory`, the log is created
beside the running FILEFIN2 macro. An absolute directory is used directly; a
relative directory is resolved below the macro directory. If the requested
directory is unwritable, FILEFIN2 falls back to the macro directory and then
`CurrDir()`. A log contains the effective search parameters, every matching
result line, and the final match count.

## Wildcard examples

| Mask | Matches |
|---|---|
| `e.*list.s` | Names beginning with `e`, followed by any characters, and ending in `list.s`; for example `eList.s` |
| `elist.?` | `elist.` followed by exactly one character, such as `elist.s` |
| `*elist*` | Any name containing `elist` |
| `file?.txt` | Names such as `file1.txt` or `fileA.txt`, but not `file10.txt` |

## Troubleshooting

### TSE reports that a DLL or procedure cannot be found

- Confirm that both DLLs are reachable from the TSE process.
- Restart TSE after rebuilding the DLLs.
- Run `tdump -ee ff.dll` and `tdump -ee zip.dll` to inspect the export tables.
- Confirm that the exported names match the `dll` declarations near the top of `ff.s` exactly.
- Confirm that `-u-` is present in both `bcc32` commands.

### The SAL compiler still reports `Binary not supported`

Compile the updated standalone `ff.s`. It contains no `binary` declarations and needs no FILEFIN2 include files.

### The SAL compiler reports that `FindFirst` is reserved

You are compiling an older source. Version 1.0.0.0.9 is standalone and contains no `FindFirst` or `FindNext` SAL procedures.

### Archive searching fails

For ZIP and JAR files, the DLL searches the central directory, so compression method and data descriptors do not affect member-name listing. Classic ZIP and ZIP64 metadata are supported. Multi-disk/spanned archives are not supported. UTF-8 ZIP/JAR member names are converted to the active Windows ANSI code page because TSE 4.50 SAL strings are not Unicode.

TAR/TGZ and nested archive searching require `zip_nested.ps1` beside `zip.dll` and Windows PowerShell 5.1 or later. Standard TAR/USTAR names and GZip-compressed TAR archives are supported. Encrypted, corrupted, unsupported, or incorrectly named archive members are skipped.

RAR and 7z searching uses the optional paths in `filefin2.ini`, which must be
kept beside `ff.s` and `zip_nested.ps1`:

```ini
[ArchiveTools]
SevenZipExecutable=C:\Program Files\7-Zip\7z.exe
RarExecutable=C:\Program Files\WinRAR\Rar.exe
```

Quotes around a path are optional. A blank or invalid setting causes automatic
discovery. `7z.exe` handles both 7z and RAR files. When `7z.exe` is unavailable,
`rar.exe` can search RAR files, but not 7z files.

The helper searches automatically in this order when an INI setting is blank
or invalid:

1. Beside `zip_nested.ps1`.
2. On the Windows `PATH`.
3. In the standard 7-Zip or WinRAR installation directories.

For a portable installation, copy `7z.exe` and its required companion files, such as `7z.dll`, beside `zip_nested.ps1`. Password-protected archives are skipped when they cannot be opened non-interactively.

Recursion is limited to eight archive levels, 256 MiB per nested archive member, and 512 MiB cumulative expanded nested data per outer archive.

### Large file sizes show `2147483647`

TSE SAL integers are signed 32-bit values. Sizes above 2,147,483,647 bytes are clamped to that maximum value.

## Version history

| Version | Date | Changes |
|---|---|---|
| 1.0.0.0.49 | 2026-11-13 | Cleared stale display-row contents after result highlighting and standardized the packaged SAL source as lowercase `ff.s` |
| 1.0.0.0.43 | 2026-11-12 | Made dedicated Ask histories reopen on their newest accepted values, added version and elapsed-time result headers, selected and highlighted actual found filenames, added scoped right-click return behavior, and reduced unnecessary display refreshes |
| 1.0.0.0.42 | 2026-11-12 | Renamed `[Search]` to `[SearchDefaults]`, renamed `topdirectory` and `searcharchive` to their plural forms, added validated optional timestamped logging with directory fallbacks, and added `<CtrlAlt G>` to return to the latest results buffer |
| 1.0.0.0.41 | 2026-11-08 | Renamed the archive-tool INI parameters to `SevenZipExecutable` and `RarExecutable`, and set their defaults to the standard 7-Zip and WinRAR installation paths |
| 1.0.0.0.40 | 2026-11-08 | Replaced shared `_EDIT_HISTORY_` use with dedicated named histories for the filename-mask and top-directory prompts; blank INI values now recall the newest value from the corresponding history, while nonempty INI defaults retain priority |
| 1.0.0.0.39 | 2026-11-08 | Removed cleanup operations from both DLL entry points during process detach to mitigate the reported `ff.dll` loader-detach crash while preserving normal explicit cleanup paths |
| 1.0.0.0.38 | 2026-11-08 | Made `build.bat` locate `bcc32.exe` and pass the Borland `Include` and `Lib` directories explicitly; added clear diagnostics for a missing compiler, `windows.h`, or library directory |
| 1.0.0.0.37 | 2026-11-08 | Added `Search archive files: Yes` or `Search archive files: No` to the results header, reflecting the archive-menu choice actually used for the search; synchronized the version in every packaged source file |
| 1.0.0.0.36 | 2026-10-20 | The distributed archive was named version 36, but its internal folder and source-file versions remained at 35; superseded by synchronized version 37 |
| 1.0.0.0.35 | 2026-10-17 | Changed both `Ask()` prompts to explicit early-return checks so Escape, or an accepted empty value, stops the macro before any search begins |
| 1.0.0.0.34 | 2026-10-16 | Replaced the misleading `Search options: i` results line with `Filename matching: DOS wildcards, case-insensitive`, clarifying that FILEFIN2 does not use TSE SAL regular expressions |
| 1.0.0.0.33 | 2026-10-16 | Added `Search options: i` to the results header to record FILEFIN2's case-insensitive filename matching |
| 1.0.0.0.32 | 2026-10-16 | Added thorough `filefin2.ini` validation with consolidated line-numbered warnings for unknown sections or parameters, missing equals signs, empty names, duplicates, misplaced settings, invalid `searcharchive` values, and the common `opdirectory` typo |
| 1.0.0.0.31 | 2026-10-16 | Allowed the second `Ask()` prompt and `topdirectory=` INI value to contain one or more semicolon-separated top directories; each tree is searched recursively in list order |
| 1.0.0.0.30 | 2026-09-18 | Left the distributed `searcharchive=` value blank so the archive menu remains visible and user-controlled; documented that nonempty `yes` or `no` automatically activates the matching menu entry |
| 1.0.0.0.29 | 2026-09-18 | Moved `[Search]` INI reading entirely into `FF.S`; blank values now preserve the macro's original empty/history-driven prompts and unforced archive-menu history |
| 1.0.0.0.28 | 2026-09-18 | Added `[Search]` INI defaults for the filename mask, top directory, and archive-menu selection; the first character of `searcharchive` positions the menu through `PushKey()` |
| 1.0.0.0.27 | 2026-09-15 | Corrected PowerShell 5.1 parsing errors in the automatic 7-Zip and WinRAR installation-path detection code |
| 1.0.0.0.26 | 2026-09-15 | Added editable `filefin2.ini` settings for complete `7z.exe` and `rar.exe` paths, automatic-discovery fallback, and direct RAR searching through `rar.exe` when 7-Zip is unavailable |
| 1.0.0.0.25 | 2026-09-15 | Increased the filename or file-mask input capacity from 80 to 255 characters so long pasted names are not truncated |
| 1.0.0.0.0 | 2026-09-07 | Documentation of the original DOS `.BIN` package |
| 1.0.0.0.1 | 2026-09-07 | Replaced both `.BIN` interfaces with Borland C++ 5.5-compatible Win32 DLL sources and updated SAL code |
| 1.0.0.0.2 | 2026-09-07 | Removed Borland C runtime dependencies, added TSE 4.50/Windows 11 compatibility updates, and replaced the ZIP reader with central-directory, UTF-8, data-descriptor, and ZIP64 support |
| 1.0.0.0.3 | 2026-09-07 | Removed Borland C++ W8012 signed/unsigned comparison warnings in the ZIP64 extra-field parser |
| 1.0.0.0.4 | 2026-09-07 | Corrected full-path input parsing, added a dedicated visible results buffer and an explicit no-results message, and removed the obsolete conversion include |
| 1.0.0.0.5 | 2026-09-08 | Fixed repeated ZIP-member duplicates and made recursion cover all ordinary subdirectories while excluding reparse-point loops |
| 1.0.0.0.6 | 2026-09-08 | Replaced recursive SAL directory enumeration with an explicit queue so child searches cannot overwrite the parent search state |
| 1.0.0.0.7 | 2026-09-08 | Moved complete recursive traversal into `ff.dll` after the SAL queue still skipped sibling branches |
| 1.0.0.0.8 | 2026-09-08 | Added `_EDIT_HISTORY_` to the search prompt and made `FF.S` standalone so compiling it no longer loads or retains include-file buffers; the shared history was replaced by dedicated prompt histories in version 40 |
| 1.0.0.0.9 | 2026-09-08 | Fixed quoted and accidentally half-quoted search input by removing double quotes before splitting the starting directory and file mask |
| 1.0.0.0.10 | 2026-09-08 | Added the **Ctrl+Alt+Shift+F** key assignment for starting a search |
| 1.0.0.0.11 | 2026-09-08 | Documented and exposed `*` and `?` wildcard searching in the prompt, including `e.*list` and `elist.?` examples |
| 1.0.0.0.12 | 2026-09-08 | Made `.*` a wildcard alias for `*`, so a mask such as `e.*list.s` matches `eList.s` |
| 1.0.0.0.13 | 2026-09-08 | Fixed ZIP searches by matching the mask against each member's basename instead of its complete internal directory path |
| 1.0.0.0.14 | 2026-09-08 | Aligned result fields, added explicit separators so file size, date, time, and path never concatenate, and renamed the package documentation to `filefin2_readme.md` |
| 1.0.0.0.15 | 2026-09-08 | Added recursive filename searching inside ZIP files nested in other ZIP files, with `::` archive-chain display and safety limits |
| 1.0.0.0.16 | 2026-09-08 | Added an `INVALID_FILE_ATTRIBUTES` compatibility definition for the older Windows headers supplied with Borland C++ 5.5.1 |
| 1.0.0.0.17 | 2026-09-08 | Removed the Borland `_llmul` linker dependency by parsing the already-capped nested member size with bounded 32-bit arithmetic |
| 1.0.0.0.18 | 2026-09-13 | Split search input into two prompts: filename or mask first, then the top directory; cancelling either prompt stops cleanly; dedicated histories were added in version 40 |
| 1.0.0.0.19 | 2026-09-15 | Added recursive `.jar`, `.tar`, and `.tgz` searching alongside `.zip`, including mixed nested archive chains |
| 1.0.0.0.20 | 2026-09-15 | Made archive searching default to **Yes**, refreshed the current archive path before scanning, and kept TSE repainting while the PowerShell helper runs |
| 1.0.0.0.21 | 2026-09-15 | Corrected the archive-menu default by queuing `<CursorUp>` before `ZipSearch()`, so the visible initial choice is **Yes** |
| 1.0.0.0.22 | 2026-09-15 | Replaced the queued-key workaround with documented variable menu history: `history = archiveMenuItemI`, reset to entry 2 (**Yes**) before every menu call |
| 1.0.0.0.23 | 2026-09-15 | Restored the original plain `history` archive menu and removed all forced-default variables and queued keys because current TSE versions behave inconsistently with forced selection |
| 1.0.0.0.24 | 2026-09-15 | Added recursive `.rar` and `.7z` filename searching through `7z.exe`, including mixed nested archive chains and automatic 7-Zip executable discovery |


## Version 1.0.0.0.49 (2026-11-13)

Adds FILEFIN2TSE-style result statistics: ordinary and archive-member matches, ordinary files and archives examined, plus archive-member entries inspected. Results are also automatically copied to `filefin2_results_YYYYMMDDHHMMSS.txt` beside the compiled macro (or the current directory if unwritable). This snapshot uses the existing temporary results buffer and does not change search semantics or DLLs. Archive-member counts include ZIP_Open/ZIP_Next entries; deeper traversal internal to the archive DLL is not separately counted.


## Version 1.0.0.0.49 compiler correction

Restored `forward proc PROCGoToResults()` before the snapshot procedure; a misplaced `forward` declaration caused compilation errors 2211 and 2333. The 1.0.0.0.45 search and results changes are preserved.


## 1.0.0.0.49 compiler correction
Removed an unintended empty `proc PROCGoToResults()` before `keydef FILEFIN2ResultKeys`. The actual procedure later in `ff.s` remains intact. This resolves the syntax error reported at line 485 in version 46. The source has not been verified with `sc32` in this environment.


## Version 1.0.0.0.49 — consolidated logging

`[Logging] CreateLog=true` is the default. A timestamped `filefin2_*.log` includes INFO search parameters, MATCH lines for each ordinary and archive member, WARN when no results were found, and INFO SUMMARY counts and elapsed time. ERROR is a reserved log severity for fatal operations. The separate results `.txt` is written only if logging is disabled or could not start. Existing navigation and result highlighting are unchanged.


## Version 1.0.0.0.49 — strict matching of nested archive member filenames

- Corrected `ZIP_NameMatches` in `zip_dll.c` so that it matches only the final
  member's basename, after any nested-archive `::` delimiters and directory
  separators (`/` and `\`).
- For a search mask of `*grep*`, `grep3230.zip::dialog.mac` is **not** a match;
  `grep3230.zip::grep.s` **is** a match.
- The containing archive's name does not qualify nonmatching members as hits.
- Recursive enumeration, extraction and result navigation are unchanged.
- The C DLL `zip.dll` **must be rebuilt** using `build.bat` and deployed alongside
  the version 0.49 SAL macro. Merely recompiling `ff.s` cannot fix this bug.
- The reference run of FILEFIN2 v0.48 had 400 results; inspection of its
  exported list identified 23 definite nonmatching nested archive member names.
  The exact v0.49 result count requires runtime testing; do not assume equality
  with FILEFIN2TSE v0.9 until the remaining entries are compared.
