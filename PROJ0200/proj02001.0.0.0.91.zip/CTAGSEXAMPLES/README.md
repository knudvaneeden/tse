# PROJ0200 CTags example inventory

The user has verified F12 navigation for all previously listed languages here, including Emacs Lisp; Markdown is newly added and pending verification. These statuses describe example navigation tests. Add one file to a test project, regenerate CTags, put the cursor on the listed symbol at its use, and press F12. Some formats (HTML, Ant, Make, SQL) index a declaration or target rather than a function. The supplied Exuberant CTags 5.8 executable and regex configuration determine actual support. All examples are in `CTAGSEXAMPLES`. `ddd.s` and `ddd.si` test the two SAL extensions. Do not add both same-language variants to a project unless testing duplicate tags.

| Language | File | Symbol | Status |
|---|---|---|---|
| ActionScript | `CTAGSEXAMPLES/ddd.as` | `greet` | F12 verified |
| Ada | `CTAGSEXAMPLES/ddd.adb` | `Greet` | F12 verified |
| Ant | `CTAGSEXAMPLES/ddd.build.xml` | `AntGreeting` | F12 verified |
| Assembly | `CTAGSEXAMPLES/ddd.asm` | `greet` | F12 verified |
| ASP | `CTAGSEXAMPLES/ddd.asp` | `Greet` | F12 verified |
| AWK | `CTAGSEXAMPLES/ddd.awk` | `greet` | F12 verified |
| Basic | `CTAGSEXAMPLES/ddd.bas` | `Greet` | F12 verified |
| BETA | `CTAGSEXAMPLES/ddd.bet` | `greet` | F12 verified |
| C | `CTAGSEXAMPLES/ddd.c` | `draw_menu` | F12 verified |
| C++ | `CTAGSEXAMPLES/ddd.cpp` | `greet` | F12 verified |
| C# | `CTAGSEXAMPLES/ddd.cs` | `Greet` | F12 verified |
| Cobol | `CTAGSEXAMPLES/ddd.cob` | `GREET` | F12 verified |
| DosBatch | `CTAGSEXAMPLES/ddd.bat` | `greet` | F12 verified |
| Emacs Lisp | `CTAGSEXAMPLES/ddd.el` | `emacs-greet` | F12 verified |
| Eiffel | `CTAGSEXAMPLES/ddd.e` | `greet` | F12 verified |
| Erlang | `CTAGSEXAMPLES/ddd.erl` | `greet` | F12 verified |
| Flex (MXML) | `CTAGSEXAMPLES/ddd.mxml` | `greet` | F12 verified |
| Fortran | `CTAGSEXAMPLES/ddd.f90` | `greet` | F12 verified |
| HTML | `CTAGSEXAMPLES/ddd.html` | `HtmlGreeting` | F12 verified |
| Java | `CTAGSEXAMPLES/ddd.java` | `greet` | F12 verified |
| JavaScript | `CTAGSEXAMPLES/ddd.js` | `greet` | F12 verified |
| Lisp | `CTAGSEXAMPLES/ddd.lisp` | `greet` | F12 verified |
| Lua | `CTAGSEXAMPLES/ddd.lua` | `greet` | F12 verified |
| Make | `CTAGSEXAMPLES/ddd.mak` | `GREETING` | F12 verified |
| MatLab | `CTAGSEXAMPLES/ddd.m` | `greet` | F12 verified |
| OCaml | `CTAGSEXAMPLES/ddd.ml` | `greet` | F12 verified |
| Pascal | `CTAGSEXAMPLES/ddd.pas` | `Greet` | F12 verified |
| Perl | `CTAGSEXAMPLES/ddd.pl` | `greet` | F12 verified |
| PHP | `CTAGSEXAMPLES/ddd.php` | `greet` | F12 verified |
| Python | `CTAGSEXAMPLES/ddd.py` | `greet` | F12 verified |
| REXX | `CTAGSEXAMPLES/ddd.rx` | `greet` | F12 verified |
| Ruby | `CTAGSEXAMPLES/ddd.rb` | `greet` | F12 verified |
| Scheme | `CTAGSEXAMPLES/ddd.scm` | `greet` | F12 verified |
| Sh | `CTAGSEXAMPLES/ddd.sh` | `greet` | F12 verified |
| SLang | `CTAGSEXAMPLES/ddd.sl` | `greet` | F12 verified |
| SML | `CTAGSEXAMPLES/ddd.sml` | `greet` | F12 verified |
| SQL | `CTAGSEXAMPLES/ddd.sql` | `greeting` | F12 verified |
| Tcl | `CTAGSEXAMPLES/ddd.tcl` | `greet` | F12 verified |
| Tex | `CTAGSEXAMPLES/ddd.tex` | `TexGreeting` | F12 verified |
| Vera | `CTAGSEXAMPLES/ddd.vr` | `greet` | F12 verified |
| Verilog | `CTAGSEXAMPLES/ddd.v` | `greet` | F12 verified |
| VHDL | `CTAGSEXAMPLES/ddd.vhd` | `greet` | F12 verified |
| TSE SAL | `CTAGSEXAMPLES/ddd.si` | `Greet` | F12 verified |
| Rust | `CTAGSEXAMPLES/ddd.rs` | `greet` | F12 verified |
| TypeScript | `CTAGSEXAMPLES/ddd.ts` | `formatName` | F12 verified |
| Go | `CTAGSEXAMPLES/ddd.go` | `makeGreeting` | F12 verified |
| Dart | `CTAGSEXAMPLES/ddd.dart` | `greet` | F12 verified |
| Haskell | `CTAGSEXAMPLES/ddd.hs` | `greet` | F12 verified |
| Markdown | `CTAGSEXAMPLES/ddd.md` | `Greet` | F12 pending |
| Maple | `CTAGSEXAMPLES/ddd.mpl` | `greet` | F12 verified |
| R | `CTAGSEXAMPLES/ddd.r` | `greet` | F12 verified |
| Mathematica | `CTAGSEXAMPLES/ddd.wl` | `greet` | F12 verified |
| Swift | `CTAGSEXAMPLES/ddd.swift` | `greet` | F12 verified |
| SAS | `CTAGSEXAMPLES/ddd.sas` | `greet` | F12 verified |
| Kotlin | `CTAGSEXAMPLES/ddd.kt` | `greet` | F12 verified |
| Prolog | `CTAGSEXAMPLES/ddd.pro` | `greet` | F12 verified |
| PowerShell | `CTAGSEXAMPLES/ddd.ps1` | `Greet` | F12 verified |
| Scala | `CTAGSEXAMPLES/ddd.scala` | `greet` | F12 verified |
| ABAP | `CTAGSEXAMPLES/ddd.abap` | `greet` | F12 verified |
| VimScript | `CTAGSEXAMPLES/ddd.vim` | `Greet` | F12 verified |
| YACC | `CTAGSEXAMPLES/ddd.y` | `greet` | F12 verified |

BETA (`ddd.bet`): ordinary pattern tags are enabled by the package configuration. Test F12 on `greet` at line 6; expected definition is line 4. Windows test pending.

Ant: F12 on `AntGreeting` in the dependency at line 5 should jump to the target at line 2. Regenerate tags first; Windows test pending.
