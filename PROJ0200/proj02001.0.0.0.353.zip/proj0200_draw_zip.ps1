param([Parameter(Mandatory=$true)][string]$Request,
      [Parameter(Mandatory=$true)][string]$Status,
      [Parameter(Mandatory=$true)][string]$Log)
# PROJ0200 1.0.0.0.353 - OpenAI Codex (GPT-6)
# ZIP exact requested files only. Never execute source code or scan directories.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$encoding = [Text.Encoding]::Default
$logLines = New-Object 'System.Collections.Generic.List[string]'
$manifest = New-Object 'System.Collections.Generic.List[string]'
$seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$zip = $null
$tempZip = $null
$included = 0
$skipped = 0
try {
    $records = [IO.File]::ReadAllLines($Request, $encoding)
    if ($records.Length -lt 1 -or -not $records[0].StartsWith('Z')) { throw 'Missing ZIP destination.' }
    $destination = [IO.Path]::GetFullPath($records[0].Substring(1))
    $parent = [IO.Path]::GetDirectoryName($destination)
    if (-not (Test-Path -LiteralPath $parent -PathType Container)) { throw 'ZIP destination directory does not exist.' }
    $tempZip = Join-Path $parent ('proj0200_draw_' + [Guid]::NewGuid().ToString('N') + '.zip')
    $zip = [IO.Compression.ZipFile]::Open($tempZip, [IO.Compression.ZipArchiveMode]::Create)
    $manifest.Add('PROJ0200 Mermaid source attachment')
    $manifest.Add('Archive entry | Original filename | Source used')
    for ($i = 1; $i -lt $records.Length; $i++) {
        if (-not $records[$i].StartsWith('S')) { continue }
        $original = $records[$i].Substring(1)
        $source = $original
        $kind = 'disk contents'
        if ($i + 1 -lt $records.Length -and $records[$i + 1].StartsWith('B')) {
            $i++
            $source = $records[$i].Substring(1)
            $kind = 'editor snapshot'
        }
        $snapshotError = ''
        if ($i + 1 -lt $records.Length -and $records[$i + 1].StartsWith('X')) {
            $i++
            $snapshotError = $records[$i].Substring(1)
        }
        if (-not $seen.Add($original)) { continue }
        try {
            if ($snapshotError) { throw $snapshotError }
            if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw 'Source file unavailable.' }
            if ($original -ieq $destination) { throw 'ZIP destination is a source file.' }
            $entryName = $original.Replace('\', '/').TrimStart('/')
            $entryName = $entryName.Replace(':', '')
            if ($original.StartsWith('\\')) { $entryName = 'UNC/' + $entryName }
            if (($entryName.Split('/') | Where-Object { $_ -eq '..' }).Count) { throw 'Unsafe archive entry path.' }
            $entryName = 'files/' + $entryName
            [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $source, $entryName, [IO.Compression.CompressionLevel]::Optimal) | Out-Null
            $manifest.Add($entryName + ' | ' + $original + ' | ' + $kind)
            $logLines.Add('INCLUDED: ' + $original + ' [' + $kind + ']')
            $included++
        } catch {
            $skipped++
            $manifest.Add('UNAVAILABLE | ' + $original + ' | ' + $_.Exception.Message)
            $logLines.Add('SKIPPED: ' + $original + ': ' + $_.Exception.Message)
        }
    }
    if ($included -eq 0) { throw 'No readable files were included; existing ZIP was retained.' }
    $entry = $zip.CreateEntry('PROJ0200_FILES.txt')
    $writer = New-Object IO.StreamWriter($entry.Open(), $encoding)
    try { foreach ($line in $manifest) { $writer.WriteLine($line) } } finally { $writer.Dispose() }
    $zip.Dispose(); $zip = $null
    Move-Item -LiteralPath $tempZip -Destination $destination -Force
    $tempZip = $null
    [IO.File]::WriteAllText($Status, ('OK: ' + $included + ' files included; ' + $skipped + ' unavailable files skipped.'), $encoding)
    $logLines.Add('ZIP: ' + $destination)
} catch {
    $message = 'ERROR: ' + $_.Exception.Message
    [IO.File]::WriteAllText($Status, $message, $encoding)
    $logLines.Add($message)
    exit 1
} finally {
    if ($zip) { $zip.Dispose() }
    if ($tempZip -and (Test-Path -LiteralPath $tempZip)) { Remove-Item -LiteralPath $tempZip -Force -ErrorAction SilentlyContinue }
    [IO.File]::WriteAllLines($Log, $logLines, $encoding)
}
