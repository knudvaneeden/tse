#include ["projdialogs.si"]
#include ["projhistory.si"]
// PROJ0200 1.0.0.0.385 - OpenAI Codex (GPT-6)
// Front end for the six supported SYNCFG2 KNUD parameter types.
proc PROJ_ConvertCurrentSyntax(integer reverseI)
    integer inputI = GetBufferId()
    integer outputI
    string commandS[20] = "texttobinary"
    string extensionS[5] = ".syn"
    string outputS[255] = SplitPath(CurrFilename(), _DRIVE_|_PATH_|_NAME_)
    string workerS[255] = SplitPath(CurrMacroFilename(), _DRIVE_|_PATH_) + "syncfg2.mac"
    if reverseI
        commandS = "binarytotext"
        extensionS = ".txt"
    endif
    if not Length(outputS)
        outputS = CurrDir() + "syntax-converted"
    endif
    outputS = outputS + extensionS
    if not PROJ_HistoryAskFilename("Output file (input is the current loaded buffer):", outputS,
        _FULL_PATH_, "PROJ0200:syncfg:" + commandS + ":output")
        return()
    endif
    if not Length(Trim(outputS))
        return()
    endif
    outputI = GetBufferId(outputS)
    if outputI == inputI
        FNProjectWarning("Output must differ from the current input file.")
        return()
    endif
    if outputI
        if FNProjectDialog("PROJ0200", "Replace the open output buffer contents: " + outputS + "?", _YES_NO_) <> 1
            return()
        endif
    endif
    if Length(QuotePath(workerS)) + Length(commandS) + 25 > 255
        FNProjectWarning("Conversion command exceeds 255 characters. Use a shorter package path.")
        return()
    endif
    if not CreateBuffer(outputS, _NORMAL_, outputI)
        FNProjectWarning("Cannot create the output buffer.")
        return()
    endif
    GotoBufferId(inputI)
    if not ExecMacro(QuotePath(workerS) + " " + commandS + " " + Str(inputI) + " " + Str(outputI))
        FNProjectWarning("Cannot run syncfg2.mac. Rebuild the complete package.")
    endif
end

proc PROJ_ConvertSyntax(integer modeI)
    string commandS[32]
    string inputS[255] = ""
    string outputS[255] = ""
    string extensionS[5] = ".syn"
    string workerS[255] = SplitPath(CurrMacroFilename(), _DRIVE_|_PATH_) + "syncfg2.mac"
    string argumentsS[255]
    string historyS[80] = "PROJ0200:syncfg:" + Str(modeI)
    integer lengthI
    case modeI
        when 1 commandS = "filetexttobinary"
        when 2 commandS = "filebinarytotext"
        when 3 commandS = "directorytexttobinary"
        when 4 commandS = "directorybinarytotext"
    endcase
    if modeI == 2 or modeI == 4
        extensionS = ".txt"
    endif
    if modeI <= 2
        if modeI == 1
            inputS = "*.txt"
        else
            inputS = "*.syn"
        endif
        if not PROJ_HistoryAskFilename("Input syntax highlight file:", inputS,
            _MUST_EXIST_|_FULL_PATH_, historyS + ":input")
            return()
        endif
        if not Length(Trim(inputS))
            return()
        endif
        outputS = SplitPath(inputS, _DRIVE_|_PATH_|_NAME_) + extensionS
        if not PROJ_HistoryAskFilename("Output syntax highlight file:", outputS,
            _FULL_PATH_, historyS + ":output")
            return()
        endif
    else
        inputS = CurrDir()
        if not PROJ_HistoryAsk("Input directory (existing):", inputS, historyS + ":input")
            return()
        endif
        if not Length(Trim(inputS))
            return()
        endif
        outputS = inputS
        if not PROJ_HistoryAsk("Output directory (existing):", outputS, historyS + ":output")
            return()
        endif
    endif
    inputS = Trim(inputS)
    outputS = Trim(outputS)
    if not Length(inputS) or not Length(outputS)
        return()
    endif
    if Pos(Chr(34), inputS) or Pos(Chr(34), outputS)
        FNProjectWarning("Enter paths without surrounding quotation marks.")
        return()
    endif
    // Quote both paths, including simple paths, and reject SAL truncation.
    lengthI = Length(QuotePath(workerS)) + Length(commandS) +
        Length(inputS) + Length(outputS) + 7
    if lengthI > 255
        FNProjectWarning("Combined conversion command exceeds 255 characters. Use shorter paths.")
        return()
    endif
    argumentsS = commandS + " " + Chr(34) + inputS + Chr(34) +
        " " + Chr(34) + outputS + Chr(34)
    if not ExecMacro(QuotePath(workerS) + " " + argumentsS)
        FNProjectWarning("Cannot run syncfg2.mac. Rebuild the complete package.")
    endif
end
menu PROJ_SyntaxConversionMenu()
    title = "Convert syntax highlighting"
    "&1: filetexttobinary - .txt to .syn", PROJ_ConvertSyntax(1), CloseAllBefore
    "&2: filebinarytotext - .syn to .txt", PROJ_ConvertSyntax(2), CloseAllBefore
    "",, Divide
    "&3: directorytexttobinary - .txt to .syn", PROJ_ConvertSyntax(3), CloseAllBefore
    "&4: directorybinarytotext - .syn to .txt", PROJ_ConvertSyntax(4), CloseAllBefore
    "",, Divide
    "&5: texttobinary - current loaded file", PROJ_ConvertCurrentSyntax(FALSE), CloseAllBefore
    "&6: binarytotext - current loaded file", PROJ_ConvertCurrentSyntax(TRUE), CloseAllBefore
end
proc Main()
    integer oldI = Set(UseCommonDialogs, FNProjectWindowsDialogs())
    PROJ_SyntaxConversionMenu()
    Set(UseCommonDialogs, oldI)
end
