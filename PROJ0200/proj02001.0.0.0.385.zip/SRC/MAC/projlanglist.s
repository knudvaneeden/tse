// PROJ0200 1.0.0.0.385 - OpenAI Codex (GPT-6)
// Keep the scrollable list outside the main macro size limit.
#include ["languagesmap.si"]
string proc PROJ_LoadedLanguages()
    integer oldBuffer = GetBufferId()
    integer count = NumFiles()
    string language[255]
    string seen[255] = "|"
    string summary[255] = ""

    if count > 0
        PushPosition()
        if BufferType() <> _NORMAL_
            NextFile(_DONT_LOAD_)
        endif
        do count times
            if BufferType() == _NORMAL_ and (Query(BufferFlags) & _LOADED_)
                language = PROJ_FileLanguage(CurrFilename())
                if Length(language) and not Pos("|" + language + "|", seen)
                    if Length(summary) + Length(language) + 3 > 250 or
                       Length(seen) + Length(language) + 1 > 255
                        summary = summary + " / ..."
                        break
                    endif
                    if Length(summary)
                        summary = summary + " / "
                    endif
                    summary = summary + language
                    seen = seen + language + "|"
                endif
            endif
            NextFile(_DONT_LOAD_)
        enddo
        GotoBufferId(oldBuffer)
        PopPosition()
    endif
    if not Length(summary)
        summary = "None"
    endif
    return(summary)
end


keydef PROJ_LanguageReturnKeys
<RightBtn> PushKey(<Escape>)
end
proc PROJ_LanguageReturnPriority()
    Disable(PROJ_LanguageReturnKeys)
    Enable(PROJ_LanguageReturnKeys)
end
proc PROJ_LanguageListStartup()
    Enable(PROJ_LanguageReturnKeys)
    ListFooter(" Escape / Right-click: Return ")
end
proc PROJ_ShowLoadedLanguages()
    integer originalI = GetBufferId()
    integer countI = NumFiles(), indexI
    integer listI = CreateTempBuffer()
    string languageS[255], previousS[255]
    if listI
        GotoBufferId(originalI)
        PushPosition()
        if countI > 0
            if BufferType() <> _NORMAL_
                NextFile(_DONT_LOAD_)
            endif
            do countI times
                if BufferType() == _NORMAL_ and (Query(BufferFlags) & _LOADED_)
                    languageS = PROJ_FileLanguage(CurrFilename())
                    if Length(languageS)
                        AddLine(languageS, listI)
                    endif
                endif
                NextFile(_DONT_LOAD_)
            enddo
        endif
        GotoBufferId(originalI)
        PopPosition()
        GotoBufferId(listI)
        if NumLines() > 1
            UnMarkBlock()
            MarkLine(1, NumLines())
            Sort(_IGNORE_CASE_)
            UnMarkBlock()
        endif
        indexI = NumLines()
        while indexI > 0
            GotoLine(indexI)
            languageS = GetText(1, 255)
            if not Length(Trim(languageS))
                KillLine()
            elseif indexI > 1
                Up()
                previousS = GetText(1, 255)
                if EquiStr(languageS, previousS)
                    Down()
                    KillLine()
                endif
            endif
            indexI = indexI - 1
        endwhile
        BegFile()
        if not Length(Trim(GetText(1, 255)))
            AddLine("No recognized computer languages are loaded.")
        endif
        BegFile()
        Hook(_LIST_STARTUP_, PROJ_LanguageListStartup)
        Hook(_BEFORE_GETKEY_, PROJ_LanguageReturnPriority)
        List("Loaded computer languages - Escape / Right-click: Return", 78)
        UnHook(PROJ_LanguageListStartup)
        UnHook(PROJ_LanguageReturnPriority)
        Disable(PROJ_LanguageReturnKeys)
        GotoBufferId(originalI)
        AbandonFile(listI)
    endif
end


proc PROJ_LanguagesStatus()
    integer x1, y1, cols, rows
    integer width
    string summary[255]

    summary = "Languages: " + PROJ_LoadedLanguages()
    width = Min(70, Query(ScreenCols) / 2 - 25)
    if width < 16
        return()
    endif
    if Length(summary) > width
        summary = SubStr(summary, 1, width - 3) + "..."
    endif
    x1 = Query(PopWinX1)
    y1 = Query(PopWinY1)
    cols = Query(PopWinCols)
    rows = Query(PopWinRows)
    Window(Query(ScreenCols) / 2 + 1, Query(StatusLineRow),
           Query(ScreenCols) / 2 + width, Query(StatusLineRow))
    VGotoXY(1, 1)
    PutStr(Format(summary:width), Query(StatusLineAttr))
    Window(x1, y1, x1 + cols - 1, y1 + rows - 1)
end

proc Main()
    if Lower(Trim(Query(MacroCmdLine))) == "-status"
        PROJ_LanguagesStatus()
    elseif Lower(Trim(Query(MacroCmdLine))) == "-summary"
        SetGlobalStr("PROJ_LanguageSummary", PROJ_LoadedLanguages())
    else
        PROJ_ShowLoadedLanguages()
    endif
end
