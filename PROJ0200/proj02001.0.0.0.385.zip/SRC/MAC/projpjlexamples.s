#include ["projdialogs.si"]
// PROJ0200 1.0.0.0.385 - OpenAI Codex (GPT-6)
// Separate batch loader keeps the PJL interpreter compact.
proc Main()
    integer originalI = GetBufferId(), listI = 0, lineI, charI
    integer countI = 0, kindI = GetGlobalInt("PROJ_PJLBatchKind")
    integer succeededB, targetI = 0, warningsI = 0, skippedI = 0
    string typeS[20] = "UNKNOWN"
    string fileS[255] = GetGlobalStr("PROJ_PJLBatchFile")
    string extensionS[255], errorS[255] = "", entryErrorS[255]
    string workerS[255] = SplitPath(CurrMacroFilename(), _DRIVE_|_PATH_) + "projexamples.mac"
    case kindI
        when 1 typeS = "HELLOWORLD"
        when 2 typeS = "BAT"
        when 3 typeS = "RULE"
        when 4 typeS = "ERRORSTEST"
        when 5 typeS = "SYNTAXHIGHLIGHT"
    endcase
    SetGlobalInt("PROJ_PJLBatchResult", FALSE)
    SetGlobalInt("PROJ_PJLBatchTarget", 0)
    SetGlobalStr("PROJ_PJLBatchError", "")
    warningsI = CreateTempBuffer()
    SetGlobalInt("PROJ_ExampleQuiet", TRUE)
    listI = CreateTempBuffer()
    if not warningsI
        errorS = "Cannot allocate the batch warning buffer."
    elseif not listI
        errorS = "Cannot allocate the language-list buffer."
    elseif not InsertFile(fileS, _DONT_PROMPT_)
        errorS = "Cannot read language list: " + fileS
    elseif kindI < 1 or kindI > 5
        errorS = "Invalid batch example type."
    else
        for lineI = 1 to NumLines()
            GotoBufferId(listI)
            GotoLine(lineI)
            errorS = ""
            extensionS = Lower(Trim(GetText(1, 255)))
            if CurrLineLen() > 255
                errorS = "Language-list line exceeds 255 characters."
            endif
            if Length(extensionS) and LeftStr(extensionS, 1) <> ";" and LeftStr(extensionS, 2) <> "//"
                if LeftStr(extensionS, 1) == "."
                    extensionS = SubStr(extensionS, 2, 254)
                endif
                if not Length(extensionS)
                    errorS = "Empty language extension."
                endif
                for charI = 1 to Length(extensionS)
                    if not Pos(SubStr(extensionS, charI, 1), "abcdefghijklmnopqrstuvwxyz0123456789_+-")
                        errorS = "Use one extension per line without spaces or filenames."
                        break
                    endif
                endfor
                if not Length(errorS)
                SetGlobalInt("PROJ_ExampleKind", kindI)
                SetGlobalStr("PROJ_ExampleExtension", extensionS)
                SetGlobalInt("PROJ_ExampleResult", FALSE)
                succeededB = ExecMacro(QuotePath(workerS))
                succeededB = succeededB and GetGlobalInt("PROJ_ExampleResult")
                if not succeededB
                    errorS = GetGlobalStr("PROJ_ExampleError")
                    if not Length(errorS)
                        errorS = "Cannot run example loader for ." + extensionS
                    endif
                endif
                if succeededB
                    targetI = GetBufferId()
                    countI = countI + 1
                endif
                endif
                if Length(errorS)
                    skippedI = skippedI + 1
                    entryErrorS = typeS + " Language-list line " + Str(lineI) + " (." + extensionS + "): " + errorS
                    if warningsI
                        GotoBufferId(warningsI)
                        EndFile()
                        AddLine(entryErrorS)
                    endif
                endif
                GotoBufferId(listI)
            endif
        endfor
        errorS = ""
        if not countI
            errorS = "No examples loaded; the list is empty or its entries could not be loaded."
        endif
    endif
    GotoBufferId(originalI)
    if listI
        AbandonFile(listI)
    endif
    if warningsI and not skippedI
        AbandonFile(warningsI)
        warningsI = 0
    endif
    SetGlobalInt("PROJ_PJLBatchWarnings", warningsI)
    DelGlobalVar("PROJ_ExampleQuiet")
    DelGlobalVar("PROJ_ExampleError")
    DelGlobalVar("PROJ_ExampleKind")
    DelGlobalVar("PROJ_ExampleExtension")
    DelGlobalVar("PROJ_ExampleResult")
    SetGlobalInt("PROJ_PJLBatchTarget", targetI)
    SetGlobalStr("PROJ_PJLBatchError", errorS)
    SetGlobalInt("PROJ_PJLBatchResult", not Length(errorS))
    FNProjectWarning("PJL " + typeS + " example entries loaded: " + Str(countI) + "; skipped: " + Str(skippedI))
end
