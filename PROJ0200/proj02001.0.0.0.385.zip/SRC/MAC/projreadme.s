#include ["projhistory.si"]
#include ["projdialogs.si"]
// PROJ0200 1.0.0.0.385 - OpenAI Codex (GPT-6)
// Read-only Markdown help. Keys exist only while a help list is active.
dll "<shell32.dll>"
    integer proc PROJ_HelpShell(integer owner, integer operation,
        string target:cstrval, string parameters:cstrval,
        string directory:cstrval, integer showMode) : "ShellExecuteA"
end
integer g_helpWidth = 100
integer g_helpHeight = 30
integer g_helpAction = 0
string g_helpSearch[255] = ""
string g_helpSearchFlags[24] = "i"

menu PROJ_ReadmeMouseMenu()
    title = "README actions"
    "&L: Links", PushKey(<F2>), CloseAfter
    "&F: Find...", PushKey(<F3>), CloseAfter
    "&N: Find next", PushKey(<Alt F3>), CloseAfter
    "&S: Window size...", PushKey(<F4>), CloseAfter
    "&B: Back", PushKey(<Escape>), CloseAfter
end

keydef PROJ_ReadmeKeys
<RightBtn> PROJ_ReadmeMouseMenu()
<F2> g_helpAction = 2 PushKey(<Escape>)
<F4> g_helpAction = 6 PushKey(<Escape>)
<F3> g_helpAction = 4 PushKey(<Escape>)
<Alt F3> g_helpAction = 5 PushKey(<Escape>)
<Alt CursorLeft> g_helpAction = 3 PushKey(<Escape>)
end

string proc PROJ_HeadingSlug(string text)
    integer index
    string slug[255] = ""
    string letter[1]
    string normalized[255] = Lower(Trim(text))
    for index = 1 to Length(normalized)
        letter = SubStr(normalized, index, 1)
        if Pos(letter, "abcdefghijklmnopqrstuvwxyz0123456789_-")
            slug = slug + letter
        elseif letter == " "
            slug = slug + "-"
        endif
    endfor
    return(slug)
end

proc PROJ_CollectHelpLinks(integer source, integer destination, integer onlyLine)
    integer lineIndex
    integer startAt
    integer endAt
    integer firstLine = 1
    integer lastLine
    string lineText[255]
    string target[255]
    GotoBufferId(source)
    lastLine = NumLines()
    if onlyLine
        firstLine = CurrLine()
        lastLine = firstLine
    endif
    PushPosition()
    for lineIndex = firstLine to lastLine
        GotoBufferId(source)
        GotoLine(lineIndex)
        lineText = GetText(1, 255)
        // Inline Markdown links [label](target), including images.
        repeat
            startAt = Pos("](", lineText)
            if not startAt
                break
            endif
            lineText = SubStr(lineText, startAt + 2, 255)
            endAt = Pos(")", lineText)
            if not endAt
                break
            endif
            target = Trim(SubStr(lineText, 1, endAt - 1))
            if Length(target)
                AddLine(target, destination)
            endif
            lineText = SubStr(lineText, endAt + 1, 255)
        until not Length(lineText)
        // Bare/angle-bracket web URLs on lines without inline links.
        lineText = GetText(1, 255)
        if not Pos("](", lineText)
            startAt = Pos("https://", lineText)
            if not startAt
                startAt = Pos("http://", lineText)
            endif
            if startAt
                target = GetToken(SubStr(lineText, startAt, 255), " " + Chr(9) + ">", 1)
                AddLine(target, destination)
            endif
        endif
    endfor
    GotoBufferId(source)
    PopPosition()
end

proc PROJ_ResizeHelp(integer askSize)
    integer widthHistory = PROJ_HistoryId("PROJ0200:projreadme:width")
    integer heightHistory = PROJ_HistoryId("PROJ0200:projreadme:height")
    string widthText[255] = PROJ_HistoryLast(widthHistory, "PROJ0200:projreadme:width")
    string heightText[255] = PROJ_HistoryLast(heightHistory, "PROJ0200:projreadme:height")
    if not Length(widthText)
        widthText = "100"
    endif
    if not Length(heightText)
        heightText = "30"
    endif
    if askSize
        widthText = Str(g_helpWidth)
        heightText = Str(g_helpHeight)
        if not PROJ_HistoryAsk("README window width in columns:", widthText, "PROJ0200:projreadme:width")
            return()
        endif
        if not PROJ_HistoryAsk("README window height in rows:", heightText, "PROJ0200:projreadme:height")
            return()
        endif
    endif
    g_helpWidth = Val(widthText)
    g_helpHeight = Val(heightText)
    if g_helpWidth < 40
        g_helpWidth = 40
    endif
    if g_helpHeight < 8
        g_helpHeight = 8
    endif
    if g_helpWidth > Query(ScreenCols)-4
        g_helpWidth = Query(ScreenCols)-4
    endif
    if g_helpHeight > Query(ScreenRows)-4
        g_helpHeight = Query(ScreenRows)-4
    endif
end

// Wrap only the disposable help buffer; preserve structured Markdown.
proc PROJ_WrapHelpText()
    integer oldRightMargin = Query(RightMargin)
    integer oldLeftMargin = Query(LeftMargin)
    integer oldAutoIndent = Query(AutoIndent)
    integer wrapWidth = g_helpWidth - 4
    integer lineIndex = 1
    integer fencedCode = FALSE
    string fence[3] = ""
    string lineText[255]
    string trimmedText[255]
    if wrapWidth > 100
        wrapWidth = 100
    endif
    if wrapWidth < 20
        wrapWidth = 20
    endif
    Set(RightMargin, wrapWidth)
    Set(LeftMargin, 1)
    Set(AutoIndent, OFF)
    while lineIndex <= NumLines()
        GotoLine(lineIndex)
        BegLine()
        lineText = GetText(1, 255)
        trimmedText = Trim(lineText)
        if SubStr(trimmedText, 1, 3) == "```" or SubStr(trimmedText, 1, 3) == "~~~"
            if not fencedCode
                fence = SubStr(trimmedText, 1, 3)
                fencedCode = TRUE
            elseif SubStr(trimmedText, 1, 3) == fence
                fencedCode = FALSE
            endif
        elseif not fencedCode and Length(trimmedText)
            // Keep tables, headings, indented code and link targets intact.
            if not Pos("|", lineText) and SubStr(trimmedText, 1, 1) <> "#" and
                SubStr(lineText, 1, 4) <> "    " and SubStr(lineText, 1, 1) <> Chr(9) and
                not Pos("](", lineText) and not Pos("http://", Lower(lineText)) and
                not Pos("https://", Lower(lineText))
                if CurrLineLen() > wrapWidth
                    WrapLine()
                endif
            endif
        endif
        lineIndex = lineIndex + 1
    endwhile
    Set(RightMargin, oldRightMargin)
    Set(LeftMargin, oldLeftMargin)
    Set(AutoIndent, oldAutoIndent)
    BegFile()
end

// Apply the user's editor palette only while a help list is visible.
integer proc PROJ_HelpList(string title)
    integer oldText = Set(MenuTextAttr, Query(TextAttr))
    integer oldLetter = Set(MenuTextLtrAttr, Query(HiLiteAttr))
    integer oldGray = Set(MenuGrayAttr, Query(TextAttr))
    integer oldSelect = Set(MenuSelectAttr, Query(HiLiteAttr))
    integer oldSelectLetter = Set(MenuSelectLtrAttr, Query(HiLiteAttr))
    integer oldSelectGray = Set(MenuSelectGrayAttr, Query(HiLiteAttr))
    integer oldBorder = Set(MenuBorderAttr, Query(CurrWinBorderAttr))
    integer selected
    selected = lList(title, g_helpWidth, g_helpHeight, _ENABLE_HSCROLL_)
    Set(MenuTextAttr, oldText)
    Set(MenuTextLtrAttr, oldLetter)
    Set(MenuGrayAttr, oldGray)
    Set(MenuSelectAttr, oldSelect)
    Set(MenuSelectLtrAttr, oldSelectLetter)
    Set(MenuSelectGrayAttr, oldSelectGray)
    Set(MenuBorderAttr, oldBorder)
    return(selected)
end

proc PROCProjectMainActions()
    integer originalBuffer = GetBufferId()
    integer searchHistory = PROJ_HistoryId("projreadme:searchtext")
    integer optionsHistory = PROJ_HistoryId("projreadme:searchoptions")
    integer helpBuffer
    integer linksBuffer
    integer historyBuffer
    integer selected
    integer helpLine
    integer anchorAt
    integer index
    integer found
    string searchOptions[24]
    string document[255] = SplitPath(CurrMacroFilename(), _DRIVE_|_PATH_) + "proj0200_readme.md"
    string target[255]
    string anchor[255]
    string record[255]
    string heading[255]
    if GetGlobalInt("PROJ_ReadmeBrowser")
        target = SplitPath(CurrMacroFilename(), _DRIVE_|_PATH_) + "proj0200_readme.html"
        if not FileExists(target)
            FNProjectWarning(Format("HTML help file could not be found: ", target))
        elseif PROJ_HelpShell(0, 0, target, "", SplitPath(target, _DRIVE_|_PATH_), 1) <= 32
            FNProjectWarning(Format("HTML help could not be opened in the default browser: ", target))
        endif
        return()
    endif
    PROJ_ResizeHelp(FALSE)
    g_helpSearch = PROJ_HistoryLast(searchHistory, "projreadme:searchtext")
    g_helpSearchFlags = PROJ_HistoryLast(optionsHistory, "projreadme:searchoptions")
    if not Length(g_helpSearchFlags)
        g_helpSearchFlags = "i"
    endif
    if not FileExists(document)
        FNProjectWarning(Format("README help file could not be found: " + document))
        return()
    endif
    helpBuffer = CreateTempBuffer()
    if not helpBuffer
        return()
    endif
    if not InsertFile(document, _DONT_PROMPT_)
        GotoBufferId(originalBuffer)
        AbandonFile(helpBuffer)
        return()
    endif
    PROJ_WrapHelpText()
    UpdateDisplay()
    historyBuffer = CreateTempBuffer()
    if not historyBuffer
        GotoBufferId(originalBuffer)
        AbandonFile(helpBuffer)
        return()
    endif
    GotoBufferId(helpBuffer)
    BegFile()
    loop
        g_helpAction = 0
        GotoBufferId(helpBuffer)
        UpdateDisplay()
        Enable(PROJ_ReadmeKeys)
        selected = PROJ_HelpList("README: Right-click actions | F2 Links F3 Find F4 Size Enter Link Esc Back")
        Disable(PROJ_ReadmeKeys)
        helpLine = CurrLine()
        if g_helpAction == 6
            PROJ_ResizeHelp(TRUE)
            GotoBufferId(helpBuffer)
            EmptyBuffer()
            InsertFile(document, _DONT_PROMPT_)
            PROJ_WrapHelpText()
            GotoLine(helpLine)
            UpdateDisplay()
        elseif g_helpAction == 4 or g_helpAction == 5
            if g_helpAction == 4 or not Length(g_helpSearch)
                if PROJ_HistoryAsk("Search README:", g_helpSearch, "projreadme:searchtext")
                    if Length(g_helpSearch)
                        if PROJ_HistoryAsk("Search options: i=ignore case, x=TSE regex:", g_helpSearchFlags, "projreadme:searchoptions")
                            g_helpAction = 4
                        else
                            g_helpAction = 0
                        endif
                    else
                        g_helpAction = 0
                    endif
                else
                    g_helpAction = 0
                endif
            endif
            if g_helpAction
                searchOptions = ""
                if Pos("i", Lower(g_helpSearchFlags))
                    searchOptions = searchOptions + "i"
                endif
                if Pos("x", Lower(g_helpSearchFlags))
                    searchOptions = searchOptions + "x"
                endif
                PushPosition()
                if g_helpAction == 4
                    BegFile()
                else
                    NextChar()
                endif
                found = lFind(g_helpSearch, searchOptions)
                if not found and g_helpAction == 5
                    BegFile()
                    found = lFind(g_helpSearch, searchOptions)
                endif
                if found
                    helpLine = CurrLine()
                    PopPosition()
                    GotoLine(helpLine)
                else
                    PopPosition()
                    FNProjectWarning(Format("Text not found in this help document: " + g_helpSearch))
                endif
            endif
        elseif g_helpAction == 3
            GotoBufferId(historyBuffer)
            if NumLines() and Length(GetText(1, 255))
                EndFile()
                record = GetText(1, 255)
                KillLine()
                target = GetToken(record, "|", 1)
                GotoBufferId(helpBuffer)
                if target <> document
                    if FileExists(target)
                        EmptyBuffer()
                        InsertFile(target, _DONT_PROMPT_)
                        PROJ_WrapHelpText()
                        document = target
                    endif
                endif
                GotoLine(Val(GetToken(record, "|", 2)))
            else
                GotoBufferId(helpBuffer)
            endif
        elseif selected or g_helpAction == 2
            linksBuffer = CreateTempBuffer()
            if linksBuffer
                GotoBufferId(helpBuffer)
                PROJ_CollectHelpLinks(helpBuffer, linksBuffer, iif(g_helpAction == 2, 0, 1))
                GotoBufferId(linksBuffer)
                BegFile()
                target = ""
                if Length(GetText(1, 255))
                    if PROJ_HelpList("Choose a link - Enter=open Esc=cancel")
                        target = GetText(1, 255)
                    endif
                else
                    FNProjectWarning(Format("No supported link here. Press F2 for all README links."))
                endif
                GotoBufferId(helpBuffer)
                AbandonFile(linksBuffer)
                if Length(target)
                    target = GetToken(target, " " + Chr(9), 1)
                    if SubStr(target, 1, 1) == "<"
                        target = SubStr(target, 2, Length(target)-2)
                    endif
                    if Pos("https://", Lower(target)) == 1 or Pos("http://", Lower(target)) == 1 or Pos("mailto:", Lower(target)) == 1
                        if PROJ_HelpShell(0, 0, target, "", "", 1) <= 32
                            FNProjectWarning(Format("Cannot open link: " + target))
                        endif
                    else
                        anchor = ""
                        anchorAt = Pos("#", target)
                        if anchorAt
                            anchor = SubStr(target, anchorAt+1, 255)
                            target = SubStr(target, 1, anchorAt-1)
                        endif
                        if not Length(target)
                            target = document
                        elseif not Length(SplitPath(target, _DRIVE_)) and SubStr(target, 1, 1) <> "\"
                            target = SplitPath(document, _DRIVE_|_PATH_) + target
                        endif
                        target = ExpandPath(target)
                        if FileExists(target)
                            AddLine(document + "|" + Str(helpLine), historyBuffer)
                            if Lower(SplitPath(target, _EXT_)) == ".md" or Lower(SplitPath(target, _EXT_)) == ".txt"
                                if target <> document
                                    EmptyBuffer()
                                    InsertFile(target, _DONT_PROMPT_)
                                    PROJ_WrapHelpText()
                                    document = target
                                endif
                                BegFile()
                                if Length(anchor)
                                    found = FALSE
                                    for index = 1 to NumLines()
                                        GotoLine(index)
                                        heading = Trim(GetText(1, 255))
                                        if SubStr(heading, 1, 1) == "#"
                                            while SubStr(heading, 1, 1) == "#"
                                                heading = SubStr(heading, 2, 254)
                                            endwhile
                                            if PROJ_HeadingSlug(heading) == Lower(anchor)
                                                found = TRUE
                                                break
                                            endif
                                        endif
                                    endfor
                                    if not found
                                        GotoLine(helpLine)
                                        FNProjectWarning(Format("Heading not found: " + anchor))
                                    endif
                                endif
                            else
                                if PROJ_HelpShell(0, 0, target, "", SplitPath(document, _DRIVE_|_PATH_), 1) <= 32
                                    FNProjectWarning(Format("Cannot open local link: " + target))
                                endif
                            endif
                        else
                            FNProjectWarning(Format("Linked file could not be found: " + target))
                        endif
                    endif
                endif
            endif
        else
            break
        endif
        GotoBufferId(helpBuffer)
        UpdateDisplay()
    endloop
    Disable(PROJ_ReadmeKeys)
    GotoBufferId(originalBuffer)
    AbandonFile(historyBuffer)
    AbandonFile(helpBuffer)
    UpdateDisplay()
end

// PROJ0200 1.0.0.0.385 - OpenAI Codex (GPT-6)
// Set() returns the previous value; restore it after all actions return.
proc Main()
    integer IOldCommonDialogs = Set(UseCommonDialogs, FNProjectWindowsDialogs())
    PROCProjectMainActions()
    Set(UseCommonDialogs, IOldCommonDialogs)
end
