#include ["projdialogs.si"]
// PROJ0200 1.0.0.0.362 - Floating point calculator
// Adapted from Knud van Eeden's supplied getstemk.s; integration by OpenAI Codex (GPT-6).
// Parser retained; private synchronous PowerShell stdin invocation; named expression history.
string GSCalculatorFailure[255] = ""
string GSCalculatorLog[255] = ""
FORWARD INTEGER PROC FNArrayCheckStackEmptyBufferB( INTEGER i1 )
FORWARD INTEGER PROC FNArrayGetStackPushBufferI( STRING s1, INTEGER i1 )
FORWARD INTEGER PROC FNArrayGetStackSearchBufferI( STRING s1, STRING s2, INTEGER i1 )
FORWARD INTEGER PROC FNArrayGetStackTotalBufferI( INTEGER i1 )
FORWARD INTEGER PROC FNBufferChangeRevertB( INTEGER i1 )
FORWARD INTEGER PROC FNErrorCheckIB( INTEGER i1 )
FORWARD INTEGER PROC FNMathCheckNumberEqualB( INTEGER i1, INTEGER i2 )
FORWARD INTEGER PROC FNMathGetErrorI()
FORWARD INTEGER PROC FNMathGetIntegerMaximumAbsoluteI()
FORWARD INTEGER PROC FNMathGetIntegerMinimumAbsoluteI()
FORWARD INTEGER PROC FNStringGetLexicalAnalyzerB( STRING s1, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD INTEGER PROC FNStringGetMathTablePriority2InitializeB( INTEGER i1, INTEGER i2, INTEGER i3, INTEGER i4 )
FORWARD INTEGER PROC FNWindowChangeSplitVerticalBuffer2B( STRING s1, STRING s2, INTEGER i1, INTEGER i2 )
FORWARD INTEGER PROC FNWindowChangeSplitVerticalBuffer3B( STRING s1, STRING s2, STRING s3, INTEGER i1, INTEGER i2, INTEGER i3 )
FORWARD PROC Main()
FORWARD PROC PROCStringGetLexicalAnalyzerSpace()
FORWARD STRING PROC FNArrayGetStackPopBufferS( INTEGER i1 )
FORWARD STRING PROC FNArrayGetStackRowBufferS( INTEGER i1, INTEGER i2 )
FORWARD STRING PROC FNArrayGetStackTopBufferS( INTEGER i1 )
FORWARD STRING PROC FNStringGetErrorS()
FORWARD STRING PROC FNStringGetExpressionMathS( STRING s1, INTEGER i1, INTEGER i2, INTEGER i3, INTEGER i4, INTEGER i5, INTEGER i6, INTEGER i7, INTEGER i8, INTEGER i9, INTEGER i10, INTEGER i11 )
FORWARD STRING PROC FNStringGetMathPowershellS( STRING s1 )
FORWARD STRING PROC FNStringGetMathTablePriority2InfixToSuffixResultS( INTEGER i1, INTEGER i2, INTEGER i3, INTEGER i4, INTEGER i5, INTEGER i6, INTEGER i7, INTEGER i8, INTEGER i9, INTEGER i10, INTEGER i11 )


// --- MAIN --- //

//
// #DEFINE DEBUG 1
#DEFINE DEBUG 0
//
// #DEFINE TSEREMOTESERVER 1
#DEFINE TSEREMOTESERVER 0
//
proc PROCProjectMainActions()
 integer originalBuffer = GetBufferId()
 integer expressionHistory = GetFreeHistory("getstemk:expression")
 string expression[255] = GetHistoryStr(expressionHistory, 1)
 string result[255] = ""
 integer buffer1I = 0
 integer buffer2I = 0
 integer buffer3I = 0
 integer buffer4I = 0
 integer buffer5I = 0
 integer buffer6I = 0
 integer buffer7I = 0
 integer buffer8I = 0
 integer buffer9I = 0
 integer buffer10I = 0

 if Length(expression) == 0
  expression = "1+sin(2)*cos(3)"
 endif
 if not FNProjectAsk("Floating point expression =", expression, expressionHistory)
  return()
 endif
 if Length(Trim(expression)) == 0
  return()
 endif
 PushPosition()
 PushBlock()
 buffer1I = CreateTempBuffer()
 buffer2I = CreateTempBuffer()
 buffer3I = CreateTempBuffer()
 buffer4I = CreateTempBuffer()
 buffer5I = CreateTempBuffer()
 buffer6I = CreateTempBuffer()
 buffer7I = CreateTempBuffer()
 buffer8I = CreateTempBuffer()
 buffer9I = CreateTempBuffer()
 buffer10I = CreateTempBuffer()

 result = FNStringGetExpressionMathS(expression, buffer1I, buffer2I, buffer3I, buffer4I, buffer5I, buffer6I, buffer7I, buffer8I, buffer9I, buffer10I, FALSE)
 if GotoBufferId(buffer1I)
  AbandonFile(buffer1I)
 endif
 if GotoBufferId(buffer2I)
  AbandonFile(buffer2I)
 endif
 if GotoBufferId(buffer3I)
  AbandonFile(buffer3I)
 endif
 if GotoBufferId(buffer4I)
  AbandonFile(buffer4I)
 endif
 if GotoBufferId(buffer5I)
  AbandonFile(buffer5I)
 endif
 if GotoBufferId(buffer6I)
  AbandonFile(buffer6I)
 endif
 if GotoBufferId(buffer7I)
  AbandonFile(buffer7I)
 endif
 if GotoBufferId(buffer8I)
  AbandonFile(buffer8I)
 endif
 if GotoBufferId(buffer9I)
  AbandonFile(buffer9I)
 endif
 if GotoBufferId(buffer10I)
  AbandonFile(buffer10I)
 endif

 GotoBufferId(originalBuffer)
 PopBlock()
 PopPosition()
 UpdateDisplay()
 if not EquiStr(result, FNStringGetErrorS()) and Length(result)
  CopyToWinClip(result)
  FNProjectWarning(Format(expression, " = ", result, " (result copied to Windows clipboard)"))
 else
  FNProjectWarning(Format("Calculation failed: ", GSCalculatorFailure))
  if Length(GSCalculatorLog)
   if FNProjectDialog("PROJ0200", "Copy the error log filename to the Microsoft Windows clipboard?", _YES_NO_) == 1
    CopyToWinClip(GSCalculatorLog)
    FNProjectWarning(Format("Error log filename copied: ", GSCalculatorLog))
   endif
  endif
 endif
END

// --- LIBRARY --- //

// library: string: get: expression: math <description></description> <version control></version control> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=getstemk.s) [<Program>] [<Research>] [kn, ri, tu, 22-04-2025 20:19:08]
STRING PROC FNStringGetExpressionMathS( STRING expressionS, INTEGER buffer1I, INTEGER buffer2I, INTEGER buffer3I, INTEGER buffer4I, INTEGER buffer5I, INTEGER buffer6I, INTEGER buffer7I, INTEGER buffer8I, INTEGER buffer9I, INTEGER buffer10I, INTEGER debugB )
 // e.g. //
 // e.g. // #DEFINE DEBUG 1
 // e.g. #DEFINE DEBUG 0
 // e.g. //
 // e.g. // #DEFINE TSEREMOTESERVER 1
 // e.g. #DEFINE TSEREMOTESERVER 0
 // e.g. //
 // e.g. PROC Main()
 // e.g.  // STRING s1[255] = GetHistoryStr( GetFreeHistory("getstemk:expression"), 1 ) // change this
 // e.g.  STRING s1[255] = "1+sin(2)*cos(3)" // = 0.0998023702644826 / 0.09980237026448251222717163610685351351248769761851357809778791788649351876 according to WolframAlpha / RPN is 1 2 sin 3 cos * +
 // e.g.  // STRING s1[255] = "1" // 1
 // e.g.  // STRING s1[255] = "1+2" // 3
 // e.g.  // STRING s1[255] = "11+12" // = 23
 // e.g.  // STRING s1[255] = "1+2*3" // = 7
 // e.g.  // STRING s1[255] = "11*12+13*14" // = 31
 // e.g.  // STRING s1[255] = "1*2+3*4" // = 14
 // e.g.  // STRING s1[255] = "(1+2)*3" // = 9
 // e.g.  // STRING s1[255] = "sin(3+4)" // = 0.656986598718789 / 0.65698659871878909039699909159363517793687001049749007465785433418929283713 according to WolframAlpha
 // e.g.  // STRING s1[255] = "123.1243+sin(1234)*cos(3)" // = 122.528396138289 / 123.5621... according to WolframAlpha / RPN is 123.1243 1234 sin 3 cos * +
 // e.g.  // STRING s1[255] = "sin( 1 )" // = 0.841470984807897 / 0.84147098480789650665250232163029899962256306079837106567275170999191040439 according to WolframAlpha / 0.8414709848 according to Google
 // e.g.  // STRING s1[255] = "cos( 1 )" // = 0.54030230586814 / 0.54030230586813971740093660744297660373231042061792222767009725538110039477 according to WolframAlpha
 // e.g.  // STRING s1[255] = "tan( 1 )" // = 1.5574077246549 / 1.55740772465490223050697480745836017308725077238152003838394660569886139715 according to WolframAlpha
 // e.g.  // STRING s1[255] = "abs( -1 )" // = 1 / 1 according to WolframAlpha
 // e.g.  // STRING s1[255] = "acos( 1 )" // = 0 / 0 according to WolframAlpha
 // e.g.  // STRING s1[255] = "atan( 1 )" // = 0.785398163397448 / 0.78539816339744830961566084581987572104929234984377645524373614807695410157 according to WolframAlpha
 // e.g.  // STRING s1[255] = "atan2( 1 )" // = 0.785398163397448
 // e.g.  // STRING s1[255] = "cosh( 1 )" // = 1.54308063481524 / 1.54308063481524377847790562075706168260152911236586370473740221471076906304 according to WolframAlpha
 // e.g.  // STRING s1[255] = "exp( 1 )" // = 2.71828182845905 / 2.71828182845904523536028747135266249775724709369995957496696762772407663035 according to WolframAlpha
 // e.g.  // STRING s1[255] = "floor( 1.23 )" // = 1 / 1 according to WolframAlpha
 // e.g.  // STRING s1[255] = "ln( 2.718 )" // = 0.999896315728952 / 0.999896 according to WolframAlpha
 // e.g.  // STRING s1[255] = "log( 10 )" // = 1 / 1 according to WolframAlpha
 // e.g.  // STRING s1[255] = "sinh( 1 )" // = 1.1752011936438 / 1.17520119364380145688238185059560081515571798133409587022956541301330756730 according to WolframAlpha
 // e.g.  // STRING s1[255] = "sqrt( 87 )" // = 9.32737905308882 / 9.32737905308881504555447554232055698327624069419165467105619729844678454880 according to WolframAlpha
 // e.g.  // STRING s1[255] = "tanh( 1 )" // = 0.761594155955765 / 0.76159415595576488811945828260479359041276859725793655159681050012195324457 according to WolframAlpha
 // e.g.  // STRING s1[255] = "2^10" // = 1024 / 1024 according to WolframAlpha
 // e.g.  // STRING s1[255] = "ceiling( 1.23 )" // = 2 / 2 according to WolframAlpha
 // e.g.  // STRING s1[255] = "log( 100 )" // = 2 / 2 according to WolframAlpha
 // e.g.  // STRING s1[255] = "sign( -1 )" // = -1 / sign( 0 ) = 0 / sign( 1 ) = 1
 // e.g.  // STRING s1[255] = "truncate( 1.23 )" // = 1 / 1 according to WolframAlpha
 // e.g.  // STRING s1[255] = "nthroot( 64, 3 )" // =  4
 // e.g.  // STRING s1[255] = "equals( 1, 2 )" // = False
 // e.g.  // STRING s1[255] = "max( 10, 20 )" // = 20 / 20 according to WolframAlpha
 // e.g.  // STRING s1[255] = "min( 10, 20 )" // = 10 / 10 according to WolframAlpha
 // e.g.  // STRING s1[255] = "round( 1.23456, 2 )" // = 1.23 / 2 according to WolframAlpha
 // e.g.  // STRING s1[255] = "_pi_" // = 3.14159265358979 / 3.14159265358979323846264338327950288419716939937510582097494459230781640628 according to WolframAlpha
 // e.g.  // STRING s1[255] = "_e_" // = 2.71828182845905 / 2.71828182845904523536028747135266249775724709369995957496696762772407663035 according to WolframAlpha
 // e.g.  // STRING s1[255] = "ln(5)*3/2" // = 1.0729586082894 / 1.07295860828940024973383955548412509301706756951234514794176526098278599180 according to WolframAlpha
 // e.g.  // STRING s1[255] = "sin(_pi_/2/3)" // = 0.5
 // e.g.  // STRING s1[255] = "bigmul( 1000, 2000 )" // = 2 / Change '+' to '#' or '*' to '@' in regular expression to get more digits, because this result is wrong, it must be 1000 . 2000 = 2000000 (check further directly in PowerShell itself what this is supposed to return [kn, ri, fr, 20-06-2025 01:05:28])
 // e.g.  // STRING s1[255] = "4*sin(_pi_/2/3)" // = 2 / 2 according to WolframAlpha
 // e.g.  // STRING s1[255] = "3*5*sin(_pi_/2/3)" // = 7.49999999999999 / 7.5 according to WolframAlpha
 // e.g.  //
 // e.g.  // ===
 // e.g.  //
 // e.g.  // check further
 // e.g.  //
 // e.g.  //
 // e.g.  // ===
 // e.g.  //
 // e.g.  // Not used:
 // e.g.  //
 // e.g.  // ? STRING s1[255] = "divrem( 1.23 )" // gives overload error in PowerShell
 // e.g.  // ? STRING s1[255] = "gethashcode( 1 )" // seems not to exist in PowerShell
 // e.g.  // ? STRING s1[255] = "gettype( 1 )" // the command is not found yet, implement it
 // e.g.  // ? STRING s1[255] = "ieeeremainder( 1.23 )" // gives overload error in PowerShell
 // e.g.  // ? STRING s1[255] = "tostring( 3 )" // seems not to exist in PowerShell
 // e.g.  //
 // e.g.  // STRING s2[255] = "1" // debug is TRUE // change this
 // e.g.  STRING s2[255] = "0" // debug is FALSE is the default // change this
 // e.g.  //
 // e.g.  // STRING s3[255] = "1" // pass expression as a parameter via DosCmdLine is TRUE // change this
 // e.g.  STRING s3[255] = "0" // pass expression as a parameter via DosCmdLine is FALSE // change this
 // e.g.  //
 // e.g.  // STRING s4[255] = "0" // run web page WolframAlpha default FALSE // change this // change this
 // e.g.  STRING s4[255] = "1" // run web page WolframAlpha default TRUE // change this // change this
 // e.g.  //
 // e.g.  STRING s[255] = ""
 // e.g.  //
 // e.g.  INTEGER buffer1I = 0
 // e.g.  INTEGER buffer2I = 0
 // e.g.  INTEGER buffer3I = 0
 // e.g.  INTEGER buffer4I = 0
 // e.g.  INTEGER buffer5I = 0
 // e.g.  INTEGER buffer6I = 0
 // e.g.  INTEGER buffer7I = 0
 // e.g.  INTEGER buffer8I = 0
 // e.g.  INTEGER buffer9I = 0
 // e.g.  INTEGER buffer10I = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer1I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer2I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer3I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer4I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer5I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer6I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer7I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer8I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer9I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer10I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  // PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default // new
 // e.g.  //
 // e.g.  IF ( Val( s3 ) == 0 ) // not passing the parameters via the DosCmdLine
 // e.g.   //
 // e.g.   IF ( NOT ( Ask( "expression = ", s1, GetFreeHistory("getstemk:expression") ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.    // IF ( NOT ( Ask( "debug = ", s2, GetFreeHistory("getstemk:expression") ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.    //
 // e.g.   ELSE
 // e.g.    //
 // e.g.    #IF TSEREMOTESERVER
 // e.g.      s1 = Query( DosCmdLine ) // on remote server
 // e.g.    #ELSE
 // e.g.     s1 = Query( MacroCmdLine )
 // e.g.    #ENDIF
 // e.g.    //
 // e.g.    IF EquiStr( Trim( s1 ), "" )
 // e.g.     //
 // e.g.     #IF TSEREMOTESERVER
 // e.g.      //
 // e.g.      // on remote server
 // e.g.      //
 // e.g.      FWrite( _STDOUT_, Format( s1, ":", " ", "input expression parameter expected after the TSE macro name", ":", " ", CurrMacroFileName(), ".", " ", "Please check." ) )
 // e.g.      Exit()
 // e.g.      //
 // e.g.     #ELSE
 // e.g.      //
 // e.g.      // locally
 // e.g.      //
 // e.g.      Warn( s1, ":", " ", "input expression parameter expected after the TSE macro name", ":", " ", CurrMacroFileName(), ".", " ", "Please check." )
 // e.g.      //
 // e.g.     #ENDIF
 // e.g.     //
 // e.g.   ENDIF
 // e.g.   //
 // e.g.  ENDIF
 // e.g.  //
 // e.g.  s = FNStringGetExpressionMathS( s1, buffer1I, buffer2I, buffer3I, buffer4I, buffer5I, buffer6I, buffer7I, buffer8I, buffer9I, buffer10I, Val( s2 ) )
 // e.g.  //
 // e.g.  #IFDEF WIN32
 // e.g.    CopyToWinClip( s )
 // e.g.    // Message( s, ":", " ", "copied to the Microsoft Windows clipboard" )
 // e.g.    Warn( s, ":", " ", "copied to the Microsoft Windows clipboard" )
 // e.g.  #ENDIF
 // e.g.  //
 // e.g.  #IFDEF LINUX
 // e.g.    CopyToClipboard( s )
 // e.g.    Message( s, ":", " ", "copied to the TSE clipboard" )
 // e.g.  #ENDIF
 // e.g.  //
 // e.g.  IF ( Val( s4 ) == 1 )
 // e.g.   IF ( YesNo( "Do you want to run the WolframAlpha web page? (no)" ) == 1 )
 // e.g.   s1 = StrReplace( "+", s1, "%2b", "" )
 // e.g.    #IFDEF WIN32
 // e.g.     StartPgm( Format( "https://wolframalpha.com/input?i=", s1 ) )
 // e.g.    #ELSE
 // e.g.     #IFDEF LINUX
 // e.g.       Shell( Format( "cmd.exe", " ", "/c", " ", "start", " ", '"', "https://wolframalpha.com/input?i=", s1 ) )
 // e.g.     #ENDIF
 // e.g.    #ELSE
 // e.g.    #ENDIF
 // e.g.   ENDIF
 // e.g.  ENDIF
 // e.g.  //
 // e.g.  #IF DEBUG
 // e.g.   OneWindow()
 // e.g.   //
 // e.g.   // 8 vertical windows seems to be the maximum fo the 1/4 TSE window on my monitor screen
 // e.g.   //
 // e.g.   VWindow() // (window 1) and (window 2)
 // e.g.   GotoWindow( 1 )
 // e.g.   VWindow() // ((window 1) and (window 3)) and (window 2)
 // e.g.   GotoWindow( 1 )
 // e.g.   VWindow() // (((window 1) and (window 4))) and (window3)) and (window 2)
 // e.g.   GotoWindow( 2 )
 // e.g.   VWindow() // (((window 1) and (window 4))) and (window3)) and ((window 2) and (window 5))
 // e.g.   GotoWindow( 2 )
 // e.g.   VWindow() // (((window 1) and (window 4))) and (window3)) and (((window 2) and (window6)) and (window 5))
 // e.g.   GotoWindow( 3 )
 // e.g.   VWindow() // (((window 1) and (window 4))) and ((window3) and (window7)) and (((window 2) and (window6)) and (window 5))
 // e.g.   GotoWindow( 5 )
 // e.g.   VWindow() // (((window 1) and (window 4))) and ((window3) and (window7)) and (((window 2) and (window6)) and ((window 5) and (window 8)))
 // e.g.   //
 // e.g.   // The order of the windows is thus from left to right 1, 4, 3, 7, 2, 6, 5, 8
 // e.g.   // The order of the buffers is thus from left to right 1, 2, 3, 4, 5, 6, 7, 8
 // e.g.   //
 // e.g.   GotoWindow( 1 )
 // e.g.   GotoBufferId( buffer1I )
 // e.g.   BegFile()
 // e.g.   InsertLine( "BUFFER01 (TYPE)" )
 // e.g.   GotoWindow( 4 )
 // e.g.   GotoBufferId( buffer2I )
 // e.g.   BegFile()
 // e.g.   InsertLine( "BUFFER02 (TOKEN)" )
 // e.g.   GotoWindow( 3 )
 // e.g.   GotoBufferId( buffer3I )
 // e.g.   BegFile()
 // e.g.   InsertLine( "BUFFER03 (TYPE)" )
 // e.g.   GotoWindow( 7 )
 // e.g.   GotoBufferId( buffer4I )
 // e.g.   BegFile()
 // e.g.   InsertLine( "BUFFER04 (INPUT PRIORITY)" )
 // e.g.   GotoWindow( 2 )
 // e.g.   GotoBufferId( buffer5I )
 // e.g.   BegFile()
 // e.g.   InsertLine( "BUFFER05 (STACK PRIORITY)" )
 // e.g.   GotoWindow( 6 )
 // e.g.   GotoBufferId( buffer6I )
 // e.g.   BegFile()
 // e.g.   InsertLine( "BUFFER06 (TYPE)" )
 // e.g.   GotoWindow( 5 )
 // e.g.   GotoBufferId( buffer7I )
 // e.g.   BegFile()
 // e.g.   InsertLine( "BUFFER07 (TOKEN)" )
 // e.g.   GotoWindow( 8 )
 // e.g.   GotoBufferId( buffer8I )
 // e.g.   BegFile()
 // e.g.   InsertLine( "BUFFER08 (STACK PRIORITY)" )
 // e.g.   //
 // e.g.   UpDateDisplay() // IF WaitForKeyPressed( 0 ) ENDIF // Activate if using a loop
 // e.g.   //
 // e.g.   Warn( "Press any key" )
 // e.g.   //
 // e.g.   OneWindow()
 // e.g.   VWindow()
 // e.g.   GotoWindow( 1 )
 // e.g.   GotoBufferId( buffer9I )
 // e.g.   BegFile()
 // e.g.   InsertLine( "BUFFER09 (TYPE)" )
 // e.g.   GotoWindow( 2 )
 // e.g.   GotoBufferId( buffer10I )
 // e.g.   BegFile()
 // e.g.   InsertLine( "BUFFER10 (TOKEN)" )
 // e.g.   //
 // e.g.   // ExecMacro( "synchscr" ) // synchronize window scrolling
 // e.g.   //
 // e.g.  #ENDIF
 // e.g.  //
 // e.g. END
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 123.1243+sin(1234)*cos(3)
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
 #
 123.1243
 +
 sin
 (
 1234
 )
 *
 cos
 (
 3
 )
 @
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // e.g. // QuickHelp( HELPDEFFNStringGetExpressionMathS, Val, Val ) )
 // e.g. HELPDEF HELPDEFFNStringGetExpressionMathS, Val, Val )
 // e.g.  title = "FNStringGetExpressionMathS( s4, Val( s1 ), Val( s2 ), Val( s3 ) ) help" // The help's caption
 // e.g.  x = 100 // Location
 // e.g.  y = 3 // Location
 // e.g.  //
 // e.g.  // The actual help text
 // e.g.  //
 // e.g.  "Usage:"
 // e.g.  "//"
 // e.g.  "1. Run this TSE macro"
 // e.g.  "2. Then press <CtrlAlt F1> to show this help."
 // e.g.  "3. Press <Shift Escape> to quit."
 // e.g.  "//"
 // e.g.  ""
 // e.g.  "Key: Definitions:"
 // e.g.  ""
 // e.g.  "<> = do something"
 // e.g. END
 //
 STRING s[255] = ""
 //
 INTEGER B = FALSE
 //
 PushPosition()
 PushBlock()
 //
 B = FNStringGetLexicalAnalyzerB( expressionS, buffer1I, buffer2I, debugB )
 if not B
  PopBlock()
  PopPosition()
  return(FNStringGetErrorS())
 endif
 B = FNStringGetMathTablePriority2InitializeB( buffer3I, buffer4I, buffer5I, debugB )
 s = FNStringGetMathTablePriority2InfixToSuffixResultS( buffer1I, buffer2I, buffer3I, buffer4I, buffer5I, buffer6I, buffer7I, buffer8I, buffer9I, buffer10I, debugB )
 //
 PopBlock()
 PopPosition()
 //
 RETURN( s )
 //
END

// library: string: get: lexical: analyzer <description></description> <version control></version control> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=getstlau.s) [<Program>] [<Research>] [kn, ri, tu, 22-04-2025 12:25:10]
INTEGER PROC FNStringGetLexicalAnalyzerB( STRING expressionS, INTEGER buffer1I, INTEGER buffer2I, INTEGER debugB )
 // e.g. //
 // e.g. // #DEFINE DEBUG 1
 // e.g. #DEFINE DEBUG 0
 // e.g. //
 // e.g. PROC Main()
 // e.g.  // STRING s1[255] = GetHistoryStr( GetFreeHistory("getstemk:expression"), 1 ) // change this
 // e.g.  STRING s1[255] = "123.1243+sin(1234)*cos(3)" // change this
 // e.g.  STRING s2[255] = "1" // debug default
 // e.g.  //
 // e.g.  INTEGER buffer1I = 0
 // e.g.  INTEGER buffer2I = 0
 // e.g.  //
 // e.g.  INTEGER B = FALSE
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer1I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer2I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  // PROCMacroRunKeep( "setwiyde" ) // operation: set: window: warn/yesno: position: x: y: default // new
 // e.g.  IF ( NOT ( Ask( "expression = ", s1, GetFreeHistory("getstemk:expression") ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  IF ( NOT ( Ask( "debug = ", s2, GetFreeHistory("getstemk:expression") ) ) AND ( Length( s1 ) > 0 ) ) RETURN() ENDIF
 // e.g.  B = FNStringGetLexicalAnalyzerB( s1, buffer1I, buffer2I, Val( s2 ) )
 // e.g.  Message( B ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  IF ( B )
 // e.g.   OneWindow()
 // e.g.   VWindow()
 // e.g.   GotoWindow( 1 )
 // e.g.   GotoBufferId( buffer1I )
 // e.g.   BegFile()
 // e.g.   InsertLine( "BUFFER01 (TYPE)" )
 // e.g.   GotoWindow( 2 )
 // e.g.   GotoBufferId( buffer2I )
 // e.g.   BegFile()
 // e.g.   InsertLine( "BUFFER02 (TOKEN)" )
 // e.g.   //
 // e.g.   GotoBufferId( buffer1I )
 // e.g.   BegFile()
 // e.g.   GotoBufferId( buffer2I )
 // e.g.   BegFile()
 // e.g.   //
 // e.g.   ExecMacro( "synchscr" ) // synchronize window scrolling
 // e.g.  ENDIF
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <Ctrl F12> Main()
 //
 // ===
 //
 // Use case = Evaluating a given mathematical expression
 //
 // ===
 //
 // ===
 //
 // Method = This is an example of a 'greedy' algorithm:
 //          (Using regular expressions) 'eat' as much as possible each time
 //           all the time starting from the front of the given mathematical input expression
 //           (repeat this removing from the front of the line until the line on which the
 //            mathematical expression is stored is completely empty).
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
 123.1243+sin(1234)*cos(3)
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
+-------------------------------------------------------------+
| BUFFER01 (TYPE)                   | BUFFER02 (TOKEN)        |
+-------------------------------------------------------------+
 begin of stack                       #
 symbol floating point                123.1243
 binary operator addition             +
 unary operator sine                  sin
 open parenthesis                     (
 symbol floating point                1234
 close parenthesis                    )
 binary operator multiplication       *
 unary operator cosine                cos
 open parenthesis                     (
 symbol integer                       3
 close parenthesis                    )
 end of stack                         @
---------------------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // e.g. // QuickHelp( HELPDEFFNStringGetLexicalAnalyzerB, Val ) )
 // e.g. HELPDEF HELPDEFFNStringGetLexicalAnalyzerB, Val )
 // e.g.  title = "FNStringGetLexicalAnalyzerB( s3, Val( s1 ), Val( s2 ) ) help" // The help's caption
 // e.g.  x = 100 // Location
 // e.g.  y = 3 // Location
 // e.g.  //
 // e.g.  // The actual help text
 // e.g.  //
 // e.g.  "Usage:"
 // e.g.  "//"
 // e.g.  "1. Run this TSE macro"
 // e.g.  "2. Then press <CtrlAlt F1> to show this help."
 // e.g.  "3. Press <Shift Escape> to quit."
 // e.g.  "//"
 // e.g.  ""
 // e.g.  "Key: Definitions:"
 // e.g.  ""
 // e.g.  "<> = do something"
 // e.g. END
 //
 /*
 123.1243+sin(1234)*cos(3)
 ++---123.1243+sin(1234)*cos(3)
 123.1243
 123.1243E+21
 123E+21
 */
 //
 INTEGER B = FALSE
 //
 STRING s[255] = ""
 //
 INTEGER buffer3I = 0
 //
 STRING s1[255] = ""
 //
 PushPosition()
 PushBlock()
 //
 PushPosition() // 1
 buffer3I = CreateTempBuffer()
 PopPosition() // 1
 //
 GotoBufferId( buffer3I )
 InsertText( "#" ) // artificial begin of stack
 InsertText( expressionS )
 InsertText( "@" ) // artificial end of stack
 BegLine()
 //
 // from the beginning of the line, you 'eat' the first found expression all the time from the given expression string umtil the current line is empty
 //
 REPEAT
  //
  B = FALSE
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^[,]}", "cx" )
   s = GetFoundText()
   s1 = "operator comma" //
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   // AddLine( s1, buffer1I ) // do not store the separator comma ',' to avoid possible interference with the analysis
   // AddLine( s, buffer2I ) // do not store the separator comma ','
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^gettype}", "cix" )
   s = GetFoundText()
   s1 = "unary operator gettype" //
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^[0-9]#{\.?[0-9]#{E{\+|\-}?[0-9]#}@}|{E{\+|\-}?[0-9]#}}", "cx" )
   s = GetFoundText()
   s1 = "symbol floating point" // real number
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^[0-9]#}", "cx" )
   s = GetFoundText()
   s1 = "symbol integer" // integer
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^[(]}", "cx" )
   s = GetFoundText()
   s1 = "open parenthesis"
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^[)]}", "cx" )
   s = GetFoundText()
   s1 = "close parenthesis"
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^[+]}", "cx" )
   s = GetFoundText()
   s1 = "binary operator addition" // add
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^[-]}", "cx" )
   s = GetFoundText()
   s1 = "binary operator subtraction" // subtract
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^[*]}", "cx" )
   s = GetFoundText()
   s1 = "binary operator multiplication" // multiply
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^[/]}", "cx" )
   s = GetFoundText()
   s1 = "binary operator division" // divide
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^[^]}", "cx" )
   s = GetFoundText()
   s1 = "binary operator power" // power
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^divrem}", "cix" )
   s = GetFoundText()
   s1 = "unary operator divrem" // divrem
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^div}", "cix" )
   s = GetFoundText()
   s1 = "binary operator div" // div
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^mod}", "cix" )
   s = GetFoundText()
   s1 = "binary operator modulus" // mod
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^nthroot}", "cix" )
   s = GetFoundText()
   s1 = "binary operator nth root" // nthroot
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^bigmul}", "cix" )
   s = GetFoundText()
   s1 = "binary operator bigmul" // bigmul
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^equals}", "cix" )
   s = GetFoundText()
   s1 = "binary operator equals" // equals
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^max}", "cix" )
   s = GetFoundText()
   s1 = "binary operator max" // max
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^min}", "cix" )
   s = GetFoundText()
   s1 = "binary operator min" // min
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^round}", "cix" )
   s = GetFoundText()
   s1 = "binary operator round" // round
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^cosh}", "cix" ) // must come before 'cos' because of cos is a substring of cosh and having to find the longer string 'cosh' first.
   s = GetFoundText()
   s1 = "unary operator cosine hyperbolicus" // cosh
   #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
   #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^sinh}", "cix" ) // must come before 'sin' because of sin is a substring of sinh and having to find the longer string 'sinh' first.
   s = GetFoundText()
   s1 = "unary operator sine hyperbolicus" // sinh
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^tanh}", "cix" ) // must come before 'tan' because of tan is a substring of tanh and having to find the longer string 'tanh' first.
   s = GetFoundText()
   s1 = "unary operator tangens hyperbolicus" // tanh
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^cos}", "cix" )
   s = GetFoundText()
   s1 = "unary operator cosine" // cos
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^sin}", "cix" )
   s = GetFoundText()
   s1 = "unary operator sine" // sin
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^tan}", "cix" )
   s = GetFoundText()
   s1 = "unary operator tangens" // tan
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if utang a loop
  IF LFind( "\c{^acos}", "cix" )
   s = GetFoundText()
   s1 = "unary operator arcus cosine" // acos
   #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
   #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^asin}", "cix" )
   s = GetFoundText()
   s1 = "unary operator arcus sine" // asin
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^atan}", "cix" )
   s = GetFoundText()
   s1 = "unary operator arcus tangens" // atan
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^abs}", "cix" )
   s = GetFoundText()
   s1 = "unary operator absolute" // abs
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^ceiling}", "cix" )
   s = GetFoundText()
   s1 = "unary operator ceiling" // ceil
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^floor}", "cix" )
   s = GetFoundText()
   s1 = "unary operator floor" // floor
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^gethashcode}", "cix" )
   s = GetFoundText()
   s1 = "unary operator gethashcode" // gethashcode
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^sign}", "cix" )
   s = GetFoundText()
   s1 = "unary operator sign" // sign
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^tostring}", "cix" )
   s = GetFoundText()
   s1 = "unary operator tostring" // tostring
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^truncate}", "cix" )
   s = GetFoundText()
   s1 = "unary operator truncate" // truncate
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^ieeeremainder}", "cix" )
   s = GetFoundText()
   s1 = "unary operator ieeeremainder" // ieeeremainder
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^log}", "cix" )
   s = GetFoundText()
   s1 = "unary operator log" // log10
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^ln}", "cix" )
   s = GetFoundText()
   s1 = "unary operator ln" // ln
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^exp}", "cix" )
   s = GetFoundText()
   s1 = "unary operator exponent" // exp
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^[#]}", "cix" )
   s = GetFoundText()
   s1 = "begin of stack" // extra symbol
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^neg}", "cix" )
   s = GetFoundText()
   s1 = "unary operator negate" // x becomes -x
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^sqrt}", "cix" )
   s = GetFoundText()
   s1 = "unary operator square root" // sqrt
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^[@]}", "cix" )
   s = GetFoundText()
   s1 = "end of stack" // extra symbol
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  // keep this at the end otherwise these characters interfere with the beginning of keywords which start with thos letters (e.g. 'equals' start with 'e')
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^_e_}", "cx" )
   s = GetFoundText()
   s1 = "symbol e" // e = 2.1718...
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  IF LFind( "\c{^_pi_}", "cix" )
   s = GetFoundText()
   s1 = "symbol pi" // Pi = 3.1415...
   #IF DEBUG
    #IF DEBUG FNProjectWarning(Format( s1, " ", s )) #ENDIF
    #IF DEBUG FNProjectWarning(Format( Length( s ) )) #ENDIF
   #ENDIF
   AddLine( s1, buffer1I )
   AddLine( s, buffer2I )
   DO Length( s ) TIMES
    DelChar()
   ENDDO
   B = TRUE
  ENDIF
  //
  PROCStringGetLexicalAnalyzerSpace()
  #IF DEBUG UpDateDisplay() #ENDIF // #IFDEF WaitForKeyPressed( 0 ) #ENDIF // Activate if using a loop
  //
 UNTIL ( B == FALSE )
 //
 IF ( CurrLineLen() == 0 )
  B = TRUE
 ELSE
  FNProjectWarning(Format( "Error found in the given expression. Please check." ))
  B = FALSE
 ENDIF
 //
 AbandonFile( buffer3I )
 //
 PopPosition()
 PopBlock()
 //
 RETURN( B )
 //
END

// library: string: get: math: table: priority2: initialize <description></description> <version control></version control> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=getstmiq.s) [<Program>] [<Research>] [kn, ri, sa, 19-04-2025 01:46:49]
INTEGER PROC FNStringGetMathTablePriority2InitializeB( INTEGER buffer3I, INTEGER buffer4I, INTEGER buffer5I, INTEGER debugB )
 // e.g. //
 // e.g. // #DEFINE DEBUG 1
 // e.g. #DEFINE DEBUG 0
 // e.g. //
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = "1" // debug default
 // e.g.  //
 // e.g.  INTEGER B = FALSE
 // e.g.  //
 // e.g.  INTEGER buffer3I = 0
 // e.g.  INTEGER buffer4I = 0
 // e.g.  INTEGER buffer5I = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer3I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer4I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer5I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  B = FNStringGetMathTablePriority2InitializeB( buffer3I, buffer4I, buffer5I, Val( s1 ) )
 // e.g.  Message( B )
 // e.g.  IF ( B )
 // e.g.   OneWindow()
 // e.g.   VWindow()
 // e.g.   VWindow()
 // e.g.   GotoWindow( 1 )
 // e.g.   GotoBufferId( buffer3I )
 // e.g.   BegFile()
 // e.g.   InsertLine( "BUFFER03 (TYPE)" )
 // e.g.   GotoWindow( 2 )
 // e.g.   GotoBufferId( buffer4I )
 // e.g.   BegFile()
 // e.g.   InsertLine( "BUFFER04 (INPUT PRIORITY)" )
 // e.g.   //
 // e.g.   GotoWindow( 3 )
 // e.g.   GotoBufferId( buffer5I )
 // e.g.   BegFile()
 // e.g.   InsertLine( "BUFFER05 (STACK PRIORITY)" )
 // e.g.   //
 // e.g.   GotoBufferId( buffer3I )
 // e.g.   BegFile()
 // e.g.   GotoBufferId( buffer4I )
 // e.g.   BegFile()
 // e.g.   GotoBufferId( buffer5I )
 // e.g.   BegFile()
 // e.g.   //
 // e.g.   ExecMacro( "synchscr" ) // synchronize window scrolling
 // e.g.  ENDIF
 // e.g. END
 // e.g.
 // e.g. <Ctrl F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method = See also book: Anthony Dvorak - BASIC in action - page 220
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
+-------------------------------------------------------------------+---------------------------+
| BUFFER03 (TYPE)                       | BUFFER04 (INPUT PRIORITY) | BUFFER05 (STACK PRIORITY) |
+-------------------------------------------------------------------+---------------------------+
 begin of stack                           0                           0
 binary operator addition                 3                           3
 binary operator div                      4                           4
 binary operator division                 4                           4
 binary operator modulus                  4                           4
 binary operator multiplication           4                           4
 binary operator subtraction              3                           3
 binary operator nth root                 5                           5
 close parenthesis                        1                           9
 end of stack                             0                           0
 open parenthesis                         9                           1
 symbol floating point                    2                           2
 symbol integer                           2                           2
 unary operator absolute                  8                           3
 unary operator arcus cosine              8                           3
 unary operator arcus sine                8                           3
 unary operator arcus tangens             8                           3
 unary operator ceiling                   8                           3
 unary operator cosine                    8                           3
 unary operator cosine hyperbolicus       8                           3
 unary operator exponent                  8                           3
 unary operator floor                     8                           3
 unary operator ln                        8                           3
 unary operator log                       8                           3
 unary operator negate                    8                           3
 unary operator power                     8                           3
 unary operator sine                      8                           3
 unary operator sine hyperbolicus         8                           3
 unary operator square root               8                           3
 unary operator tangens                   8                           3
 unary operator tangens hyperbolicus      8                           3
-------------------------------------------------------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // e.g. // QuickHelp( HELPDEFPROCStringGetMathInterpreterS, Val, Val, Val ) )
 // e.g. HELPDEF HELPDEFPROCStringGetMathInterpreterS, Val, Val, Val )
 // e.g.  title = "PROCStringGetMathInterpreterS( Val( s1 ), Val( s2 ), Val( s3 ), Val( s4 ) ) help" // The help's caption
 // e.g.  x = 100 // Location
 // e.g.  y = 3 // Location
 // e.g.  //
 // e.g.  // The actual help text
 // e.g.  //
 // e.g.  "Usage:"
 // e.g.  "//"
 // e.g.  "1. Run this TSE macro"
 // e.g.  "2. Then press <CtrlAlt F1> to show this help."
 // e.g.  "3. Press <Shift Escape> to quit."
 // e.g.  "//"
 // e.g.  ""
 // e.g.  "Key: Definitions:"
 // e.g.  ""
 // e.g.  "<> = do something"
 // e.g. END
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // e.g. // QuickHelp( HELPDEFFNStringGetMathInterpreterS )
 // e.g. HELPDEF HELPDEFFNStringGetMathInterpreterS
 // e.g.  title = "FNStringGetMathInterpreterS( s1 ) help" // The help's caption
 // e.g.  x = 100 // Location
 // e.g.  y = 3 // Location
 // e.g.  //
 // e.g.  // The actual help text
 // e.g.  //
 // e.g.  "Usage:"
 // e.g.  "//"
 // e.g.  "1. Run this TSE macro"
 // e.g.  "2. Then press <CtrlAlt F1> to show this help."
 // e.g.  "3. Press <Shift Escape> to quit."
 // e.g.  "//"
 // e.g.  ""
 // e.g.  "Key: Definitions:"
 // e.g.  ""
 // e.g.  "<> = do something"
 // e.g. END
 //
 INTEGER B = FALSE
 //
 PushPosition()
 PushBlock()
 //
 // begin of stack
 //
 AddLine( "begin of stack",                            buffer3I ) AddLine( "0", buffer4I ) AddLine( "0", buffer5I ) // #
 //
 // end of stack
 //
 AddLine( "end of stack",                              buffer3I ) AddLine( "0", buffer4I ) AddLine( "0", buffer5I ) // @
 //
 // parentheses
 //
 AddLine( "open parenthesis",                          buffer3I ) AddLine( "9", buffer4I ) AddLine( "2", buffer5I )
 AddLine( "close parenthesis",                         buffer3I ) AddLine( "2", buffer4I ) AddLine( "9", buffer5I )
 //
 // symbol
 //
 AddLine( "symbol floating point",                     buffer3I ) AddLine( "9", buffer4I ) AddLine( "9", buffer5I )
 AddLine( "symbol integer",                            buffer3I ) AddLine( "9", buffer4I ) AddLine( "9", buffer5I )
 AddLine( "symbol e",                                  buffer3I ) AddLine( "9", buffer4I ) AddLine( "9", buffer5I )
 AddLine( "symbol pi",                                 buffer3I ) AddLine( "9", buffer4I ) AddLine( "9", buffer5I )
 //
 // binary operator
 //
 AddLine( "binary operator addition",                  buffer3I ) AddLine( "3", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "binary operator subtraction",               buffer3I ) AddLine( "3", buffer4I ) AddLine( "3", buffer5I )
 //
 AddLine( "binary operator div",                       buffer3I ) AddLine( "4", buffer4I ) AddLine( "4", buffer5I )
 AddLine( "binary operator division",                  buffer3I ) AddLine( "4", buffer4I ) AddLine( "4", buffer5I )
 AddLine( "binary operator modulus",                   buffer3I ) AddLine( "4", buffer4I ) AddLine( "4", buffer5I )
 AddLine( "binary operator multiplication",            buffer3I ) AddLine( "4", buffer4I ) AddLine( "4", buffer5I )
 //
 AddLine( "binary operator power",                     buffer3I ) AddLine( "5", buffer4I ) AddLine( "5", buffer5I )
 //
 AddLine( "binary operator bigmul",                    buffer3I ) AddLine( "6", buffer4I ) AddLine( "6", buffer5I )
 AddLine( "binary operator equals",                    buffer3I ) AddLine( "6", buffer4I ) AddLine( "6", buffer5I )
 AddLine( "binary operator max",                       buffer3I ) AddLine( "6", buffer4I ) AddLine( "6", buffer5I )
 AddLine( "binary operator min",                       buffer3I ) AddLine( "6", buffer4I ) AddLine( "6", buffer5I )
 AddLine( "binary operator nth root",                  buffer3I ) AddLine( "6", buffer4I ) AddLine( "6", buffer5I )
 AddLine( "binary operator round",                     buffer3I ) AddLine( "6", buffer4I ) AddLine( "6", buffer5I )
 //
 // unary operator
 //
 AddLine( "unary operator absolute",                   buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator arcus cosine",               buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator arcus sine",                 buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator arcus tangens",              buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator arcus tangens 2",            buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator ceiling",                    buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator cosine hyperbolicus",        buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator cosine",                     buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator div",                        buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator divrem",                     buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator exponent",                   buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator floor",                      buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator gethashcode",                buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator gettype",                    buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator ieeeremainder",              buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator ln",                         buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator log",                        buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator negate",                     buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator sign",                       buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator sine hyperbolicus",          buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator sine",                       buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator square root",                buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator tangens hyperbolicus",       buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator tangens",                    buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator tostring",                   buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 AddLine( "unary operator truncate",                   buffer3I ) AddLine( "8", buffer4I ) AddLine( "3", buffer5I )
 //
 B = TRUE
 //
 PopBlock()
 PopPosition()
 //
 RETURN( B )
 //
END

// library: string: get: math: table: priority2: infix: to: suffix: result <description></description> <version control></version control> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=getsttsj.s) [<Program>] [<Research>] [kn, ri, tu, 22-04-2025 23:04:32]
STRING PROC FNStringGetMathTablePriority2InfixToSuffixResultS( INTEGER buffer1I, INTEGER buffer2I, INTEGER buffer3I, INTEGER buffer4I, INTEGER buffer5I, INTEGER buffer6I, INTEGER buffer7I, INTEGER buffer8I, INTEGER buffer9I, INTEGER buffer10I, INTEGER debugB )
 // e.g. //
 // e.g. // #DEFINE DEBUG 1
 // e.g. #DEFINE DEBUG 0
 // e.g. //
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  STRING s1[255] = "1" // debug default
 // e.g.  //
 // e.g.  INTEGER buffer1I = 0
 // e.g.  INTEGER buffer2I = 0
 // e.g.  INTEGER buffer3I = 0
 // e.g.  INTEGER buffer4I = 0
 // e.g.  INTEGER buffer5I = 0
 // e.g.  INTEGER buffer6I = 0
 // e.g.  INTEGER buffer7I = 0
 // e.g.  INTEGER buffer8I = 0
 // e.g.  INTEGER buffer9I = 0
 // e.g.  INTEGER buffer10I = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer1I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer2I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer3I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer4I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer5I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer6I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer7I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer8I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer9I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer10I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  Message( FNStringGetMathTablePriority2InfixToSuffixResultS( buffer1I, buffer2I, buffer3I, buffer4I, buffer5I, buffer6I, buffer7I, buffer8I, buffer9I, buffer10I, Val( s1 ) ) ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <Ctrl F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // e.g. // QuickHelp( HELPDEFFNStringGetMathTablePriority2InfixToSuffixB, Val, Val, Val, Val, Val, Val ) )
 // e.g. HELPDEF HELPDEFFNStringGetMathTablePriority2InfixToSuffixB, Val, Val, Val, Val, Val, Val )
 // e.g.  title = "FNStringGetMathTablePriority2InfixToSuffixB( Val( s1 ), Val( s2 ), Val( s3 ), Val( s4 ), Val( s5 ), Val( s6 ), Val( s7 ) ) help" // The help's caption
 // e.g.  x = 100 // Location
 // e.g.  y = 3 // Location
 // e.g.  //
 // e.g.  // The actual help text
 // e.g.  //
 // e.g.  "Usage:"
 // e.g.  "//"
 // e.g.  "1. Run this TSE macro"
 // e.g.  "2. Then press <CtrlAlt F1> to show this help."
 // e.g.  "3. Press <Shift Escape> to quit."
 // e.g.  "//"
 // e.g.  ""
 // e.g.  "Key: Definitions:"
 // e.g.  ""
 // e.g.  "<> = do something"
 // e.g. END
 //
 STRING s[255] = ""
 //
 STRING s1[255] = "" // type (in input expression)
 STRING s2[255] = "" // token (in input expression)
 //
 STRING s3[255] = "" // type (in priority table)
 STRING s4[255] = "" // input priority (in priority table)
 STRING s5[255] = "" // stack priority (in priority table)
 //
 STRING s6[255] = "" // type (in intermediate stack)
 STRING s7[255] = "" // token (in intermediate stack)
 STRING s8[255] = "" // stack priority (in intermediate stack)
 //
 STRING s9[255] = "" // type (in output stack)
 STRING s10[255] = "" // token (in output stack)
 //
 STRING s11[255] = "" // stack priority (in intermediate stack)
 //
 STRING s12[255] = ""
 STRING s13[255] = ""
 STRING s14[255] = ""
 STRING s15[255] = ""
 STRING s16[255] = ""
 //
 INTEGER I = 0
 //
 INTEGER evalBufferI = 0
 //
 STRING typeS[255] = FNArrayGetStackPopBufferS(buffer9I)
 STRING tokenS[255] = FNArrayGetStackPopBufferS(buffer10I)
 //
 STRING aS[255] = ""
 STRING bS[255] = ""
 STRING expressionS[255] = ""
 //
 STRING expressionFinalS[255] = ""
 //
 INTEGER B = FALSE
 //
 PushBlock()
 PushPosition()
 //
 PushPosition() // 1
 evalBufferI = CreateTempBuffer()
 PopPosition() // 1
 //
 s6 = FNArrayGetStackTopBufferS( buffer1I )
 s7 = FNArrayGetStackTopBufferS( buffer2I )
 #IF DEBUG FNProjectWarning(Format( "read only from top of buffer 1 and read only from top  of buffer 2:"; "'", s6, "'"; ":", " ", s7 )) #ENDIF
 //
 IF NOT EquiStr( s6, "begin of stack" )
  #IF DEBUG FNProjectWarning(Format( s6, ":", " ", "found. But instead 'begin of stack' expected here. Please check." )) #ENDIF
  s = FNStringGetErrorS()
  RETURN( s )
 ENDIF
 //
 I = FNArrayGetStackSearchBufferI( s6, "gi", buffer3I )
 #IF DEBUG FNProjectWarning(Format( "searched in buffer 3 for:"; s6 )) #ENDIF
 //
 IF FNErrorCheckIB( I )
  #IF DEBUG FNProjectWarning(Format( "type", ":", " ", s6, " ", "not found in the types in the priority table. Please check." )) #ENDIF
  s = FNStringGetErrorS()
  RETURN( s )
 ENDIF
 //
 s8 = FNArrayGetStackRowBufferS( I, buffer5I ) // stack priority (in priority table)
 #IF DEBUG FNProjectWarning(Format( "get the stack priority from buffer 5", ":", " ", s8, " ", "in the priority table at that row:"; I )) #ENDIF
 //
 s6 = FNArrayGetStackPopBufferS( buffer1I )
 s7 = FNArrayGetStackPopBufferS( buffer2I )
 #IF DEBUG FNProjectWarning(Format( "popped from top of buffer 1 and popped from top of buffer 2:"; "'", s6, "'"; ":", " ", s7 )) #ENDIF
 //
 I = FNArrayGetStackPushBufferI( s6, buffer6I ) // type (in intermediate stack)
 I = FNArrayGetStackPushBufferI( s7, buffer7I ) // token (in intermediate stack)
 I = FNArrayGetStackPushBufferI( s8, buffer8I ) // stack priority (in intermediate stack)
 #IF DEBUG FNProjectWarning(Format( "pushed on buffer 6, buffer 7 and buffer 8: "; s6; s7; s8 )) #ENDIF
 //
 #IF DEBUG GotoBufferId( buffer1I ) BegFile() UpdateDisplay() FNProjectWarning(Format( "Buffer 1: Press any key" )) #ENDIF
 #IF DEBUG GotoBufferId( buffer6I ) BegFile() UpdateDisplay() FNProjectWarning(Format( "Buffer 6: Press any key" )) #ENDIF
 //
 WHILE NOT FNArrayCheckStackEmptyBufferB( buffer1I )
  //
  #IF DEBUG B = FNWindowChangeSplitVerticalBuffer2B( "TYPE [in buffer1]", "TOKEN [in buffer2]", buffer1I, buffer2I ) #ENDIF
  //
  s1 = FNArrayGetStackPopBufferS( buffer1I ) // type (in input expression)
  s2 = FNArrayGetStackPopBufferS( buffer2I ) // token (in input expression)
  #IF DEBUG FNProjectWarning(Format( "popped from top of buffer 1 and popped from top of buffer 2:"; "'", s1, "'"; ":", " ", s2 )) #ENDIF
  //
  I = FNArrayGetStackSearchBufferI( s1, "gi", buffer3I )
  #IF DEBUG FNProjectWarning(Format( s1, ":", " ", "found in buffer 3 at line"; I )) #ENDIF
  //
  IF FNErrorCheckIB( I )
   #IF DEBUG FNProjectWarning(Format( "type", ":", " ", s1, " ", "not found in the types in the priority table. Please check." )) #ENDIF
   s = FNStringGetErrorS()
   RETURN( s )
  ENDIF
  //
  s4 = FNArrayGetStackRowBufferS( I, buffer4I ) // input priority (in priority table)
  s5 = FNArrayGetStackRowBufferS( I, buffer5I ) // stack priority (in priority table)
  #IF DEBUG FNProjectWarning(Format( s1, ":", " ", "input priority is", ":", s4, " ", "and stack priority is", ":", " ", s5, " ", "at this line ="; I )) #ENDIF
  //
  s = FNArrayGetStackTopBufferS( buffer8I )
  #IF DEBUG FNProjectWarning(Format( s, ":", " ", "currently at top of the stack in buffer 8")) #ENDIF
  //
  #IF DEBUG FNProjectWarning(Format( "checking if larger"; Val( s4 ); Val( s ) )) #ENDIF
  //
  // Special handling for parentheses
  IF EquiStr( s1, "open parenthesis" )
    #IF DEBUG FNProjectWarning(Format( "Always push ( to the stack, regardless of priorities" )) #ENDIF
    // Always push ( to the stack, regardless of priorities
    I = FNArrayGetStackPushBufferI( s1, buffer6I )
    I = FNArrayGetStackPushBufferI( s2, buffer7I )
    I = FNArrayGetStackPushBufferI( s5, buffer8I ) // push stack priority
    // CONTINUE
  //
  ELSEIF EquiStr( s1, "close parenthesis" )
    //
    #IF DEBUG FNProjectWarning(Format( 'Pop until "open parenthesis" is found' )) #ENDIF
    // Pop until "open parenthesis" is found
    REPEAT
      s9 = FNArrayGetStackPopBufferS( buffer6I ) // type
      s10 = FNArrayGetStackPopBufferS( buffer7I ) // token
      s11 = FNArrayGetStackPopBufferS( buffer8I ) // stack priority
      //
      IF NOT EquiStr( s9, "open parenthesis" )
        I = FNArrayGetStackPushBufferI( s9, buffer9I )
        I = FNArrayGetStackPushBufferI( s10, buffer10I )
      ENDIF
    UNTIL EquiStr( s9, "open parenthesis" ) OR FNArrayCheckStackEmptyBufferB( buffer6I )
    //
    // After popping '(', check for function (e.g., sin/cos) on top of stack
    s12 = FNArrayGetStackTopBufferS( buffer6I )
    s13 = FNArrayGetStackTopBufferS( buffer7I )
    IF EquiStr( LeftStr( s12, Length( "unary operator" ) ), "unary operator" ) // adjust type as needed
      #IF DEBUG FNProjectWarning(Format( s12, ":", "unary operator found" )) #ENDIF
      s14 = FNArrayGetStackPopBufferS( buffer6I )
      s15 = FNArrayGetStackPopBufferS( buffer7I )
      s16 = FNArrayGetStackPopBufferS( buffer8I )
      I = FNArrayGetStackPushBufferI( s14, buffer9I )
      I = FNArrayGetStackPushBufferI( s15, buffer10I )
    ENDIF
    // CONTINUE
  ELSEIF EquiStr( s1, "symbol floating point" ) OR EquiStr( s1, "symbol integer" )
   //
   #IF DEBUG FNProjectWarning(Format( "variable"; s1; s2 )) #ENDIF
   //
   I = FNArrayGetStackPushBufferI( s1, buffer9I )
   I = FNArrayGetStackPushBufferI( s2, buffer10I )
   s = FNArrayGetStackTopBufferS( buffer8I )
   #IF DEBUG
    PushPosition() // 1
    PushBlock() // 1
    GotoBufferId( buffer6I )
    UpdateDisplay()
    FNProjectWarning(Format( "Press any key 6" ))
    GotoBufferId( buffer7I )
    UpdateDisplay()
    FNProjectWarning(Format( "Press any key 7" ))
    GotoBufferId( buffer8I )
    UpdateDisplay()
    FNProjectWarning(Format( "Press any key 8" ))
    GotoBufferId( buffer9I )
    UpdateDisplay()
    FNProjectWarning(Format( "Press any key 9" ))
    GotoBufferId( buffer10I )
    UpdateDisplay()
    FNProjectWarning(Format( "Press any key 10" ))
    PopBlock() // 1
    PopPosition() // 1
   #ENDIF
   //
  ELSE
   //
   IF ( Val( s4 ) <= Val( s ) )
     REPEAT
       s9 = FNArrayGetStackPopBufferS( buffer6I )
       s10 = FNArrayGetStackPopBufferS( buffer7I )
       s11 = FNArrayGetStackPopBufferS( buffer8I )
       #IF DEBUG FNProjectWarning(Format( "popped larger or equal from buffer 6, buffer 7 and buffer 8: "; s9; s10; s11 )) #ENDIF
       IF NOT ( EquiStr( s9, "open parenthesis" ) OR EquiStr( s9, "close parenthesis" ) OR EquiStr( s9, "begin of stack" ) OR EquiStr( s9, "end of stack" ) )
        I = FNArrayGetStackPushBufferI( s9, buffer9I )
        I = FNArrayGetStackPushBufferI( s10, buffer10I )
       ENDIF
       #IF DEBUG
        FNProjectWarning(Format( "<=" ))
        PushPosition() // 1
        PushBlock() // 1
        GotoBufferId( buffer6I )
        UpdateDisplay()
        FNProjectWarning(Format( "Press any key 6" ))
        GotoBufferId( buffer7I )
        UpdateDisplay()
        FNProjectWarning(Format( "Press any key 7" ))
        GotoBufferId( buffer8I )
        UpdateDisplay()
        FNProjectWarning(Format( "Press any key 8" ))
        GotoBufferId( buffer9I )
        UpdateDisplay()
        FNProjectWarning(Format( "Press any key 9" ))
        GotoBufferId( buffer10I )
        UpdateDisplay()
        FNProjectWarning(Format( "Press any key 10" ))
        PopBlock() // 1
        PopPosition() // 1
       #ENDIF
   //
    #IF DEBUG FNProjectWarning(Format( "pushed larger or equal on buffer 9 and 10: "; s9; s10 )) #ENDIF
    #IF DEBUG GotoBufferId( buffer9I ) BegFile() UpdateDisplay() FNProjectWarning(Format( "Buffer 9: Press any key" )) #ENDIF
    #IF DEBUG GotoBufferId( buffer10I ) BegFile() UpdateDisplay() FNProjectWarning(Format( "Buffer 10: Press any key" )) #ENDIF
    s = FNArrayGetStackTopBufferS( buffer8I )
    #IF DEBUG FNProjectWarning(Format( "reading again the current top of the stack priority" )) #ENDIF
    UNTIL ( Val( s4 ) > Val( s ) ) OR FNArrayCheckStackEmptyBufferB( buffer6I )
   ENDIF
   //
   // Then push current operator to the intermediate stack
   //
   I = FNArrayGetStackPushBufferI( s1, buffer6I )
   I = FNArrayGetStackPushBufferI( s2, buffer7I )
   I = FNArrayGetStackPushBufferI( s5, buffer8I )
   #IF DEBUG FNProjectWarning(Format( "pushed smaller on buffer 6, 7, 8: "; s1; s2; s5 )) #ENDIF
   #IF DEBUG GotoBufferId( buffer6I ) BegFile() UpdateDisplay() FNProjectWarning(Format( "Buffer 6: Press any key" )) #ENDIF
   #IF DEBUG GotoBufferId( buffer7I ) BegFile() UpdateDisplay() FNProjectWarning(Format( "Buffer 7: Press any key" )) #ENDIF
   #IF DEBUG GotoBufferId( buffer8I ) BegFile() UpdateDisplay() FNProjectWarning(Format( "Buffer 8: Press any key" )) #ENDIF
    //
   #IF DEBUG B = FNWindowChangeSplitVerticalBuffer3B( "TYPE [in buffer3]", "TOKEN [in buffer4]", "* stack priority (buffer5)", buffer3I, buffer4I, buffer5I ) #ENDIF
   #IF DEBUG B = FNWindowChangeSplitVerticalBuffer2B( "TYPE [in buffer9]", "TOKEN [in buffer10]", buffer9I, buffer10I ) #ENDIF
   //
   #IF DEBUG
    FNProjectWarning(Format( ">" ))
    //
    PushPosition() // 1
    PushBlock() // 1
    GotoBufferId( buffer6I )
    UpdateDisplay()
    FNProjectWarning(Format( "Press any key 6" ))
    GotoBufferId( buffer7I )
    UpdateDisplay()
    FNProjectWarning(Format( "Press any key 7" ))
    GotoBufferId( buffer8I )
    UpdateDisplay()
    FNProjectWarning(Format( "Press any key 8" ))
    GotoBufferId( buffer9I )
    UpdateDisplay()
    FNProjectWarning(Format( "Press any key 9" ))
    GotoBufferId( buffer10I )
    UpdateDisplay()
    FNProjectWarning(Format( "Press any key 10" ))
    PopBlock() // 1
    PopPosition() // 1
  #ENDIF
  //
  ENDIF
  //
 ENDWHILE
 //
 B = FNBufferChangeRevertB( buffer9I ) // revert the stack order, so that the last elements are on the top of the stack
 B = FNBufferChangeRevertB( buffer10I ) // revert the stack order, so that the last elements are on the top of the stack
 //
 PushPosition() // 1
 evalBufferI = CreateTempBuffer()
 PopPosition() // 1
 //
 WHILE NOT FNArrayCheckStackEmptyBufferB(buffer9I)
  //
  typeS = FNArrayGetStackPopBufferS(buffer9I)
  //
  tokenS = FNArrayGetStackPopBufferS(buffer10I)
  //
  IF EquiStr(typeS, "symbol integer") OR EquiStr(typeS, "symbol floating point") OR EquiStr( typeS, "symbol pi" ) OR EquiStr( typeS, "symbol e" )
   //
   // Push any number 'as-is'
   //
   IF EquiStr( typeS, "symbol pi" )
    tokenS = "3.14159265358979"
   ENDIF
   //
   IF EquiStr( typeS, "symbol e" )
    tokenS = "2.71828182845905"
   ENDIF
   //
   I = FNArrayGetStackPushBufferI( tokenS, evalBufferI )
   //
    ELSEIF EquiStr( LeftStr( typeS, Length( "unary operator" ) ), "unary operator" )
   aS = FNArrayGetStackPopBufferS(evalBufferI)
   expressionS = ""
   //
  IF      EquiStr( tokenS, "sin")              expressionS = "[MATH]::Sin(" + aS + ")"
   ELSEIF EquiStr( tokenS, "cos")              expressionS = "[MATH]::Cos(" + aS + ")"
   ELSEIF EquiStr( tokenS, "tan")              expressionS = "[MATH]::Tan(" + aS + ")"
   ELSEIF EquiStr( tokenS, "abs" )             expressionS = "[MATH]::Abs(" + aS + ")"
   ELSEIF EquiStr( tokenS, "acos" )            expressionS = "[MATH]::Acos(" + aS + ")"
   ELSEIF EquiStr( tokenS, "atan" )            expressionS = "[MATH]::Atan(" + aS + ")"
   ELSEIF EquiStr( tokenS, "atan2" )           expressionS = "[MATH]::Atan2(" + aS + ")"
   ELSEIF EquiStr( tokenS, "ceiling" )         expressionS = "[MATH]::Ceiling(" + aS + ")"
   ELSEIF EquiStr( tokenS, "cosh" )            expressionS = "[MATH]::Cosh(" + aS + ")"
   ELSEIF EquiStr( tokenS, "divrem" )          expressionS = "[MATH]::DivRem(" + aS + ")"
   ELSEIF EquiStr( tokenS, "exp" )             expressionS = "[MATH]::Exp(" + aS + ")"
   ELSEIF EquiStr( tokenS, "floor" )           expressionS = "[MATH]::Floor(" + aS + ")"
   ELSEIF EquiStr( tokenS, "gethashcode" )     expressionS = "[MATH]::GetHashCode(" + aS + ")"
   ELSEIF EquiStr( tokenS, "gettype" )         expressionS = "[MATH]::GetType(" + aS + ")"
   ELSEIF EquiStr( tokenS, "ieeeremainder" )   expressionS = "[MATH]::IEEERemainder(" + aS + ")"
   ELSEIF EquiStr( tokenS, "ln" )              expressionS = "[MATH]::Log(" + aS + ")"
   ELSEIF EquiStr( tokenS, "log" )             expressionS = "[MATH]::Log10(" + aS + ")"
   ELSEIF EquiStr( tokenS, "sign" )            expressionS = "[MATH]::Sign(" + aS + ")"
   ELSEIF EquiStr( tokenS, "sinh" )            expressionS = "[MATH]::Sinh(" + aS + ")"
   ELSEIF EquiStr( tokenS, "sqrt" )            expressionS = "[MATH]::Sqrt(" + aS + ")"
   ELSEIF EquiStr( tokenS, "tanh" )            expressionS = "[MATH]::Tanh(" + aS + ")"
   ELSEIF EquiStr( tokenS, "tostring" )        expressionS = "[MATH]::ToString(" + aS + ")"
   ELSEIF EquiStr( tokenS, "truncate" )        expressionS = "[MATH]::Truncate(" + aS + ")"
   // ELSEIF EquiStr( tokenS, "_e_" )             expressionS = "[MATH]::e" // disable this because  _e_ is not a unary operator but a constant number, so should be hanlde elsewhere
   // ELSEIF EquiStr( tokenS, "_pi_" )            expressionS = "[MATH]::Pi" // disable this because  _pi_ is not a unary operator but a constant number, so should be hanlde elsewhere
   ELSE                                       expressionS = tokenS + "(" + aS + ")" // fallback
  ENDIF
  //
  I = FNArrayGetStackPushBufferI( expressionS, evalBufferI)
  //
  ELSEIF EquiStr( LeftStr( typeS, Length( "binary operator" ) ), "binary operator" ) // adjust type as needed
   bS = FNArrayGetStackPopBufferS(evalBufferI)
   aS = FNArrayGetStackPopBufferS(evalBufferI)
   expressionS = ""
   //
   IF     EquiStr( tokenS, "+")                expressionS = "(" + aS + " + " + bS + ")"
   ELSEIF EquiStr( tokenS, "-")                expressionS = "(" + aS + " - " + bS + ")"
   ELSEIF EquiStr( tokenS, "*")                expressionS = "(" + aS + " * " + bS + ")"
   ELSEIF EquiStr( tokenS, "/")                expressionS = "(" + aS + " / " + bS + ")"
   ELSEIF EquiStr( tokenS, "^")                expressionS = "[MATH]::Pow(" + aS + "," + bS + ")"
   ELSEIF EquiStr( tokenS, "bigmul" )          expressionS = "[MATH]::BigMul(" + aS + "," + bS + ")"
   ELSEIF EquiStr( tokenS, "equals" )          expressionS = "[MATH]::Equals(" + aS + "," + bS + ")"
   ELSEIF EquiStr( tokenS, "max" )             expressionS = "[MATH]::Max(" + aS + "," + bS + ")"
   ELSEIF EquiStr( tokenS, "min" )             expressionS = "[MATH]::Min(" + aS + "," + bS + ")"
   ELSEIF EquiStr( tokenS, "nthroot" )         expressionS = "[MATH]::Pow(" + aS + "," + "1/(" + bS + ")" + ")"
   ELSEIF EquiStr( tokenS, "round" )           expressionS = "[MATH]::Round(" + aS + "," + bS + ")"
   ELSE                                       expressionS = "(" + aS + " " + tokenS + " " + bS + ")" // fallback
   ENDIF
   //
   I = FNArrayGetStackPushBufferI( expressionS, evalBufferI)
   //
  ENDIF
  //
 ENDWHILE
 //
 // At this point, the final expression is on top
 expressionFinalS = FNArrayGetStackPopBufferS(evalBufferI)
 //
 s = expressionFinalS
 //
 // Run the expression in PowerShell as a one-liner
 s = FNStringGetMathPowershellS( s ) // calculate
 //
 PopBlock()
 PopPosition()
 //
 RETURN( s )
 //
END

// library: string: get: lexical: analyzer: space <description></description> <version control></version control> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=getstasp.s) [<Program>] [<Research>] [kn, ri, tu, 22-04-2025 13:31:11]
PROC PROCStringGetLexicalAnalyzerSpace()
 // e.g. // #DEFINE DEBUG 1
 // e.g. #DEFINE DEBUG 0
 // e.g. PROC Main()
 // e.g.  PROCStringGetLexicalAnalyzerSpace()
 // e.g. END
 // e.g.
 // e.g. <Ctrl F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // e.g. // QuickHelp( HELPDEFPROCStringGetLexicalAnalyzerSpace )
 // e.g. HELPDEF HELPDEFPROCStringGetLexicalAnalyzerSpace
 // e.g.  title = "PROCStringGetLexicalAnalyzerSpace() help" // The help's caption
 // e.g.  x = 100 // Location
 // e.g.  y = 3 // Location
 // e.g.  //
 // e.g.  // The actual help text
 // e.g.  //
 // e.g.  "Usage:"
 // e.g.  "//"
 // e.g.  "1. Run this TSE macro"
 // e.g.  "2. Then press <CtrlAlt F1> to show this help."
 // e.g.  "3. Press <Shift Escape> to quit."
 // e.g.  "//"
 // e.g.  ""
 // e.g.  "Key: Definitions:"
 // e.g.  ""
 // e.g.  "<> = do something"
 // e.g. END
 //
 STRING s[255] = ""
 //
 IF LFind( "\c{^[ ]#}", "cx" )
  s = GetFoundText()
  #IF DEBUG
   FNProjectWarning(Format( "space(s)", " ", s ))
   FNProjectWarning(Format( Length( s ) ))
  #ENDIF
  DO Length( s ) TIMES
   DelChar()
  ENDDO
 ENDIF
 //
END

// library: array: get: stack: pop: buffer <description></description> <version control></version control> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=getarpbu.s) [<Program>] [<Research>] [kn, ri, th, 15-05-2025 00:38:08]
STRING PROC FNArrayGetStackPopBufferS( INTEGER bufferI )
 // e.g. //
 // e.g. // #DEFINE DEBUG 1
 // e.g. #DEFINE DEBUG 0
 // e.g. //
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition() // 1
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition() // 2
 // e.g.  //
 // e.g.  Message( FNArrayGetStackPopBufferS( bufferI ) ) // gives e.g. "test"
 // e.g. END
 // e.g.
 // e.g. <Ctrl F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // e.g. // QuickHelp( HELPDEFFNArrayGetStackPopBufferS ) )
 // e.g. HELPDEF HELPDEFFNArrayGetStackPopBufferS )
 // e.g.  title = "FNArrayGetStackPopBufferS( Val( s1 ) ) help" // The help's caption
 // e.g.  x = 100 // Location
 // e.g.  y = 3 // Location
 // e.g.  //
 // e.g.  // The actual help text
 // e.g.  //
 // e.g.  "Usage:"
 // e.g.  "//"
 // e.g.  "1. Run this TSE macro"
 // e.g.  "2. Then press <CtrlAlt F1> to show this help."
 // e.g.  "3. Press <Shift Escape> to quit."
 // e.g.  "//"
 // e.g.  ""
 // e.g.  "Key: Definitions:"
 // e.g.  ""
 // e.g.  "<> = do something"
 // e.g. END
 //
 STRING s[255] = ""
 //
 PushPosition()
 PushBlock()
 //
 GotoBufferId( bufferI )
 //
 BegFile() // the top of the stack is here at the beginning of the buffer
 //
 s = GetText( 1, MAXSTRINGLEN )
 s = Trim( s )
 //
 DelLine()
 //
 PopBlock()
 PopPosition()
 //
 RETURN( s )
 //
END

// library: array: get: stack: top: buffer <description></description> <version control></version control> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=getartbw.s) [<Program>] [<Research>] [kn, ri, th, 15-05-2025 01:22:04]
STRING PROC FNArrayGetStackTopBufferS( INTEGER bufferI )
 // e.g. //
 // e.g. // #DEFINE DEBUG 1
 // e.g. #DEFINE DEBUG 0
 // e.g. //
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition() // 1
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition() // 2
 // e.g.  //
 // e.g.  Message( FNArrayGetStackTopBufferS( bufferI ) ) // gives e.g. "test"
 // e.g. END
 // e.g.
 // e.g. <Ctrl F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // e.g. // QuickHelp( HELPDEFFNArrayGetStackTopBufferS ) )
 // e.g. HELPDEF HELPDEFFNArrayGetStackTopBufferS )
 // e.g.  title = "FNArrayGetStackTopBufferS( Val( s1 ) ) help" // The help's caption
 // e.g.  x = 100 // Location
 // e.g.  y = 3 // Location
 // e.g.  //
 // e.g.  // The actual help text
 // e.g.  //
 // e.g.  "Usage:"
 // e.g.  "//"
 // e.g.  "1. Run this TSE macro"
 // e.g.  "2. Then press <CtrlAlt F1> to show this help."
 // e.g.  "3. Press <Shift Escape> to quit."
 // e.g.  "//"
 // e.g.  ""
 // e.g.  "Key: Definitions:"
 // e.g.  ""
 // e.g.  "<> = do something"
 // e.g. END
 //
 INTEGER topI = 1 // top of the stack is the first row
 //
 STRING s[255] = ""
 //
 PushPosition()
 PushBlock()
 //
 s = FNArrayGetStackRowBufferS( topI, bufferI )
 //
 PopBlock()
 PopPosition()
 //
 RETURN( s )
 //
END

// library: string: get: error <description>general output string to recognize an error (e.g. in another routine). Central routine, only one occurrence of this constant string</description> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=getstger.s) [<Program>] [<Research>] [kn, ri, sa, 05-12-1998 20:58:17]
STRING PROC FNStringGetErrorS()
 // e.g. PROC Main()
 // e.g.  Message( FNStringGetErrorS() ) // gives e.g. "<ERROR>"
 // e.g. END
 //
 RETURN( "<ERROR>" )
 //
END

// library: array: get: stack: search: buffer <description></description> <version control></version control> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=getarsbu.s) [<Program>] [<Research>] [kn, ri, th, 15-05-2025 00:51:44]
INTEGER PROC FNArrayGetStackSearchBufferI( STRING searchS, STRING searchOptionS, INTEGER bufferI )
 // e.g. //
 // e.g. // #DEFINE DEBUG 1
 // e.g. #DEFINE DEBUG 0
 // e.g. //
 // e.g. PROC Main()
 // e.g.  // STRING s1[255] = GetHistoryStr( GetFreeHistory("getstemk:expression"), 1 ) // change this
 // e.g.  STRING s1[255] = "x" // change this
 // e.g.  STRING s2[255] = "i" // change this
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  Message( FNArrayGetStackSearchBufferI( s1, s2, bufferI ) ) // gives e.g. 10
 // e.g. END
 // e.g.
 // e.g. <Ctrl F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // e.g. // QuickHelp( HELPDEFFNArrayGetStackSearchBufferI ) )
 // e.g. HELPDEF HELPDEFFNArrayGetStackSearchBufferI )
 // e.g.  title = "FNArrayGetStackSearchBufferI( s2, s3, Val( s1 ) ) help" // The help's caption
 // e.g.  x = 100 // Location
 // e.g.  y = 3 // Location
 // e.g.  //
 // e.g.  // The actual help text
 // e.g.  //
 // e.g.  "Usage:"
 // e.g.  "//"
 // e.g.  "1. Run this TSE macro"
 // e.g.  "2. Then press <CtrlAlt F1> to show this help."
 // e.g.  "3. Press <Shift Escape> to quit."
 // e.g.  "//"
 // e.g.  ""
 // e.g.  "Key: Definitions:"
 // e.g.  ""
 // e.g.  "<> = do something"
 // e.g. END
 //
 INTEGER I = 0
 //
 PushPosition()
 PushBlock()
 //
 GotoBufferId( bufferI )
 //
 IF LFind( searchS, searchOptionS )
  //
  I = CurrLine()
  //
 ELSE
  //
  FNProjectWarning(Format( searchS, ":", " ", "not found in the buffer. Please check." ))
  //
  I = FNMathGetErrorI()
  //
 ENDIF
 //
 PopBlock()
 PopPosition()
 //
 RETURN( I )
 //
END

// library: error: check <description>error: test if an integer error occurred</description> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=checerci.s) [<Program>] [<Research>] [[kn, zoe, th, 21-10-1999 00:58:35]
INTEGER PROC FNErrorCheckIB( INTEGER I )
 // e.g. PROC Main()
 // e.g.  Message( FNErrorCheckIB( -2147483647 ) ) // gives TRUE if you pass it the arbitrary integer value (e.g here -2147483647 has been chosen by me to indicate an error) that indicates an error.
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNMathCheckNumberEqualB( I, FNMathGetErrorI() ) )
 //
END

// library: array: get: stack: row: buffer <description></description> <version control></version control> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=getarrbu.s) [<Program>] [<Research>] [kn, ri, th, 15-05-2025 01:04:05]
STRING PROC FNArrayGetStackRowBufferS( INTEGER rowI, INTEGER bufferI )
 // e.g. //
 // e.g. // #DEFINE DEBUG 1
 // e.g. #DEFINE DEBUG 0
 // e.g. //
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  // STRING s1[255] = GetHistoryStr( GetFreeHistory("getstemk:expression"), 1 ) // change this
 // e.g.  STRING s1[255] = "" // change this
 // e.g.  STRING s2[255] = "" // change this
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  Message( FNArrayGetStackRowBufferS( Val( s1 ), bufferI ) ) // gives e.g. "test"
 // e.g. END
 // e.g.
 // e.g. <Ctrl F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // e.g. // QuickHelp( HELPDEFFNArrayGetStackRowBufferS, Val ) )
 // e.g. HELPDEF HELPDEFFNArrayGetStackRowBufferS, Val )
 // e.g.  title = "FNArrayGetStackRowBufferS( Val( s1 ), Val( s2 ) ) help" // The help's caption
 // e.g.  x = 100 // Location
 // e.g.  y = 3 // Location
 // e.g.  //
 // e.g.  // The actual help text
 // e.g.  //
 // e.g.  "Usage:"
 // e.g.  "//"
 // e.g.  "1. Run this TSE macro"
 // e.g.  "2. Then press <CtrlAlt F1> to show this help."
 // e.g.  "3. Press <Shift Escape> to quit."
 // e.g.  "//"
 // e.g.  ""
 // e.g.  "Key: Definitions:"
 // e.g.  ""
 // e.g.  "<> = do something"
 // e.g. END
 //
 STRING s[255] = ""
 //
 PushPosition()
 PushBlock()
 //
 GotoBufferId( bufferI )
 //
 GotoLine( rowI )
 s = GetText( 1, MAXSTRINGLEN )
 s = Trim( s )
 //
 PopBlock()
 PopPosition()
 //
 RETURN( s )
 //
END

// library: array: get: stack: push: buffer <description></description> <version control></version control> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=getarpbv.s) [<Program>] [<Research>] [kn, ri, th, 15-05-2025 00:38:26]
INTEGER PROC FNArrayGetStackPushBufferI( STRING s, INTEGER bufferI )
 // e.g. //
 // e.g. // #DEFINE DEBUG 1
 // e.g. #DEFINE DEBUG 0
 // e.g. //
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  // STRING s1[255] = GetHistoryStr( GetFreeHistory("getstemk:expression"), 1 ) // change this
 // e.g.  STRING s1[255] = "test" // change this
 // e.g.  Message( FNArrayGetStackPushBufferI( s1, bufferI ) ) // gives e.g. 10
 // e.g. END
 // e.g.
 // e.g. <Ctrl F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // e.g. // QuickHelp( HELPDEFFNArrayGetStackPushBufferI ) )
 // e.g. HELPDEF HELPDEFFNArrayGetStackPushBufferI )
 // e.g.  title = "FNArrayGetStackPushBufferI( s2, Val( s1 ) ) help" // The help's caption
 // e.g.  x = 100 // Location
 // e.g.  y = 3 // Location
 // e.g.  //
 // e.g.  // The actual help text
 // e.g.  //
 // e.g.  "Usage:"
 // e.g.  "//"
 // e.g.  "1. Run this TSE macro"
 // e.g.  "2. Then press <CtrlAlt F1> to show this help."
 // e.g.  "3. Press <Shift Escape> to quit."
 // e.g.  "//"
 // e.g.  ""
 // e.g.  "Key: Definitions:"
 // e.g.  ""
 // e.g.  "<> = do something"
 // e.g. END
 //
 INTEGER I = 0
 //
 PushPosition()
 PushBlock()
 //
 GotoBufferId( bufferI )
 //
 BegFile() // the top of the stack is here at the beginning of the buffer
 //
 InsertLine( s )
 //
 I = FNArrayGetStackTotalBufferI( bufferI )
 //
 PopBlock()
 PopPosition()
 //
 RETURN( I )
 //
END

// library: array: check: stack: empty: buffer <description></description> <version control></version control> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=checareb.s) [<Program>] [<Research>] [kn, ri, th, 15-05-2025 00:18:28]
INTEGER PROC FNArrayCheckStackEmptyBufferB( INTEGER bufferI )
 // e.g. //
 // e.g. // #DEFINE DEBUG 1
 // e.g. #DEFINE DEBUG 0
 // e.g. //
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition() // 1
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition() // 2
 // e.g.  //
 // e.g.  Message( FNArrayCheckStackEmptyBufferB( bufferI ) ) // gives e.g. TRUE
 // e.g. END
 // e.g.
 // e.g. <Ctrl F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // e.g. // QuickHelp( HELPDEFFNArrayCheckStackEmptyBufferB ) )
 // e.g. HELPDEF HELPDEFFNArrayCheckStackEmptyBufferB )
 // e.g.  title = "FNArrayCheckStackEmptyBufferB( Val( s1 ) ) help" // The help's caption
 // e.g.  x = 100 // Location
 // e.g.  y = 3 // Location
 // e.g.  //
 // e.g.  // The actual help text
 // e.g.  //
 // e.g.  "Usage:"
 // e.g.  "//"
 // e.g.  "1. Run this TSE macro"
 // e.g.  "2. Then press <CtrlAlt F1> to show this help."
 // e.g.  "3. Press <Shift Escape> to quit."
 // e.g.  "//"
 // e.g.  ""
 // e.g.  "Key: Definitions:"
 // e.g.  ""
 // e.g.  "<> = do something"
 // e.g. END
 //
 INTEGER I = 0
 //
 INTEGER B = FALSE
 //
 I = FNArrayGetStackTotalBufferI( bufferI )
 //
 B = ( I == 0 )
 //
 RETURN( B )
 //
END

// library: window: change: split: vertical: buffer2 <description></description> <version control></version control> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=chanwisb.s) [<Program>] [<Research>] [kn, ri, fr, 16-05-2025 00:02:47]
INTEGER PROC FNWindowChangeSplitVerticalBuffer2B( STRING title1S, STRING title2S, INTEGER buffer1I, INTEGER buffer2I )
 // e.g. //
 // e.g. // #DEFINE DEBUG 1
 // e.g. #DEFINE DEBUG 0
 // e.g. //
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  INTEGER buffer1I = 0
 // e.g.  INTEGER buffer2I = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer1I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer2I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  Message( FNWindowChangeSplitVerticalBuffer2B( "1", "2", buffer1I, buffer2I ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <Ctrl F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // e.g. // QuickHelp( HELPDEFFNWindowChangeSplitVerticalBuffer2B, Val ) )
 // e.g. HELPDEF HELPDEFFNWindowChangeSplitVerticalBuffer2B, Val )
 // e.g.  title = "FNWindowChangeSplitVerticalBuffer2B( s3, s4, Val( s1 ), Val( s2 ) ) help" // The help's caption
 // e.g.  x = 100 // Location
 // e.g.  y = 3 // Location
 // e.g.  //
 // e.g.  // The actual help text
 // e.g.  //
 // e.g.  "Usage:"
 // e.g.  "//"
 // e.g.  "1. Run this TSE macro"
 // e.g.  "2. Then press <CtrlAlt F1> to show this help."
 // e.g.  "3. Press <Shift Escape> to quit."
 // e.g.  "//"
 // e.g.  ""
 // e.g.  "Key: Definitions:"
 // e.g.  ""
 // e.g.  "<> = do something"
 // e.g. END
 //
 INTEGER B = FALSE
 //
 PushPosition()
 PushBlock()
 //
 OneWindow()
 //
 VWindow()
 //
 GotoWindow( 1 )
 GotoBufferId( buffer1I )
 BegFile()
 InsertLine( title1S )
 //
 GotoWindow( 2 )
 GotoBufferId( buffer2I )
 BegFile()
 InsertLine( title2S )
 //
 B = TRUE
 //
 UpDateDisplay() // IF WaitForKeyPressed( 0 ) ENDIF // Activate if using a loop
 //
 #IF DEBUG FNProjectWarning(Format( "Press any key" )) #ENDIF
 //
 GotoBufferId( buffer1I )
 BegFile()
 DelLine()
 //
 GotoBufferId( buffer2I )
 BegFile()
 DelLine()
 //
 PopBlock()
 PopPosition()
 //
 RETURN( B )
 //
END

// library: window: change: split: vertical: buffer3 <description></description> <version control></version control> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=chanwisc.s) [<Program>] [<Research>] [kn, ri, fr, 16-05-2025 00:03:14]
INTEGER PROC FNWindowChangeSplitVerticalBuffer3B( STRING title1S, STRING title2S, STRING title3S, INTEGER buffer1I, INTEGER buffer2I, INTEGER buffer3I )
 // e.g. //
 // e.g. // #DEFINE DEBUG 1
 // e.g. #DEFINE DEBUG 0
 // e.g. //
 // e.g. PROC Main()
 // e.g.  INTEGER buffer1I = 0
 // e.g.  INTEGER buffer2I = 0
 // e.g.  INTEGER buffer3I = 0
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer1I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer2I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  buffer3I = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  Message( FNWindowChangeSplitVerticalBuffer3B( "1", "2", "3", buffer1I, buffer2I, buffer3I ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <Ctrl F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // e.g. // QuickHelp( HELPDEFFNWindowChangeSplitVerticalBuffer3B, Val, Val ) )
 // e.g. HELPDEF HELPDEFFNWindowChangeSplitVerticalBuffer3B, Val, Val )
 // e.g.  title = "FNWindowChangeSplitVerticalBuffer3B( s4, s5, s6, Val( s1 ), Val( s2 ), Val( s3 ) ) help" // The help's caption
 // e.g.  x = 100 // Location
 // e.g.  y = 3 // Location
 // e.g.  //
 // e.g.  // The actual help text
 // e.g.  //
 // e.g.  "Usage:"
 // e.g.  "//"
 // e.g.  "1. Run this TSE macro"
 // e.g.  "2. Then press <CtrlAlt F1> to show this help."
 // e.g.  "3. Press <Shift Escape> to quit."
 // e.g.  "//"
 // e.g.  ""
 // e.g.  "Key: Definitions:"
 // e.g.  ""
 // e.g.  "<> = do something"
 // e.g. END
 //
 INTEGER B = FALSE
 //
 PushPosition()
 PushBlock()
 //
 OneWindow()
 VWindow() // 1 / 2
 VWindow() // 1 / 2 / 3
 //
 GotoWindow( 1 )
 GotoBufferId( buffer1I )
 BegFile()
 InsertLine( title1S )
 //
 GotoWindow( 2 )
 GotoBufferId( buffer2I )
 BegFile()
 InsertLine( title2S )
 //
 GotoWindow( 3 )
 GotoBufferId( buffer3I )
 BegFile()
 InsertLine( title3S )
 //
 UpDateDisplay() // IF WaitForKeyPressed( 0 ) ENDIF // Activate if using a loop
 //
 #IF DEBUG FNProjectWarning(Format( "Press any key" )) #ENDIF
 //
 GotoBufferId( buffer1I )
 BegFile()
 DelLine()
 //
 GotoBufferId( buffer2I )
 BegFile()
 DelLine()
 //
 GotoBufferId( buffer3I )
 BegFile()
 DelLine()
 //
 B = TRUE
 //
 PopBlock()
 PopPosition()
 //
 RETURN( B )
 //
END

// library: buffer: change: revert <description></description> <version control></version control> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=chanbucr.s) [<Program>] [<Research>] [kn, ri, th, 19-06-2025 16:36:44]
INTEGER PROC FNBufferChangeRevertB( INTEGER bufferI )
 // e.g. //
 // e.g. // #DEFINE DEBUG 1
 // e.g. #DEFINE DEBUG 0
 // e.g. //
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  INTEGER bufferI
 // e.g.  //
 // e.g.  PushPosition()
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition()
 // e.g.  //
 // e.g.  AddLine( "a", bufferI )
 // e.g.  AddLine( "b", bufferI )
 // e.g.  AddLine( "c", bufferI )
 // e.g.  AddLine( "d", bufferI )
 // e.g.  AddLine( "e", bufferI )
 // e.g.  AddLine( "f", bufferI )
 // e.g.  AddLine( "g", bufferI )
 // e.g.  AddLine( "h", bufferI )
 // e.g.  AddLine( "i", bufferI )
 // e.g.  AddLine( "j", bufferI )
 // e.g.  AddLine( "k", bufferI )
 // e.g.  //
 // e.g.  Message( FNBufferChangeRevertB( bufferI ) ) // gives e.g. TRUE
 // e.g.  //
 // e.g.  GotoBufferId( bufferI )
 // e.g.  //
 // e.g. END
 // e.g.
 // e.g. <Ctrl F12> Main()
 //
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // e.g. // QuickHelp( HELPDEFFNBufferChangeRevertB  ) )
 // e.g. HELPDEF HELPDEFFNBufferChangeRevertB  )
 // e.g.  title = "FNBufferChangeRevertB( Val( s1 )  ) help" // The help's caption
 // e.g.  x = 100 // Location
 // e.g.  y = 3 // Location
 // e.g.  //
 // e.g.  // The actual help text
 // e.g.  //
 // e.g.  "Usage:"
 // e.g.  "//"
 // e.g.  "1. Run this TSE macro"
 // e.g.  "2. Then press <CtrlAlt F1> to show this help."
 // e.g.  "3. Press <Shift Escape> to quit."
 // e.g.  "//"
 // e.g.  ""
 // e.g.  "Key: Definitions:"
 // e.g.  ""
 // e.g.  "<> = do something"
 // e.g. END
 //
 INTEGER B = FALSE
 //
 INTEGER I = 0
 //
 STRING s1[255] = ""
 STRING s2[255] = ""
 //
 PushPosition()
 PushBlock()
 //
 GotoBufferId( bufferI )
 //
 FOR I = 1 TO NumLines() / 2
  GotoLine( I )
  s1 = GetText( 1, 255 )
  GotoLine( NumLines() - I + 1 )
  s2 = GetText( 1, 255 )
  GotoLine( I )
  BegLine()
  DelToEol()
  BegLine()
  InsertText( s2, _INSERT_ )
  //
  GotoLine( NumLines() - I + 1 )
  BegLine()
  DelToEol()
  BegLine()
  InsertText( s1, _INSERT_ )
 ENDFOR
 //
 PopBlock()
 PopPosition()
 //
 B = TRUE
 //
 RETURN( B )
 //
END

// library: string: get: math: powershell <description></description> <version control></version control> <version>1.0.0.0.362</version <version control></version control> (filenamemacro=getstmpt.s) [<Program>] [<Research>] [kn, ri, tu, 20-05-2025 10:38:59]
STRING PROC FNStringGetMathPowershellS( STRING expressionInS )
 integer originalBuffer = GetBufferId()
 integer scratchBuffer = 0
 integer sequence = 1
 integer ready = FALSE
 integer exitCode = 0
 string root[255] = SplitPath(CurrMacroFilename(), _DRIVE_ | _PATH_)
 string stem[80] = ""
 string scriptFile[255] = ""
 string resultFile[255] = ""
 string batchFile[255] = ""
 string result[255] = FNStringGetErrorS()
 GSCalculatorFailure = ""
 GSCalculatorLog = ""
 PushPosition()
 PushBlock()
 repeat
  stem = "proj0200_calculator_" + Str(sequence)
  sequence = sequence + 1
 until not FileExists(root + stem + ".ps1") and not FileExists(root + stem + ".log") and not FileExists(root + stem + ".bat")
 scriptFile = root + stem + ".ps1"
 resultFile = root + stem + ".log"
 batchFile = root + stem + ".bat"
 GSCalculatorLog = resultFile
 scratchBuffer = CreateTempBuffer()
 AddLine("$ErrorActionPreference = 'Stop'")
 AddLine("try {")
 AddLine("$value = " + expressionInS)
 AddLine("[Console]::WriteLine('PROJ0200_RESULT=' + [Convert]::ToString($value, [Globalization.CultureInfo]::InvariantCulture))")
 AddLine("} catch { [Console]::WriteLine('PROJ0200_ERROR=' + $_.Exception.Message); exit 1 }")
 // PowerShell stdin requires an empty line to execute a multiline block.
 AddLine("")
 AddLine("")
 if SaveAs(scriptFile, _DONT_PROMPT_ | _OVERWRITE_)
  EmptyBuffer()
  AddLine("@echo off")
  AddLine("cd /d " + QuotePath(root))
  AddLine('powershell.exe -NoLogo -NoProfile -NonInteractive -Command - <"' + stem + '.ps1" >"' + stem + '.log" 2>&1')
  if SaveAs(batchFile, _DONT_PROMPT_ | _OVERWRITE_)
   exitCode = Dos('cmd.exe /d /c ""' + batchFile + '""', _DONT_PROMPT_)
   EmptyBuffer()
   if InsertFile(resultFile, _DONT_PROMPT_)
    BegFile()
    if lFind("PROJ0200_RESULT=", "g")
     result = Trim(GetText(CurrPos() + 15, 255))
     ready = Length(result) > 0
    else
     BegFile()
     if lFind("PROJ0200_ERROR=", "g")
      GSCalculatorFailure = Trim(GetText(CurrPos() + 14, 255))
     endif
     result = FNStringGetErrorS()
    endif
   endif
  endif
 endif
 if not ready or Length(result) == 0
  result = FNStringGetErrorS()
 endif
 if not ready
  // Preserve captured output, and add diagnostics even when it was empty.
  EndFile()
  AddLine("")
  AddLine("PROJ0200 calculator 1.0.0.0.362")
  AddLine("No non-empty PROJ0200_RESULT marker was received.")
  AddLine("Expression: " + expressionInS)
  AddLine("Dos return: " + Str(exitCode))
  AddLine("Script: " + scriptFile)
  AddLine("Batch: " + batchFile)
  if not SaveAs(resultFile, _DONT_PROMPT_ | _OVERWRITE_)
   GSCalculatorFailure = "Could not save the calculator diagnostic log."
  endif
 endif
 AbandonFile(scratchBuffer)
 if ready
  EraseDiskFile(scriptFile)
  EraseDiskFile(resultFile)
  EraseDiskFile(batchFile)
 else
  if not Length(GSCalculatorFailure)
   GSCalculatorFailure = "PowerShell launch/result failed (Dos return " + Str(exitCode) + ")."
  endif
  GSCalculatorFailure = GSCalculatorFailure + " Diagnostics: " + resultFile
 endif
 GotoBufferId(originalBuffer)
 PopBlock()
 PopPosition()
 return(result)
END

// library: math: get: error <description>indicate, via the returned number, that an error occurred</description> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=getmager.s) [<Program>] [<Research>] [kn, ri, th, 29-04-1999 21:19:56]
INTEGER PROC FNMathGetErrorI()
 // e.g. PROC Main()
 // e.g.  Message( FNMathGetErrorI() ) // gives e.g. -( 2^31 - 1 ) = -2147483647
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( FNMathGetIntegerMinimumAbsoluteI() )
 //
END

// library: math: number: compare: equal: number1 EQUAL TO number2? <description></description> <version control></version control> <version>1.0.0.0.362</version> (filenamemacro=checmane.s) [<Program>] [<Research>] [kn, ri, th, 03-05-2001 12:51:27]
INTEGER PROC FNMathCheckNumberEqualB( INTEGER x1, INTEGER x2 )
 // e.g. PROC Main()
 // e.g.  Message( FNMathCheckNumberEqualB( 3, 3 ) ) // gives TRUE
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( x1 == x2 )
 //
END

// library: array: get: stack: total: buffer <description></description> <version control></version control> <version>1.0.0.0.362</version> <version control></version control> (filenamemacro=getartbv.s) [<Program>] [<Research>] [kn, ri, th, 15-05-2025 00:41:12]
INTEGER PROC FNArrayGetStackTotalBufferI( INTEGER bufferI )
 // e.g. //
 // e.g. // #DEFINE DEBUG 1
 // e.g. #DEFINE DEBUG 0
 // e.g. //
 // e.g. PROC Main()
 // e.g.  //
 // e.g.  INTEGER bufferI = 0
 // e.g.  //
 // e.g.  PushPosition() // 1
 // e.g.  bufferI = CreateTempBuffer()
 // e.g.  PopPosition() // 2
 // e.g.  //
 // e.g.  Message( FNArrayGetStackTotalBufferI( bufferI ) ) // gives e.g. 10
 // e.g. END
 // e.g.
 // e.g. <Ctrl F12> Main()
 //
 // ===
 //
 // Use case =
 //
 // ===
 //
 // ===
 //
 // Method =
 //
 // ===
 //
 // ===
 //
 // Example:
 //
 // Input:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // Output:
 //
 /*
--- cut here: begin --------------------------------------------------
--- cut here: end ----------------------------------------------------
 */
 //
 // ===
 //
 // e.g. // QuickHelp( HELPDEFFNArrayGetStackTotalBufferI ) )
 // e.g. HELPDEF HELPDEFFNArrayGetStackTotalBufferI )
 // e.g.  title = "FNArrayGetStackTotalBufferI( Val( s1 ) ) help" // The help's caption
 // e.g.  x = 100 // Location
 // e.g.  y = 3 // Location
 // e.g.  //
 // e.g.  // The actual help text
 // e.g.  //
 // e.g.  "Usage:"
 // e.g.  "//"
 // e.g.  "1. Run this TSE macro"
 // e.g.  "2. Then press <CtrlAlt F1> to show this help."
 // e.g.  "3. Press <Shift Escape> to quit."
 // e.g.  "//"
 // e.g.  ""
 // e.g.  "Key: Definitions:"
 // e.g.  ""
 // e.g.  "<> = do something"
 // e.g. END
 //
 INTEGER I = 0
 //
 PushPosition()
 PushBlock()
 //
 GotoBufferId( bufferI )
 //
 I = NumLines()
 //
 PopBlock()
 PopPosition()
 //
 RETURN( I )
 //
END

// library: math: get: integer: minimum: absolute <description></description> <version control></version control> <version>1.0.0.0.362</version> (filenamemacro=getmamab.s) [<Program>] [<Research>] [kn, noot, mo, 09-07-2001 11:51:54]
INTEGER PROC FNMathGetIntegerMinimumAbsoluteI()
 // e.g. PROC Main()
 // e.g.  Message( FNMathGetIntegerMinimumAbsoluteI() ) // gives always a negative integer. E.g. -4
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( - FNMathGetIntegerMaximumAbsoluteI() )
 //
END

// library: math: get: integer: maximum: absolute <description></description> <version control></version control> <version>1.0.0.0.362</version> (filenamemacro=getmamac.s) [<Program>] [<Research>] [kn, noot, mo, 09-07-2001 11:51:54]
INTEGER PROC FNMathGetIntegerMaximumAbsoluteI()
 // e.g. PROC Main()
 // e.g.  Message( FNMathGetIntegerMaximumAbsoluteI() ) // gives the maximum value of an integer possible in TSE. This is currently 2147483647 (= 2^31 - 1. Note this is not 2^32 - 1 even if 32 bits, because 1 bit is reserved for the sign (thus '+' or '-'), as it are signed integers by design in TSE).
 // e.g. END
 // e.g.
 // e.g. <F12> Main()
 //
 RETURN( MAXINT )
 //
END

// PROJ0200 1.0.0.0.362 - OpenAI Codex (GPT-6)
// Set() returns the previous value; restore it after all actions return.
proc Main()
    integer IOldCommonDialogs = Set(UseCommonDialogs, FNProjectWindowsDialogs())
    PROCProjectMainActions()
    Set(UseCommonDialogs, IOldCommonDialogs)
end
