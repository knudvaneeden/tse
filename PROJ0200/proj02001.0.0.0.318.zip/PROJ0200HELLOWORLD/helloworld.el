( princ "Hello world" )
