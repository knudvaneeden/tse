greet[] := "Hello"
Print[greet[]]
