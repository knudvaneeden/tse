# PROJ0200 timestamped file merging

Package 1.0.0.0.534. Implementation adapted from Knud van Eeden's supplied
sortblck.s workflow, sortblfu.s timestamp handling, and log format definitions.

## First test

1. Build the package with your SAL compiler and restart TSE.
2. Set `mergesortexe` in `proj0200.ini` to your Cygwin/GNU sort executable:

   ```ini
   mergesortexe=G:\CYGWIN\bin\sort.exe
   singleline=true
   mergetempdirectory=
   ```

3. Open **Merge projects > Merge the two bundled test logs...**.
4. Choose a new output filename. Existing files and open buffers are refused.
5. Expect **43 records from 2 files**. The samples are `ddd01.log` and
   `ddd02.log` in the package root; no files need copying to C:\TEMP.
6. Open the result when prompted. `DOCS/proj0200_merge_expected.log` is the
   reference output generated from the same samples. Its source paths use
   C:\TEMP; your result correctly names the actual PROJ0200 directory.

The explicit test list `proj0200_merge_test.txt` uses:

```text
PROJ0200: pjllog; ddd01.log
PROJ0200: pjllog; ddd02.log
```

Relative paths in merge lists and settings are resolved from the package root.
The sample contents, including their historical version labels, are preserved.
The two test logs intentionally contain dates in a nonchronological order.

## File scopes

- Merge all files in the TSE ring.
- Merge all files in the current project.
- Merge all files in all projects.
- Merge all files in all projects + the TSE ring.

The project scopes use the existing project path collector, including saved
projects and current in-memory membership. Merge scans all physical files
under these paths, independently of the Known file types filter, then applies
its own exclusions. Named ring files are enumerated with `_DONT_LOAD_`.
Input files are not opened in editor buffers or removed from the ring.
All scopes merge the saved contents on disk. Save edits before merging if
those edits should appear in the output. Unsaved/unnamed buffers have no disk
contents to merge. Archive containers are excluded by default; this feature
does not expand archive members. Duplicate source paths are merged only once.

## Output and large files

Each first record line has this layout:

```text
YYYY-MM-DD HH:MM:SS; source line number; full source filename; message
```

`singleline=true` (the default) includes only the timestamped first line
of each record. `false` includes that line and its continuation lines up to the
next recognizable timestamp in the same source file. Lines before the first
timestamp are skipped with a WARN entry. Files with no recognized complete
date/time are skipped with a WARN entry.

The worker streams input one physical line at a time. Normalized records go
to a temporary disk spool, while a separate short index contains timestamp,
source ordinal, source line number, and 64-bit spool offset and record length.
Cygwin `sort.exe` sorts this index using `LC_ALL=C`, `--stable`, and a 64 MiB
sort buffer. The helper copies sorted records from disk in 64 KiB chunks.
Equal timestamps preserve source-list order and original source-line order.
The complete input, result, and full blocks are never accumulated in a TSE
buffer. The longest individual physical input line still requires memory.

Windows PowerShell 5.1 or newer performs the streaming disk I/O and invokes
the configured external sort. This follows the package's existing helper
model and avoids SAL's 255-character strings and 32-bit byte offsets. No new
compiled helper executable is required. Actual Cygwin/Windows execution and
Windows SAL compilation must be tested with your local installation.

Leave `mergetempdirectory` empty for Windows TEMP or set a disk directory with
sufficient free space for the record spool, sorted index, sort scratch and
output. Temporary files are removed after completion/failure. Output is
published only after successful sorting/reconstruction and is never allowed
to replace an input or an existing result. The completed output can be opened
when prompted; opening a gigabyte-sized result can consume editor memory.

Text uses the system Windows ANSI encoding, matching the package's legacy
text files; BOM-marked input is decoded by StreamReader. Binary inputs with
NUL characters are skipped. Timestamps are normalized to seconds, as in the
supplied workflow. Fractional seconds do not distinguish sort keys, and time
zones are not converted to UTC: records sort by their written wall-clock
values. Missing-year formats are not assigned an invented year.

## Exclusions and explicit types

`mergeexcludeextensions` in `proj0200.ini` accepts extensions without dots,
separated by spaces, commas or semicolons. Matching is case insensitive.
Common binaries and archive containers are excluded by default.

**Edit merge filename exclusions...** opens `proj0200_merge_exclude.txt`.
Use one expression per line; blank lines and lines starting with `;` are
ignored. Each expression is tested against both the basename and full path,
ignoring case. The supported TSE-style subset is `. * + ? ^ $ |`, character
classes including `[~...]`, tagged groups `{...}`, and escaped literal
characters. TSE-specific `@` and `#` operators are rejected explicitly; escape
them when literal characters are intended. A malformed expression stops the
merge with an error. Generated merge artifacts/results are excluded by default.

**Edit merge log type overrides...** opens `proj0200_merge_types.txt`.
Assign an exact file using:

```text
Tomcat: catalina.log; C:\logs\catalina.2026-10-20.log
PROJ0200: pjllog; C:\TEMP\ddd01.log
```

Unknown explicit type names are errors. Without an override, filename hints
prioritize candidate formats, and file contents must yield a valid date/time.
If only a timestamp pattern is recognized, the report calls it a generic
format with unconfirmed origin rather than claiming to know the originating
application. After detecting a file's format, that format is used throughout
that file. Mixed formats in a single file are not currently supported.

## Format definitions and reports

**Edit merge timestamp formats...** opens the runtime configuration
`proj0200_merge_formats.json`. It contains 68 complete-date entries: 67 from
the supplied 68-row CSV plus PROJ0200: pjllog. The missing-year Linux entry
cannot form a complete timestamp and is omitted. The supplied CSV and the
22-expression list are retained unchanged in the package root as references.
The runtime JSON is the editable configuration; changing those reference
files alone does not change the runtime JSON. Each JSON definition contains
a TSE-style pattern and zero-based year/month/day/time capture-group order.
The original software is preserved under `DOCS/MERGE_REFERENCE` for reference;
it is not compiled because its local paths/optional tools are system specific.

Each run writes a unique `mergeYYYYMMDDHHMMSS_<suffix>.log` in the package root,
using INFO, WARN and ERROR. It records resolved formats, file counts, exclusions,
unrecognized files, failures and the output path. `proj0200_merge_status.txt`
is the current run's small status file used by the SAL dialog. Sorting failures
never publish a partial successful result. A per-file read/regex failure discards
that file's partial spool/index entries and reports it as skipped.

## Validation performed here

- All runtime patterns compiled with the explicit syntax translation; capture
  indexes were checked. The supplied 22 expressions were checked as well.
- A reference implementation of the disk-index algorithm, using GNU sort,
  reproduced the expected 43-record sample output byte for byte (C:\TEMP paths).
- Additional checks covered multiline record reconstruction, equal-time
  ordering, skipped preambles and first-line-only operation.
- The PowerShell helper passed a PowerShell grammar syntax parse.
- These checks do not replace executing the actual helper under Windows
  PowerShell/Cygwin or compiling the SAL source with sc32.exe.

## PROJ0200 log types

The following explicit labels use `YYYY-MM-DD HH:MM:SS` timestamps:

```text
FileVersionControleSubversion: subversionlog; proj0200_svn_log.txt
FileVersionControleGit: gitlog; proj0200_git_log.txt
PROJ0200: mergelog; proj0200_merge_ui.log
PROJ0200: pjllog; ddd01.log
```

Replace the filenames with the desired full or package-relative paths in the
log type overrides file. Use `PROJ0200: mergelog` also for a previous
`mergeYYYYMMDDHHMMSS_XXXXXXXX.log` diagnostic journal. The journal currently
being written is always excluded; previous journals are eligible inputs.
Generated merged result files (`merged_...`) remain excluded by default.

New Subversion/Git helper logs timestamp each diagnostic line with INFO or
ERROR severity. These are operation logs, not repository commit-history logs.
Existing logs without timestamps cannot be assigned accurate event times;
regenerate them by running the corresponding operation. No dates are invented.

## Merge all PROJ0200 logs

Choose **Merge projects > P: Merge all PROJ0200 logs**. The file list is
rebuilt on every run from the main PROJ0200 directory: all `.log` files,
plus `.txt` files whose names start with `proj0200_` and contain `log`
(including `proj0200_svn_log.txt` and `proj0200_git_log.txt`). This includes
PJL, command-line, merge UI and previous merge diagnostic logs. Future
matching log files are discovered automatically; no active project is needed.
The bundled `ddd01.log` and `ddd02.log` are also eligible `.log` files.

The normal filename/extension exclusions still apply. Generated `merged_...`
results are excluded by default, and the running merge's own diagnostic
journal is always excluded. Files without recognizable timestamps are
reported as skipped. Logs in subdirectories or other directories use the
existing project/ring merge options instead.


## Additional operation/compiler logs

The all-logs action also includes preserved compiler diagnostics, backup, Visustin,
drawing ZIP, timelog and calculator diagnostics. See [logs_and_compiler_diagnostics.md](logs_and_compiler_diagnostics.md)
for discovery and explicitly labelled file-modification-time fallback for undated
input. Other merge actions continue to require recognizable timestamps.
