# Search inclusions and exclusions

PROJ0200 1.0.0.0.534

Use **Search projects > ?: Edit search inclusions...** for shared or
engine-specific inclusion files. They use the same four sections and mask
syntax documented below. Empty inclusion files allow all items. When an
inclusion section has masks, only matching items in that category are searched.
Directory ancestors remain traversable so included descendants can be reached.
Explicit exclusion rules always win. The distributed inclusion files contain
only comments; specify one mask per line rather than a semicolon-separated list.

Open **Search projects > E: Edit search exclusions >** and choose:

- **S: Shared search exclusions...** -> search_exclude.txt
- **F: FILEFIN2 exclusions...** -> filefin2_exclude.txt
- **G: GREPZIP exclusions...** -> grepzip_exclude.txt

Save the edited file before searching. Rules are reloaded for each search;
there is no need to rebuild SAL after changing rules. FILEFIN2 uses shared plus
FILEFIN2 rules. GREPZIP uses shared plus GREPZIP rules. The union applies:
a rule in either file excludes the matching item. Empty or missing files add
no exclusions. The distributed files contain only commented examples.

## Format

```ini
[files]
*.bak
*.tmp
old_*

[directories]
.git
.svn
C:/TEMP/backups

[members]
*.class
private/*

[archives]
old_*.zip
vendor.7z
```

One mask per line. Matching ignores case. `*` matches zero or more characters;
`?` matches exactly one character. Other characters, including square brackets,
are literal; these rules are not regular expressions. A leading `;` or `#`
disables a line. Blank lines are ignored. Do not quote masks, append inline
comments, or separate several masks with semicolons. Use at most 254 characters
per mask. Section names are case insensitive.

Backslashes and forward slashes are interchangeable. A mask without a slash
matches the last filename or directory component at any level. A mask with a
slash matches a complete path within its physical-file or archive-member
segment. Thus `private/*` matches the member path `private/notes.txt`, while
`*/private/*` can match a deeper member path. `C:/TEMP/backups` excludes that
physical directory and its descendants. A trailing directory slash is optional.
`*` may cross directory separators. `*.*` in an exclusion is literal DOS-style
star-dot-star: it only matches names containing a dot; use `*` to exclude all.

- **[files]** excludes physical filenames and archive member filenames.
  An excluded archive filename is not opened for searching.
- **[directories]** excludes files below matching directories, both physical
  directories and directory paths inside archives.
- **[members]** excludes names inside archives only, leaving matching ordinary
  disk files searchable.
- **[archives]** excludes whole archives, including nested archives and all
  their descendants. Recognized archive extensions include ZIP, JAR, TAR, TGZ,
  GZ/GZIP, RAR, 7Z, BZ2 and XZ; actual format support still depends on the engine.

Nested archive segments are checked separately. A nested archive named
`old_inner.zip` matches `[archives] old_*.zip` even when the outer archive has
another name. No inclusion/override rules are provided; remove or comment an
exclusion to include the item again.

## Which searches use the rules?

FILEFIN2's directory/archive filename search and the three project filename
search scopes use shared + FILEFIN2 rules. The archive-aware project content
searches and the TSE-ring content search use shared + GREPZIP rules. This does
not alter TSE's ordinary Find/Replace, legacy Find across open files, project
membership, backups, merges, or file refresh operations.

Excluded top-level archives are skipped before opening. ZIP member exclusions
are checked before member extraction or recursive expansion in the updated
PowerShell helper. Nested archive exclusions stop recursion into those archives.
The existing FILEFIN2 DLL still enumerates physical directory metadata and ZIP
central-directory metadata; exclusions filter those entries before searching.
GREPZIP prunes excluded physical directory trees. Its external TAR/RAR/7Z
extraction may unpack excluded members in bulk, but those members are not
searched and excluded nested archives are not recursively expanded.

The DLL binaries are unchanged; no DLL rebuild is required. The SAL adapters
and PowerShell helpers enforce the rules. Keep proj0200_search_exclude.ps1
beside zip_nested.ps1 and proj0200_archive_helper.ps1.

## Windows verification

1. Create ordinary files `keep.txt`, `skip.tmp`, and `folder/keep.txt`, all
   containing `needle`. Create a ZIP containing the same paths plus a nested
   `old_inner.zip` with another `keep.txt` containing `needle`.
2. With empty rules, run FILEFIN2 with `*` and archives enabled, then the
   archive-aware content search for `needle`. Verify the baseline hits.
3. In shared `[files]`, add `*.tmp`. Save; verify both engines omit skip.tmp
   on disk and inside the archive.
4. In FILEFIN2-only `[directories]`, add `folder`. Save; verify FILEFIN2 omits
   folder/keep.txt while GREPZIP still includes it.
5. In GREPZIP-only `[members]`, add `keep.txt`. Save; verify ordinary keep.txt
   remains searchable but archive member keep.txt is omitted by GREPZIP.
6. In shared `[archives]`, add `old_*.zip`. Save; verify both engines omit that
   nested archive and its descendants. Add the outer ZIP's filename and verify
   that archive is not scanned at all.
7. Comment the rules and repeat. Confirm restored hits, mixed-case masks,
   backslash paths, ring files outside projects, and unmodified backup/merge
   collection. These runtime checks require Windows TSE and PowerShell.
