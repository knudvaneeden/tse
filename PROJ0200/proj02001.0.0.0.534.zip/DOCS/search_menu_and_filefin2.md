# Search menu and FILEFIN2 launch

PROJ0200 1.0.0.0.534

The main **Search projects >** entry now immediately follows **Save projects >**.

**Search projects > Q: Simple search options (original PROJECTS) >** exposes
the complete search menu from the attached projects.s:

- Audit bookmarks forward and reverse.
- Same file: Find, Repeat find forward/reverse, Find word at cursor
  forward/reverse, and Replace.
- Multi-file: Find, Repeat find forward/reverse, Find word at cursor
  forward/reverse, and Replace.
- Toggle to previous file.

These call the existing original PROJECTS routines in projsession.mac; they
keep that worker's find-history and audit-bookmark behavior. The existing
current-file, open-file, archive-aware, filename, and exclusion searches remain
available. These original simple searches use their own search behavior; the
FILEFIN2/GREPZIP exclusion files do not change native Find/Replace.

## FILEFIN2 launch correction and diagnostics

FILEFIN2 is now requested as a deferred main-menu action. The project menus
close before projfflaunch.mac checks dependencies, enters the package directory,
purges any older resident filefin2 macro, explicitly loads filefin2.mac and then
executes its Main. It restores the prior working directory afterward. This
avoids launching the DLL-backed macro while the project menus are active and
ensures a rebuilt SAL file is used. The DLL binaries themselves are unchanged.

The original silent-return cause could not be reproduced in the Linux build
environment. The changed launch sequence addresses menu/resident-macro issues;
a timestamped trace now identifies whether execution reaches each stage:

1. Deferred launch requested.
2. Dependency checks and LoadMacro.
3. Entered FILEFIN2 Main.
4. Filename prompt, directory prompt and archive-choice menu.
5. Search started, match count, completion or cancellation.

The trace is **proj0200_search.log**, with INFO/WARN/ERROR records. Open it using
**Load projects > Load logs > H: Load search diagnostics log**. The all-logs
browser and Merge all PROJ0200 logs discover it automatically. Failed dependency
or loading checks give a visible warning. A cancelled input is logged as such.
No filename mask or file contents are recorded; the selected directory string
is recorded to help diagnose scope problems.

Rebuild with build.bat and restart TSE before testing, especially after replacing
DLLs. Choose FILEFIN2 and verify that the filename prompt appears. If it still
returns immediately, inspect the search log: the last recorded stage shows
whether the issue occurred before DLL loading, before Main, or during input.
Directly executing projfflaunch.mac uses the same launch path and trace.
Windows SAL/DLL/runtime verification is still required.


## Shared handoff correction

The previous build still returned to the main menu for both Simple searches
and FILEFIN2. The handoff is now changed for every search-menu action:

1. The main Search projects entry uses CloseAllBefore, closing the project menu
   before the external search menu opens.
2. The selected search callback immediately records PROJ_PendingSearchChoice.
3. After ProjectMenu returns, the main menu loop consumes that choice exactly
   once and dispatches it outside the menu callback. Deferred session actions
   are then handled by the existing main-loop session dispatcher.

PROJ_SearchMenu no longer reads a selected return value or dispatches after
ExecMacro returns. That removes reliance on continuation through cross-macro
CloseAllBefore handling. Opening the menu and each selected action are traced
independently of the FILEFIN2 loader. The log should show action 20 for Simple
searches and action 13 for FILEFIN2. FILEFIN2 then logs the main-menu dispatch
number and its loader/prompt stages. Cancelling a search menu records no choice.

Rebuild, restart TSE and test Q and U with both mouse and keyboard. Q should
open the original simple-search menu; U should display FILEFIN2's filename
prompt. Escape should return to the main menu. Repeat both selections in the
same TSE session and try an ordinary current-file search to check the shared
handoff. If either still fails, provide proj0200_search.log: selection tracing
now begins before the previously silent handoff. These runtime results remain
to be verified on Windows.
