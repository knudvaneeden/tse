@ECHO OFF
SETLOCAL EnableExtensions DisableDelayedExpansion
REM COMPOWERSHELL.BAT version 1.0.0.0.9
REM Run POWERSHELL program - Knud van Eeden / OpenAI GPT-6
REM
REM PART 1 - USER SETTINGS: installation-specific values belong here.
SET "CPS_EXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
REM PowerShell 7 alternative: full path to pwsh.exe.
SET "CPS_POLICY=Bypass"
SET "CPS_PAUSE=1"
SET "CPS_HELLO=%~dp0helloworld.ps1"
SET "CPS_ERRORS=%~dp0errorstest.ps1"
REM Tests expect the two supplied example files beside this BAT by default.
REM Change CPS_HELLO / CPS_ERRORS if you store them in different directories.
REM Optional executable override: set COMPOWERSHELL_EXE before invoking BAT.
REM Optional automation setting: set COMPOWERSHELL_NOPAUSE=1.
REM
REM Supported invocations:
REM   COMPOWERSHELL.BAT "C:\Scripts\helloworld.ps1"
REM   COMPOWERSHELL.BAT --exe "C:\Program Files\PowerShell\7\pwsh.exe" "C:\Scripts\helloworld.ps1"
REM TSE's six parameters keep their original meaning:
REM   1=name, 2=extension, 3=source, 4=drive, 5=path, 6=output log.
REM   COMPOWERSHELL.BAT "helloworld" ".ps1" "C:\Scripts\helloworld.ps1" "C:" "\Scripts\" "C:\Temp\powershell.log"
REM Quote every TSE parameter. Use CALL when invoked from another BAT.
REM The supplied TSE rule invokes the six-parameter form.
REM Source script arguments are not supported by this interface.
REM The script runs once; syntax is checked before execution.
REM No helper script is generated. Only diagnostic text logs are created.
REM Logs are overwritten; their parent directory must already exist.
REM Use ordinary Windows paths; literal percent signs are unsupported by CALL.
REM
REM Tests for BOTH shells, from the directory containing this BAT:
REM   cmd.exe /D /C COMPOWERSHELL.BAT --test
REM   "G:\UTILS\JPSOFT\TCMD\tcc.exe" /C COMPOWERSHELL.BAT --test
REM Substitute your own TCC installation path.
REM   COMPOWERSHELL.BAT --test "C:\Program Files\PowerShell\7\pwsh.exe"
REM --test runs the supplied examples, checks hello output, three diagnostics,
REM source locations, exit codes, missing-file handling, and a directory input.
REM --testformat prints synthetic diagnostics only; it does not run PowerShell.
REM   COMPOWERSHELL.BAT --testformat "C:\Scripts\errorstest.ps1"
REM For actual TSE jumps, compile errorstest.ps1 with the supplied rule.
REM Expected runtime errors: lines 6, 7, 8; column 1 for these Write-Error calls.
REM A terminating error ends execution; nonterminating errors can accumulate.
REM Parser errors are reported together, without executing invalid source.
REM Runtime location: use file-based InvocationInfo when available.
REM Otherwise use the first source-file frame in ScriptStackTrace.
REM Stack-frame columns use the first command start on that line, else 1.
REM With no source location, line/column 1 is an explicit fallback.
REM Inline command offsets must never be used as source coordinates.
REM Native child-process text is not converted to PowerShell source errors.
REM Nonzero explicit script/native exit codes are retained if no PS errors.
REM Return codes: 0=success, 1=PS error/test failure, 2=input, 3=log failure.
REM --test retains logs under TEMP for inspection; it creates no helper program.
REM
REM PART 2 - REUSABLE LOGIC: no installation settings below this line.
IF DEFINED COMPOWERSHELL_EXE SET "CPS_EXE=%COMPOWERSHELL_EXE%"
IF "%COMPOWERSHELL_NOPAUSE%"=="1" SET "CPS_PAUSE=0"
SET "CPS_RC=2"
IF /I "%~1"=="--test" GOTO Tests
IF /I "%~1"=="/TEST" GOTO Tests
IF /I "%~1"=="--testformat" GOTO TestFormat
IF /I "%~1"=="/?" GOTO Usage
SET "CPS_SOURCE=%~1"
SET "CPS_LOG=%TEMP%\compowershell-%RANDOM%-%RANDOM%.txt"
IF NOT "%~3"=="" GOTO SixArguments
GOTO HaveArguments
:SixArguments
IF /I "%~1"=="--exe" GOTO ExeArguments
SET "CPS_SOURCE=%~3"
IF NOT "%~6"=="" SET "CPS_LOG=%~6"
GOTO HaveArguments
:ExeArguments
SET "CPS_EXE=%~2"
SET "CPS_SOURCE=%~3"
:HaveArguments
ECHO COMPOWERSHELL.BAT version 1.0.0.0.9
IF "%CPS_SOURCE%"=="" GOTO Usage
IF NOT EXIST "%CPS_EXE%" GOTO MissingExe
IF NOT EXIST "%CPS_SOURCE%" GOTO MissingSource
REM Do not test IF EXIST source\: that gives false positives in native TCC.
IF DEFINED _TCC GOTO TccCheck
FOR %%I IN ("%CPS_SOURCE%") DO SET "CPS_ATTR=%%~aI"
IF /I "%CPS_ATTR:~0,1%"=="d" GOTO MissingSource
GOTO SourceChecked
:TccCheck
IF ISDIR "%CPS_SOURCE%" GOTO MissingSource
:SourceChecked
FOR %%I IN ("%CPS_SOURCE%") DO SET "CPS_SOURCE=%%~fI"
FOR %%I IN ("%CPS_LOG%") DO SET "CPS_LOG=%%~fI"
IF /I "%CPS_LOG%"=="%CPS_SOURCE%" GOTO BadLog
>"%CPS_LOG%" ECHO filename="%CPS_SOURCE%"
IF ERRORLEVEL 1 GOTO BadLog
REM Pass filenames through the environment; never inject them into PS code.
REM This inline command uses PowerShell's own parser and ErrorRecord objects.
"%CPS_EXE%" -NoLogo -NoProfile -ExecutionPolicy "%CPS_POLICY%" -Command "$ErrorActionPreference='Continue'; $script:cpsFailed=$false; function CPSerror($r) { $i=$r.InvocationInfo; $f=$i.ScriptName; $l=1; $c=1; if ($f -and (Test-Path -LiteralPath $f -PathType Leaf)) { $l=[Math]::Max(1,$i.ScriptLineNumber); $c=[Math]::Max(1,$i.OffsetInLine) } else { $f=$env:CPS_SOURCE; $sm=[regex]::Match($r.ScriptStackTrace,'(?m)^at .+?, (.+): line ([0-9]+)\r?$'); if ($sm.Success -and (Test-Path -LiteralPath $sm.Groups[1].Value -PathType Leaf)) { $f=$sm.Groups[1].Value; $l=[int]$sm.Groups[2].Value; $st=$null; $se=$null; $sa=[System.Management.Automation.Language.Parser]::ParseFile($f,[ref]$st,[ref]$se); $nodes=@($sa.FindAll({ param($n) $n -is [System.Management.Automation.Language.CommandAst] -and $n.Extent.StartLineNumber -eq $l },$true) | Sort-Object { $_.Extent.StartColumnNumber }); if ($nodes.Count -gt 0) { $c=$nodes[0].Extent.StartColumnNumber } } }; $m=($r.ToString() -replace '[\r\n]+',' '); [Console]::WriteLine((([char]34+'{0}'+[char]34+'({1},{2}): Error: {3}') -f $f,$l,$c,$m)); $script:cpsFailed=$true }; if (-not (Test-Path -LiteralPath $env:CPS_SOURCE -PathType Leaf)) { [Console]::Error.WriteLine('ERROR: source is not a file'); exit 2 }; $t=$null; $e=$null; $null=[System.Management.Automation.Language.Parser]::ParseFile($env:CPS_SOURCE,[ref]$t,[ref]$e); if ($e.Count -gt 0) { foreach ($p in $e) { [Console]::WriteLine((([char]34+'{0}'+[char]34+'({1},{2}): Error: {3}') -f $env:CPS_SOURCE,$p.Extent.StartLineNumber,$p.Extent.StartColumnNumber,($p.Message -replace '[\r\n]+',' '))) }; exit 1 }; $global:LASTEXITCODE=0; try { & $env:CPS_SOURCE 2>&1 | ForEach-Object { if ($_ -is [System.Management.Automation.ErrorRecord]) { CPSerror $_ } else { $_ } } } catch { CPSerror $_ }; if ($script:cpsFailed) { exit 1 }; exit $global:LASTEXITCODE" >>"%CPS_LOG%" 2>&1
SET "CPS_RC=%ERRORLEVEL%"
TYPE "%CPS_LOG%"
ECHO PowerShell exit code: %CPS_RC%
ECHO Diagnostics: "%CPS_LOG%"
GOTO Finish
:MissingExe
ECHO ERROR: PowerShell executable not found: "%CPS_EXE%" 1>&2
GOTO Finish
:MissingSource
ECHO ERROR: source file not found or is a directory: "%CPS_SOURCE%" 1>&2
GOTO Finish
:BadLog
ECHO ERROR: cannot write output log, or log equals source: "%CPS_LOG%" 1>&2
SET "CPS_RC=3"
GOTO Finish
:Usage
ECHO Usage: COMPOWERSHELL.BAT "source.ps1"
ECHO Or: COMPOWERSHELL.BAT --exe "powershell.exe path" "source.ps1"
ECHO Tests: COMPOWERSHELL.BAT --test ["powershell.exe path"]
GOTO Finish
:Finish
IF "%CPS_PAUSE%"=="1" PAUSE
ENDLOCAL & EXIT /B %CPS_RC%

:TestFormat
SET "CPS_SOURCE=%~2"
IF "%CPS_SOURCE%"=="" SET "CPS_SOURCE=%CPS_ERRORS%"
FOR %%I IN ("%CPS_SOURCE%") DO SET "CPS_SOURCE=%%~fI"
ECHO filename="%CPS_SOURCE%"
ECHO "%CPS_SOURCE%"(6,1): Error: Synthetic first error; version 1.0.0.0.9
ECHO "%CPS_SOURCE%"(7,1): Error: Synthetic second error; version 1.0.0.0.9
ECHO "%CPS_SOURCE%"(8,1): Error: Synthetic third error; version 1.0.0.0.9
ENDLOCAL & EXIT /B 0

:Tests
IF NOT "%~2"=="" SET "CPS_EXE=%~2"
SET "COMPOWERSHELL_EXE=%CPS_EXE%"
SET "COMPOWERSHELL_NOPAUSE=1"
SET "CPS_TEST=%TEMP%\compowershell-test-%RANDOM%-%RANDOM%"
IF EXIST "%CPS_TEST%" GOTO TestFail
MD "%CPS_TEST%"
IF ERRORLEVEL 1 GOTO TestFail
CALL "%~f0" "hello" ".ps1" "%CPS_HELLO%" "" "" "%CPS_TEST%\hello.txt"
IF ERRORLEVEL 1 GOTO TestFail
"%SystemRoot%\System32\findstr.exe" /C:"Hello, world!" "%CPS_TEST%\hello.txt" >NUL
IF ERRORLEVEL 1 GOTO TestFail
CALL "%~f0" "errors" ".ps1" "%CPS_ERRORS%" "" "" "%CPS_TEST%\errors.txt"
IF ERRORLEVEL 2 GOTO TestFail
IF NOT ERRORLEVEL 1 GOTO TestFail
REM Check exact expected locations and messages via inline PS, no helper file.
SET "CPS_TEST_LOG=%CPS_TEST%\errors.txt"
SET "CPS_TEST_SOURCE=%CPS_ERRORS%"
"%CPS_EXE%" -NoProfile -Command "$s=[IO.Path]::GetFullPath($env:CPS_TEST_SOURCE); $a=Get-Content -LiteralPath $env:CPS_TEST_LOG; $d=@($a | Where-Object { $_ -match '\([0-9]+,[0-9]+\): Error:' }); if ($d.Count -ne 3) { exit 1 }; foreach ($n in 6,7,8) { $p=[char]34+$s+[char]34+'('+$n+',1): Error: Intentional error '; if (-not ($d | Where-Object { $_.StartsWith($p) })) { exit 1 } }; exit 0"
IF ERRORLEVEL 1 GOTO TestFail
CALL "%~f0" "%CPS_TEST%\missing.ps1"
IF ERRORLEVEL 3 GOTO TestFail
IF NOT ERRORLEVEL 2 GOTO TestFail
CALL "%~f0" "%CPS_TEST%"
IF ERRORLEVEL 3 GOTO TestFail
IF NOT ERRORLEVEL 2 GOTO TestFail
ECHO COMPOWERSHELL 1.0.0.0.9 tests: PASS
ECHO Test logs: "%CPS_TEST%"
ENDLOCAL & EXIT /B 0
:TestFail
ECHO COMPOWERSHELL 1.0.0.0.9 tests: FAIL 1>&2
ECHO Check executable and example settings. Logs: "%CPS_TEST%" 1>&2
ENDLOCAL & EXIT /B 1
