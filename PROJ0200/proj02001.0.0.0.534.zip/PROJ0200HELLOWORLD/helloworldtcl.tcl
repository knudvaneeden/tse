# helloworldtcl.tcl - version 1.0.0.0.7 - 2026-11-04
# Run using COMTCL.BAT; expected exit code 0.
puts "Hello world from Tcl!"
