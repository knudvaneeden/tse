<?xml version="1.0" encoding="UTF-8"?>
<!-- Version 1.0.0.0.0 - 2026-11-01 -->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="xml" indent="yes"/>
  <xsl:template match="/">
    <result><greeting><xsl:value-of select="example/greeting"/></greeting></result>
  </xsl:template>
</xsl:stylesheet>
