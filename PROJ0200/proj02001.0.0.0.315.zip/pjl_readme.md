# Project Language (.pjl) - 1.0.0.0.315

Open Project menu > Run projects > Run scripts > Run Project Language script.
Choose example.pjl in the package directory for the first test.

One command per line, command name first. Commands and parameter names are
case-insensitive; filename spelling is preserved. Blank lines and lines
starting with ; or // are ignored. Double quotes group values containing
spaces. Backslashes are literal. Inline comments are not supported yet.
Commands are ASCII and limited to 255 characters per line in this first
version. Relative paths resolve against the script directory.

| Command | Parameters / behavior |
| --- | --- |
| createproject | NAME or name=NAME, optional desc="TEXT", followed by repeated file=PATH / dir=PATH entries. |
| openproject | NAME or name=NAME; opens an existing saved project. |
| changeproject | Same as openproject. |
| closeproject | No parameters; uses normal close/save behavior. |
| saveproject | No parameters; saves the active project. |
| getallprojectnames | file=OUTPUT; exports registered project filenames without .pj. |
| getcurrentprojectname | No parameters; displays the active name on the message line. |

scan=yes includes subdirectories; scan=no scans only the named directory.
Omitting scan defaults to no. scan must follow dir and cannot follow file.
Each file must exist and be a regular file; each dir must exist as a directory.
Use separate createproject lines to create multiple projects.

Project metadata is saved in the configured PJ directory and registered in
Proj.DB. The current active project and open documents are retained during
createproject. The saved path list is scanned when that project is opened.
The interpreter uses a CASE dispatcher in SRC/MAC/projpjl.si, included by
pjfile.si. No shell evaluation is used.

Existing project records and exported name lists are rejected. Execution
stops at the first error with its script line number. Earlier successful
commands remain committed; there is no whole-script rollback. The summary
counts completed commands, not projects. Close/save can use existing editor
prompts; this is not yet an unattended runner.

Install pjl.txt as a TSE syntax-highlighting definition for *.pjl using your
normal highlighting setup. Its copy also lives in PROJ0200SYNTAXHIGHLIGHTS.
Build using the existing build.bat command; pjfile.si includes the interpreter.
SAL compilation and TSE runtime testing are required on Windows.

Optional desc= stores the project description; omitted or desc="" means empty.
Use it at most once, after the project name. Quote values containing spaces.
The complete command line remains limited to 255 characters.

Example:

```text
createproject name=HELLOWORLD desc="Hello world examples in many languages." dir="PROJ0200HELLOWORLD" scan=no
```

## Version 1.0.0.0.315 - script creation and logs

Create script... is directly below Create project... in the main menu.
Choose a new .pjl filename. List() offers every supported command, a custom
line, editing the last line, and Save and return to editor. Selecting a command
opens an editable template; Enter inserts it, Escape cancels that insertion.
The list repeats for the next command. Escape from the list returns to the
normal editor with the script buffer retained; save any further edits.

openallprojects "C:\TEMP\DDDPJ\" imports and registers valid .pj records
from that directory (nonrecursive). It does not restore every project's files
into the editor. Only one project is active at once; the next command can be
openproject PROJ0200HELLOWORLD. Existing destination records use the same
copy behavior as Import all projects. Invalid records are skipped with WARNING;
no valid records or a failed copy stops execution with ERROR.

Script errors create pjlYYYYMMDDHHMMSS.log in the package directory. Each event
uses local Windows time: YYYY-MM-DD HH:MM:SS ERROR/WARNING/INFO message.
ERROR records the script filename, line, and failure. WARNING records skipped
invalid projects. INFO records the completed-command count after a logged run.
Successful runs without warnings do not create a log. Existing same-minute
logs are appended. These .pjl log files are plain text, not executable scripts.
The portable logging helpers use powershell.exe from PATH; script text is
passed through a data file, never evaluated as shell commands.

Rebuild using build.bat. SAL compilation and Windows runtime tests are pending.
Test Create script, openprojects.pjl (adapt the directory), and errorstest.pjl.
OpenAI Codex (GPT-6).

While editing an existing .pjl script, Run scripts > K: Insert PJL keyword
opens the same List(). The selected editable command is inserted at the
current cursor. Commands can also be typed directly in the normal editor.

Version 1.0.0.0.315: Main menu shows 4: Create script... directly below Create project...; G: Copy project... now follows Calculate projects. Rebuild with build.bat, then restart TSE to load the newly compiled resident proj.mac. OpenAI Codex (GPT-6). Windows compilation and runtime verification remain pending.

Version 1.0.0.0.315: Create script reopens the initially saved .pjl as a normal named editor file before adding commands. This fixes File has no name when selecting Save and return to editor. OpenAI Codex (GPT-6). Rebuild and restart TSE. Windows compilation and runtime verification remain pending.

Version 1.0.0.0.315: Run scripts defaults to the main PROJ0200 directory and *.pjl. Previous script filenames remain available from history without overriding the default directory. The original working directory is restored after cancellation or execution. OpenAI Codex (GPT-6). Rebuild and restart TSE. Windows runtime verification remains pending.

Version 1.0.0.0.315: openallprojects removes a trailing filename wildcard added by ExpandPath before constructing the *.pj search. This fixes No valid .pj projects found for directories resolving to path\*.*. OpenAI Codex (GPT-6). Rebuild and restart TSE. Windows runtime verification remains pending.

Version 1.0.0.0.315: PJL logging overwrites stale event files and reports event-file or buffer failures. Helper diagnostics go to proj0200_pjl_log_errors.txt; returned log paths are checked for existence. INFO is written only after a successful ERROR event. Test errorstest.pjl to trigger an unknown command and a timestamped log. OpenAI Codex (GPT-6). Windows runtime verification remains pending.

Version 1.0.0.0.315: PJL log filenames use pjlYYYYMMDDHHMMSS.log, for example pjl20261013191530.log. Logging includes seconds and retains ERROR, WARNING and INFO timestamps. Stale event files are overwritten and logging failures report diagnostics in proj0200_pjl_log_errors.txt. Test errorstest.pjl. OpenAI Codex (GPT-6). Windows runtime verification remains pending.

Version 1.0.0.0.315: Each logged script run reserves a new pjlYYYYMMDDHHMMSS.log using exclusive CreateNew mode. Existing logs are never overwritten or reused for a new run; a timestamp collision waits for the next available second. Later events append to the same run log. OpenAI Codex (GPT-6). Windows runtime verification remains pending.

Version 1.0.0.0.315: PJL ERROR log entries and final error messages include a one-based source column. Token columns preserve leading spaces and tabs (each tab counts as one source character). Unknown commands point to the command; invalid parameters point to the parsed token; overlength lines point to column 256. File/read failures use line 0 column 1 when no source location is available. OpenAI Codex (GPT-6). Windows compilation and runtime verification remain pending.

Version 1.0.0.0.315: New PJL command viewcurrentactiveproject takes no parameters and invokes the same name, filename and description dialogs as View current active project. No active project or extra parameters produce a logged ERROR. The command is included in the keyword picker and pjl.txt syntax definitions. OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows compilation and runtime verification remain pending.

Version 1.0.0.0.315: Run a PJL script through the macro parameter:
  projstart.mac newscript.pjl
  projstart.mac "C:\TEMP\my script.pjl"
  proj.mac newscript.pjl
  proj.mac -RunPJL "C:\TEMP\my script.pjl"
Relative script filenames resolve from the main PROJ0200 directory. The filename prompt is skipped. No parameter retains the existing menu behavior. Script errors use the existing timestamped .log mechanism. These are TSE Execute Macro commands; projstart.mac is not a standalone executable. OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows compilation and runtime verification remain pending.

Version 1.0.0.0.315: Restored the clean version 313 implementation. CmdLineParameter source, test macro, build integration and -p parameter capture from version 314 are absent. In-editor Execute Macro support remains: projstart.mac newscript.pjl. OpenAI Codex (GPT-6). Rebuild and restart TSE.
