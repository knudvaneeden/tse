PROJ0200 package version: 1.0.0.0.377

# Project Language (.pjl) - 

## Syntax diagram

![PJL railroad diagram](DOCS/pjl_railroad.png)

[Scalable SVG diagram](DOCS/pjl_railroad.svg).


Open Project menu > Run projects > Run scripts > Run Project Language script.
Choose example.pjl in the package directory for the first test.

One command per line, command name first. Commands and parameter names are
case-insensitive; filename spelling is preserved. Blank lines and lines
starting with ; or // are ignored. Double quotes group values containing
spaces. Backslashes are literal. Inline comments are not supported yet.
Commands are ASCII and limited to 255 characters per line in this first
version. Relative paths resolve against the script directory.

| Command | Parameters / behavior |
| --- | --- |
| project create | NAME or name=NAME, optional desc="TEXT", followed by repeated file=PATH / dir=PATH entries. |
| project open | NAME or name=NAME; opens an existing saved project. |
| project change | Same as project open. |
| project close | No parameters; uses normal close/save behavior. |
| project save current | No parameters; saves the active project. |
| project get names all | file=OUTPUT; exports registered project filenames without .pj. |
| project get name current | No parameters; displays the active name on the message line. |

scan=yes includes subdirectories; scan=no scans only the named directory.
Omitting scan defaults to no. scan must follow dir and cannot follow file.
Each file must exist and be a regular file; each dir must exist as a directory.
Use separate project create lines to create multiple projects.

Project metadata is saved in the configured PJ directory and registered in
Proj.DB. The current active project and open documents are retained during
project create. The saved path list is scanned when that project is opened.
The interpreter uses a CASE dispatcher in SRC/MAC/projpjl.si, included by
pjfile.si. No shell evaluation is used.

Existing project records and exported name lists are rejected. Execution
stops at the first error with its script line number. Earlier successful
commands remain committed; there is no whole-script rollback. The summary
counts completed commands, not projects. Close/save can use existing editor
prompts; this is not yet an unattended runner.

Install pjl.txt as a TSE syntax-highlighting definition for *.pjl using your
normal highlighting setup. Its copy also lives in PROJ0200SYNTAXHIGHLIGHTS.
Build using the existing build.bat command; pjfile.si includes the interpreter.
SAL compilation and TSE runtime testing are required on Windows.

Optional desc= stores the project description; omitted or desc="" means empty.
Use it at most once, after the project name. Quote values containing spaces.
The complete command line remains limited to 255 characters.

Example:

```text
project create name=HELLOWORLD desc="Hello world examples in many languages." dir="PROJ0200HELLOWORLD" scan=no
```

script creation and logs

Create script... is directly below Create project... in the main menu.
Choose a new .pjl filename. List() offers every supported command, a custom
line, editing the last line, and Save and return to editor. Selecting a command
opens an editable template; Enter inserts it, Escape cancels that insertion.
The list repeats for the next command. Escape from the list returns to the
normal editor with the script buffer retained; save any further edits.

project open all "C:\TEMP\DDDPJ\" imports and registers valid .pj records
from that directory (nonrecursive). It does not restore every project's files
into the editor. Only one project is active at once; the next command can be
project open PROJ0200HELLOWORLD. Existing destination records use the same
copy behavior as Import all projects. Invalid records are skipped with WARNING;
no valid records or a failed copy stops execution with ERROR.

Script errors create pjlYYYYMMDDHHMMSS.log in the package directory. Each event
uses local Windows time: YYYY-MM-DD HH:MM:SS ERROR/WARNING/INFO message.
ERROR records the script filename, line, and failure. WARNING records skipped
invalid projects. INFO records the completed-command count after a logged run.
Successful runs without warnings do not create a log. Existing same-minute
logs are appended. These .pjl log files are plain text, not executable scripts.
The portable logging helpers use powershell.exe from PATH; script text is
passed through a data file, never evaluated as shell commands.

Rebuild using build.bat. SAL compilation and Windows runtime tests are pending.
Test Create script, project opens.pjl (adapt the directory), and errorstest.pjl.
OpenAI Codex (GPT-6).

While editing an existing .pjl script, Run scripts > K: Insert PJL keyword
opens the same List(). The selected editable command is inserted at the
current cursor. Commands can also be typed directly in the normal editor.

Main menu shows 4: Create script... directly below Create project...; G: Copy project... now follows Calculate projects. Rebuild with build.bat, then restart TSE to load the newly compiled resident proj.mac. OpenAI Codex (GPT-6). Windows compilation and runtime verification remain pending.

Create script reopens the initially saved .pjl as a normal named editor file before adding commands. This fixes File has no name when selecting Save and return to editor. OpenAI Codex (GPT-6). Rebuild and restart TSE. Windows compilation and runtime verification remain pending.

Run scripts defaults to the main PROJ0200 directory and *.pjl. Previous script filenames remain available from history without overriding the default directory. The original working directory is restored after cancellation or execution. OpenAI Codex (GPT-6). Rebuild and restart TSE. Windows runtime verification remains pending.

project open all removes a trailing filename wildcard added by ExpandPath before constructing the *.pj search. This fixes No valid .pj projects found for directories resolving to path\*.*. OpenAI Codex (GPT-6). Rebuild and restart TSE. Windows runtime verification remains pending.

PJL logging overwrites stale event files and reports event-file or buffer failures. Helper diagnostics go to proj0200_pjl_log_errors.txt; returned log paths are checked for existence. INFO is written only after a successful ERROR event. Test errorstest.pjl to trigger an unknown command and a timestamped log. OpenAI Codex (GPT-6). Windows runtime verification remains pending.

PJL log filenames use pjlYYYYMMDDHHMMSS.log, for example pjl20261013191530.log. Logging includes seconds and retains ERROR, WARNING and INFO timestamps. Stale event files are overwritten and logging failures report diagnostics in proj0200_pjl_log_errors.txt. Test errorstest.pjl. OpenAI Codex (GPT-6). Windows runtime verification remains pending.

Each logged script run reserves a new pjlYYYYMMDDHHMMSS.log using exclusive CreateNew mode. Existing logs are never overwritten or reused for a new run; a timestamp collision waits for the next available second. Later events append to the same run log. OpenAI Codex (GPT-6). Windows runtime verification remains pending.

PJL ERROR log entries and final error messages include a one-based source column. Token columns preserve leading spaces and tabs (each tab counts as one source character). Unknown commands point to the command; invalid parameters point to the parsed token; overlength lines point to column 256. File/read failures use line 0 column 1 when no source location is available. OpenAI Codex (GPT-6). Windows compilation and runtime verification remain pending.

New PJL command project view current active takes no parameters and invokes the same name, filename and description dialogs as View current active project. No active project or extra parameters produce a logged ERROR. The command is included in the keyword picker and pjl.txt syntax definitions. OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows compilation and runtime verification remain pending.

Run a PJL script through the macro parameter:
  projstart.mac newscript.pjl
  projstart.mac "C:\TEMP\my script.pjl"
  proj.mac newscript.pjl
  proj.mac -RunPJL "C:\TEMP\my script.pjl"
Relative script filenames resolve from the main PROJ0200 directory. The filename prompt is skipped. No parameter retains the existing menu behavior. Script errors use the existing timestamped .log mechanism. These are TSE Execute Macro commands; projstart.mac is not a standalone executable. OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows compilation and runtime verification remain pending.

Restored the clean version 313 implementation. CmdLineParameter source, test macro, build integration and -p parameter capture from version 314 are absent. In-editor Execute Macro support remains: projstart.mac newscript.pjl. OpenAI Codex (GPT-6). Rebuild and restart TSE.

New PJL command project view all takes no parameters and calls the existing View all projects action. It displays saved project names without switching the active project and does not require an active project. Included in the keyword picker and syntax highlighting. OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows compilation and runtime verification remain pending.

project open all can be run repeatedly. Existing valid destination project records are retained and registered, counted as available projects, and do not show replacement prompts. Only missing records are copied. An invalid existing destination reports ERROR without overwriting it. Use the interactive Import action when intentionally replacing an existing record from the source directory. OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows runtime verification remains pending.

PJL pause [text]

pause displays Press a key to continue... and waits for the user to dismiss
the native TSE/selected Windows OK dialog, then continues the script.
pause Some text here displays that text and waits.
pause "Some text here" is also supported; unmatched quotes report ERROR.
Commands are case-insensitive: PAUSE, Pause and pause are equivalent.
Included in the keyword picker and syntax highlighting.
OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows verification pending.

Timelog commands (no parameters):

```pjl
log start timelog
log view timelog
log stop timelog
```

Start/resume tracking, save and show results, or save and stop tracking.
Showing a stopped log leaves it stopped. Start/show require an active project.

## Noun-first commands

The command syntax now uses the noun first. Old joined spellings are replaced;
update existing scripts using this table. Commands remain case-insensitive.
Spaces or tabs may separate command words. `pause [message]` is unchanged.

| Previous spelling | Current command |
| --- | --- |
| createproject | project create |
| openallprojects | project open all |
| openproject | project open |
| changeproject | project change |
| closeproject | project close |
| savecurrentproject | project save current |
| getallprojectnames | project get names all |
| getcurrentprojectname | project get name current |
| viewcurrentactiveproject | project view current active |
| viewallprojects | project view all |
| starttimelog | log start timelog |
| showtimelog | log view timelog |
| stoptimelog | log stop timelog |

## File version control

```text
fileversioncontrol upload subversion allfilesinthetsering automatic
fileversioncontrol upload subversion allfilesinthetsering withnotes
fileversioncontrol upload git allfilesinthetsering automatic
fileversioncontrol upload git allfilesinthetsering withnotes
fileversioncontrol upload subversion allfilesinallprojects automatic
fileversioncontrol upload subversion allfilesinallprojects withnotes
fileversioncontrol upload git allfilesinallprojects automatic
fileversioncontrol upload git allfilesinallprojects withnotes
fileversioncontrol upload subversion allfilesincurrentproject automatic
fileversioncontrol upload subversion allfilesincurrentproject withnotes
fileversioncontrol upload git allfilesincurrentproject automatic
fileversioncontrol upload git allfilesincurrentproject withnotes
fileversioncontrol upload subversion currentfile automatic
fileversioncontrol upload subversion currentfile withnotes
fileversioncontrol upload git currentfile automatic
fileversioncontrol upload git currentfile withnotes
```

The syntax is `fileversioncontrol upload <backend> <scope> <modifier>`.
Backend, scope and modifier are case-insensitive. The modifier is required:
`automatic` uses the existing automatic-upload action and configured commit
message (an empty message can prompt); `withnotes` uses the interactive action
and asks for notes for each file. Spell `withnotes` as one word.

Configure the corresponding repository/executable settings in proj0200.ini.
Git pushing follows gitpush and the remote/branch settings. Subversion follows
its existing commit behavior. Unsaved-buffer snapshot settings also apply.
The current project scope requires an active project. The ring scope includes
normal named file buffers. `currentfile` means the named normal file active
before the script starts, rather than the interpreter's temporary script buffer.
These actions can commit files, just like their corresponding menu actions.
An unsuccessful or cancelled upload stops the script and creates a PJL error
log; consult proj0200_git_log.txt or proj0200_svn_log.txt for details.
All sixteen combinations are offered as editable command templates.

Syntax highlighting groups: nouns in [KeyWords1], verbs in [KeyWords3],
and third and later parameters in [KeyWords5]. The TSE definition highlights
words by group wherever they occur; it does not parse argument positions.

Unnamed editor buffers (including labels such as <unnamed-2>) are excluded
from ring uploads. Save them under real filenames before uploading.
The currentfile scope rejects an unnamed active buffer.

## Load examples for the current file

```text
file load current example helloworld
file load current example bat
file load current example rule
file load current example errortest
file load current example syntaxhighlight
```

These commands invoke the same loaders as Load projects. They require no active
project. The first command uses the normal named source buffer active before
running the script, rather than the interpreter's temporary script buffer.
A successfully loaded example becomes the current file for later commands and
is displayed when the script finishes. Current-file version-control uploads
also use this updated current file. The commands do not compile or execute
loaded source files or batch files.

The first four example types use proj0200_examples.txt. syntaxhighlight uses
only listsynext.txt and loads from PROJ0200SYNTAXHIGHLIGHTS. Missing mappings
or files stop the script and create a normal PJL error log. Existing files
remain open. Commands accept no extra arguments and are case-insensitive.

Example, starting with a .cpp source file selected:

```text
file load current example bat
file load current example rule
file load current example helloworld
file load current example errortest
file load current example syntaxhighlight
```

Each lookup uses the current file's extension or compiler-example filename.
For syntax highlighting, select a source example first: an ordinary .txt file
is looked up as .txt rather than as the language described inside it.

## Load examples from a language list

```text
file load examples helloworld from "languages.txt"
file load examples bat from "languages.txt"
file load examples rule from "languages.txt"
file load examples errortest from "languages.txt"
file load examples syntaxhighlight from "languages.txt"
```

The list has one extension per line, for example:

```text
c
cpp
py
```

A leading dot is optional; extensions are case-insensitive. Blank lines and
whole-line comments starting with ; or // are ignored. Use extensions rather
than full language names. Spaces within entries, filenames and inline comments
are rejected. List lines are limited to 255 characters. Quote the list filename
if it contains spaces. Relative list paths resolve against the PJL script.

Entries are processed in list order. Each is looked up independently, so later
lookups do not depend on the type of the example opened previously. This form
does not require a source file or project to be active. It loads files into the
editor; it does not compile or execute them. Repeated entries use the existing
editor behavior for already-open files. The last successful example becomes
current for later PJL commands and is shown when the script ends.

Invalid entries, missing mappings and missing files are logged as WARNING with
the example type (HELLOWORLD, BAT, RULE, ERRORTEST or SYNTAXHIGHLIGHT)
and the language-list line number, then loading continues. A summary reports loaded
and skipped entries. An unreadable list or a list with no successful loads is
an error. Earlier loaded files stay open. One successful batch counts as one PJL
command, regardless of the number of examples loaded.

The included load_examples_languages.pjl and languages.txt demonstrate loading
the supplied full language list as helloworld examples.
The .sql default is MySQL, .bas is BBC BASIC, .v is Rocq and .bat is TCC.
Repeated extensions select the same example; they cannot select distinct dialects. All five forms have editable templates.

Compiler BAT examples select the language's RULE record in proj0200_examples.txt,
then read that rule file's Command field at runtime. That command supplies the
actual COM...BAT name, such as COMBRAINF.BAT, COMZIG.BAT or COMGROOVY.BAT.
Duplicate BAT mapping rows are no longer used. Quoted executable paths and an
optional CALL prefix and cmd.exe /c wrappers are supported. Only the named BAT file in
PROJ0200COMPILERS is opened; its command is not executed.
An active *batcompilersetting_* rule file is read directly from disk.
Saved rule edits apply on the next load without a BAT table update.
For .s, the rule invokes SAL directly; no compiler BAT example is bundled.

To inspect the latest log, choose **Load projects > Load .pjl log file...**.
This opens the log with the newest filename timestamp in the PROJ0200 directory.
It warns if no pjlYYYYMMDDHHMMSS.log file exists there.
