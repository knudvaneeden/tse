#include ["projdialogs.si"]
#include ["projhistory.si"]
// PROJ0200 1.0.0.0.377 - OpenAI Codex (GPT-6)
// Separate example loader avoids the main macro size limit.
string proc PROJ_ExampleType(integer kindI)
    case kindI
        when 1 return("HELLOWORLD")
        when 2 return("BAT")
        when 3 return("RULE")
        when 4 return("ERRORTEST")
        when 5 return("SYNTAXHIGHLIGHT")
        when 6 return("CTAGS")
    endcase
    return("UNKNOWN")
end

proc PROJ_ExampleWarning(string textS)
    SetGlobalStr("PROJ_ExampleError", textS)
    if not GetGlobalInt("PROJ_ExampleQuiet")
        FNProjectWarning(textS)
    endif
end

string proc GetInstallationDir()
    return(SplitPath(CurrMacroFilename(), _DRIVE_|_PATH_))
end
// PROJ0200 1.0.0.0.377 - OpenAI Codex (GPT-6)
// Resolve examples from the installation directory, not the working directory.
// listsynext.txt is the sole extension-to-syntax-definition mapping.
proc PROJ_LoadSyntaxExample()
    integer originalI = GetBufferId(), mapI, lineI, tokenI
    integer colonI
    string extensionS[255] = Lower(SplitPath(CurrFilename(), _EXT_))
    string recordS[255], syntaxS[255] = "", tokenS[255]
    string filenameS[255]
    if Length(GetGlobalStr("PROJ_ExampleExtension"))
        extensionS = GetGlobalStr("PROJ_ExampleExtension")
    endif
    if LeftStr(extensionS, 1) == "."
        extensionS = SubStr(extensionS, 2, 254)
    endif
    if not Length(extensionS)
        PROJ_ExampleWarning("The current file has no extension for the syntax mapping.")
        return()
    endif
    mapI = CreateTempBuffer()
    if not mapI
        return()
    endif
    if not InsertFile(GetInstallationDir() + "listsynext.txt", _DONT_PROMPT_)
        GotoBufferId(originalI)
        AbandonFile(mapI)
        PROJ_ExampleWarning("Cannot read listsynext.txt in the PROJ0200 directory.")
        return()
    endif
    for lineI = 1 to NumLines()
        GotoLine(lineI)
        recordS = Lower(Trim(GetText(1, 255)))
        colonI = Pos(":", recordS)
        if colonI
            recordS = SubStr(recordS, 1, colonI - 1) + " " + SubStr(recordS, colonI + 1, 255)
        endif
        tokenI = 2
        loop
            tokenS = GetToken(recordS, " " + Chr(9), tokenI)
            if not Length(tokenS)
                break
            endif
            if tokenS == extensionS
                syntaxS = GetToken(recordS, " " + Chr(9), 1)
                break
            endif
            tokenI = tokenI + 1
        endloop
        if Length(syntaxS)
            break
        endif
    endfor
    GotoBufferId(originalI)
    AbandonFile(mapI)
    if not Length(syntaxS)
        PROJ_ExampleWarning("No syntax mapping for ." + extensionS + " in listsynext.txt.")
        return()
    endif
    if Pos("\", syntaxS) or Pos("/", syntaxS) or Pos(":", syntaxS) or
       Pos("..", syntaxS) or Pos("*", syntaxS) or Pos("?", syntaxS)
        PROJ_ExampleWarning("Invalid syntax-definition name in listsynext.txt: " + syntaxS)
        return()
    endif
    if Length(GetInstallationDir()) + Length(syntaxS) + 28 > 255
        PROJ_ExampleWarning("The mapped syntax-definition path exceeds 255 characters.")
        return()
    endif
    filenameS = GetInstallationDir() + "PROJ0200SYNTAXHIGHLIGHTS\" + syntaxS + ".txt"
    if not FileExists(filenameS)
        PROJ_ExampleWarning("Mapped ." + extensionS + " to " + syntaxS + ".txt, but the file is missing from PROJ0200SYNTAXHIGHLIGHTS.")
    elseif EditFile(QuotePath(filenameS))
        SetGlobalInt("PROJ_ExampleResult", TRUE)
        UpdateDisplay()
    else
        PROJ_ExampleWarning("Could not load syntax definition: " + filenameS)
    endif
end

// Resolve the BAT from the rule's Command field, never from a BAT mapping row.
string proc PROJ_RuleBat(string relativeRuleS)
    integer originalI = GetBufferId(), ruleI, lineI, endI
    string lineS[255], commandS[255] = "", executableS[255] = ""
    string ruleS[255] = GetInstallationDir() + relativeRuleS
    if Pos(":", relativeRuleS) or LeftStr(relativeRuleS, 2) == "\\"
        ruleS = relativeRuleS
    elseif Length(GetInstallationDir()) + Length(relativeRuleS) > 255
        PROJ_ExampleWarning("The compiler-rule filename exceeds the SAL 255-character limit.")
        return("")
    endif
    ruleI = CreateTempBuffer()
    if not ruleI
        PROJ_ExampleWarning("Cannot create the compiler-rule lookup buffer.")
        return("")
    endif
    if InsertFile(ruleS, _DONT_PROMPT_)
        for lineI = 1 to NumLines()
            GotoLine(lineI)
            lineS = Trim(GetText(1, 255))
            if Lower(LeftStr(lineS, 8)) == "command="
                commandS = Trim(SubStr(lineS, 9, 247))
                break
            endif
        endfor
    endif
    GotoBufferId(originalI)
    AbandonFile(ruleI)
    if not FileExists(ruleS)
        PROJ_ExampleWarning("Compiler rule file is missing: " + ruleS)
        return("")
    endif
    if Lower(GetToken(commandS, " " + Chr(9), 1)) == "cmd.exe" or
       Lower(GetToken(commandS, " " + Chr(9), 1)) == "cmd"
        endI = Pos("/c ", Lower(commandS))
        if endI
            commandS = Trim(SubStr(commandS, endI + 3, 255))
        endif
    endif
    if Lower(LeftStr(commandS, 5)) == "call "
        commandS = Trim(SubStr(commandS, 6, 250))
    endif
    if LeftStr(commandS, 1) == Chr(34)
        endI = 2
        while endI <= Length(commandS) and SubStr(commandS, endI, 1) <> Chr(34)
            endI = endI + 1
        endwhile
        if endI <= Length(commandS)
            executableS = SubStr(commandS, 2, endI - 2)
        endif
    else
        executableS = GetToken(commandS, " " + Chr(9), 1)
    endif
    executableS = SplitPath(executableS, _NAME_|_EXT_)
    if Lower(SplitPath(executableS, _EXT_)) <> ".bat" or
       Lower(LeftStr(executableS, 3)) <> "com"
        PROJ_ExampleWarning("BAT example unavailable: rule " + relativeRuleS + " has no COM...BAT command.")
        return("")
    endif
    return("PROJ0200COMPILERS\" + executableS)
end

proc PROJ_LoadLanguageExample(integer kind)
    integer originalBuffer = GetBufferId()
    integer mapBuffer
    integer lineIndex
    integer lineCount
    integer mappingKind = kind
    string extension[255] = Lower(SplitPath(CurrFilename(), _EXT_))
    string basename[255] = Lower(SplitPath(CurrFilename(), _NAME_|_EXT_))
    string lookup[255]
    string record[255]
    string relativeName[255] = ""
    string filename[255]
    if kind == 5
        PROJ_LoadSyntaxExample()
        return()
    endif
    if Length(GetGlobalStr("PROJ_ExampleExtension"))
        lookup = GetGlobalStr("PROJ_ExampleExtension")
    elseif extension == ".bat" or Pos("batcompilersetting_", basename)
        lookup = "@" + basename
    else
        if SubStr(extension, 1, 1) == "."
            extension = SubStr(extension, 2, 254)
        endif
        lookup = extension
    endif
    if not Length(lookup)
        PROJ_ExampleWarning(Format("The current file has no language extension. Open a source file first."))
        return()
    endif
    if kind == 2
        mappingKind = 3
    endif
    mapBuffer = CreateTempBuffer()
    if not mapBuffer
        PROJ_ExampleWarning(Format("Cannot create the example lookup buffer."))
        return()
    endif
    if InsertFile(GetInstallationDir() + "proj0200_examples.txt", _DONT_PROMPT_)
        lineCount = NumLines()
        for lineIndex = 1 to lineCount
            GotoLine(lineIndex)
            record = GetText(1, 255)
            if GetToken(record, "|", 1) == lookup and
               GetToken(record, "|", 2) == Str(mappingKind)
                relativeName = GetToken(record, "|", 3)
                break
            endif
        endfor
    endif
    GotoBufferId(originalBuffer)
    AbandonFile(mapBuffer)
    if kind == 2 and not Length(GetGlobalStr("PROJ_ExampleExtension")) and
       Pos("batcompilersetting_", basename)
        relativeName = CurrFilename()
    endif
    if not Length(relativeName)
        PROJ_ExampleWarning(Format("No " + PROJ_ExampleType(mappingKind) + " mapping for " + lookup + "."))
        return()
    endif
    if kind == 2
        relativeName = PROJ_RuleBat(relativeName)
        if not Length(relativeName)
            return()
        endif
    endif
    if Length(GetInstallationDir()) + Length(relativeName) > 255
        PROJ_ExampleWarning(Format("The example filename exceeds the SAL 255-character limit."))
        return()
    endif
    filename = GetInstallationDir() + relativeName
    if not FileExists(filename)
        PROJ_ExampleWarning(Format("Example file could not be found: " + filename))
        return()
    endif
    if EditFile(QuotePath(filename))
        SetGlobalInt("PROJ_ExampleResult", TRUE)
        UpdateDisplay()
    else
        PROJ_ExampleWarning(Format("Could not load example file: " + filename))
    endif
end

string proc PROJ_FileExtension(string filename)
    string extension[255] = Lower(SplitPath(filename, _EXT_))
    if extension[1] == "."
        extension = SubStr(extension, 2, 254)
    endif
    return(extension)
end

integer proc PROJ_HasType(string extension, integer bufferId)
    integer originalBuffer = GetBufferId()
    integer found = FALSE
    if bufferId
        GotoBufferId(bufferId)
        PushPosition()
        BegFile()
        do NumLines() times
            if Lower(Trim(GetText(1, 255))) == Lower(extension)
                found = TRUE
                break
            endif
            Down()
        enddo
        PopPosition()
        GotoBufferId(originalBuffer)
    endif
    return(found)
end


proc PROJ_LoadDirectoryNonBinary()
    integer originalBuffer = GetBufferId()
    integer excludedBuffer = 0
    integer listBuffer = 0
    integer searchHandle
    integer lineIndex
    integer fileCount
    integer loaded = 0
    integer skipped = 0
    string directory[255] = CurrDir()
    string filename[255]
    if not PROJ_HistoryAsk("Directory to load non-binary files from (no subdirectories):", directory, "PROJ0200:projexamples:PROJ_LoadDirectoryNonBinary:input1")
        return()
    endif
    directory = Trim(directory)
    if not Length(directory) or not (FileExists(directory) & _DIRECTORY_)
        PROJ_ExampleWarning(Format("Directory not found: " + directory))
        return()
    endif
    directory = ExpandPath(directory)
    if directory[Length(directory)] <> "\"
        directory = directory + "\"
    endif
    excludedBuffer = CreateTempBuffer()
    if not excludedBuffer
        return()
    endif
    if not InsertFile(GetInstallationDir() + "proj0200_binarytypes.txt", _DONT_PROMPT_)
        GotoBufferId(originalBuffer)
        AbandonFile(excludedBuffer)
        PROJ_ExampleWarning(Format("Cannot read proj0200_binarytypes.txt; no directory files were loaded."))
        return()
    endif
    listBuffer = CreateTempBuffer()
    if not listBuffer
        GotoBufferId(originalBuffer)
        AbandonFile(excludedBuffer)
        return()
    endif
    searchHandle = FindFirstFile(directory + "*", _NORMAL_|_ARCHIVE_|_READONLY_|_HIDDEN_|_SYSTEM_)
    if searchHandle <> -1
        repeat
            filename = directory + FFName()
            if not (FileExists(filename) & _DIRECTORY_)
                if not PROJ_HasType(PROJ_FileExtension(filename), excludedBuffer)
                    AddLine(filename, listBuffer)
                else
                    skipped = skipped + 1
                endif
            endif
        until not FindNextFile(searchHandle, _NORMAL_|_ARCHIVE_|_READONLY_|_HIDDEN_|_SYSTEM_)
        FindFileClose(searchHandle)
    endif
    GotoBufferId(listBuffer)
    fileCount = NumLines()
    for lineIndex = 1 to fileCount
        GotoBufferId(listBuffer)
        GotoLine(lineIndex)
        filename = GetText(1, 255)
        if Length(filename)
            GotoBufferId(originalBuffer)
            if EditFile(QuotePath(filename))
                loaded = loaded + 1
            endif
        endif
    endfor
    GotoBufferId(originalBuffer)
    AbandonFile(listBuffer)
    AbandonFile(excludedBuffer)
    PROJ_ExampleWarning(Format("Directory files loaded: " + Str(loaded) + "; excluded binary extensions: " + Str(skipped) + "."))
end

string proc PROJ_PackageSetting(string settingName)
    integer previousBuffer = GetBufferId()
    integer iniBuffer
    integer equalsAt
    string settingValue[255] = ""
    string lineText[255]
    string iniFilename[255] = GetInstallationDir() + "proj0200.ini"
    if not FileExists(iniFilename)
        return(settingValue)
    endif
    iniBuffer = CreateTempBuffer()
    if iniBuffer
        if InsertFile(iniFilename, _DONT_PROMPT_)
            BegFile()
            repeat
                lineText = Trim(GetText(1, 255))
                equalsAt = Pos("=", lineText)
                if equalsAt > 1
                    if Lower(Trim(SubStr(lineText, 1, equalsAt - 1))) == Lower(settingName)
                        settingValue = Trim(SubStr(lineText, equalsAt + 1, 255))
                        break
                    endif
                endif
            until not Down()
        endif
        GotoBufferId(previousBuffer)
        AbandonFile(iniBuffer)
    endif
    return(settingValue)
end

// Read the optional package setting without changing PROJ's editor profile.
integer proc PROJ_ShowStartupMessage()
	integer oldBuffer = GetBufferId()
	integer iniBuffer
	integer showMessage = TRUE
	string iniFile[255] = GetInstallationDir() + "proj0200.ini"
	string line[255]

    if GetGlobalStr("PROJ0200_FromLauncher") == "true"
        SetGlobalStr("PROJ0200_FromLauncher", "")
        if GetGlobalStr("PROJ0200_BeginMessageShown") == "true"
            return(FALSE)
        endif
        if Lower(Trim(PROJ_PackageSetting("showbeginmessage"))) <> "false"
            SetGlobalStr("PROJ0200_BeginMessageShown", "true")
            return(TRUE)
        endif
    endif

	if not FileExists(iniFile)
		return(showMessage)
	endif
	iniBuffer = CreateTempBuffer()
	if iniBuffer
		if InsertFile(iniFile, _DONT_PROMPT_)
			BegFile()
			repeat
				line = Lower(Trim(GetText(1, 255)))
				if Pos("silent=", line) == 1
					if Trim(SubStr(line, 8, 255)) == "true"
						showMessage = FALSE
					endif
						break
				endif
			until not Down()
		endif
		GotoBufferId(oldBuffer)
		AbandonFile(iniBuffer)
	endif
	return(showMessage)
end

proc PROJ_SetStartupMenuSelection()
    string selection[255] = Lower(PROJ_PackageSetting("startprojectmenu"))
    SetGlobalInt("PROJ_StartupMenuSelection", 1)
    if selection == "open project" or selection == "open"
        SetGlobalInt("PROJ_StartupMenuSelection", 4)
    elseif Length(selection) and selection <> "new project" and selection <> "new"
        PROJ_ExampleWarning(Format("startprojectmenu must be New Project or Open Project in proj0200.ini. Using New Project."))
    endif
end


// Timestamped names sort chronologically without changing the working directory.
proc PROJ_LoadLatestPJLLog()
    integer handleI, indexI, validB
    string baseS[255] = GetInstallationDir()
    string nameS[255], latestS[255] = ""
    handleI = FindFirstFile(baseS + "pjl??????????????.log", _NORMAL_|_ARCHIVE_|_READONLY_|_HIDDEN_|_SYSTEM_)
    if handleI <> -1
        repeat
            nameS = Lower(FFName())
            validB = Length(nameS) == 21 and LeftStr(nameS, 3) == "pjl" and RightStr(nameS, 4) == ".log"
            for indexI = 4 to 17
                if not Pos(SubStr(nameS, indexI, 1), "0123456789")
                    validB = FALSE
                endif
            endfor
            if validB and not (FileExists(baseS + nameS) & _DIRECTORY_)
                if nameS > latestS
                    latestS = nameS
                endif
            endif
        until not FindNextFile(handleI, _NORMAL_|_ARCHIVE_|_READONLY_|_HIDDEN_|_SYSTEM_)
        FindFileClose(handleI)
    endif
    if not Length(latestS)
        FNProjectWarning("No PJL log files (pjlYYYYMMDDHHMMSS.log) found in: " + baseS)
    elseif not EditFile(QuotePath(baseS + latestS))
        FNProjectWarning("Cannot load PJL log file: " + baseS + latestS)
    else
        SetGlobalInt("PROJ_ExampleResult", TRUE)
        UpdateDisplay()
    endif
end

proc PROCProjectMainActions()
    SetGlobalInt("PROJ_ExampleResult", FALSE)
    SetGlobalStr("PROJ_ExampleError", "")
    case GetGlobalInt("PROJ_ExampleKind")
        when -1
            if PROJ_ShowStartupMessage()
                PROJ_ExampleWarning(Format("PROJ0200 1.0.0.0.377: the Project menu opens after this message. " +
                     "Press <F1> for help; <Alt [> reopens the menu. " +
                     "Set silent=true in proj0200.ini to hide this message."))
            endif
            PROJ_SetStartupMenuSelection()
        when 7
            PROJ_LoadLatestPJLLog()
        when 0
            PROJ_LoadDirectoryNonBinary()
        otherwise
            PROJ_LoadLanguageExample(GetGlobalInt("PROJ_ExampleKind"))
    endcase
end

// PROJ0200 1.0.0.0.377 - OpenAI Codex (GPT-6)
// Set() returns the previous value; restore it after all actions return.
proc Main()
    integer IOldCommonDialogs = Set(UseCommonDialogs, FNProjectWindowsDialogs())
    PROCProjectMainActions()
    Set(UseCommonDialogs, IOldCommonDialogs)
end
