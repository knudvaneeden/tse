// PROJ0200 1.0.0.0.179 - OpenAI Codex (GPT-6)
// Buffer searches compile independently of the project manager.
string g_scopeExpression[255] = ""
string g_scopeFindOptions[24] = "ix"
proc PROJ_CenterList(integer width, integer maxHeight)
    integer boxWidth = Min(width + 2, Query(ScreenCols))
    integer boxHeight = Min(NumLines() + 4, Min(maxHeight, Query(ScreenRows) - 2))
    Set(X1, Max(1, (Query(ScreenCols) - boxWidth) / 2 + 1))
    Set(Y1, Max(1, (Query(ScreenRows) - boxHeight) / 2 + 1))
end

proc PROJ_SearchCurrentBuffer()
    integer originalBuffer = GetBufferId()
    integer resultBuffer = CreateTempBuffer()
    integer matches = 0
    string options[24] = ""
    string display[255]
    if not resultBuffer
        return()
    endif
    GotoBufferId(originalBuffer)
    display = CurrFilename()
    if not Length(display)
        display = "(unnamed current buffer)"
    endif
    if Pos("i", Lower(g_scopeFindOptions))
        options = options + "i"
    endif
    if Pos("x", Lower(g_scopeFindOptions))
        options = options + "x"
    endif
    PushPosition()
    BegFile()
    if lFind(g_scopeExpression, options)
        repeat
            AddLine(Format(display, "(", CurrLine(), ",", CurrCol(), "): ", GetText(1, 255)), resultBuffer)
            matches = matches + 1
        until not lRepeatFind()
    endif
    PopPosition()
    GotoBufferId(resultBuffer)
    AddLine(Format(matches, " matches in current buffer."))
    BegFile()
    PROJ_CenterList(100, Query(ScreenRows))
    lList("Current file search results", 100, Query(ScreenRows), _ENABLE_HSCROLL_)
    AbandonFile(resultBuffer)
    GotoBufferId(originalBuffer)
end

proc PROJ_SearchRing()
    integer originalBuffer = GetBufferId()
    integer ringCount = NumFiles()
    integer resultBuffer
    integer files = 0
    integer matches = 0
    string display[255]
    string options[24] = ""
    if not Ask("Search string in the TSE ring:", g_scopeExpression, _EDIT_HISTORY_)
        return()
    endif
    if not Length(g_scopeExpression) or not Ask("Search options: i=ignore case, x=TSE regex:", g_scopeFindOptions, _EDIT_HISTORY_)
        return()
    endif
    if Pos("i", Lower(g_scopeFindOptions))
        options = options + "i"
    endif
    if Pos("x", Lower(g_scopeFindOptions))
        options = options + "x"
    endif
    resultBuffer = CreateTempBuffer()
    if not resultBuffer
        return()
    endif
    AddLine("Search: " + g_scopeExpression, resultBuffer)
    GotoBufferId(originalBuffer)
    PushBlock()
    UnMarkBlock()
    do ringCount times
        if BufferType() == _NORMAL_
            display = CurrFilename()
            if not Length(display)
                display = "Unnamed buffer " + Str(GetBufferId())
            endif
            files = files + 1
            PushPosition()
            BegFile()
            if lFind(g_scopeExpression, options)
                repeat
                    AddLine(Format(display, "(", CurrLine(), ",", CurrCol(), "): ", GetText(1, 255)), resultBuffer)
                    matches = matches + 1
                until not lRepeatFind()
            endif
            PopPosition()
        endif
        NextFile(_DONT_LOAD_)
    enddo
    GotoBufferId(originalBuffer)
    PopBlock()
    AddLine(Format(matches, " matches in ", files, " open buffers."), resultBuffer)
    GotoBufferId(resultBuffer)
    BegFile()
    PROJ_CenterList(100, Query(ScreenRows))
    lList("TSE ring search results", 100, Query(ScreenRows), _ENABLE_HSCROLL_)
    GotoBufferId(originalBuffer)
    AbandonFile(resultBuffer)
end


proc Main()
    if GetGlobalInt("PROJ_BufferSearchMode") == 1
        g_scopeExpression = GetGlobalStr("PROJ_BufferSearchExpression")
        g_scopeFindOptions = GetGlobalStr("PROJ_BufferSearchOptions")
        PROJ_SearchCurrentBuffer()
    else
        PROJ_SearchRing()
    endif
end
