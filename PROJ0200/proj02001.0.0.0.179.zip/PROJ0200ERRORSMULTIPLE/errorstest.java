class java_multiple_errors {
    public static void main(String[] args) {
        int number = "text";
        boolean flag = 123;
        String text = 456;
    }
}
