fn main() {
    missing_one();
    missing_two();
    missing_three();
}
