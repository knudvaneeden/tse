using System;
class Ddd
{
    static void Main()
    {
        Console.WriteLine(missingOne);
        Console.WriteLine(missingTwo);
        Console.WriteLine(missingThree);
    }
}
