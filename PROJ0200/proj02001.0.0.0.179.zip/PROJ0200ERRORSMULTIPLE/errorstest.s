// SAL multiple-error test.
// Version 1.0.0.0.0 - ChatGPT

PROC Main()
    INTEGER iFirst
    INTEGER iSecond
    INTEGER iThird

    iFirst  = "First deliberate type error"
    iSecond = "Second deliberate type error"
    iThird  = "Third deliberate type error"
END
