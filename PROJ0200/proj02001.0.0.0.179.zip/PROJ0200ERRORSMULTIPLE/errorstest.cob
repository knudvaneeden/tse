       >>SOURCE FORMAT FREE
*> COMCOBOL test version 1.0.0.0.10 - 2026-10-09 - OpenAI Codex
*> Replace missing-first/second/third with quoted text for a success test.
identification division.
program-id. errorstest.
procedure division.
    display "COBOL test version 1.0.0.0.10"
    display missing-first
    display missing-second
    display missing-third
    stop run.
