REM errorstestbbcbasic.bas - version 1.0.0.10
REM Created 2026-10-06 with OpenAI GPT-6 / Codex.
REM First error: line 5. Change 1/0 to 1/1, then rerun for line 7.
PRINT "BBC BASIC error test"
PRINT 1/0
PRINT "First error fixed; testing the second error"
PRINT SQR(-1)
END
