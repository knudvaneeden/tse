; errorstest.nasm version 1.0.0.0.10
; Updated 2026-10-08. LLM: OpenAI GPT-6.
; Intentional errors: lines 10, 11 and 12. No linker is needed for this test.
; Native TCC: COMASSEMBLERNASM.BAT "C:\PROJ0200\PROJ0200ERRORSMULTIPLE\errorstest.nasm"
; CMD: cmd.exe /d /c COMASSEMBLERNASM.BAT "C:\PROJ0200\PROJ0200ERRORSMULTIPLE\errorstest.nasm"
bits 64
default rel
section .text
global main
mov rax, rbx, rcx
mov rdx, rsi, rdi
mov r8, r9, r10
main:
    sub rsp, 40
    xor ecx, ecx
    call ExitProcess
extern ExitProcess
; After checking the three jumps, remove the three invalid MOV lines.
; With those lines removed, this program exits with status zero.
