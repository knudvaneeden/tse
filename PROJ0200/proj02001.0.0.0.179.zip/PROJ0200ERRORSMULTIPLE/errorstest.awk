# Version 1.0.0.7 - Intentional errors on lines 3, 6 and 9.
BEGIN {
    break
}
BEGIN {
    continue
}
BEGIN {
    next
}
