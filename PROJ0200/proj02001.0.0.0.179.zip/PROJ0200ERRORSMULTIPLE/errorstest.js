// version 1.0.0.7 - JavaScript syntax error jump test
// Fix line 3 first, then check again to find line 4.
const first = ;
const second = ;
console.log("Hello from JavaScript", first, second);
