// errorstest.kt - version 1.0.0.11
// OpenAI GPT-6 / Codex. Three independent intentional compiler errors.
// Expected unresolved references: lines 8, 9, 10; column 5 on each line.
// Import the supplied .kt compiler rule in TSE, then compile this file.
// Select each error in the jump list and press Enter to check its location.
// Remove or comment out the three missingFunction calls to run successfully.
fun main() {
    missingFunctionOne()
    missingFunctionTwo()
    missingFunctionThree()
    println("Hello from Kotlin")
}
