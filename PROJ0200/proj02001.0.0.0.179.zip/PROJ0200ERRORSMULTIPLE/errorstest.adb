-- errorstest.adb - version 1.0.0.0.8
-- 2026-10-06 02:22 +0200. OpenAI GPT-6 / Codex.
-- Deliberate independent errors; compile to test TSE error navigation.
procedure Errorstest is
   Number : Integer := 0;
   Flag   : Boolean := False;
begin
   Number := "wrong type"; -- Error: String assigned to Integer.
   Flag := 123;            -- Error: Integer assigned to Boolean.
   Missing_Name := 1;      -- Error: undeclared identifier.
end Errorstest;
