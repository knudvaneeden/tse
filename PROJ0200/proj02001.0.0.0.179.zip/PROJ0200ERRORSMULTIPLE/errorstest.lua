-- errorstest.lua version 1.0.0.7 - OpenAI GPT-6
-- Lua reports only the first syntax error in this whole file.
-- Fix line 7 to: local first = 1
-- Then fix line 10 to: local second = 2
-- Expected column is 1, a fallback because Lua has no error column.

local first = )

-- Second deliberate syntax error (visible after fixing the first).
local second = )

print("Hello from Lua")
