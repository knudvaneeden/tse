(* errorstest.wl - version 1.0.0.0.9 - OpenAI GPT-6 *)
(* Three syntax errors; Mathematica 9 reports the first, then stops. *)
(* Fix and rerun successively: lines 6, 9, 12; column fallback is 1. *)
Print["Mathematica test version 1.0.0.0.9"];

first = 1 + * 2;
Print["After first error"];

second = 3 + / 4;
Print["After second error"];

third = 5 + ^ 6;
Print["After third error"];
(* Fix the three expressions to test a successful run. *)
