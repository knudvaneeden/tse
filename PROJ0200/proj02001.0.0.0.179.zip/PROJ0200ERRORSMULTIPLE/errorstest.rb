# errorstest.rb version 1.0.0.7 - OpenAI GPT-6 / Codex
# Three independent syntax errors: surplus ')' on lines 6, 9, and 12.
# Ruby may recover and report several errors; recovery varies by version.
# Remove the final ')' from each puts line to print all three greetings.

puts("Hello from Ruby - first") )

# Second deliberate error:
puts("Hello from Ruby - second") )

# Third deliberate error:
puts("Hello from Ruby - third") )
