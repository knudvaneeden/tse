// errorstest.swift version 1.0.0.0.7
// Three independent intentional errors for TSE line/column jump testing.
// Expected diagnostic locations: 6:7, 9:7, 12:7.
// Fix by replacing the three missing names with quoted strings.

print(missingFirst)

// Second independent error.
print(missingSecond)

// Third independent error.
print(missingThird)
