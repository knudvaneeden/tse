// errorstest.scala - version 1.0.0.0.8 - 2026-10-09
// OpenAI GPT-6. Three independent, intentional compile-time errors.
// Expected locations: 6:13, 9:13, 12:13. Replace missing names with 1, 2, 3.
object errorstest {
  def main(args: Array[String]): Unit = {
    println(missingFirst)

    // Second intentional error.
    println(missingSecond)

    // Third intentional error.
    println(missingThird)
  }
}
