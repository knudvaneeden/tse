-- errorstest.hs version 1.0.0.13 - OpenAI GPT-6
-- Three deliberate name errors for TSE filename/line/column jump tests.
-- Remove lines 5-12 to run the valid main program below.

first :: Int
first = missingFirst

second :: Int
second = missingSecond

third :: Int
third = missingThird

main :: IO ()
main = putStrLn "Hello from Haskell - version 1.0.0.13"
