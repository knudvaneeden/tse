;; errorstest.clj version 1.0.0.0.10
;; Updated 2026-10-09. OpenAI GPT-6 (Codex).
;; Normal script execution stops at the first uncaught error.
;; Comment out each failing form in turn to expose the next error.
(println "Clojure test version 1.0.0.0.10")
(println missingFirst)

;; Second error, exposed after commenting out line 6.
(println missingSecond)

;; Third error, exposed after commenting out lines 6 and 9.
(println missingThird)

;; Comment out lines 6, 9 and 12 for the successful smoke test.
(println "Hello from Clojure!")
