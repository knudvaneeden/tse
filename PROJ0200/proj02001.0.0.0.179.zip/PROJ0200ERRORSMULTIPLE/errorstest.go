package main

func main() {
    println(missingOne)
    println(missingTwo)
    println(missingThree)
}
