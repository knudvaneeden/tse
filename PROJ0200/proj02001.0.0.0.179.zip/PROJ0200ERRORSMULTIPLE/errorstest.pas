program errorstest;
{ Version 1.0.0.0.10 - OpenAI GPT-6 }
{ Three intentional type errors on lines 10, 11, and 12. }
{ DCC32 reports line numbers; native diagnostics do not supply columns. }
var
  numberValue: Integer;
  booleanValue: Boolean;
  textValue: string;
begin
  numberValue := 'not an integer';
  booleanValue := 123;
  textValue := False;
  WriteLn('Hello from Delphi');
end.
