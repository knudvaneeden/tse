# Maple multiple syntax-error test - version 1.0.0.0.14
# OpenAI GPT-6. Checked by Maple V Release 5 Student Mint.
# Run COMMAPLE.BAT with this filename to check all three errors.
# Intentional syntax error 1, line 5:
first := 1 + * 2;
# Correct independent statement to help recovery:
print("After first error");
# Intentional syntax error 2, line 9:
second := 3 + / 4;
print("After second error");
# Intentional syntax error 3, line 12:
third := 5 + ^ 6;
print("End of error test 1.0.0.0.14");
