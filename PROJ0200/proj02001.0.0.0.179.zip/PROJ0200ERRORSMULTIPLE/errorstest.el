;;; errorstest.el - version 1.0.0.7 -*- lexical-binding: t; -*-
;; Three intentional BYTE-COMPILER WARNINGS; these are not syntax errors.
;; COMEMACSLISP stops before running a file that has compiler diagnostics.
;; Replace the missing references with numbers to test a successful run.

(defun cem-test-first ()
  (+ 1 cem-missing-first))

(defun cem-test-second ()
  (+ 2 cem-missing-second))

(defun cem-test-third ()
  (+ 3 cem-missing-third))

(princ "Hello from Emacs Lisp\n")
