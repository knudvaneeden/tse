use strict;
use warnings;

$first_error = 1;

$second_error = 2;

$third_error = 3;
