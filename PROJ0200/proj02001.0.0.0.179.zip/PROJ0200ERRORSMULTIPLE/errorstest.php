<?php
// errorstest.php version 1.0.0.7 - OpenAI GPT-6
// Intentional runtime warnings: both should appear in the TSE error list.
// Expected jumps: line 6 and line 7; PHP supplies no diagnostic column.
echo "PHP test version 1.0.0.7\n";
trigger_error("First intentional warning", E_USER_WARNING);
trigger_error("Second intentional warning", E_USER_WARNING);
trigger_error("Third intentional warning", E_USER_WARNING);
exit(1); // Deliberate nonzero exit so the runner reports failure.
// Syntax-error test: remove the closing parenthesis on line 6.
// PHP then stops at the first syntax error; restore it to test both warnings.
