-- errorstest.lean version 1.0.0.0.8
-- Three independent, deliberate Lean elaboration errors.
-- Compile with: lean errorstest.lean

-- First error: unknown identifier.
def first : Nat := missingFirst

-- Second error: unknown identifier.
def second : Nat := missingSecond

-- Third error: unknown identifier.
def third : Nat := missingThird
