# errorstest.jl version 1.0.0.0.8 - ChatGPT
# Three independently caught runtime errors, not a multi-error compiler pass.
# Each diagnostic uses the actual stack-frame line; column 1 is a fallback.
# To test the ordinary first-error behavior, run: missingFirst()
println("Julia error test version 1.0.0.0.8")

function first_test()
    missingFirst()
end

function second_test()
    missingSecond()
end

function third_test()
    missingThird()
end

for test in (first_test, second_test, third_test)
    try
        test()
    catch err
        frame = first(stacktrace(catch_backtrace()))
        println(stderr, "TSE: ", abspath(@__FILE__), ":", frame.line,
                ":1: ", sprint(showerror, err))
    end
end
# All three errors were caught and reported; return a failing test exit code.
exit(1)
