print("Starting test")

first = 1 / 0

second = unknown_variable

third = int("not a number")
