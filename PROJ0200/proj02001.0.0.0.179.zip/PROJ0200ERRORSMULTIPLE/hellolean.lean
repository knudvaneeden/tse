-- hellolean.lean version 1.0.0.0.8
-- Expected: proof checks, then program prints Hello from Lean 4.
theorem two_plus_two : 2 + 2 = 4 := by
  decide

def main : IO Unit := do
  IO.println "Hello from Lean 4"
