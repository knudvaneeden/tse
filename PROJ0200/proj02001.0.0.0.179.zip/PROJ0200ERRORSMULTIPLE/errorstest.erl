% errorstest.erl version 1.0.0.9
% OpenAI GPT-6 / Codex. Intentional compile errors; no helper program.
% Expect errors at 9:31, 10:32, and 11:31 (line:column).
% Fix by replacing MissingOne/Two/Three with 1/2/3, respectively.
-module(errorstest).
-export([errorstest/0]).

errorstest() ->
    io:format("First: ~p~n", [MissingOne]),
    io:format("Second: ~p~n", [MissingTwo]),
    io:format("Third: ~p~n", [MissingThree]).
