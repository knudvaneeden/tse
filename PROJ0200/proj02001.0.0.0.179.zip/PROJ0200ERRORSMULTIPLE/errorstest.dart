// errorstest.dart version 1.0.0.0.8 - 2026-10-09
// OpenAI GPT-6 / Codex. Intentional compilation errors for TSE navigation.
// Expected locations: 6:3, 9:3, 12:3. This program must not run.
void main() {
  // First undefined function.
  missingFirst();

  // Second undefined function.
  missingSecond();

  // Third undefined function.
  missingThird();
}
