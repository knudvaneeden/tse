// errorstest.ts version 1.0.0.8 - OpenAI GPT-6
// Three independent type errors: expected on lines 4, 5 and 6.
// Fix the values to 123, "text", and true to run successfully.
const testNumber: number = "not a number";
const testText: string = 123;
const testBoolean: boolean = "not a boolean";
console.log("Hello from TypeScript", testNumber, testText, testBoolean);
