-- Three independent errors; no database changes.
SELECT * FROM;
SELECT 1 + ;
SELECT (2 * );
SELECT 'Finished checking all statements' AS message;
