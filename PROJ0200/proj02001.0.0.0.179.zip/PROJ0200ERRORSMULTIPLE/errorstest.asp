<%@ Language="VBScript" %>
<%
' errorstest.asp - version 1.0.0.8
' Updated 2026-10-06 03:18 +02:00; OpenAI GPT-6 (Codex).
' Classic ASP normally reports one stopping error per request.
' First: line 9 is missing a closing parenthesis. Add ) and rerun.
' Second: line 10 divides by zero. Change 0 to 1 and rerun.
Dim answer
Response.Write("Hello from Classic ASP"
answer = 10 / 0
Response.Write " Answer: " & answer
%>
