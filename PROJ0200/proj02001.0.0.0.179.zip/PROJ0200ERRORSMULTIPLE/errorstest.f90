program test_errors
  implicit none

  first = 1
  second = 2
end program test_errors
