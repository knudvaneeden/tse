int main(void)
{
    missingOne = 1;
    missingTwo = 2;
    missingThree = 3;
    return 0;
}
