COMASP version 1.0.0.8
=====================
Updated 2026-10-06 03:18 +02:00. Prepared with OpenAI GPT-6 (Codex).

Place COMASP.BAT and COMASP.ps1 together on your batch search path. The helper
is required. Import the supplied .asp compiler rule into TSE. All four code/rule
files use version 1.0.0.8. The BAT retains separate local settings and stable logic.

Configure ASP_WEB_ROOT and ASP_BASE_URL in the BAT for an existing LOCAL IIS
site with Classic ASP installed. No IIS configuration changes are made by the
runner. In IIS Manager, the site's ASP > Debugging Properties > Send Errors To
Browser must be True. Error Pages must preserve the ASP-generated error body
for local requests (rather than replace it with a generic 500 page). Enable this
for your local development site; these errors may disclose source details.
Windows PowerShell 5.1 is used; no third-party packages are needed.

The runner copies the selected file into IIS and issues an HTTP request. That
executes the ASP page, including any application side effects. Only one file is
copied; includes and database dependencies must already be configured. OVERWRITE_PAGE=1 now replaces the deployed page for repeated tests.
Set it to 0 to protect existing destination files. The deployed
copy stays in IIS. OPEN_BROWSER defaults to 0 because opening a browser would
execute the page a second time. Set it to 1 if you want that behavior after success.

Use the TCC and CMD commands in the BAT header. Both enter through the BAT;
the runner delegates to Windows CMD to keep quoting behavior consistent. The
six-argument call writes errors to the exact path supplied in argument 6. A
successful request leaves that file empty, preventing status text from appearing
as a TSE error. Status and exit codes remain visible in the console.

TSE error records have this shape:

    C:\PROJ0200\CTAGSEXAMPLES\errorstest.asp(9,1): Error: ...

The rule extracts the full filename, line and column; Message uses Tag=0 so
TSE displays the entire record, including location. This is a single response
capture, not a separate offline ASP compiler. IIS error-page formatting varies;
the parser recognizes English locations such as /errorstest.asp, line 9 and an
optional explicit column. If IIS omits the column, column 1 is used and clearly
labelled. Unrecognized HTTP errors are reported at fallback position (1,1),
never as successful compilation. Errors from another server file are also
labelled and use fallback (1,1); includes are not falsely mapped to this source.
Redirects and authentication errors are reported as failures. A successful HTTP
response alone cannot prove the absence of suppressed application errors.

Classic ASP normally reports one stopping compilation/runtime error per request;
this runner does not aggregate errors or resume through failures. In TSE:

1. Compile errorstest.asp: the missing parenthesis is on line 9.
2. Check the displayed line/column and jump to that error.
3. Add the closing parenthesis on line 9 and rerun.
4. The division by zero is now on line 10; check its jump.
5. Change the divisor from 0 to 1 and rerun: expect Hello and no error records.

Do not expect both errors simultaneously. This exercises consecutive error
navigation. IIS may report a neighboring token/line for syntax errors; its
reported location is preserved. Also test a nonexistent file, invalid web root,
and protected existing destination. These must return nonzero exit codes.

Validation performed here: ASCII/CRLF files, consistent versions, BAT label
references, rule tag assignments and representative IIS-location parsing.
Windows CMD, TCC, PowerShell, IIS and TSE are not installed in this environment;
actual execution and TSE navigation need verification on your Windows machine.

References:
- https://learn.microsoft.com/en-us/iis/application-frameworks/running-classic-asp-applications-on-iis-7-and-iis-8/classic-asp-script-error-messages-no-longer-shown-in-web-browser-by-default
- https://learn.microsoft.com/en-us/previous-versions/iis/6.0-sdk/ms524942(v=vs.90)
