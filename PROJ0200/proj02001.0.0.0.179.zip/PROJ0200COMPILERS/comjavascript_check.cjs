// version 1.0.0.7 - OpenAI GPT-6 - 2026-10-06
// Adapter for Node --check; no third-party packages required.
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const [, , input, output] = process.argv;
let text = '', code = 2;
try {
  if (!input) throw new Error('Source filename is required');
  const source = path.resolve(input);
  if (!fs.statSync(source).isFile()) throw new Error('Source is not a file');
  const check = spawnSync(process.execPath, ['--check', source], {
    encoding: 'utf8', windowsHide: true, maxBuffer: 8 * 1024 * 1024
  });
  if (check.error) throw check.error;
  if (check.signal) throw new Error('Syntax checker terminated: ' + check.signal);
  if (check.status === 0) {
    text = 'Syntax check successful: ' + source + '\n';
    code = 0;
  } else {
    const lines = (check.stderr || check.stdout || '').split(/\r?\n/);
    const location = lines.findIndex(line => line.startsWith(source + ':'));
    const match = location >= 0 && lines[location].slice(source.length).match(/^:(\d+)(?::(\d+))?$/);
    const message = lines.find(line => /^SyntaxError:/.test(line));
    if (match && message) {
      const caret = lines[location + 2] || '';
      const column = match[2] ? Number(match[2]) : Math.max(1, caret.indexOf('^') + 1);
      const detail = caret.includes('^') || match[2] ? '' : ' [column unavailable; using 1]';
      text = source + '(' + match[1] + ',' + column + '): Error: ' + message + detail + '\n';
      code = 1;
    } else {
      // Never invent a jump target for an unrecognized Node diagnostic.
      text = 'ERROR: Unrecognized Node diagnostic\n' + lines.join('\n') + '\n';
      code = 2;
    }
  }
} catch (error) {
  text = 'ERROR: ' + String(error.message).replace(/[\r\n]+/g, ' ') + '\n';
}
try {
  fs.writeFileSync(output, text.replace(/\n/g, '\r\n'), 'utf8');
} catch (error) {
  console.error('ERROR: Cannot write diagnostic file: ' + error.message);
  process.exit(2);
}
process.exit(code);
