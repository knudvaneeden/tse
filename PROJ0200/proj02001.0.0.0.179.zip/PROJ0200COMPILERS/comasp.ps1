# COMASP.ps1 - version 1.0.0.8
# 2026-10-06 03:18 +02:00; OpenAI GPT-6 (Codex).
# Invoked by COMASP.BAT. Settings and paths arrive through the environment.
$ErrorActionPreference = 'Stop'
$version = '1.0.0.8'
$source = $env:COMASP_SOURCE
$log = $env:COMASP_LOG
$encoding = [Text.Encoding]::Default
$logReady = $false
function Write-Diagnostic([string]$file, [int]$line, [int]$column, [string]$message) {
    $message = ($message -replace '[\r\n]+', ' ').Trim()
    $record = '{0}({1},{2}): Error: {3}' -f $file, $line, $column, $message
    Write-Host $record
    if ($script:logReady) { [IO.File]::AppendAllText($log, $record + "`r`n", $encoding) }
}
function Get-AspDiagnostic([string]$html, [string]$expectedPath) {
    $plain = $html -replace '(?i)<(?:br\s*/?|/?p|/?div)[^>]*>', "`n"
    $plain = [Net.WebUtility]::HtmlDecode(($plain -replace '<[^>]*>', ''))
    $location = [regex]::Match($plain, '(?im)^\s*(?<file>/[^\r\n,]+\.asp)\s*,\s*line\s+(?<line>\d+)(?:\s*,\s*column\s+(?<column>\d+))?')
    if (-not $location.Success) { return $null }
    $lines = @($plain -split '[\r\n]+' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
    $message = $lines -join ' | '
    if ($message.Length -gt 1600) { $message = $message.Substring(0,1600) }
    $line = [int]$location.Groups['line'].Value
    $column = 1
    if ($location.Groups['column'].Success -and [int]$location.Groups['column'].Value -gt 0) {
        $column = [int]$location.Groups['column'].Value
    } else { $message += ' | column unavailable from IIS; using column 1' }
    $serverPath = [Uri]::UnescapeDataString($location.Groups['file'].Value)
    if ($serverPath -ine [Uri]::UnescapeDataString($expectedPath)) {
        # Do not map include-file line numbers onto the selected source.
        $line = 1; $column = 1
        $message += ' | error is in another server file; source position is fallback (1,1)'
    }
    return [pscustomobject]@{ Line=$line; Column=$column; Message=$message }
}
try {
    if ([string]::IsNullOrWhiteSpace($source)) { throw 'Supply a .asp source filename.' }
    $source = [IO.Path]::GetFullPath($source)
    $name = [IO.Path]::GetFileName($source)
    $target = [IO.Path]::GetFullPath([IO.Path]::Combine($env:ASP_WEB_ROOT, $name))
    $log = [IO.Path]::GetFullPath($log)
    if ($log -ieq $source -or $log -ieq $target -or $log -ieq $PSCommandPath) {
        throw 'Diagnostics path would overwrite a source, helper or deployed page.'
    }
    if ([IO.Path]::GetExtension($log) -notin @('.err','.txt','.log')) {
        throw 'Use a .err, .txt or .log diagnostics file.'
    }
    [IO.File]::WriteAllText($log, '', $encoding)
    $logReady = $true
    if (-not [IO.File]::Exists($source)) { throw "Source file not found: $source" }
    if ([IO.Path]::GetExtension($source) -ine '.asp') { throw 'The source must have extension .asp.' }
    if (-not [IO.Directory]::Exists($env:ASP_WEB_ROOT)) { throw "IIS directory not found: $env:ASP_WEB_ROOT" }
    $base = [Uri]$env:ASP_BASE_URL
    if (-not $base.IsAbsoluteUri -or $base.Scheme -notin @('http','https') -or -not $base.IsLoopback) {
        throw 'ASP_BASE_URL must be an absolute local http://localhost/ or loopback URL.'
    }
    if ($base.Query -or $base.Fragment -or -not $base.AbsolutePath.EndsWith('/')) {
        throw 'ASP_BASE_URL must end in / and contain no query or fragment.'
    }
    $url = $base.AbsoluteUri + [Uri]::EscapeDataString($name)
    if ($source -ine $target) {
        if ([IO.Directory]::Exists($target)) { throw "Destination is a directory: $target" }
        $overwrite = $env:OVERWRITE_PAGE -eq '1'
        [IO.File]::Copy($source, $target, $overwrite)
    }
    Write-Host "COMASP version $version"
    Write-Host "Requesting $url"
    $request = [Net.HttpWebRequest]::Create($url)
    $request.AllowAutoRedirect = $false
    $request.UseDefaultCredentials = $true
    $seconds = [int]$env:HTTP_TIMEOUT_SECONDS
    if ($seconds -lt 1 -or $seconds -gt 600) { throw 'HTTP_TIMEOUT_SECONDS must be 1 to 600.' }
    $request.Timeout = $seconds * 1000
    $request.ReadWriteTimeout = $request.Timeout
    $response = $null
    try { $response = $request.GetResponse() }
    catch [Net.WebException] {
        if ($null -eq $_.Exception.Response) { throw }
        $response = $_.Exception.Response
    }
    try {
        $status = [int]$response.StatusCode
        $reader = New-Object IO.StreamReader($response.GetResponseStream())
        try { $body = $reader.ReadToEnd() } finally { $reader.Dispose() }
    } finally { $response.Close() }
    $diagnostic = Get-AspDiagnostic $body ([Uri]$url).AbsolutePath
    if ($null -ne $diagnostic) {
        Write-Diagnostic $source $diagnostic.Line $diagnostic.Column $diagnostic.Message
        exit 1
    }
    if ($status -lt 200 -or $status -ge 300) {
        throw "HTTP $status without a recognizable ASP location. Enable local detailed ASP errors and preserve the ASP response in IIS Error Pages. Position (1,1) is a fallback."
    }
    # A missing ASP handler can serve script text as a successful static response.
    if ($body.Contains('<%')) { throw 'Response contains unexecuted ASP script. Check the IIS ASP handler. Position (1,1) is a fallback.' }
    Write-Host "HTTP ${status}: page request completed without a reported ASP error."
    if ($env:OPEN_BROWSER -eq '1') {
        if ([string]::IsNullOrWhiteSpace($env:BROWSER_EXE)) { Start-Process $url }
        else { Start-Process -FilePath $env:BROWSER_EXE -ArgumentList ('"' + $url + '"') }
    }
    Write-Host "Diagnostics saved to $log (empty on success)."
    exit 0
} catch {
    if ([string]::IsNullOrWhiteSpace($source)) { $source = 'COMASP.BAT' }
    Write-Diagnostic $source 1 1 ($_.Exception.Message + ' | runner/setup position fallback (1,1)')
    exit 2
}
