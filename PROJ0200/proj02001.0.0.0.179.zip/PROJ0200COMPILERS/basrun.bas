      REM basrun - version 1.0.0.0.10
      REM Updated 2026-10-06 with OpenAI GPT-6 / Codex.
      REM Based on Richard Russell's BAS command-line helper (April 2019).
      REM Save this text from the BBC BASIC IDE as tokenised basrun.bbc.
      REM Unnumbered programs use physical source lines, including blank lines.
      REM Explicit BASIC line numbers are retained for GOTO/GOSUB compatibility;
      REM diagnostics for numbered programs refer to BASIC numbers, not editor rows.
      REM Test with PRINT 1/0 on physical line 4 of an unnumbered program.
      REM The source file is read only and is never rewritten.

      PRINT "basrun launcher version 1.0.0.0.10"

      REM. Find address of string accumulator:
      IF INKEY(-256)<>&57 IF @platform% AND &40 Accs%% = ]332 ELSE Accs%% = !332

      REM. Allocate a 256-byte string buffer:
      DIM Buff%% 255

      REM. Find BAS file name:
      IF ASC@cmd$=&22 P% = INSTR(@cmd$,"""",2) ELSE P% = INSTR(@cmd$," ",2)
      IF P% = 0 ERROR 0, "No BAS filename specified"

      REM. Open BAS file:
      F% = OPENIN MID$(@cmd$,P%+1)
      IF F% = 0 ERROR 0, "Couldn't open file " + MID$(@cmd$,P%+1)

      REM. Allocate space for program:
      DIM Prog%% 5 * EXT#F% + 511
      Prog%% = (Prog%% + 255) AND -256
      PAGE = Prog%%

      REM. Read and tokenise BAS file:
      SourceLine% = 0
      WHILE NOT EOF#F%
        SourceLine% += 1
        IF SourceLine% > 65534 ERROR 0, "Too many source lines"
        REM Read one physical line. Consume CRLF together, not as two lines.
        $Buff%% = ""
        FinishedLine% = FALSE
        WHILE NOT EOF#F% AND NOT FinishedLine%
          C% = BGET#F%
          IF C%=13 OR C%=10 THEN
            FinishedLine% = TRUE
            IF C%=13 AND NOT EOF#F% THEN
              C% = BGET#F%
              IF C%<>10 PTR#F% = PTR#F%-1
            ENDIF
          ELSE
            IF LEN$Buff%%>=251 ERROR 0, "Source line too long"
            $Buff%% += CHR$C%
          ENDIF
        ENDWHILE
        IF $Buff%%<>"" THEN
          REM Remove indentation, then recognise only a separated line number.
          WHILE ?Buff%%=&20 OR ?Buff%%=9 $Buff%% = MID$($Buff%%,2) : ENDWHILE
          N% = SourceLine%
          J% = 1
          WHILE MID$($Buff%%,J%,1)>="0" AND MID$($Buff%%,J%,1)<="9" AND J%<=LEN$Buff%%
            J% += 1
          ENDWHILE
          IF J%>1 AND (J%>LEN$Buff%% OR MID$($Buff%%,J%,1)=" " OR MID$($Buff%%,J%,1)=CHR$9) THEN
            N% = VAL$Buff%%
            IF N%>65534 ERROR 0, "BASIC line number too large"
            $Buff%% = MID$($Buff%%,J%)
          ENDIF
          REPEAT I%=INSTR($Buff%%,".") : IF I% MID$($Buff%%,I%,1) = CHR$17
          UNTIL I%=0 : REPEAT I%=INSTR($Buff%%,"\") : IF I% MID$($Buff%%,I%,1) = CHR$18
          UNTIL I%=0 : IF EVAL("1RECTANGLERECTANGLE:"+$Buff%%) $Buff%% = $(Accs%%+4)
          REPEAT I%=INSTR($Buff%%,CHR$18) : IF I% MID$($Buff%%,I%,1) = "\"
          UNTIL I%=0 : REPEAT I%=INSTR($Buff%%,CHR$17) : IF I% MID$($Buff%%,I%,1) = "."
          UNTIL I%=0 : L% = LEN$Buff%% + 4 : IF L%>255 ERROR 0, "Line too long"
          $Prog%% = CHR$(L%)+CHR$(N%MOD256)+CHR$(N%DIV256)+$Buff%% : Prog%% += L% : ?Prog%% = 0
        ENDIF
      ENDWHILE
      CLOSE #F% : !Prog%% = &FFFF00

      REM Transfer control to the loaded program, as in the original helper.
      RUN
