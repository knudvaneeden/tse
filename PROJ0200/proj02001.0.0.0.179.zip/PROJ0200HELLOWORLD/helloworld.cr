puts "Hello world"





1/0
adfasdf  --   //// ddfdf

