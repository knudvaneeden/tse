echo "Hello world"
