console.log("Hello world");
1 / 0;
ada; // add fffd ----
a / 2343;
