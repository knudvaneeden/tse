using System;
class HelloWorld {
 static public void Main() {
  System.Console.WriteLine( "Hello world" );
 }
}
