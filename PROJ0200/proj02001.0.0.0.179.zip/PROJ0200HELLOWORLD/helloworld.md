Hello world

$\int_a^b{ e^ \left( -x \right) dx }$
