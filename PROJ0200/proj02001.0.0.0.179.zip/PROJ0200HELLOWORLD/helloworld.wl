Print[ Integrate[ x, x ] ]
Print[ Integrate[ x^3, x ] ]
Print[ "Hello world" ]
