print "Hello world";

1/0
