print( "Hello world" )
