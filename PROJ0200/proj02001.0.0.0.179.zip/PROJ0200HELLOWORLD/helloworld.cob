      * Sample COBOL program - https://gnucobol.sourceforge.io/doc/gnucobol.html
       IDENTIFICATION DIVISION.
       PROGRAM-ID. hello.
       PROCEDURE DIVISION.
           DISPLAY "Hello world".
           STOP RUN.
