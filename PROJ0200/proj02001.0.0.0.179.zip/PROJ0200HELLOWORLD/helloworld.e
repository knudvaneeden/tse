#include "slick.sh"
_command void mymacro01() {
 message("Hello world\n");
}
1/0





