<!DOCTYPE html>
<html>
<head>
   <title>Hello, World!</title>
</head>
<body>
   <cfoutput>
      Hello, World!
   </cfoutput>
</body>
</html>
