printf( "Hello world" );
int( x^2, x );
