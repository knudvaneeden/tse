public class HelloWorld {
 public static void main( String[] args ) {
  System.out.println( "Hello World" );
 }
}

1/0

asdfasdfasdfasdf
