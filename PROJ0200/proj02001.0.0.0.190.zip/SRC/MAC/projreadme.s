// PROJ0200 1.0.0.0.190 - OpenAI Codex (GPT-6)
// Read-only Markdown help. Keys exist only while a help list is active.
dll "<shell32.dll>"
    integer proc PROJ_HelpShell(integer owner, integer operation,
        string target:cstrval, string parameters:cstrval,
        string directory:cstrval, integer showMode) : "ShellExecuteA"
end
integer g_helpAction = 0
string g_helpSearch[255] = ""
string g_helpSearchFlags[24] = "i"

keydef PROJ_ReadmeKeys
<F2> g_helpAction = 2 PushKey(<Escape>)
<F3> g_helpAction = 4 PushKey(<Escape>)
<Alt F3> g_helpAction = 5 PushKey(<Escape>)
<Alt Left> g_helpAction = 3 PushKey(<Escape>)
end

string proc PROJ_HeadingSlug(string text)
    integer index
    string slug[255] = ""
    string letter[1]
    string normalized[255] = Lower(Trim(text))
    for index = 1 to Length(normalized)
        letter = SubStr(normalized, index, 1)
        if Pos(letter, "abcdefghijklmnopqrstuvwxyz0123456789_-")
            slug = slug + letter
        elseif letter == " "
            slug = slug + "-"
        endif
    endfor
    return(slug)
end

proc PROJ_CollectHelpLinks(integer source, integer destination, integer onlyLine)
    integer lineIndex
    integer startAt
    integer endAt
    integer firstLine = 1
    integer lastLine
    string lineText[255]
    string target[255]
    GotoBufferId(source)
    lastLine = NumLines()
    if onlyLine
        firstLine = CurrLine()
        lastLine = firstLine
    endif
    PushPosition()
    for lineIndex = firstLine to lastLine
        GotoBufferId(source)
        GotoLine(lineIndex)
        lineText = GetText(1, 255)
        // Inline Markdown links [label](target), including images.
        repeat
            startAt = Pos("](", lineText)
            if not startAt
                break
            endif
            lineText = SubStr(lineText, startAt + 2, 255)
            endAt = Pos(")", lineText)
            if not endAt
                break
            endif
            target = Trim(SubStr(lineText, 1, endAt - 1))
            if Length(target)
                AddLine(target, destination)
            endif
            lineText = SubStr(lineText, endAt + 1, 255)
        until not Length(lineText)
        // Bare/angle-bracket web URLs on lines without inline links.
        lineText = GetText(1, 255)
        if not Pos("](", lineText)
            startAt = Pos("https://", lineText)
            if not startAt
                startAt = Pos("http://", lineText)
            endif
            if startAt
                target = GetToken(SubStr(lineText, startAt, 255), " " + Chr(9) + ">", 1)
                AddLine(target, destination)
            endif
        endif
    endfor
    GotoBufferId(source)
    PopPosition()
end

proc Main()
    integer originalBuffer = GetBufferId()
    integer searchHistory = GetFreeHistory("projreadme:searchtext")
    integer optionsHistory = GetFreeHistory("projreadme:searchoptions")
    integer helpBuffer
    integer linksBuffer
    integer historyBuffer
    integer selected
    integer helpLine
    integer anchorAt
    integer index
    integer found
    string searchOptions[24]
    string document[255] = SplitPath(CurrMacroFilename(), _DRIVE_|_PATH_) + "proj0200_readme.md"
    string target[255]
    string anchor[255]
    string record[255]
    string heading[255]
    g_helpSearch = GetHistoryStr(searchHistory, 1)
    g_helpSearchFlags = GetHistoryStr(optionsHistory, 1)
    if not Length(g_helpSearchFlags)
        g_helpSearchFlags = "i"
    endif
    if not FileExists(document)
        Warn("README help file could not be found: " + document)
        return()
    endif
    helpBuffer = CreateTempBuffer()
    if not helpBuffer
        return()
    endif
    if not InsertFile(document, _DONT_PROMPT_)
        GotoBufferId(originalBuffer)
        AbandonFile(helpBuffer)
        return()
    endif
    historyBuffer = CreateTempBuffer()
    if not historyBuffer
        GotoBufferId(originalBuffer)
        AbandonFile(helpBuffer)
        return()
    endif
    GotoBufferId(helpBuffer)
    BegFile()
    loop
        g_helpAction = 0
        Enable(PROJ_ReadmeKeys)
        selected = lList("README: Enter=link F2=Links F3=Search Alt+F3=Next Esc=back", Query(ScreenCols)-4, Query(ScreenRows)-4, _ENABLE_HSCROLL_)
        Disable(PROJ_ReadmeKeys)
        helpLine = CurrLine()
        if g_helpAction == 4 or g_helpAction == 5
            if g_helpAction == 4 or not Length(g_helpSearch)
                if Ask("Search README:", g_helpSearch, searchHistory)
                    if Length(g_helpSearch)
                        if Ask("Search options: i=ignore case, x=TSE regex:", g_helpSearchFlags, optionsHistory)
                            g_helpAction = 4
                        else
                            g_helpAction = 0
                        endif
                    else
                        g_helpAction = 0
                    endif
                else
                    g_helpAction = 0
                endif
            endif
            if g_helpAction
                searchOptions = ""
                if Pos("i", Lower(g_helpSearchFlags))
                    searchOptions = searchOptions + "i"
                endif
                if Pos("x", Lower(g_helpSearchFlags))
                    searchOptions = searchOptions + "x"
                endif
                PushPosition()
                if g_helpAction == 4
                    BegFile()
                else
                    NextChar()
                endif
                found = lFind(g_helpSearch, searchOptions)
                if not found and g_helpAction == 5
                    BegFile()
                    found = lFind(g_helpSearch, searchOptions)
                endif
                if found
                    helpLine = CurrLine()
                    PopPosition()
                    GotoLine(helpLine)
                else
                    PopPosition()
                    Warn("Text not found in this help document: " + g_helpSearch)
                endif
            endif
        elseif g_helpAction == 3
            GotoBufferId(historyBuffer)
            if NumLines() and Length(GetText(1, 255))
                EndFile()
                record = GetText(1, 255)
                KillLine()
                target = GetToken(record, "|", 1)
                GotoBufferId(helpBuffer)
                if target <> document
                    if FileExists(target)
                        EmptyBuffer()
                        InsertFile(target, _DONT_PROMPT_)
                        document = target
                    endif
                endif
                GotoLine(Val(GetToken(record, "|", 2)))
            else
                GotoBufferId(helpBuffer)
            endif
        elseif selected or g_helpAction == 2
            linksBuffer = CreateTempBuffer()
            if linksBuffer
                GotoBufferId(helpBuffer)
                PROJ_CollectHelpLinks(helpBuffer, linksBuffer, iif(g_helpAction == 2, 0, 1))
                GotoBufferId(linksBuffer)
                BegFile()
                target = ""
                if Length(GetText(1, 255))
                    if lList("Choose a link - Enter=open Esc=cancel", Query(ScreenCols)-4, Query(ScreenRows)-4, _ENABLE_HSCROLL_)
                        target = GetText(1, 255)
                    endif
                else
                    Warn("No supported link here. Press F2 for all README links.")
                endif
                GotoBufferId(helpBuffer)
                AbandonFile(linksBuffer)
                if Length(target)
                    target = GetToken(target, " " + Chr(9), 1)
                    if SubStr(target, 1, 1) == "<"
                        target = SubStr(target, 2, Length(target)-2)
                    endif
                    if Pos("https://", Lower(target)) == 1 or Pos("http://", Lower(target)) == 1 or Pos("mailto:", Lower(target)) == 1
                        if PROJ_HelpShell(0, 0, target, "", "", 1) <= 32
                            Warn("Cannot open link: " + target)
                        endif
                    else
                        anchor = ""
                        anchorAt = Pos("#", target)
                        if anchorAt
                            anchor = SubStr(target, anchorAt+1, 255)
                            target = SubStr(target, 1, anchorAt-1)
                        endif
                        if not Length(target)
                            target = document
                        elseif not Length(SplitPath(target, _DRIVE_)) and SubStr(target, 1, 1) <> "\"
                            target = SplitPath(document, _DRIVE_|_PATH_) + target
                        endif
                        target = ExpandPath(target)
                        if FileExists(target)
                            AddLine(document + "|" + Str(helpLine), historyBuffer)
                            if Lower(SplitPath(target, _EXT_)) == ".md" or Lower(SplitPath(target, _EXT_)) == ".txt"
                                if target <> document
                                    EmptyBuffer()
                                    InsertFile(target, _DONT_PROMPT_)
                                    document = target
                                endif
                                BegFile()
                                if Length(anchor)
                                    found = FALSE
                                    for index = 1 to NumLines()
                                        GotoLine(index)
                                        heading = Trim(GetText(1, 255))
                                        if SubStr(heading, 1, 1) == "#"
                                            while SubStr(heading, 1, 1) == "#"
                                                heading = SubStr(heading, 2, 254)
                                            endwhile
                                            if PROJ_HeadingSlug(heading) == Lower(anchor)
                                                found = TRUE
                                                break
                                            endif
                                        endif
                                    endfor
                                    if not found
                                        GotoLine(helpLine)
                                        Warn("Heading not found: " + anchor)
                                    endif
                                endif
                            else
                                if PROJ_HelpShell(0, 0, target, "", SplitPath(document, _DRIVE_|_PATH_), 1) <= 32
                                    Warn("Cannot open local link: " + target)
                                endif
                            endif
                        else
                            Warn("Linked file could not be found: " + target)
                        endif
                    endif
                endif
            endif
        else
            break
        endif
        GotoBufferId(helpBuffer)
        UpdateDisplay()
    endloop
    Disable(PROJ_ReadmeKeys)
    GotoBufferId(originalBuffer)
    AbandonFile(historyBuffer)
    AbandonFile(helpBuffer)
    UpdateDisplay()
end
