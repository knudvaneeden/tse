param([string]$Source, [string]$Language)
# PROJ0200 1.0.0.0.301
$ErrorActionPreference = 'Stop'
$log = Join-Path $PSScriptRoot 'proj0200_visustin_log.txt'
try {
    $settings = @{}
    Get-Content -LiteralPath (Join-Path $PSScriptRoot 'proj0200.ini') | ForEach-Object {
        if ($_ -match '^\s*([^;#][^=]*?)\s*=(.*)$') { $settings[$matches[1].Trim()] = $matches[2].Trim() }
    }
    $exe = $settings['FNStringGetProgramVisustinS']
    if (-not [IO.Path]::IsPathRooted($exe)) { $exe = Join-Path $PSScriptRoot $exe }
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'Visustin executable could not be found. Check FNStringGetProgramVisustinS.' }
    Add-Type @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public class ProjVisShort {
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode)]
 public static extern uint GetShortPathName(string path, StringBuilder result, uint size);
}
'@
    function ShortPath([string]$path) {
        $buffer = New-Object Text.StringBuilder 32768
        $n = [ProjVisShort]::GetShortPathName($path, $buffer, 32768)
        if ($n -eq 0 -or $n -ge 32768) { throw ('Cannot obtain short filename: ' + $path) }
        $result = $buffer.ToString()
        if ($result.Contains(' ')) { throw ('8.3 short filenames are unavailable: ' + $path) }
        return $result
    }
    $shortExe = ShortPath $exe
    $shortSource = ShortPath $Source
    $arguments = $settings['VisustinParameters']
    if (-not $arguments.Contains('{file}')) { throw 'VisustinParameters must contain {file}.' }
    if ($Language -notmatch '^/[A-Za-z0-9_#+.]+$') { throw 'Invalid language switch.' }
    $arguments = $arguments.Replace('{language}', $Language).Replace('{file}', $shortSource)
    $list = $settings['FNStringGetVisustinTseListS']
    if ($list -and -not [IO.Path]::IsPathRooted($list)) { $list = Join-Path $PSScriptRoot $list }
    @('Executable: ' + $shortExe, 'Arguments: ' + $arguments, 'Language reference: ' + $list) | Set-Content -LiteralPath $log
    Start-Process -FilePath $shortExe -ArgumentList $arguments -Wait
} catch {
    $_.Exception.Message | Set-Content -LiteralPath $log
    Write-Host $_.Exception.Message
    exit 1
}
