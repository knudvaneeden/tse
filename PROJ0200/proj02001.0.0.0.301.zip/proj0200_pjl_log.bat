@echo off
REM PROJ0200 1.0.0.0.301 - OpenAI Codex (GPT-6)
del "%~dp0proj0200_pjl_log_result.txt" >nul 2>&1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0proj0200_pjl_log.ps1"
