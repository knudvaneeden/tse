# PROJ0200 named input histories - 1.0.0.0.210

Each prompt below uses GetFreeHistory() and restores GetHistoryStr(historyId, 1) before asking.
First use retains the existing default. INI values that bypass prompts retain their precedence.

| Source | Procedure | Named history |
|---|---|---|
| commands.si | TryToOpen | `PROJ0200:commands:TryToOpen:input1` |
| ctags.si | mSetCurrentSymbol | `PROJ0200:ctags:mSetCurrentSymbol:input1` |
| ctags.si | TagsGotoTag | `PROJ0200:ctags:TagsGotoTag:input1` |
| edtassoc.si | EditExts | `PROJ0200:edtassoc:EditExts:input1` |
| edtassoc.si | AddAssocExt | `PROJ0200:edtassoc:AddAssocExt:input1` |
| filetypes.si | PROJ_AddType | `PROJ0200:filetypes:PROJ_AddType:input1` |
| flatfile.si | GetFilePathPrompt | `PROJ0200:flatfile:GetFilePathPrompt:input1` |
| gethelp.si | AskHelpPath | `PROJ0200:gethelp:AskHelpPath:input1` |
| gethelp.si | HelpInsertTopic | `PROJ0200:gethelp:HelpInsertTopic:input1` |
| git.s | ask_repository | `PROJ0200:git:ask_repository:input1` |
| pjfile.si | PROJ_AskNewProjectFilename | `PROJ0200:pjfile:PROJ_AskNewProjectFilename:input1` |
| pjfile.si | EditProjDir | `PROJ0200:pjfile:EditProjDir:input1` |
| pjfile.si | EditOpenPath | `PROJ0200:pjfile:EditOpenPath:input1` |
| pjfile.si | AskPath | `PROJ0200:pjfile:AskPath` |
| pjfile.si | AskPath | `PROJ0200:pjfile:AskPath` |
| pjfile.si | ListProjectsInDatabase | `PROJ0200:pjfile:ListProjectsInDatabase:input1` |
| pjfile.si | PROJ_TransferProjects | `PROJ0200:pjfile:PROJ_TransferProjects:input1` |
| pjfile.si | PROJ_TransferProjects | `PROJ0200:pjfile:PROJ_TransferProjects:input2` |
| pjfile.si | PROJ_TransferProjects | `PROJ0200:pjfile:transferdirectory` |
| pjfile.si | SaveProject | `PROJ0200:pjfile:SaveProject:input1` |
| pjfile.si | RenameProject | `PROJ0200:pjfile:RenameProject:input1` |
| pjpublic.si | global | `PROJ0200:pjpublic:global:input1` |
| pjpublic.si | global | `PROJ0200:pjpublic:global:input2` |
| projbackup.si | PROJ_BackupScope | `PROJ0200:projbackup:PROJ_BackupScope:input1` |
| projbuffersearch.s | PROJ_SearchRing | `PROJ0200:projbuffersearch:PROJ_SearchRing:input1` |
| projbuffersearch.s | PROJ_SearchRing | `PROJ0200:projbuffersearch:PROJ_SearchRing:input2` |
| projexamples.s | PROJ_LoadDirectoryNonBinary | `PROJ0200:projexamples:PROJ_LoadDirectoryNonBinary:input1` |
| projgetnames.si | PROJ_GetFilenameScope | `PROJ0200:projgetnames:PROJ_GetFilenameScope:input1` |
| projgit.si | PROJ_UploadGitScope | `PROJ0200:projgit:PROJ_UploadGitScope:input1` |
| projgit.si | PROJ_UploadGitScope | `PROJ0200:projgit:PROJ_UploadGitScope:input2` |
| projgit.si | PROJ_UploadGitScope | `PROJ0200:projgit:PROJ_UploadGitScope:input3` |
| projloadnames.si | PROJ_LoadFilenameList | `PROJ0200:projloadnames:PROJ_LoadFilenameList:input1` |
| projsession.s | mFindSuperSearch | `PROJ0200:projsession:find` |
| projsession.s | mFindSuperSearch | `PROJ0200:projsession:findoptions` |
| projsession.s | mSuperReplace | `PROJ0200:projsession:find` |
| projsession.s | mSuperReplace | `PROJ0200:projsession:replace` |
| projsession.s | mSuperReplace | `PROJ0200:projsession:replaceoptions` |
| projsession.s | mSaveProjectFiles | `PROJ0200:projsession:mSaveProjectFiles:input1` |
| projsvn.si | PROJ_UploadSVNScope | `PROJ0200:projsvn:PROJ_UploadSVNScope:input1` |
| projsvn.si | PROJ_UploadSVNScope | `PROJ0200:projsvn:PROJ_UploadSVNScope:input2` |
| projsvn.si | PROJ_UploadSVNScope | `PROJ0200:projsvn:PROJ_UploadSVNScope:input3` |
| projsvnbrowse.s | ask_repository | `PROJ0200:projsvnbrowse:ask_repository:input1` |
| scopeops.si | PROJ_SearchScope | `PROJ0200:scopeops:PROJ_SearchScope:input1` |
| scopeops.si | PROJ_SearchScope | `PROJ0200:scopeops:PROJ_SearchScope:input2` |

Already named: `projreadme:searchtext`, `projreadme:searchoptions`, `getstemk:expression`.

AskPath adds the prompt text to its history name; import/export directory prompts add the operation number.
Session search and replace intentionally share their find-text history; their options and replacement text have separate histories.
Editor-owned file-opening history bookkeeping remains editor-owned; it is not used for these input prompts.

New drawing histories: `PROJ0200:projdraw:diagramtype`, `PROJ0200:projdraw:promptfile`, and `PROJ0200:projdraw:mermaidfile`.

Optional drawing ZIP output: `PROJ0200:projdraw:sourcezip`.
