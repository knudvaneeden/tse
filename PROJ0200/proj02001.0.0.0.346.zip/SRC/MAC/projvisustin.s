#include ["projdialogs.si"]
// PROJ0200 1.0.0.0.346 - Visustin block and current-file workflow - OpenAI Codex (GPT-6)
#include ["projhistory.si"]
string proc PROJ_VisRoot()
    return(SplitPath(CurrMacroFilename(), _DRIVE_|_PATH_))
end
proc PROCProjectMainActions()
    integer originalBuffer = GetBufferId()
    integer sequence = 0
    integer saved = FALSE
    integer wholeFile = GetGlobalInt("PROJ_VisustinWholeFile")
    string extension[255] = SplitPath(CurrFilename(), _EXT_)
    string temporaryFile[255]
    string command[255]
    string language[255] = "/C"
    SetGlobalInt("PROJ_VisustinWholeFile", FALSE)
    // The result is a block TYPE, not just TRUE/FALSE. Test zero explicitly.
    if not wholeFile and isBlockInCurrFile() == 0
        FNProjectWarning(Format("No block in current buffer: ", CurrFilename(), ". Current ID=", originalBuffer, ", BlockId=", Query(BlockId), ", block type=", isBlockMarked(), ", menu entry block=", GetGlobalInt("PROJ_DrawEntryBlockType"), ". First mark the source text in this file."))
        return()
    endif
    if not Length(extension)
        FNProjectWarning(Format("Save or name the current file with a language extension first."))
        return()
    endif
    if not PROJ_HistoryAsk("Visustin language switch (for example /C, /CPP, /JAVA, /CLIPPER):", language, "PROJ0200:visustin:language")
        return()
    endif
    if not Length(Trim(language))
        return()
    endif
    repeat
        sequence = sequence + 1
        temporaryFile = PROJ_VisRoot() + "proj0200_visustin_" + Str(sequence) + extension
    until not FileExists(temporaryFile)
    command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File " + QuotePath(PROJ_VisRoot() + "proj0200_visustin.ps1") + " -Source " + QuotePath(temporaryFile) + " -Language " + QuotePath(language)
    if Length(PROJ_VisRoot()) * 2 + Length(extension) + Length(language) + 150 > 255
        FNProjectWarning(Format("Visustin command exceeds the SAL path limit. Use a shorter installation path."))
        return()
    endif
    PushPosition()
    PushBlock()
    if wholeFile
        UnMarkBlock()
        MarkLine(1, NumLines())
    endif
    // Same direct block-saving operation as the supplied working runblclj.s.
    saved = SaveBlock(QuotePath(temporaryFile))
    GotoBufferId(originalBuffer)
    PopBlock()
    PopPosition()
    if not saved
        EraseDiskFile(temporaryFile)
        FNProjectWarning(Format("Could not save the source text for Visustin."))
        return()
    endif
    if wholeFile
        FNProjectWarning(Format("Visustin will receive the entire current file, including unsaved edits. Close Visustin before confirming the next message; that confirmation deletes the temporary source file."))
    else
        FNProjectWarning(Format("Visustin will receive only the marked block. Close Visustin before confirming the next message; that confirmation deletes the temporary source file."))
    endif
    Dos(command, _DONT_PROMPT_)
    FNProjectWarning(Format("Close Visustin now. Press Enter only after it has closed to delete the temporary source file. Launch details: proj0200_visustin_log.txt."))
    EraseDiskFile(temporaryFile)
    UpdateDisplay()
end

// PROJ0200 1.0.0.0.346 - OpenAI Codex (GPT-6)
// Set() returns the previous value; restore it after all actions return.
proc Main()
    integer IOldCommonDialogs = Set(UseCommonDialogs, FNProjectWindowsDialogs())
    PROCProjectMainActions()
    Set(UseCommonDialogs, IOldCommonDialogs)
end
