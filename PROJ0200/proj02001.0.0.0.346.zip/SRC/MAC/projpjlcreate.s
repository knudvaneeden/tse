// PROJ0200 1.0.0.0.346 - OpenAI Codex (GPT-6)
// Separate authoring macro keeps the main project macro small.
#include ["projdialogs.si"]

proc Main()
    integer insertingB = Query(MacroCmdLine) == "-Insert"
    integer originalI = GetBufferId()
    integer scriptI = 0, listI = 0, acceptedI = 0
    string filenameS[255] = SplitPath(CurrMacroFilename(), _DRIVE_|_PATH_) + "newscript.pjl"
    string keywordS[255], commandS[255]
    if insertingB
        if Lower(SplitPath(CurrFilename(), _EXT_)) <> ".pjl"
            FNProjectWarning("Open a .pjl script before inserting a keyword.")
            return()
        endif
        scriptI = originalI
    else
        if not FNProjectAsk("Create script (.pjl filename):", filenameS, _EDIT_HISTORY_)
            return()
        endif
        filenameS = ExpandPath(filenameS)
        if Lower(SplitPath(filenameS, _EXT_)) <> ".pjl"
            filenameS = filenameS + ".pjl"
        endif
        if FileExists(filenameS) or GetBufferId(filenameS)
            FNProjectWarning("Script already exists or is open. Choose a new filename.")
            return()
        endif
        scriptI = CreateTempBuffer()
        if not scriptI
            return()
        endif
        AddLine("; PROJ0200 Project Language script - 1.0.0.0.346")
        if not SaveAs(filenameS, _DONT_PROMPT_)
            GotoBufferId(originalI)
            AbandonFile(scriptI)
            FNProjectWarning("Cannot create script file.")
            return()
        endif
        // SaveAs writes a temporary buffer without naming it.
        // Continue authoring in the real saved file, not that temp buffer.
        GotoBufferId(originalI)
        AbandonFile(scriptI)
        if not EditFile(filenameS)
            FNProjectWarning("Script was created but could not be opened: " + filenameS)
            return()
        endif
        scriptI = GetBufferId()
    endif
    loop
        listI = CreateTempBuffer()
        if not listI
            break
        endif
        AddLine("openallprojects")
        AddLine("openproject")
        AddLine("createproject")
        AddLine("changeproject")
        AddLine("closeproject")
        AddLine("saveproject")
        AddLine("getallprojectnames")
        AddLine("getcurrentprojectname")
        AddLine("viewcurrentactiveproject")
        AddLine("viewallprojects")
        AddLine("starttimelog")
        AddLine("showtimelog")
        AddLine("stoptimelog")
        AddLine("pause")
        AddLine("Custom command or comment")
        AddLine("Edit last line")
        AddLine("Save and return to editor")
        BegFile()
        acceptedI = List("Create script: select a command (Escape returns to editor)", 72)
        keywordS = Trim(GetText(1, 255))
        GotoBufferId(scriptI)
        AbandonFile(listI)
        if not acceptedI
            break
        endif
        if keywordS == "Save and return to editor"
            if SaveFile()
                break
            endif
        else
            case keywordS
                when "pause"
                    commandS = 'pause "Press a key to continue..."'
                when "openallprojects"
                    commandS = 'openallprojects "C:\TEMP\DDDPJ\"'
                when "openproject"
                    commandS = "openproject PROJ0200HELLOWORLD"
                when "createproject"
                    commandS = 'createproject name=NEWPROJECT dir="C:\TEMP\" scan=no'
                when "changeproject"
                    commandS = "changeproject PROJ0200HELLOWORLD"
                when "getallprojectnames"
                    commandS = 'getallprojectnames file="projectnames.txt"'
                when "Custom command or comment"
                    commandS = ""
                when "Edit last line"
                    EndFile()
                    commandS = GetText(1, 255)
                otherwise
                    commandS = keywordS
            endcase
            if FNProjectAsk("Edit command, then Enter to insert:", commandS, _EDIT_HISTORY_)
                GotoBufferId(scriptI)
                if not insertingB or keywordS == "Edit last line"
                    EndFile()
                endif
                if keywordS == "Edit last line"
                    BegLine()
                    KillToEol()
                    InsertText(commandS)
                elseif insertingB
                    InsertText(commandS)
                    break
                else
                    AddLine(commandS)
                endif
            endif
        endif
    endloop
    GotoBufferId(scriptI)
    if not insertingB
        EndFile()
    endif
    Message("PJL script ready for normal editing. Save your changes before Run scripts.")
end
