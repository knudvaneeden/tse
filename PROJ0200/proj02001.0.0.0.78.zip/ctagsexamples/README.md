# PROJ0200 CTags example inventory

These are test sources. Earlier F12 checks confirmed six languages with prior test files; these packaged examples still need individual verification. Add one file to a test project, regenerate CTags, put the cursor on the listed symbol at its use, and press F12. Some formats (HTML, Ant, Make, SQL) index a declaration or target rather than a function. The supplied Exuberant CTags 5.8 executable and regex configuration determine actual support. All examples are in `ctagsexamples`. `ddd.s` and `ddd.si` test the two SAL extensions. Do not add both same-language variants to a project unless testing duplicate tags.

| Language | File | Symbol | Status |
|---|---|---|---|
| ActionScript | `ctagsexamples/ddd.as` | `greet` | Custom regex parser; pending TSE test |
| Ada | `ctagsexamples/ddd.adb` | `Greet` | Custom regex parser; pending TSE test |
| Ant | `ctagsexamples/ddd.build.xml` | `AntGreeting` | Verified in TSE |
| Assembly | `ctagsexamples/ddd.asm` | `greet` | Pending TSE test |
| ASP | `ctagsexamples/ddd.asp` | `Greet` | Pending TSE test |
| AWK | `ctagsexamples/ddd.awk` | `greet` | Pending TSE test |
| Basic | `ctagsexamples/ddd.bas` | `Greet` | Pending TSE test |
| BETA | `ctagsexamples/ddd.bet` | `greet` | Verified by user |
| C | `ctagsexamples/ddd.c` | `draw_menu` | Language previously tested; packaged sample pending |
| C++ | `ctagsexamples/ddd.cpp` | `greet` | Pending TSE test |
| C# | `ctagsexamples/ddd.cs` | `Greet` | Pending TSE test |
| Cobol | `ctagsexamples/ddd.cob` | `GREET` | Pending TSE test |
| DosBatch | `ctagsexamples/ddd.bat` | `greet` | Pending TSE test |
| Eiffel | `ctagsexamples/ddd.e` | `greet` | Pending TSE test |
| Erlang | `ctagsexamples/ddd.erl` | `greet` | Pending TSE test |
| Flex (MXML) | `ctagsexamples/ddd.mxml` | `greet` | Pending TSE test |
| Fortran | `ctagsexamples/ddd.f90` | `greet` | Pending TSE test |
| HTML | `ctagsexamples/ddd.html` | `HtmlGreeting` | Named anchor sample; pending TSE test |
| Java | `ctagsexamples/ddd.java` | `greet` | Verified in TSE |
| JavaScript | `ctagsexamples/ddd.js` | `greet` | Pending TSE test |
| Lisp | `ctagsexamples/ddd.lisp` | `greet` | Pending TSE test |
| Lua | `ctagsexamples/ddd.lua` | `greet` | Pending TSE test |
| Make | `ctagsexamples/ddd.mak` | `GREETING` | F12 verified on Windows CTags 5.8 |
| MatLab | `ctagsexamples/ddd.m` | `greet` | Pending TSE test |
| OCaml | `ctagsexamples/ddd.ml` | `greet` | Pending TSE test |
| Pascal | `ctagsexamples/ddd.pas` | `Greet` | Pending TSE test |
| Perl | `ctagsexamples/ddd.pl` | `greet` | Pending TSE test |
| PHP | `ctagsexamples/ddd.php` | `greet` | Pending TSE test |
| Python | `ctagsexamples/ddd.py` | `greet` | Language previously tested; packaged sample pending |
| REXX | `ctagsexamples/ddd.rx` | `greet` | Pending TSE test |
| Ruby | `ctagsexamples/ddd.rb` | `greet` | Pending TSE test |
| Scheme | `ctagsexamples/ddd.scm` | `greet` | Pending TSE test |
| Sh | `ctagsexamples/ddd.sh` | `greet` | Pending TSE test |
| SLang | `ctagsexamples/ddd.sl` | `greet` | Verified in TSE |
| SML | `ctagsexamples/ddd.sml` | `greet` | Pending TSE test |
| SQL | `ctagsexamples/ddd.sql` | `greeting` | Pending TSE test |
| Tcl | `ctagsexamples/ddd.tcl` | `greet` | Pending TSE test |
| Tex | `ctagsexamples/ddd.tex` | `TexGreeting` | F12 verified on Windows CTags 5.8 |
| Vera | `ctagsexamples/ddd.vr` | `greet` | Pending TSE test |
| Verilog | `ctagsexamples/ddd.v` | `greet` | Pending TSE test |
| VHDL | `ctagsexamples/ddd.vhd` | `greet` | Pending TSE test |
| TSE SAL | `ctagsexamples/ddd.si` | `Greet` | Language previously tested; packaged sample pending |
| Rust | `ctagsexamples/ddd.rs` | `greet` | Language previously tested; packaged sample pending |
| TypeScript | `ctagsexamples/ddd.ts` | `formatName` | Language previously tested; packaged sample pending |
| Go | `ctagsexamples/ddd.go` | `makeGreeting` | Language previously tested; packaged sample pending |
| Dart | `ctagsexamples/ddd.dart` | `greet` | Pending TSE test |
| Haskell | `ctagsexamples/ddd.hs` | `greet` | Pending TSE test |
| Maple | `ctagsexamples/ddd.mpl` | `greet` | Pending TSE test |
| R | `ctagsexamples/ddd.r` | `greet` | Pending TSE test |
| Mathematica | `ctagsexamples/ddd.wl` | `greet` | Pending TSE test |
| Swift | `ctagsexamples/ddd.swift` | `greet` | Pending TSE test |
| SAS | `ctagsexamples/ddd.sas` | `greet` | Pending TSE test |
| Kotlin | `ctagsexamples/ddd.kt` | `greet` | Pending TSE test |
| Prolog | `ctagsexamples/ddd.pro` | `greet` | Pending TSE test |
| PowerShell | `ctagsexamples/ddd.ps1` | `Greet` | Pending TSE test |
| Scala | `ctagsexamples/ddd.scala` | `greet` | Pending TSE test |
| ABAP | `ctagsexamples/ddd.abap` | `greet` | Pending TSE test |
| Vim | `ctagsexamples/ddd.vim` | `Greet` | Pending TSE test |
| YACC | `ctagsexamples/ddd.y` | `greet` | Pending TSE test |

BETA (`ddd.bet`): ordinary pattern tags are enabled by the package configuration. Test F12 on `greet` at line 6; expected definition is line 4. Windows test pending.

Ant: F12 on `AntGreeting` in the dependency at line 5 should jump to the target at line 2. Regenerate tags first; Windows test pending.
