#include ["projdialogs.si"]
#include ["projhistory.si"]
// PROJ0200 1.0.0.0.372 - OpenAI Codex (GPT-6)
// Separate example loader avoids the main macro size limit.
string proc GetInstallationDir()
    return(SplitPath(CurrMacroFilename(), _DRIVE_|_PATH_))
end
// PROJ0200 1.0.0.0.372 - OpenAI Codex (GPT-6)
// Resolve examples from the installation directory, not the working directory.
// listsynext.txt is the sole extension-to-syntax-definition mapping.
proc PROJ_LoadSyntaxExample()
    integer originalI = GetBufferId(), mapI, lineI, tokenI
    integer colonI
    string extensionS[255] = Lower(SplitPath(CurrFilename(), _EXT_))
    string recordS[255], syntaxS[255] = "", tokenS[255]
    string filenameS[255]
    if Length(GetGlobalStr("PROJ_ExampleExtension"))
        extensionS = GetGlobalStr("PROJ_ExampleExtension")
    endif
    if LeftStr(extensionS, 1) == "."
        extensionS = SubStr(extensionS, 2, 254)
    endif
    if not Length(extensionS)
        FNProjectWarning("The current file has no extension for the syntax mapping.")
        return()
    endif
    mapI = CreateTempBuffer()
    if not mapI
        return()
    endif
    if not InsertFile(GetInstallationDir() + "listsynext.txt", _DONT_PROMPT_)
        GotoBufferId(originalI)
        AbandonFile(mapI)
        FNProjectWarning("Cannot read listsynext.txt in the PROJ0200 directory.")
        return()
    endif
    for lineI = 1 to NumLines()
        GotoLine(lineI)
        recordS = Lower(Trim(GetText(1, 255)))
        colonI = Pos(":", recordS)
        if colonI
            recordS = SubStr(recordS, 1, colonI - 1) + " " + SubStr(recordS, colonI + 1, 255)
        endif
        tokenI = 2
        loop
            tokenS = GetToken(recordS, " " + Chr(9), tokenI)
            if not Length(tokenS)
                break
            endif
            if tokenS == extensionS
                syntaxS = GetToken(recordS, " " + Chr(9), 1)
                break
            endif
            tokenI = tokenI + 1
        endloop
        if Length(syntaxS)
            break
        endif
    endfor
    GotoBufferId(originalI)
    AbandonFile(mapI)
    if not Length(syntaxS)
        FNProjectWarning("No syntax mapping for ." + extensionS + " in listsynext.txt.")
        return()
    endif
    if Pos("\", syntaxS) or Pos("/", syntaxS) or Pos(":", syntaxS) or
       Pos("..", syntaxS) or Pos("*", syntaxS) or Pos("?", syntaxS)
        FNProjectWarning("Invalid syntax-definition name in listsynext.txt: " + syntaxS)
        return()
    endif
    if Length(GetInstallationDir()) + Length(syntaxS) + 28 > 255
        FNProjectWarning("The mapped syntax-definition path exceeds 255 characters.")
        return()
    endif
    filenameS = GetInstallationDir() + "PROJ0200SYNTAXHIGHLIGHTS\" + syntaxS + ".txt"
    if not FileExists(filenameS)
        FNProjectWarning("Mapped ." + extensionS + " to " + syntaxS + ".txt, but the file is missing from PROJ0200SYNTAXHIGHLIGHTS.")
    elseif EditFile(QuotePath(filenameS))
        SetGlobalInt("PROJ_ExampleResult", TRUE)
        UpdateDisplay()
    else
        FNProjectWarning("Could not load syntax definition: " + filenameS)
    endif
end

proc PROJ_LoadLanguageExample(integer kind)
    integer originalBuffer = GetBufferId()
    integer mapBuffer
    integer lineIndex
    integer lineCount
    string extension[255] = Lower(SplitPath(CurrFilename(), _EXT_))
    string basename[255] = Lower(SplitPath(CurrFilename(), _NAME_|_EXT_))
    string lookup[255]
    string record[255]
    string relativeName[255] = ""
    string filename[255]
    if kind == 5
        PROJ_LoadSyntaxExample()
        return()
    endif
    if Length(GetGlobalStr("PROJ_ExampleExtension"))
        lookup = GetGlobalStr("PROJ_ExampleExtension")
    elseif extension == ".bat" or Pos("batcompilersetting_", basename)
        lookup = "@" + basename
    else
        if SubStr(extension, 1, 1) == "."
            extension = SubStr(extension, 2, 254)
        endif
        lookup = extension
    endif
    if not Length(lookup)
        FNProjectWarning(Format("The current file has no language extension. Open a source file first."))
        return()
    endif
    mapBuffer = CreateTempBuffer()
    if not mapBuffer
        FNProjectWarning(Format("Cannot create the example lookup buffer."))
        return()
    endif
    if InsertFile(GetInstallationDir() + "proj0200_examples.txt", _DONT_PROMPT_)
        lineCount = NumLines()
        for lineIndex = 1 to lineCount
            GotoLine(lineIndex)
            record = GetText(1, 255)
            if GetToken(record, "|", 1) == lookup and
               GetToken(record, "|", 2) == Str(kind)
                relativeName = GetToken(record, "|", 3)
                break
            endif
        endfor
    endif
    GotoBufferId(originalBuffer)
    AbandonFile(mapBuffer)
    if not Length(relativeName)
        FNProjectWarning(Format("No supplied example of this type is available for " + basename + "."))
        return()
    endif
    if Length(GetInstallationDir()) + Length(relativeName) > 255
        FNProjectWarning(Format("The example filename exceeds the SAL 255-character limit."))
        return()
    endif
    filename = GetInstallationDir() + relativeName
    if not FileExists(filename)
        FNProjectWarning(Format("Example file could not be found: " + filename))
        return()
    endif
    if EditFile(QuotePath(filename))
        SetGlobalInt("PROJ_ExampleResult", TRUE)
        UpdateDisplay()
    else
        FNProjectWarning(Format("Could not load example file: " + filename))
    endif
end

string proc PROJ_FileExtension(string filename)
    string extension[255] = Lower(SplitPath(filename, _EXT_))
    if extension[1] == "."
        extension = SubStr(extension, 2, 254)
    endif
    return(extension)
end

integer proc PROJ_HasType(string extension, integer bufferId)
    integer originalBuffer = GetBufferId()
    integer found = FALSE
    if bufferId
        GotoBufferId(bufferId)
        PushPosition()
        BegFile()
        do NumLines() times
            if Lower(Trim(GetText(1, 255))) == Lower(extension)
                found = TRUE
                break
            endif
            Down()
        enddo
        PopPosition()
        GotoBufferId(originalBuffer)
    endif
    return(found)
end


proc PROJ_LoadDirectoryNonBinary()
    integer originalBuffer = GetBufferId()
    integer excludedBuffer = 0
    integer listBuffer = 0
    integer searchHandle
    integer lineIndex
    integer fileCount
    integer loaded = 0
    integer skipped = 0
    string directory[255] = CurrDir()
    string filename[255]
    if not PROJ_HistoryAsk("Directory to load non-binary files from (no subdirectories):", directory, "PROJ0200:projexamples:PROJ_LoadDirectoryNonBinary:input1")
        return()
    endif
    directory = Trim(directory)
    if not Length(directory) or not (FileExists(directory) & _DIRECTORY_)
        FNProjectWarning(Format("Directory not found: " + directory))
        return()
    endif
    directory = ExpandPath(directory)
    if directory[Length(directory)] <> "\"
        directory = directory + "\"
    endif
    excludedBuffer = CreateTempBuffer()
    if not excludedBuffer
        return()
    endif
    if not InsertFile(GetInstallationDir() + "proj0200_binarytypes.txt", _DONT_PROMPT_)
        GotoBufferId(originalBuffer)
        AbandonFile(excludedBuffer)
        FNProjectWarning(Format("Cannot read proj0200_binarytypes.txt; no directory files were loaded."))
        return()
    endif
    listBuffer = CreateTempBuffer()
    if not listBuffer
        GotoBufferId(originalBuffer)
        AbandonFile(excludedBuffer)
        return()
    endif
    searchHandle = FindFirstFile(directory + "*", _NORMAL_|_ARCHIVE_|_READONLY_|_HIDDEN_|_SYSTEM_)
    if searchHandle <> -1
        repeat
            filename = directory + FFName()
            if not (FileExists(filename) & _DIRECTORY_)
                if not PROJ_HasType(PROJ_FileExtension(filename), excludedBuffer)
                    AddLine(filename, listBuffer)
                else
                    skipped = skipped + 1
                endif
            endif
        until not FindNextFile(searchHandle, _NORMAL_|_ARCHIVE_|_READONLY_|_HIDDEN_|_SYSTEM_)
        FindFileClose(searchHandle)
    endif
    GotoBufferId(listBuffer)
    fileCount = NumLines()
    for lineIndex = 1 to fileCount
        GotoBufferId(listBuffer)
        GotoLine(lineIndex)
        filename = GetText(1, 255)
        if Length(filename)
            GotoBufferId(originalBuffer)
            if EditFile(QuotePath(filename))
                loaded = loaded + 1
            endif
        endif
    endfor
    GotoBufferId(originalBuffer)
    AbandonFile(listBuffer)
    AbandonFile(excludedBuffer)
    FNProjectWarning(Format("Directory files loaded: " + Str(loaded) + "; excluded binary extensions: " + Str(skipped) + "."))
end

string proc PROJ_PackageSetting(string settingName)
    integer previousBuffer = GetBufferId()
    integer iniBuffer
    integer equalsAt
    string settingValue[255] = ""
    string lineText[255]
    string iniFilename[255] = GetInstallationDir() + "proj0200.ini"
    if not FileExists(iniFilename)
        return(settingValue)
    endif
    iniBuffer = CreateTempBuffer()
    if iniBuffer
        if InsertFile(iniFilename, _DONT_PROMPT_)
            BegFile()
            repeat
                lineText = Trim(GetText(1, 255))
                equalsAt = Pos("=", lineText)
                if equalsAt > 1
                    if Lower(Trim(SubStr(lineText, 1, equalsAt - 1))) == Lower(settingName)
                        settingValue = Trim(SubStr(lineText, equalsAt + 1, 255))
                        break
                    endif
                endif
            until not Down()
        endif
        GotoBufferId(previousBuffer)
        AbandonFile(iniBuffer)
    endif
    return(settingValue)
end

// Read the optional package setting without changing PROJ's editor profile.
integer proc PROJ_ShowStartupMessage()
	integer oldBuffer = GetBufferId()
	integer iniBuffer
	integer showMessage = TRUE
	string iniFile[255] = GetInstallationDir() + "proj0200.ini"
	string line[255]

    if GetGlobalStr("PROJ0200_FromLauncher") == "true"
        SetGlobalStr("PROJ0200_FromLauncher", "")
        if GetGlobalStr("PROJ0200_BeginMessageShown") == "true"
            return(FALSE)
        endif
        if Lower(Trim(PROJ_PackageSetting("showbeginmessage"))) <> "false"
            SetGlobalStr("PROJ0200_BeginMessageShown", "true")
            return(TRUE)
        endif
    endif

	if not FileExists(iniFile)
		return(showMessage)
	endif
	iniBuffer = CreateTempBuffer()
	if iniBuffer
		if InsertFile(iniFile, _DONT_PROMPT_)
			BegFile()
			repeat
				line = Lower(Trim(GetText(1, 255)))
				if Pos("silent=", line) == 1
					if Trim(SubStr(line, 8, 255)) == "true"
						showMessage = FALSE
					endif
						break
				endif
			until not Down()
		endif
		GotoBufferId(oldBuffer)
		AbandonFile(iniBuffer)
	endif
	return(showMessage)
end

proc PROJ_SetStartupMenuSelection()
    string selection[255] = Lower(PROJ_PackageSetting("startprojectmenu"))
    SetGlobalInt("PROJ_StartupMenuSelection", 1)
    if selection == "open project" or selection == "open"
        SetGlobalInt("PROJ_StartupMenuSelection", 4)
    elseif Length(selection) and selection <> "new project" and selection <> "new"
        FNProjectWarning(Format("startprojectmenu must be New Project or Open Project in proj0200.ini. Using New Project."))
    endif
end


proc PROCProjectMainActions()
    SetGlobalInt("PROJ_ExampleResult", FALSE)
    case GetGlobalInt("PROJ_ExampleKind")
        when -1
            if PROJ_ShowStartupMessage()
                FNProjectWarning(Format("PROJ0200 1.0.0.0.372: the Project menu opens after this message. " +
                     "Press <F1> for help; <Alt [> reopens the menu. " +
                     "Set silent=true in proj0200.ini to hide this message."))
            endif
            PROJ_SetStartupMenuSelection()
        when 0
            PROJ_LoadDirectoryNonBinary()
        otherwise
            PROJ_LoadLanguageExample(GetGlobalInt("PROJ_ExampleKind"))
    endcase
end

// PROJ0200 1.0.0.0.372 - OpenAI Codex (GPT-6)
// Set() returns the previous value; restore it after all actions return.
proc Main()
    integer IOldCommonDialogs = Set(UseCommonDialogs, FNProjectWindowsDialogs())
    PROCProjectMainActions()
    Set(UseCommonDialogs, IOldCommonDialogs)
end
