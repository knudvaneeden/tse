#include ["projdialogs.si"]
// PROJ0200 1.0.0.0.372 - OpenAI Codex (GPT-6)
// Separate batch loader keeps the PJL interpreter compact.
proc Main()
    integer originalI = GetBufferId(), listI = 0, lineI, charI
    integer countI = 0, kindI = GetGlobalInt("PROJ_PJLBatchKind")
    integer succeededB, targetI = 0
    string fileS[255] = GetGlobalStr("PROJ_PJLBatchFile")
    string extensionS[255], errorS[255] = ""
    string workerS[255] = SplitPath(CurrMacroFilename(), _DRIVE_|_PATH_) + "projexamples.mac"
    SetGlobalInt("PROJ_PJLBatchResult", FALSE)
    SetGlobalInt("PROJ_PJLBatchTarget", 0)
    SetGlobalStr("PROJ_PJLBatchError", "")
    listI = CreateTempBuffer()
    if not listI
        errorS = "Cannot allocate the language-list buffer."
    elseif not InsertFile(fileS, _DONT_PROMPT_)
        errorS = "Cannot read language list: " + fileS
    elseif kindI < 1 or kindI > 5
        errorS = "Invalid batch example type."
    else
        for lineI = 1 to NumLines()
            GotoBufferId(listI)
            GotoLine(lineI)
            extensionS = Lower(Trim(GetText(1, 255)))
            if CurrLineLen() > 255
                errorS = "Language-list line exceeds 255 characters."
                break
            endif
            if Length(extensionS) and LeftStr(extensionS, 1) <> ";" and LeftStr(extensionS, 2) <> "//"
                if LeftStr(extensionS, 1) == "."
                    extensionS = SubStr(extensionS, 2, 254)
                endif
                if not Length(extensionS)
                    errorS = "Empty language extension."
                endif
                for charI = 1 to Length(extensionS)
                    if not Pos(SubStr(extensionS, charI, 1), "abcdefghijklmnopqrstuvwxyz0123456789_+-")
                        errorS = "Use one extension per line without spaces or filenames."
                        break
                    endif
                endfor
                if Length(errorS)
                    break
                endif
                SetGlobalInt("PROJ_ExampleKind", kindI)
                SetGlobalStr("PROJ_ExampleExtension", extensionS)
                SetGlobalInt("PROJ_ExampleResult", FALSE)
                succeededB = ExecMacro(QuotePath(workerS))
                succeededB = succeededB and GetGlobalInt("PROJ_ExampleResult")
                if not succeededB
                    errorS = "Cannot load example for ." + extensionS + "; check its mapping and file."
                    break
                endif
                targetI = GetBufferId()
                countI = countI + 1
                GotoBufferId(listI)
            endif
        endfor
        if Length(errorS)
            errorS = "Language-list line " + Str(lineI) + ": " + errorS
        elseif not countI
            errorS = "The language list contains no extensions."
        endif
    endif
    GotoBufferId(originalI)
    if listI
        AbandonFile(listI)
    endif
    DelGlobalVar("PROJ_ExampleKind")
    DelGlobalVar("PROJ_ExampleExtension")
    DelGlobalVar("PROJ_ExampleResult")
    SetGlobalInt("PROJ_PJLBatchTarget", targetI)
    SetGlobalStr("PROJ_PJLBatchError", errorS)
    SetGlobalInt("PROJ_PJLBatchResult", not Length(errorS))
    if not Length(errorS)
        Message("PJL examples loaded: " + Str(countI))
    endif
end
