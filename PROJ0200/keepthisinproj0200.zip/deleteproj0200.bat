F:
cd /d F:\BBC\TAAL\PROJ0200\
dir
del *.*
deltreey CTAGSEXAMPLES
deltreey PJ
deltreey SRC
dir
