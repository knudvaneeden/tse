# Project Language (.pjl) - 1.0.0.0.260

Open Project menu > Run projects > Run scripts > Run Project Language script.
Choose example.pjl in the package directory for the first test.

One command per line, command name first. Commands and parameter names are
case-insensitive; filename spelling is preserved. Blank lines and lines
starting with ; or // are ignored. Double quotes group values containing
spaces. Backslashes are literal. Inline comments are not supported yet.
Commands are ASCII and limited to 255 characters per line in this first
version. Relative paths resolve against the script directory.

| Command | Parameters / behavior |
| --- | --- |
| createproject | NAME or name=NAME, followed by repeated file=PATH / dir=PATH entries. |
| openproject | NAME or name=NAME; opens an existing saved project. |
| changeproject | Same as openproject. |
| closeproject | No parameters; uses normal close/save behavior. |
| saveproject | No parameters; saves the active project. |
| getallprojectnames | file=OUTPUT; exports registered project filenames without .pj. |
| getcurrentprojectname | No parameters; displays the active name on the message line. |

scan=yes includes subdirectories; scan=no scans only the named directory.
Omitting scan defaults to no. scan must follow dir and cannot follow file.
Each file must exist and be a regular file; each dir must exist as a directory.
Use separate createproject lines to create multiple projects.

Project metadata is saved in the configured PJ directory and registered in
Proj.DB. The current active project and open documents are retained during
createproject. The saved path list is scanned when that project is opened.
The interpreter uses a CASE dispatcher in SRC/MAC/projpjl.si, included by
pjfile.si. No shell evaluation is used.

Existing project records and exported name lists are rejected. Execution
stops at the first error with its script line number. Earlier successful
commands remain committed; there is no whole-script rollback. The summary
counts completed commands, not projects. Close/save can use existing editor
prompts; this is not yet an unattended runner.

Install pjl.txt as a TSE syntax-highlighting definition for *.pjl using your
normal highlighting setup. Its copy also lives in PROJ0200SYNTAXHIGHLIGHTS.
Build using the existing build.bat command; pjfile.si includes the interpreter.
SAL compilation and TSE runtime testing are required on Windows.
