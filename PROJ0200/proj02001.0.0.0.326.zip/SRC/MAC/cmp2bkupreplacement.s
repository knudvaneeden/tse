// PROJ0200 1.0.0.0.326 - OpenAI Codex (GPT-6)
// Read-only line comparison of current buffer against a selected backup.
#include ["projdialogs.si"]

integer proc FNCmpRestoreDirectory(string dir)
	integer i
	string s[4]

	if not Length(dir)
		return (FALSE)
	endif

	s = SplitPath(dir, _DRIVE_)
	if Length(s) <> 0
		if s[1] == "\"
			// can't CD to a UNC path
			return (FALSE)
		endif
		i = ChDir(s)
		if s == dir
			return (i)
		endif
	endif
	i = iif(dir[Length(dir)] == "\", 1, 0)
	return (ChDir(SubStr(dir, 1, Length(dir) - i)))
end

proc Main()
    integer sourceI = GetBufferId()
    integer backupI = 0, reportI = 0
    integer sourceLinesI, backupLinesI, maximumI, lineI, columnI
    integer sourceLengthI, backupLengthI, offsetI, indexI, differencesI = 0
    integer selectedI = 0, targetLineI = 0, targetColumnI = 1
    string sourceS[255] = CurrFilename()
    string backupS[255] = "", chunk1S[255], chunk2S[255]
    string rowS[255], preview1S[80], preview2S[80]
    string directoryS[255] = CurrDir()
    integer historyI = GetFreeHistory("PROJ0200:comparebackup:filename")
    if BufferType() <> _NORMAL_ or not Length(sourceS)
        FNProjectWarning("Open a named text file before comparing it to a backup.")
        return()
    endif
    backupS = SplitPath(sourceS, _DRIVE_|_PATH_|_NAME_) + ".bak"
    if not FileExists(backupS) and FileExists(sourceS + ".bak")
        backupS = sourceS + ".bak"
    endif
    if not FileExists(backupS) and NumHistoryItems(historyI)
        backupS = GetHistoryStr(historyI, 1)
    endif
    if not FNProjectAskFilename("Compare current buffer with backup file:", backupS,
            _MUST_EXIST_|_FULL_PATH_, historyI)
        FNCmpRestoreDirectory(directoryS)
        return()
    endif
    backupS = ExpandPath(backupS)
    FNCmpRestoreDirectory(directoryS)
    if EquiStr(sourceS, backupS)
        FNProjectWarning("Choose a different file as the backup.")
        return()
    endif
    PushPosition()
    backupI = CreateTempBuffer()
    if backupI
        if not InsertFile(backupS, _DONT_PROMPT_)
            AbandonFile(backupI)
            backupI = 0
        endif
    endif
    if not backupI
        GotoBufferId(sourceI)
        PopPosition()
        FNProjectWarning("Cannot read backup: " + backupS)
        return()
    endif
    backupLinesI = NumLines()
    GotoBufferId(sourceI)
    sourceLinesI = NumLines()
    maximumI = Max(sourceLinesI, backupLinesI)
    reportI = CreateTempBuffer()
    if reportI
        AddLine("CURRENT: " + sourceS)
        AddLine("BACKUP:  " + backupS)
        AddLine("Line:Column | Current text | Backup text. Enter jumps; Escape returns.")
        for lineI = 1 to maximumI
            columnI = 0
            sourceLengthI = -1
            backupLengthI = -1
            preview1S = "<no line>"
            preview2S = "<no line>"
            if lineI <= sourceLinesI
                GotoBufferId(sourceI)
                GotoLine(lineI)
                sourceLengthI = CurrLineLen()
                preview1S = GetText(1, 80)
            endif
            if lineI <= backupLinesI
                GotoBufferId(backupI)
                GotoLine(lineI)
                backupLengthI = CurrLineLen()
                preview2S = GetText(1, 80)
            endif
            if sourceLengthI < 0 or backupLengthI < 0
                columnI = 1
            else
                offsetI = 1
                while offsetI <= Max(sourceLengthI, backupLengthI) and not columnI
                    GotoBufferId(sourceI)
                    GotoLine(lineI)
                    chunk1S = GetText(offsetI, 255)
                    GotoBufferId(backupI)
                    GotoLine(lineI)
                    chunk2S = GetText(offsetI, 255)
                    if chunk1S <> chunk2S
                        indexI = 1
                        while indexI <= Min(Length(chunk1S), Length(chunk2S))
                            if chunk1S[indexI] <> chunk2S[indexI]
                                break
                            endif
                            indexI = indexI + 1
                        endwhile
                        columnI = offsetI + indexI - 1
                    endif
                    offsetI = offsetI + 255
                endwhile
                if not columnI and sourceLengthI <> backupLengthI
                    columnI = Min(sourceLengthI, backupLengthI) + 1
                endif
            endif
            if columnI
                differencesI = differencesI + 1
                AddLine(Str(lineI) + ":" + Str(columnI) + " | " +
                    preview1S + " | " + preview2S, reportI)
            endif
        endfor
        GotoBufferId(reportI)
        if differencesI
            GotoLine(4)
            selectedI = List("Compare to backup: " + Str(differencesI) + " differing lines", 100)
            if selectedI and CurrLine() > 3
                rowS = GetToken(GetText(1, 255), " ", 1)
                targetLineI = Val(GetToken(rowS, ":", 1))
                targetColumnI = Val(GetToken(rowS, ":", 2))
            endif
        endif
    endif
    GotoBufferId(sourceI)
    if reportI
        AbandonFile(reportI)
    endif
    AbandonFile(backupI)
    PopPosition()
    if targetLineI
        GotoLine(Max(1, Min(targetLineI, sourceLinesI)))
        GotoColumn(targetColumnI)
    endif
    if not reportI
        FNProjectWarning("Cannot allocate comparison report.")
    elseif not differencesI
        FNProjectWarning("Current buffer and backup have identical text.")
    endif
end
