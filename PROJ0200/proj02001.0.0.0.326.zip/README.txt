PROJ0200 version 1.0.0.0.326 - optional project descriptions
REQUIRED: Run build.bat with your matching sc32.exe, then restart TSE.
Create project asks for a description. Change projects > Edit project description saves it.
View projects > View current active project displays it. Empty descriptions are allowed.
Windows SAL compilation and runtime testing are still required.

Info for PROJ macro v2.00 (05/19/2002).
by Chris Antos, chrisant@premier1.net



Description:

    Project manager for keeping track of projects with many files.



DOS vs Windows:  PROJ is designed for use with TSE 2.8 and higher.
                 You can also get it to work with TSE 2.6 if you edit
                 the macro source (particularly CTAGS.SI) on your own.
                 It does not work with TSE 2.5 or earlier, period.



-- SETUP --------------------------------------------------------------

1.  Copy the following files to your Mac\ directory:
        - PROJ.MAC
        - PJFILE.MAC
        - PROJDLL.DLL
        - PROJ.HLP
        - GETHELP.MAC
        - HELPHELP.MAC

2.  Start TSE

3.  PROJ will automatically set itself up the first time you load it:
        - Select "Macro" from TSE's main menu
        - Select "Execute..."
        - Type "proj" and press <Enter>


That's all!  PROJ will display a welcome message and walk you through
the simple setup process (it's short).



* Note: if TSE complains "Macro compiled with wrong version", then see
  the "NOTES" section below.

* CTags: there is now support for CTags!  Just make sure CTAGS.EXE is in
  the same directory as your TSE executable.  CTags is available from
  http://home.hiwaay.net/~darren/ctags/

* BSC: Microsoft's BSC (source browse info) files are now supported!
  You can download the necessary DLL from
  http://support.microsoft.com/download/support/mslfiles/BSCKIT60.EXE
  (substitute 50, 41, 40, etc if you need the kit for VC5, VC4.1, VC4,
  etc).  If the link does not work, visit http://www.microsoft.com and
  do a search for "bsc toolkit".



-- NOTES --------------------------------------------------------------

- PROJ comes pre-configured for use with TSE 4.0, but it's pretty easy
  to get it to work with TSE 2.8 or TSE 3.0:

        1.  Unzip all the files from the .Zip file
        2.  Enter the following commands at the DOS prompt:
                SC32 PROJ.SI
                SC32 PJFILE.SI
                SC32 GETHELP.SI
                SC32 HELPHELP.S
        3.  Follow the Setup instructions above.



-- MACRO INTEGRATION --------------------------------------------------

- SetGlobalInt("PROJ_FlatFilePrompt", TRUE) before displaying a prompt
  to force enable the flat file list.

- ExecMacro("PROJ_GetFilePath filename.ext") looks up "filename.ext" in
  the current project's file list.  If an exact match is found,
  MacroCmdLine is set to the full pathname of the match.  If multiple
  matches are found, MacroCmdLine is set to "-1".  If no matches are
  found, MacroCmdLine is set to "".

- SetGlobalStr("PROJ_Prefix", <prefix>) is the prefix used in search
  result files, such as from Find() and from popular Grep macros.  If
  this variable is not set, the default is "File:".  [NOT USED 06/05/97]

- SetGlobalStr("PROJ_OpenPath", <searchpath>) is the search path used to
  find files when using the Open File At Cursor command (<F12>).

- ExecMacro("PROJ_OpenFileAtCursor") opens file at cursor.

- ExecMacro("PROJ_GrepWholeProject") greps all files in the project for
  the specified word/phrase.




-- HISTORY ------------------------------------------------------------

v2.00 (released 05/19/2002) -----------------------------------

- NEW: supports TSE4.0 (also still supports TSE2.8 and higher).

- The last official release was PROJ v1.10 in 1998.  Since then all
  kinds of improvements and fixes have gone into the PROJ macro.  Most
  are listed below, but there are probably some that didn't make it into
  this list; sorry, I've lost track.

- Sadly, the help has remained essentially unchanged, so it's still
  "under construction".


v1.50 (never released) ----------------------------------------

- NEW: added .BSC support for MSVC browse files!

- uses new TSE3.0 SaveHistory/LoadHistory commands

- NEW: supports new TSE3.0 ReadOnlyBuffer command (saves/restores
  buffer's readonly state -- not same as a file's readonly attribute)

- done: commands to save/load clipboard (public procs, even!)

- NEW: supports autoloading Local projects, i.e. "local.pj" in the
  current directory

- lots of other miscellaneous changes and fixes.


v1.11 (never released) ----------------------------------------

- fixed: oops, compiling for TSE2.6 left out CTags support!

- fixed: two commands were trying to display listboxes 82 characters
  wide, so if the "screen" was not at least 82 characters wide, they
  failed.

- done: BACKGROUND THREAD for building file list!  MUCH faster and
  smoother!

- done: PgUp/Dn and Ctrl-PgUp/Dn now work in the file list


v1.10 ---------------------------------------------------------

- CTags support!  <F12> jumps to tag definition, <AltShift F12> displays
  Tags menu (from here you can generate tags file for a directory or
  reload a tags file, or use several other handy commands).  even if the
  current file is not in a project, you can still use CTags for that
  file's directory!  Make sure CTAGS.EXE is located in the same
  directory as your TSE executable.  CTags is available from
  http://home.hiwaay.net/~darren/ctags/

- fixed: if project filename contained a period (eg, "MyThing v1.0") the
  keyboard macros were saved to an incorrect filename and were not able
  to be reloaded

- fixed: default extensions got erased if you went to open a project and
  then canceled (or went to create a new project and canceled, etc)

- done: fully qualify paths entered in the "include files in this
  path" prompt

- fixed: "include loaded files in project?" prompt was pretty
  misleading, changed to "close all open files?"

- fixed: adding paths to the project was not clearing the file list
  before rebuilding it, resulting in duplicates

- done: can add paths to exclude; all files in that path and subdirs
  are excluded from the project (can be overridden on specific
  directories by explicitly listing the directory to include; cannot
  override subdir behavior, though)

- fixed: for some users crash could happen (was trying up to 32 windows,
  but GotoWindow didn't have error checking to fail when appropriate)

- fixed: cancel when creating new project did not cancel correctly


v1.00 ---------------------------------------------------------

- done: initial version with flat file list.  also saves list of files
  in use, windows in use, keyboard macros, marked block.

- done: auto load directories; automatically load associated project
  when started from matching directory.

- removed: when user opens a .PJ file, automatically open it as a
  project (see PROJECTS.S for example).  [REMOVED: causes bug where
  syntax hiliting does not work]

- done: do matching on "foo\foo" in flat file list.

- done: when saving list of open files, it saves several TSE settings
  with each filename, in case user is running a macro that remembers TSE
  settings on a per-file basis, such as FS.MAC.

- done: '-P' dos command line option forces not to load a project.

- done: '-Pproject_file' dos command line option loads project
  "project_file".

- fixed: when compile macro, reload, open project again, why does it
  not go to the file i was last editing??  [FIX: only try to load a
  project in WhenLoaded if NumFiles() == 0]

- fixed: why no OnFirstEdit for files we load in initial project??
  [FIX: because the loading was occurring in an OnFirstEdit hook]

- added: project-wide grep command, requires Grep v2.2.

- done: saves/restores TSE clipboard

- done: Open Project gives a menu of all known projects, plus an "Open
  other project..." command.

- done: before opening a project, prompts to save loaded files.

- done: after opening a project, closes files that were not open last
  time project was saved.

- done: database is stored in LoadDir, project files are stored in
  user-configurable subdirectory of LoadDir.

- done: first time you execute PROJ on your machine, it automatically
  steps you thru getting it set up.

- done: if TSE clipboard is > 500 lines, prompt before saving it.

- done: if you enter a filename (with no drive or path) that does not
  match a filename in the project, and the file is not found in the
  current directory, the OpenPath is searched (the same path used by
  OpenFileAtCursor).

- done: you can specify what file extensions are recognized by each
  project.  hit <Alt [>, "Project Settings", "Known File Types".

- fixed: when opening a project, if a file wasn't found, user could be
  left in an empty system file.

- fixed: when opening a project, if an error occurred while saving a
  file that was open, it was not aborting the open, so the new project
  still got opened.  now it aborts, so the new project is not opened.



-- WISH LIST ----------------------------------------------------------

- see comments scattered thru the .SI source files.  (look for "//$")


Version 1.0.0.0.326: Alt+[ shows Search projects (Z) and Refresh projects (0) submenus near the top of the main menu.
ASCII decimal 16 at the right of a menu label indicates a submenu. Refresh can discard unsaved edits.
A YesNo warning precedes any without-asking refresh of modified buffers.
Recompile all macros before testing. See proj0200_readme.md for details.

Version 1.0.0.0.326: Draw projects offers B for the marked block and V for the entire current file (including unsaved edits). Rebuild with build.bat.

Version 1.0.0.0.326: Replaced the default Known file types and the built-in fallback with all 358 unique extensions from dddfileextensionsall(1).txt, in the supplied order. Existing projects retain their saved [KnownFileTypes] lists. OpenAI Codex (GPT-6). Rebuild using build.bat before use.

Version 1.0.0.0.326: Compact tokenized fallback for all 358 Known file types fixes the macro-size increase introduced in 291. OpenAI Codex (GPT-6). Windows SAL compilation remains to be verified.

Version 1.0.0.0.326: Removed embedded extension fallback data to reduce proj.mac below its prior size. All 358 default extensions remain in proj0200_filetypes.txt. A missing defaults file produces a message asking to restore it. OpenAI Codex (GPT-6). Windows SAL compilation remains unverified.

## Version 1.0.0.0.326 - script creation and logs

Create script... is directly below Create project... in the main menu.
Choose a new .pjl filename. List() offers every supported command, a custom
line, editing the last line, and Save and return to editor. Selecting a command
opens an editable template; Enter inserts it, Escape cancels that insertion.
The list repeats for the next command. Escape from the list returns to the
normal editor with the script buffer retained; save any further edits.

openallprojects "C:\TEMP\DDDPJ\" imports and registers valid .pj records
from that directory (nonrecursive). It does not restore every project's files
into the editor. Only one project is active at once; the next command can be
openproject PROJ0200HELLOWORLD. Existing destination records use the same
copy behavior as Import all projects. Invalid records are skipped with WARNING;
no valid records or a failed copy stops execution with ERROR.

Script errors create pjlYYYYMMDDHHMMSS.log in the package directory. Each event
uses local Windows time: YYYY-MM-DD HH:MM:SS ERROR/WARNING/INFO message.
ERROR records the script filename, line, and failure. WARNING records skipped
invalid projects. INFO records the completed-command count after a logged run.
Successful runs without warnings do not create a log. Existing same-minute
logs are appended. These .pjl log files are plain text, not executable scripts.
The portable logging helpers use powershell.exe from PATH; script text is
passed through a data file, never evaluated as shell commands.

Rebuild using build.bat. SAL compilation and Windows runtime tests are pending.
Test Create script, openprojects.pjl (adapt the directory), and errorstest.pjl.
OpenAI Codex (GPT-6).

While editing an existing .pjl script, Run scripts > K: Insert PJL keyword
opens the same List(). The selected editable command is inserted at the
current cursor. Commands can also be typed directly in the normal editor.

Version 1.0.0.0.326: Main menu shows 4: Create script... directly below Create project...; G: Copy project... now follows Calculate projects. Rebuild with build.bat, then restart TSE to load the newly compiled resident proj.mac. OpenAI Codex (GPT-6). Windows compilation and runtime verification remain pending.

Version 1.0.0.0.326: Session Tools About reports the package version and path published by the loaded main proj.mac, separately from the Session Tools version. It shows a mismatch message when versions differ, or Unknown when an older main macro does not publish its package version. Purging the main macro clears its published identity. OpenAI Codex (GPT-6). Rebuild and restart TSE. Windows compilation and runtime verification remain pending.

Version 1.0.0.0.326: Help > About credits include previous author Chris Antos - 2002-05-19, alongside Ian Campbell. OpenAI Codex (GPT-6). Rebuild with build.bat and restart TSE.

Version 1.0.0.0.326: Help > About credits also include ChatGPT - 2026-08-28. OpenAI Codex (GPT-6). Rebuild with build.bat and restart TSE.

Version 1.0.0.0.326: Help > About credits also include Knud van Eeden - 2026-08-28. OpenAI Codex (GPT-6). Rebuild with build.bat and restart TSE.

Version 1.0.0.0.326: About now displays a buffer-based list with separate lines, avoiding the 255-character message-string limit. All four author credits are shown, including OpenAI ChatGPT GPT-6.1 Sol Light - 2026-08-28 and Knud van Eeden - 2026-08-28. OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows compilation and runtime verification remain pending.

Version 1.0.0.0.326: About credit uses OpenAI ChatGPT GPT-6.1 Sol Light - 2026-08-28. About retains the separate-line list so all author credits remain visible. Rebuild and restart TSE. Windows compilation and runtime verification remain pending.

Version 1.0.0.0.326: Create script reopens the initially saved .pjl as a normal named editor file before adding commands. This fixes File has no name when selecting Save and return to editor. OpenAI Codex (GPT-6). Rebuild and restart TSE. Windows compilation and runtime verification remain pending.

Version 1.0.0.0.326: Run scripts defaults to the main PROJ0200 directory and *.pjl. Previous script filenames remain available from history without overriding the default directory. The original working directory is restored after cancellation or execution. OpenAI Codex (GPT-6). Rebuild and restart TSE. Windows runtime verification remains pending.

Version 1.0.0.0.326: openallprojects removes a trailing filename wildcard added by ExpandPath before constructing the *.pj search. This fixes No valid .pj projects found for directories resolving to path\*.*. OpenAI Codex (GPT-6). Rebuild and restart TSE. Windows runtime verification remains pending.

Version 1.0.0.0.326: PJL logging overwrites stale event files and reports event-file or buffer failures. Helper diagnostics go to proj0200_pjl_log_errors.txt; returned log paths are checked for existence. INFO is written only after a successful ERROR event. Test errorstest.pjl to trigger an unknown command and a timestamped log. OpenAI Codex (GPT-6). Windows runtime verification remains pending.

Version 1.0.0.0.326: PJL log filenames use pjlYYYYMMDDHHMMSS.log, for example pjl20261013191530.log. Logging includes seconds and retains ERROR, WARNING and INFO timestamps. Stale event files are overwritten and logging failures report diagnostics in proj0200_pjl_log_errors.txt. Test errorstest.pjl. OpenAI Codex (GPT-6). Windows runtime verification remains pending.

Version 1.0.0.0.326: Each logged script run reserves a new pjlYYYYMMDDHHMMSS.log using exclusive CreateNew mode. Existing logs are never overwritten or reused for a new run; a timestamp collision waits for the next available second. Later events append to the same run log. OpenAI Codex (GPT-6). Windows runtime verification remains pending.

Version 1.0.0.0.326: PJL logs use ERROR instead of SEVERE. Updated SAL logging, PowerShell severity validation, and documentation. OpenAI Codex (GPT-6). Rebuild with build.bat and restart TSE. Windows compilation and runtime verification remain pending.

Version 1.0.0.0.326: PJL ERROR log entries and final error messages include a one-based source column. Token columns preserve leading spaces and tabs (each tab counts as one source character). Unknown commands point to the command; invalid parameters point to the parsed token; overlength lines point to column 256. File/read failures use line 0 column 1 when no source location is available. OpenAI Codex (GPT-6). Windows compilation and runtime verification remain pending.

Version 1.0.0.0.326: Run scripts lists R: Run Project Language script (.pjl)... first, followed by K: Insert PJL keyword.... Existing actions and hotkeys are retained. OpenAI Codex (GPT-6). Rebuild and restart TSE.

Version 1.0.0.0.326: New PJL command viewcurrentactiveproject takes no parameters and invokes the same name, filename and description dialogs as View current active project. No active project or extra parameters produce a logged ERROR. The command is included in the keyword picker and pjl.txt syntax definitions. OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows compilation and runtime verification remain pending.

Version 1.0.0.0.326: Run projects now lists R: Run scripts first, above F: Run block or files. Existing hotkeys and actions are retained. OpenAI Codex (GPT-6). Rebuild and restart TSE.

Version 1.0.0.0.326: Run a PJL script through the macro parameter:
  projstart.mac newscript.pjl
  projstart.mac "C:\TEMP\my script.pjl"
  proj.mac newscript.pjl
  proj.mac -RunPJL "C:\TEMP\my script.pjl"
Relative script filenames resolve from the main PROJ0200 directory. The filename prompt is skipped. No parameter retains the existing menu behavior. Script errors use the existing timestamped .log mechanism. These are TSE Execute Macro commands; projstart.mac is not a standalone executable. OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows compilation and runtime verification remain pending.

Version 1.0.0.0.326: Restored the clean version 313 implementation. CmdLineParameter source, test macro, build integration and -p parameter capture from version 314 are absent. In-editor Execute Macro support remains: projstart.mac newscript.pjl. OpenAI Codex (GPT-6). Rebuild and restart TSE.

Version 1.0.0.0.326: New PJL command viewallprojects takes no parameters and calls the existing View all projects action. It displays saved project names without switching the active project and does not require an active project. Included in the keyword picker and syntax highlighting. OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows compilation and runtime verification remain pending.

Version 1.0.0.0.326: openallprojects can be run repeatedly. Existing valid destination project records are retained and registered, counted as available projects, and do not show replacement prompts. Only missing records are copied. An invalid existing destination reports ERROR without overwriting it. Use the interactive Import action when intentionally replacing an existing record from the source directory. OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows runtime verification remains pending.

Version 1.0.0.0.326: PJL pause [text]

pause displays Press a key to continue... and waits for the user to dismiss
the native TSE/selected Windows OK dialog, then continues the script.
pause Some text here displays that text and waits.
pause "Some text here" is also supported; unmatched quotes report ERROR.
Commands are case-insensitive: PAUSE, Pause and pause are equivalent.
Included in the keyword picker and syntax highlighting.
OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows verification pending.

Version 1.0.0.0.326: AI selection under Run projects

Run projects > A: Run AI... launches the supplied runprain macro as a
separate companion. It retains the complete AI choice list, web URL
launching, command-line alias execution, and Ctrl-F12 binding from the
submitted source. Escape returns without launching a choice.

The build compiles SRC\MAC\runprain.s and copies runprain.s/runprain.mac
to the package root. Its existing implementation and original credits
are preserved, with a package-version header added.

Command-line choices require the original macro's configured TCC and
alias-file paths (dddpath.ini settings); optional setwiyde.mac is referenced
by its existing diagnostic helpers. These personal dependencies are not
bundled or changed by this integration. Web entries use StartPgm(URL).
No AI service is launched merely by opening the menu.

OpenAI Codex (GPT-6). Rebuild with build.bat and restart TSE.
Windows SAL compilation and launch testing remain pending.

Version 1.0.0.0.326: syntax highlight conversion

Change projects > S: Convert syntax highlight .txt to .syn or .syn to .txt
runs the package's syncfg2.mac without parameters, using its existing
interactive/current-buffer interface. Open the syntax highlight file to
convert before selecting the action.

Includes syncfg2.si, common.h and syncfg.inc from syncfg2knud 1.0.0.0.8
in both the package root and SRC\MAC. Component code and its version are
preserved. build.bat compiles syncfg2.si and copies syncfg2.mac and its
sources to the package root. No external converter program is needed.
The converter's explicit file and directory parameter modes remain available.
OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows compilation and
menu/runtime verification remain pending.

Version 1.0.0.0.326: Session Tools actions in project menus

Search projects: Replace across open files; Audit bookmarks forward/reverse.
View projects: Toggle to previous file; List open / recent files (sorting
and recent-file keys remain available inside the list).
Save projects is now a submenu: Save current project; Save session snapshot.
Load projects: Restore session snapshot; Add another snapshot's files;
Save and switch session. Snapshots are distinct from .pj project records.
Backup projects: Compare current file to backup (requires the existing TSE
cmp2bkup.mac in the macro search path; it is not included in this package).

Actions reuse Session Tools routines and run after the main menu's buffer,
block and display cleanup. Session Tools load on demand; file/bookmark
tracking starts when those tools load. The original Session Tools menus
remain available. Cross-file replacement operates on the editor ring.
OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows compilation and
runtime verification remain pending.

Version 1.0.0.0.326: Removed ten duplicate Session Tools menu entries now available through the main Search/View/Save/Load/Backup menus: open/recent list, previous-file toggle, bookmark forward/reverse, cross-file replace, snapshot save/restore/append/switch, and compare to backup. Shared implementations and action dispatch remain; unique Session Tools entries are retained. OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows compilation and runtime verification remain pending.

Version 1.0.0.0.326: built-in SAL backup comparison replacement

Backup projects > Compare current file to backup now runs the supplied
cmp2bkupreplacement.mac, compiled from cmp2bkupreplacement.s by build.bat.
No cmp2bkup.mac, external diff executable, DLL or shell helper is required.
It can also be run directly through TSE Execute Macro.

Open a named text file, select the command, then choose the backup filename.
The default suggests same-basename .bak, then filename.ext.bak when found,
then the most recent comparison path. Other backup filenames can be selected.
For PROJ0200 timestamped backups, browse into the run folder and select the
backed-up file beneath its drive/path subdirectories. Extract ZIP backups
before comparison. No automatic latest-snapshot selection is performed.

Comparison uses the current editor buffer, including unsaved changes, and
reads the backup from disk into a private temporary buffer. It does not
save or modify either input. Differences are compared by line number,
case-sensitively, including whitespace; 255-character chunks allow
comparisons beyond column 255. Each result shows line:column and previews
of both lines (up to 80 characters each). Enter jumps to that position in
the current file; Escape returns. Missing current lines jump to the last
current line. This is a line-by-line comparison, not an aligned diff:
an inserted/deleted line can cause subsequent lines to differ. It compares
editor text, not binary bytes, encoding or line-ending formats.

OpenAI Codex (GPT-6). Rebuild and restart TSE. Windows SAL compilation and
runtime verification remain pending.

Version 1.0.0.0.326: cmp2bkupreplacement.s
Backup projects > Compare current file to backup runs the bundled SAL
replacement. build.bat compiles and copies it; no external diff program,
DLL or shell helper is required. Choose a backup file; the default suggests
a nearby .bak or the last comparison filename. For PROJ0200 backups browse
into the timestamped run folder and select its drive/path copy of the file.
Extract ZIP backups first. No automatic latest-snapshot selection is made.
Compares current buffer including unsaved edits against backup text on disk.
Neither input is saved or modified. Results show line:column and 80-character
previews of each line. Enter jumps in the current file; Escape returns.
Comparison is case-sensitive and includes whitespace and columns beyond 255.
This compares matching line numbers, not an aligned diff; insertions/deletions
can cause subsequent lines to differ. Encoding and line-ending differences
are not compared as binary bytes. OpenAI Codex (GPT-6).
Rebuild and restart TSE; Windows compilation/runtime verification pending.

Version 1.0.0.0.326: Reduced compiled main-menu help strings to address SAL Macro too long. Menu labels, hotkeys and action calls are retained. Full help descriptions follow below. OpenAI Codex (GPT-6). Rebuild and restart TSE; Windows SAL verification remains pending.

Version 1.0.0.0.326: cmp2bkupreplacement now includes its own directory-restoration helper using native ChDir, replacing unavailable CDD calls. OpenAI Codex (GPT-6). Rebuild; Windows compilation and runtime verification remain pending.

Version 1.0.0.0.326: Backup menu explicitly labels the comparison action as Compare 2 FILES (current file and backup)... . OpenAI Codex (GPT-6).
