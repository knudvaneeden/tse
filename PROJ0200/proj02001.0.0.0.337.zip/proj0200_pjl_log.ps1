# PROJ0200 1.0.0.0.337 - OpenAI Codex (GPT-6)
$ErrorActionPreference = 'Stop'
$eventPath = Join-Path $PSScriptRoot 'proj0200_pjl_event.txt'
$resultPath = Join-Path $PSScriptRoot 'proj0200_pjl_log_result.txt'
$lines = [IO.File]::ReadAllLines($eventPath)
if ($lines.Length -lt 3) { throw 'Incomplete PJL log event.' }
$severity = $lines[0]
if ($severity -notin @('ERROR', 'WARNING', 'INFO')) { throw 'Invalid severity.' }
$now = Get-Date
$log = $lines[1]
if (-not $log) {
    while ($true) {
        $now = Get-Date
        $candidate = Join-Path $PSScriptRoot ('pjl' + $now.ToString('yyyyMMddHHmmss') + '.log')
        try {
            # CreateNew atomically refuses to overwrite an existing log.
            $stream = [IO.File]::Open($candidate, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)
            $stream.Dispose()
            $log = $candidate
            break
        } catch [IO.IOException] {
            if (-not [IO.File]::Exists($candidate)) { throw }
            Start-Sleep -Milliseconds 100
        }
    }
}
if ([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($log)) -ne $PSScriptRoot) { throw 'Invalid log directory.' }
$message = ($lines[2..($lines.Length-1)] -join ' ')
[IO.File]::AppendAllText($log, $now.ToString('yyyy-MM-dd HH:mm:ss') + ' ' + $severity + ' ' + $message + "`r`n", [Text.Encoding]::Default)
[IO.File]::WriteAllText($resultPath, $log + "`r`n", [Text.Encoding]::Default)
Remove-Item -LiteralPath $eventPath
