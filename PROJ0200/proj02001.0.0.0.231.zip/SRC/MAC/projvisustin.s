// PROJ0200 1.0.0.0.231 - Visustin marked-block workflow
#include ["projhistory.si"]
string proc PROJ_VisRoot()
    return(SplitPath(CurrMacroFilename(), _DRIVE_|_PATH_))
end
proc Main()
    integer originalBuffer = GetBufferId()
    integer sequence = 0
    integer saved = FALSE
    string extension[255] = SplitPath(CurrFilename(), _EXT_)
    string temporaryFile[255]
    string command[255]
    string language[255] = "/C"
    // The result is a block TYPE, not just TRUE/FALSE. Test zero explicitly.
    if isBlockInCurrFile() == 0
        Warn("No block in current buffer: ", CurrFilename(), ". Current ID=", originalBuffer, ", BlockId=", Query(BlockId), ", block type=", isBlockMarked(), ", menu entry block=", GetGlobalInt("PROJ_DrawEntryBlockType"), ". First mark the source text in this file.")
        return()
    endif
    if not Length(extension)
        Warn("Save or name the current file with a language extension first.")
        return()
    endif
    if not PROJ_HistoryAsk("Visustin language switch (for example /C, /CPP, /JAVA):", language, "PROJ0200:visustin:language")
        return()
    endif
    if not Length(Trim(language))
        return()
    endif
    repeat
        sequence = sequence + 1
        temporaryFile = PROJ_VisRoot() + "proj0200_visustin_" + Str(sequence) + extension
    until not FileExists(temporaryFile)
    command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File " + QuotePath(PROJ_VisRoot() + "proj0200_visustin.ps1") + " -Source " + QuotePath(temporaryFile) + " -Language " + QuotePath(language)
    if Length(PROJ_VisRoot()) * 2 + Length(extension) + Length(language) + 150 > 255
        Warn("Visustin command exceeds the SAL path limit. Use a shorter installation path.")
        return()
    endif
    PushPosition()
    PushBlock()
    // Same direct block-saving operation as the supplied working runblclj.s.
    saved = SaveBlock(QuotePath(temporaryFile))
    GotoBufferId(originalBuffer)
    PopBlock()
    PopPosition()
    if not saved
        EraseDiskFile(temporaryFile)
        Warn("Could not save the marked block for Visustin.")
        return()
    endif
    Warn("Visustin will receive only the marked block. Close Visustin before confirming the next message; that confirmation deletes the temporary source file.")
    Dos(command, _DONT_PROMPT_)
    Warn("Close Visustin now. Press Enter only after it has closed to delete the temporary source file. Launch details: proj0200_visustin_log.txt.")
    EraseDiskFile(temporaryFile)
    UpdateDisplay()
end
