PROJ0200 package version: 1.0.0.0.355

cmp2bkupreplacement.s
Backup projects > Compare current file to backup runs the bundled SAL
replacement. build.bat compiles and copies it; no external diff program,
DLL or shell helper is required. Choose a backup file; the default suggests
a nearby .bak or the last comparison filename. For PROJ0200 backups browse
into the timestamped run folder and select its drive/path copy of the file.
Extract ZIP backups first. No automatic latest-snapshot selection is made.
Compares current buffer including unsaved edits against backup text on disk.
Neither input is saved or modified. Results show line:column and 80-character
previews of each line. Enter jumps in the current file; Escape returns.
Comparison is case-sensitive and includes whitespace and columns beyond 255.
This compares matching line numbers, not an aligned diff; insertions/deletions
can cause subsequent lines to differ. Encoding and line-ending differences
are not compared as binary bytes. OpenAI Codex (GPT-6).
Rebuild and restart TSE; Windows compilation/runtime verification pending.

cmp2bkupreplacement now includes its own directory-restoration helper using native ChDir, replacing unavailable CDD calls. OpenAI Codex (GPT-6). Rebuild; Windows compilation and runtime verification remain pending.
