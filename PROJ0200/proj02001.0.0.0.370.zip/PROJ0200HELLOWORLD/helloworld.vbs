' helloworld.vbs version 1.0.0.0.9
' Created with OpenAI ChatGPT - 2026-10-17
Option Explicit
WScript.Echo "Hello from VBScript"
