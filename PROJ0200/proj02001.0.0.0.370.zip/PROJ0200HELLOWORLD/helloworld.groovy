// helloworld.groovy version 1.0.0.0.10
// Prepared with OpenAI ChatGPT (Codex), 2026-10-14.
println 'Hello world'
