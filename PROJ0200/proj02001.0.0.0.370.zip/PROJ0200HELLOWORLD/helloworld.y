/* helloworld.y - version 1.0.0.0.10 - OpenAI ChatGPT GPT-6
   Bison generates C. COMBISON builds and runs it using Borland C++ 5.5.
   No Flex or input required: the lexer returns end-of-input. */
%{
#include <stdio.h>
int yylex(void);
void yyerror(const char *message);
%}
%%
start: %empty { puts("Hello world"); } ;
%%
int yylex(void)
{
    return 0;
}
void yyerror(const char *message)
{
    fprintf(stderr, "%s\n", message);
}
int main(void)
{
    return yyparse();
}
