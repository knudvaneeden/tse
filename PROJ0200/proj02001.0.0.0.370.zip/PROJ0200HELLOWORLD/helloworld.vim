" helloworld.vim version 1.0.0.0.9 - OpenAI GPT-6.1
" Run with COMVIMSCRIPT.BAT; output should contain Hello world.
echomsg 'Hello world from Vimscript!'
