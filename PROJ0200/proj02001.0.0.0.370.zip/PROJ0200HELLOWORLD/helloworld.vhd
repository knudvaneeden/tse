-- helloworld.vhd version 1.0.0.0.8 - OpenAI GPT-6
entity helloworld is
end entity helloworld;

architecture demo of helloworld is
begin
    process
    begin
        report "Hello world" severity note;
        wait;
    end process;
end architecture demo;
