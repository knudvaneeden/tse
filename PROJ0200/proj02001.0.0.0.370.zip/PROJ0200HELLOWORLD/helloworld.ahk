; helloworld.ahk version 1.0.0.0.10
; OpenAI ChatGPT (GPT-6), 2026-10-16
#Requires AutoHotkey v2.0
#SingleInstance Off
MsgBox("Hello world from AutoHotkey v2!", "Hello world")
ExitApp(0)
