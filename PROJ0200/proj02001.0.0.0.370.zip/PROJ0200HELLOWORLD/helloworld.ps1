# helloworld.ps1 - version 1.0.0.0.9
# Knud van Eeden / OpenAI GPT-6
# Save as helloworld.ps1. Run using COMPOWERSHELL.BAT or TSE.
Write-Output 'Hello, world!'
