PROC Main()
 Warn( "Hello world" )
END
