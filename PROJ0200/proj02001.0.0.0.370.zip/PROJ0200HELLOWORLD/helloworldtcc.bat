@echo off
REM helloworld.bat version 1.0.0.0.9
REM Run through COMTCC.BAT, from either TCC or CMD.
echo Hello world from TCC!
exit /b 0
