; helloworld.scm - version 1.0.0.0.11 - OpenAI GPT-6
; Chez Scheme sample for COMSCHEME.BAT.
(display "Hello world from Scheme")
(newline)
(exit)
