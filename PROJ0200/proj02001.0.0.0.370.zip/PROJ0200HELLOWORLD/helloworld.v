(* helloworld.v version 1.0.0.0.9 - OpenAI GPT-6 *)
(* Compile with COMROCQ.BAT using the standard Rocq .v extension. *)
Goal True.
Proof.
  idtac "Hello world from Rocq!".
  exact I.
Qed.
Compute (2 + 3).
