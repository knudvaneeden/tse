#include ["projdialogs.si"]
// PROJ0200 1.0.0.0.370 - OpenAI Codex (GPT-6)
integer GIResults = 0
integer GIMap = 0
integer GIOwned = 0
proc PROJ_ReleaseResults()
    integer countI
    integer rowI
    integer bufferI
    if GIOwned and GotoBufferId(GIOwned)
        countI = NumLines()
        for rowI = 1 to countI
            GotoBufferId(GIOwned)
            GotoLine(rowI)
            bufferI = Val(GetText(1, 255))
            if bufferI
                AbandonFile(bufferI)
            endif
        endfor
        AbandonFile(GIOwned)
    endif
    if GIResults
        AbandonFile(GIResults)
    endif
    if GIMap
        AbandonFile(GIMap)
    endif
    GIResults = 0
    GIMap = 0
    GIOwned = 0
end
proc PROJ_ResultClick()
    if MouseHotSpot() == _MOUSE_MARKING_
        GotoMouseCursor()
        PushKey(<Enter>)
    else
        ProcessHotSpot()
    endif
end
keydef PROJ_ResultListKeys
<LeftBtn> PROJ_ResultClick()
end
proc PROJ_ResultStartup()
    Enable(PROJ_ResultListKeys)
    ListFooter(" Click/Enter: jump | Esc: close | Ctrl+Alt+Shift+G: results ")
end
proc PROJ_ResultCleanup()
    Disable(PROJ_ResultListKeys)
end
proc PROJ_ShowResults()
    integer originalI = GetBufferId()
    integer acceptedI
    integer rowI
    integer targetI
    integer lineI
    integer columnI
    string pathS[255]
    if not GIResults or not GotoBufferId(GIResults)
        FNProjectWarning("No retained project search results. Run a search first.")
        return()
    endif
    Hook(_LIST_STARTUP_, PROJ_ResultStartup)
    Hook(_LIST_CLEANUP_, PROJ_ResultCleanup)
    acceptedI = List("Project search results - Click/Enter jumps; Esc returns", 100)
    UnHook(PROJ_ResultStartup)
    UnHook(PROJ_ResultCleanup)
    Disable(PROJ_ResultListKeys)
    rowI = CurrLine()
    GotoBufferId(originalI)
    if acceptedI and GotoBufferId(GIMap)
        GotoLine((rowI - 1) * 4 + 1)
        targetI = Val(GetText(1, 255))
        Down()
        pathS = GetText(1, 255)
        Down()
        lineI = Val(GetText(1, 255))
        Down()
        columnI = Val(GetText(1, 255))
        GotoBufferId(originalI)
        if lineI
            if targetI and GotoBufferId(targetI)
                if CurrFilename() <> pathS
                    targetI = 0
                endif
            else
                targetI = 0
            endif
            if not targetI and Length(pathS)
                targetI = GetBufferId(pathS)
                if not targetI
                    if EditFile(QuotePath(pathS), _DONT_PROMPT_)
                        targetI = GetBufferId()
                    endif
                endif
            endif
            if targetI
                GotoBufferId(targetI)
                GotoLine(lineI)
                GotoColumn(columnI)
            else
                GotoBufferId(originalI)
                FNProjectWarning("Search target is no longer available. Run the search again.")
            endif
        endif
    endif
end
keydef PROJ_ResultReturnKeys
<CtrlAltShift G> PROJ_ShowResults()
end
proc WhenLoaded()
    Enable(PROJ_ResultReturnKeys)
end
proc WhenPurged()
    Disable(PROJ_ResultReturnKeys)
    PROJ_ReleaseResults()
end
proc Main()
    integer originalI = GetBufferId()
    integer incomingI = GetGlobalInt("PROJ_SearchResults")
    string summaryS[255]
    if incomingI
        PROJ_ReleaseResults()
        GIResults = incomingI
        GIMap = GetGlobalInt("PROJ_SearchMap")
        GIOwned = GetGlobalInt("PROJ_SearchOwned")
        DelGlobalVar("PROJ_SearchResults")
        DelGlobalVar("PROJ_SearchMap")
        DelGlobalVar("PROJ_SearchOwned")
        GotoBufferId(GIResults)
        EndFile()
        summaryS = GetText(1, 100)
        BegFile()
        GotoBufferId(originalI)
        FNProjectWarning(summaryS + Chr(13) +
            "Click a found line or press Enter to open the file at its row and column." + Chr(13) +
            "Ctrl+Alt+Shift+G returns to the search results.")
    endif
    PROJ_ShowResults()
end
