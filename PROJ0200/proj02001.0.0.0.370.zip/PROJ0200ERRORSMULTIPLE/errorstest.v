(* errorstest.v version 1.0.0.0.9 - OpenAI GPT-6 *)
(* Normal compilation reports the first error, then stops. *)
(* Fix each definition as indicated and compile again for the next jump. *)
(* 1: replace missing_one with 1. *)
Definition first_value : nat := missing_one.

(* 2: replace missing_two with 2. *)
Definition second_value : nat := missing_two.

(* 3: replace missing_three with 3. *)
Definition third_value : nat := missing_three.
