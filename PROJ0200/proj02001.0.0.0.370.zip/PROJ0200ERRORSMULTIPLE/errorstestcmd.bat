@echo off
REM errorstest.bat version 1.0.0.0.8 - CMD multiple runtime errors
REM OpenAI ChatGPT - 2026-10-17. Explicit source locations for TSE.
REM Keep line numbers below synchronized if editing this demonstration.
setlocal
echo filename=%~f0
comcmd_missing_command_one
if errorlevel 1 call :reportError 7 comcmd_missing_command_one
REM Continue after the first failure.
comcmd_missing_command_two
if errorlevel 1 call :reportError 10 comcmd_missing_command_two
REM Continue after the second failure.
comcmd_missing_command_three
if errorlevel 1 call :reportError 13 comcmd_missing_command_three
REM These locations are explicitly reported by this source, not by CMD.
endlocal & exit /b 1

:reportError
REM Each error has independent metadata for the TSE backward searches.
echo filename=%~f0
echo line=%~1
echo column=1
echo CMD: ERROR: Unknown command %~2
exit /b 0
