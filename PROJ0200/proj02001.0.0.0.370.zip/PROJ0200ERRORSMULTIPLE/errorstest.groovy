// errorstest.groovy version 1.0.0.0.10
// Prepared with OpenAI ChatGPT (Codex), 2026-10-14.
// Install as F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.groovy
// Three independent compile-time errors; no runtime execution expected.
import groovy.transform.TypeChecked

@TypeChecked
void testErrors() {
    int first = missingVariableOne
    int second = missingVariableTwo
    int third = missingVariableThree
}

testErrors()
