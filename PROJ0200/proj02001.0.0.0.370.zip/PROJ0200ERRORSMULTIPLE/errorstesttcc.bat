@echo off
REM errorstest.bat version 1.0.0.0.9
REM Three harmless unknown commands; no files are modified.
REM Expected error lines: 7, 9, 11. Column 1 is a fallback.
REM A later success may reset the process exit code; inspect diagnostics.
echo Testing three independent TCC runtime errors.
COMTCC_MISSING_COMMAND_ONE_1_0_0_0_7
echo Continuing after error one.
COMTCC_MISSING_COMMAND_TWO_1_0_0_0_7
echo Continuing after error two.
COMTCC_MISSING_COMMAND_THREE_1_0_0_0_7
exit /b 1
