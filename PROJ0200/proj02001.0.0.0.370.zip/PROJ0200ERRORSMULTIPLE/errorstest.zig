// errorstest.zig version 1.0.0.0.9 - Created with OpenAI GPT-6
// Save as F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.zig
// true: three independent compile errors; false: compile/run Hello World.
const std = @import("std");
const showErrors = true;

comptime {
    if (showErrors) @compileError("First deliberate error");
}

comptime {
    if (showErrors) @compileError("Second deliberate error");
}

comptime {
    if (showErrors) @compileError("Third deliberate error");
}

pub fn main() void {
    std.debug.print("Hello from Zig - version 1.0.0.0.9\n", .{});
}
