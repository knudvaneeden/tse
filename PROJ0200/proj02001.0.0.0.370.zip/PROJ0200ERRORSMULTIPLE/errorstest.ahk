; errorstest.ahk version 1.0.0.0.10
; OpenAI ChatGPT (GPT-6), 2026-10-16
; Syntax errors: first only. Fix each by replacing ) with 1, then rerun.
; Use check mode. Expected error lines: 8, then 9, then 10.
#Requires AutoHotkey v2.0
#SingleInstance Off
; Three intentionally invalid assignments:
first := )
second := )
third := )
ExitApp(0)
