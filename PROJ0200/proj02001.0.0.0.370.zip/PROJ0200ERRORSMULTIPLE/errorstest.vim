" errorstest.vim version 1.0.0.0.9 - OpenAI GPT-6.1
" Three independent errors: expected lines 5, 7, 9 and byte column 13.
" Vim should continue between these top-level undefined-variable errors.
" First error:
let first = missing_variable_one
" Second error:
let other = missing_variable_two
" Third error:
let third = missing_variable_three
" This confirms that execution reached the end.
echomsg 'Finished the three-error test.'
