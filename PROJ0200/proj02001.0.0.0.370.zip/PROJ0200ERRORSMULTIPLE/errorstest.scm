; errorstest.scm - version 1.0.0.0.11 - OpenAI GPT-6
; Save as F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.scm
; Three independent errors. A normal script stops at the first one.
; Comment out the first failing expression to try the next error.
; Precise line/column positions are not supplied by this runner.
(display missing-variable-one)
(car 123)
(+ 1 "not-a-number")
(exit)
