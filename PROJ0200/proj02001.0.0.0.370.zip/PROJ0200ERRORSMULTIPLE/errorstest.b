[COMBRAINF errorstest version 1.0.0.0.9]

Three intentionally unmatched brackets follow
Expected locations are row six col three row eight col five row ten col seven

  ]

    ]

      [
