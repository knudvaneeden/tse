# errorstest.ps1 - version 1.0.0.0.9
# Knud van Eeden / OpenAI GPT-6
# Save as F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.ps1
# Three nonterminating runtime errors: lines 6, 7, 8; column 1.
$ErrorActionPreference = 'Continue'
Write-Error 'Intentional error one' -ErrorAction Continue
Write-Error 'Intentional error two' -ErrorAction Continue
Write-Error 'Intentional error three' -ErrorAction Continue
Write-Output 'All three intentional errors have been reached.'
