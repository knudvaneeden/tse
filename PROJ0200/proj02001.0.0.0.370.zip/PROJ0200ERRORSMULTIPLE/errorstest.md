<!-- errorstest.md - version 1.0.0.8 -->
<!-- 2026-10-11 01:58 +0200; GPT-6 / Codex -->
<!-- Visual test only: COMMARKDOWN does not report Markdown syntax errors. -->
# Markdeep formatting test

## Problem 1: incomplete link
[Example link](https://example.com

## Problem 2: unclosed code fence
```text
Hello from Markdown
This code fence intentionally has no closing fence.
