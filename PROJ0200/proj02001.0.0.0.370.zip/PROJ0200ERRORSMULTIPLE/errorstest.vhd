-- errorstest.vhd version 1.0.0.0.8 - OpenAI GPT-6
-- Install as F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.vhd
-- Three independent undeclared identifiers: lines 13, 14, and 15.
entity errorstest is
end entity errorstest;

architecture demo of errorstest is
begin
    process
        variable firstValue : integer := 0;
        variable secondValue : integer := 0;
    begin
        firstValue := missingFirst;
        secondValue := missingSecond;
        firstValue := missingThird;
        wait;
    end process;
end architecture demo;
