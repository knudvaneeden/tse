' errorstest.vbs version 1.0.0.0.9
' Created with OpenAI ChatGPT - 2026-10-17
' CScript stops at the first unhandled error.
' Comment out line 10, run again; then comment out line 13 and run again.
' Expected failing lines: 10, 13, 16; use the host-reported column.

Option Explicit
Dim result

' Error 1: division by zero.
result = 1 / 0

' Error 2: type mismatch.
result = CInt("this is not a number")

' Error 3: invalid procedure call or argument.
result = Sqr(-1)
