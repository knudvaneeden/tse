note
    description: "COMEIFFEL error test version 1.0.0.0.10 - OpenAI GPT-6"

class
    ERRORSTEST

create
    make

feature {NONE}
    make
        local
            first_number: INTEGER
            second_number: INTEGER
            third_number: INTEGER
        do
            first_number := "First intentional type error"
            second_number := "Second intentional type error"
            third_number := "Third intentional type error"
            print (first_number)
            print (second_number)
            print (third_number)
        end
end
