/* errorstest.y - version 1.0.0.0.10 - OpenAI ChatGPT GPT-6
   Save as F:\BBC\TAAL\PROJ0200ERRORSMULTIPLE\errorstest.y
   Expected: three Bison errors at lines 6, 7, 8; column 5. */
%%
start:
    missing_one
  | missing_two
  | missing_three
  ;
%%
