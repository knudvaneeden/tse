@echo off
@REM Run this batch file from the extracted package's main directory.
@REM Usage: build.bat "F:\WORDPROC\tse32_v45024\sc32.exe"
@REM Use the sc32.exe matching your TSE installation.
if "%1"=="" goto usage
SET sc32=%1

cd src
cd mac

%sc32% timelog.s
if errorlevel 1 goto compile_failed
%sc32% nameclip.s
if errorlevel 1 goto compile_failed
%sc32% clipview.s
if errorlevel 1 goto compile_failed
%sc32% proj.si
if errorlevel 1 goto compile_failed
%sc32% cmp2bkupreplacement.s
if errorlevel 1 goto compile_failed
%sc32% projsyncfg.s
if errorlevel 1 goto compile_failed
%sc32% syncfg.si
if errorlevel 1 goto compile_failed
%sc32% syncfg2.si
if errorlevel 1 goto compile_failed
%sc32% runprain.s
if errorlevel 1 goto compile_failed
%sc32% projpjlcreate.s
if errorlevel 1 goto compile_failed
%sc32% projreadme.s
if errorlevel 1 goto compile_failed
%sc32% projvisustin.s
if errorlevel 1 goto compile_failed
%sc32% projtooltip.s
if errorlevel 1 goto compile_failed
%sc32% projscope.s
if errorlevel 1 goto compile_failed
%sc32% projdraw.s
if errorlevel 1 goto compile_failed
%sc32% projsearchresults.s
if errorlevel 1 goto compile_failed
%sc32% projbuffersearch.s
if errorlevel 1 goto compile_failed
%sc32% projpjlexamples.s
if errorlevel 1 goto compile_failed
%sc32% projexamples.s
if errorlevel 1 goto compile_failed
%sc32% getstemk.s
if errorlevel 1 goto compile_failed
%sc32% pjfile.si
if errorlevel 1 goto compile_failed
%sc32% gethelp.si
if errorlevel 1 goto compile_failed
%sc32% helphelp.s
if errorlevel 1 goto compile_failed
%sc32% projstart.s
if errorlevel 1 goto compile_failed
%sc32% projsession.s
if errorlevel 1 goto compile_failed
%sc32% projtransfer.s
if errorlevel 1 goto compile_failed
%sc32% projsvnbrowse.s
if errorlevel 1 goto compile_failed
%sc32% git.s
if errorlevel 1 goto compile_failed

@REM Return from SRC\MAC to the directory containing this batch file.
cd ..
cd ..

copy SRC\MAC\cmp2bkupreplacement.s
copy SRC\MAC\cmp2bkupreplacement.mac
copy SRC\MAC\projsyncfg.s
copy SRC\MAC\projsyncfg.mac
copy SRC\MAC\syncfg.si
copy SRC\MAC\syncfg.mac
copy SRC\MAC\syncfg2.si
copy SRC\MAC\syncfg2.mac
copy SRC\MAC\common.h
copy SRC\MAC\syncfg.inc
copy SRC\MAC\runprain.s
copy SRC\MAC\runprain.mac
copy SRC\MAC\projpjlcreate.s
copy SRC\MAC\projpjlcreate.mac
copy SRC\MAC\proj.si
copy SRC\MAC\proj.mac
copy SRC\MAC\projpjlexamples.s
copy SRC\MAC\projpjlexamples.mac
copy SRC\MAC\projexamples.s
copy SRC\MAC\projexamples.mac
copy SRC\MAC\getstemk.s
copy SRC\MAC\getstemk.mac
copy SRC\MAC\projsearchresults.s
copy SRC\MAC\projsearchresults.mac
copy SRC\MAC\projsearchbridge.si
copy SRC\MAC\projbuffersearch.s
copy SRC\MAC\projbuffersearch.mac
copy SRC\MAC\projreadme.s
copy SRC\MAC\projreadme.mac
copy SRC\MAC\projvisustin.s
copy SRC\MAC\projvisustin.mac
copy SRC\MAC\projtooltip.s
copy SRC\MAC\projtooltip.mac
copy SRC\MAC\projscope.s
copy SRC\MAC\projscope.mac
copy SRC\MAC\projdraw.s
copy SRC\MAC\projdraw.mac
copy SRC\MAC\pjfile.si
copy SRC\MAC\pjfile.mac
copy SRC\MAC\gethelp.si
copy SRC\MAC\gethelp.mac
copy SRC\MAC\helphelp.s
copy SRC\MAC\helphelp.mac
copy SRC\MAC\projstart.s
copy SRC\MAC\projstart.mac
copy SRC\MAC\timelog.s
copy SRC\MAC\timelog.mac
copy SRC\MAC\nameclip.s
copy SRC\MAC\nameclip.mac
copy SRC\MAC\clipview.s
copy SRC\MAC\clipview.mac
copy SRC\MAC\projsession.s
copy SRC\MAC\projsession.mac
copy SRC\MAC\projtransfer.s
copy SRC\MAC\projtransfer.mac
copy SRC\MAC\projsvnbrowse.s
copy SRC\MAC\projsvnbrowse.mac
copy SRC\MAC\git.s
copy SRC\MAC\git.mac
copy SRC\MAC\proj.hlp
goto done

:compile_failed
cd ..
cd ..
echo SAL compilation failed; no macros were copied.
goto done

:usage
echo Usage: build.bat "C:\path to TSE\sc32.exe"
:done
