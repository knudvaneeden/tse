#include ["projdialogs.si"]
#include ["projhistory.si"]
// PROJ0200 1.0.0.0.351 - OpenAI Codex (GPT-6)
// Buffer searches compile independently of the project manager.
string g_scopeExpression[255] = ""
string g_scopeFindOptions[24] = "ix"
proc PROJ_CenterList(integer width, integer maxHeight)
    integer boxWidth = Min(width + 2, Query(ScreenCols))
    integer boxHeight = Min(NumLines() + 4, Min(maxHeight, Query(ScreenRows) - 2))
    Set(X1, Max(1, (Query(ScreenCols) - boxWidth) / 2 + 1))
    Set(Y1, Max(1, (Query(ScreenRows) - boxHeight) / 2 + 1))
end

#include ["projsearchbridge.si"]

proc PROJ_SearchCurrentBuffer()
    integer originalBuffer = GetBufferId()
    integer resultBuffer = CreateTempBuffer()
    integer matches = 0
    string options[24] = ""
    string display[255]
    if not resultBuffer
        return()
    endif
    if not PROJ_ResultBegin()
        AbandonFile(resultBuffer)
        return()
    endif
    GotoBufferId(originalBuffer)
    display = CurrFilename()
    if not Length(display)
        display = "(unnamed current buffer)"
    endif
    if Pos("i", Lower(g_scopeFindOptions))
        options = options + "i"
    endif
    if Pos("x", Lower(g_scopeFindOptions))
        options = options + "x"
    endif
    Message("Searching: " + display)
    PushPosition()
    BegFile()
    if lFind(g_scopeExpression, options)
        repeat
            AddLine(Format(display, "(", CurrLine(), ",", CurrCol(), "): ", GetText(1, 255)), resultBuffer)
            PROJ_ResultRow(originalBuffer, CurrFilename(), CurrLine(), CurrCol())
            matches = matches + 1
        until not lRepeatFind()
    endif
    PopPosition()
    GotoBufferId(resultBuffer)
    AddLine(Format(matches, " matches in current buffer."))
    PROJ_ResultRow(0, "", 0, 0)
    GotoBufferId(originalBuffer)
    Message("Search complete: " + Str(matches) + " matches.")
    PROJ_ResultShow(resultBuffer)
end

proc PROJ_SearchRing()
    integer originalBuffer = GetBufferId()
    integer ringCount = NumFiles()
    integer resultBuffer
    integer files = 0
    integer matches = 0
    string display[255]
    string options[24] = ""
    if not PROJ_HistoryAsk("Search string in the TSE ring:", g_scopeExpression, "PROJ0200:projbuffersearch:PROJ_SearchRing:input1")
        return()
    endif
    if not Length(g_scopeExpression) or not PROJ_HistoryAsk("Search options: i=ignore case, x=TSE regex:", g_scopeFindOptions, "PROJ0200:projbuffersearch:PROJ_SearchRing:input2")
        return()
    endif
    if Pos("i", Lower(g_scopeFindOptions))
        options = options + "i"
    endif
    if Pos("x", Lower(g_scopeFindOptions))
        options = options + "x"
    endif
    resultBuffer = CreateTempBuffer()
    if not resultBuffer
        return()
    endif
    if not PROJ_ResultBegin()
        AbandonFile(resultBuffer)
        return()
    endif
    AddLine("Search: " + g_scopeExpression + " Options: " + options, resultBuffer)
    PROJ_ResultRow(0, "", 0, 0)
    GotoBufferId(originalBuffer)
    PushBlock()
    UnMarkBlock()
    do ringCount times
        if BufferType() == _NORMAL_
            display = CurrFilename()
            if not Length(display)
                display = "Unnamed buffer " + Str(GetBufferId())
            endif
            Message("Searching: " + display)
            files = files + 1
            PushPosition()
            BegFile()
            if lFind(g_scopeExpression, options)
                repeat
                    AddLine(Format(display, "(", CurrLine(), ",", CurrCol(), "): ", GetText(1, 255)), resultBuffer)
                    PROJ_ResultRow(GetBufferId(), CurrFilename(), CurrLine(), CurrCol())
                    matches = matches + 1
                until not lRepeatFind()
            endif
            PopPosition()
        endif
        NextFile(_DONT_LOAD_)
    enddo
    GotoBufferId(originalBuffer)
    PopBlock()
    AddLine(Format(matches, " matches in ", files, " open buffers."), resultBuffer)
    PROJ_ResultRow(0, "", 0, 0)
    GotoBufferId(originalBuffer)
    Message("Search complete: " + Str(matches) + " matches in " + Str(files) + " buffers.")
    PROJ_ResultShow(resultBuffer)
end


proc PROCProjectMainActions()
    if GetGlobalInt("PROJ_BufferSearchMode") == 1
        g_scopeExpression = GetGlobalStr("PROJ_BufferSearchExpression")
        g_scopeFindOptions = GetGlobalStr("PROJ_BufferSearchOptions")
        PROJ_SearchCurrentBuffer()
    else
        PROJ_SearchRing()
    endif
end

// PROJ0200 1.0.0.0.351 - OpenAI Codex (GPT-6)
// Set() returns the previous value; restore it after all actions return.
proc Main()
    integer IOldCommonDialogs = Set(UseCommonDialogs, FNProjectWindowsDialogs())
    PROCProjectMainActions()
    Set(UseCommonDialogs, IOldCommonDialogs)
end
