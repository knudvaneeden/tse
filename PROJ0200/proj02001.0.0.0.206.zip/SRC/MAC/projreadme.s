// PROJ0200 1.0.0.0.206 - OpenAI Codex (GPT-6)
// Open package documentation using the normal TSE editor.
proc Main()
    string document[255] = SplitPath(CurrMacroFilename(), _DRIVE_|_PATH_) + "proj0200_readme.md"
    if not FileExists(document)
        Warn("README help file could not be found: " + document)
        return()
    endif
    if not EditFile(QuotePath(document))
        Warn("README help file could not be opened: " + document)
    endif
end
