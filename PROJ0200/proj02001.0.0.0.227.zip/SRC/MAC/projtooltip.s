// PROJ0200 1.0.0.0.227 - OpenAI Codex (GPT-6)
// Resident hover worker; shares project state through ProjDLL.
#include ["projdll.si"]
integer proc PROJ_TipWhite(string value)
    return(value == Chr(32) or value == Chr(9))
end

string proc GetTagFilename()
    if Get_Int(iFProjectTags)
        if not Length(Get_Str(iTagFile))
            if Length(Get_Str(iTagsLocation))
                Set_Str(iTagFile, AddTrailingSlash(SplitPath(Get_Str(iTagsLocation), _DRIVE_|_NAME_)) + "tags")
            else
                Set_Str(iTagFile, SplitPath(Get_Str(iProjectFilename), _DRIVE_|_NAME_) + ".tag")
            endif
        endif
    else
        Set_Str(iTagFile, SplitPath(CurrFilename(), _DRIVE_|_PATH_) + "tags")
    endif
    return(Get_Str(iTagFile))
end

// MASTER FILE: ["proj.si"]
//#pragma inhouse,chrisant


#define MIN_WORD_LENGTH 2
#define MOUSE_WIN_COLOR Color(BLINK Black on Yellow)


integer mouse_x = 0
integer mouse_y = 0
integer g_fVisible = FALSE
integer g_nIdleBaseline = 0


dll "<user32.dll>"
	proc GetCursorPos(integer pPoint)
end


proc GetMousePos(var integer x, var integer y)
    string pt[8] = ""

    GetCursorPos(AdjPtr(Addr(pt), 2))
	x = PeekLong(AdjPtr(Addr(pt), 2+0))
	y = PeekLong(AdjPtr(Addr(pt), 2+4))
end


integer s_xMouse = 0
integer s_yMouse = 0
integer proc FMouseMoved()
    integer x
    integer y
    integer fMoved = FALSE

    GetMousePos(x, y)

    if x <> s_xMouse
        fMoved = TRUE
        s_xMouse = x
    endif
    if y <> s_yMouse
        fMoved = TRUE
        s_yMouse = y
    endif

    return (fMoved)
end


integer s_xMouseClear = 0
integer s_yMouseClear = 0
integer proc FMouseMovedSinceClear()
    integer x
    integer y
    integer fMoved = FALSE

    GetMousePos(x, y)

    if x <> s_xMouseClear
        fMoved = TRUE
        s_xMouseClear = x
    endif
    if y <> s_yMouseClear
        fMoved = TRUE
        s_yMouseClear = y
    endif

    return (fMoved)
end


string proc GetWordAtMouseCursor()
    string word[40] = ""
    string ws[32] = Set(WordSet, ChrSet("0-9A-Za-z_"))
    integer rtw = Set(RemoveTrailingWhite, OFF)
    integer wid

    wid = WindowId()
    GotoWindow(MouseWindowId())
    PushPosition()
    PushBlock()
    if GotoMouseCursor()
	    if MarkWord() or (Left() and MarkWord())
	        word = GetMarkedText()
	    endif
	endif
    PopBlock()
    PopPosition()
    GotoWindow(wid)
    Set(RemoveTrailingWhite, rtw)
    Set(WordSet, ws)
    return(word)
end


proc MessageBox(integer width, integer height, integer pos_x, integer pos_y, integer colattr)
    integer half_window

    // limit height
    half_window = Query(ScreenRows) - pos_y
    if pos_y > half_window
        half_window = pos_y
    endif
    half_window = half_window - 2

    if height > half_window
        height = half_window
    endif

    // calculate vertical window position
    if pos_y - height > 1
        pos_y = pos_y - height
    else
        pos_y = pos_y + 1
    endif

    // limit width
    if width > Query(ScreenCols) - 2
        width = Query(ScreenCols) - 2
    endif

    // calculate horizontal window position
    if pos_x + width + 2 >= Query(ScreenCols)
        pos_x = Query(ScreenCols) - 1 - width
    else
        pos_x = pos_x + 2
    endif

    //Message("Window at ", pos_x, ", ", pos_y, ", ", pos_x + width - 1, ", ", pos_y + height - 1)
    Window(pos_x, pos_y, pos_x + width - 1, pos_y + height - 1)
    Set(Attr, colattr)
    ClrScr() VGotoXY(1, 1)
end


proc ClearMouseWindow()
    if g_fVisible
        UpdateDisplay(_ALL_WINDOWS_REFRESH_)
        g_fVisible = FALSE

        GetMousePos(s_xMouseClear, s_yMouseClear)
    endif
end


proc Tooltip_AfterCommand()
    g_nIdleBaseline = 0
    ClearMouseWindow()
end


string proc GetTipText()
	string s1[255] = Trim(GetText(PosFirstNonWhite(), 255))
	string s2[255] = ""
	integer ii
	integer fWhite = FALSE

	for ii = 1 to Length(s1)
		if PROJ_TipWhite(s1[ii])
			if not fWhite
				fWhite = TRUE
				s2 = s2 + " "
			endif
		else
			fWhite = FALSE
			s2 = s2 + s1[ii]
		endif
	endfor

	if not Length(s2)
		s2 = "<unknown>"
	endif

	return (s2)
end


proc Tooltip_Idle()
    string stWord[64] = ""
	string stTitle[255]
	string s[255]
	string fn[_MAXPATH_]
	integer nLine
	string stTarget[255]
	integer iIndex = -1
	integer iLast
	integer cid = GetBufferId()
	integer idAbandon = 0
	integer ml = Set(MsgLevel, _NONE_)
	integer rtw = Set(RemoveTrailingWhite, OFF)

	integer iTypeClass = -1
	integer iTypeDefine = -1
	integer iTypeEnumValue = -1
	integer iTypeFunction = -1
	integer iTypeEnum = -1
	integer iTypeMember = -1
	integer iTypePrototype = -1
	integer iTypeStruct = -1
	integer iTypeTypedef = -1
	integer iTypeUnion = -1
	integer iTypeVariable = -1

	PushBlock()

    if Query(MouseEnabled)
        if FMouseMoved()
            // mouse moved, so clear message box and restore display
            ClearMouseWindow()
            g_nIdleBaseline = Query(IdleTime)
        elseif not g_fVisible
            //message(Query(IdleTime), ", ", g_nIdleBaseline)
            if Query(IdleTime) - g_nIdleBaseline > 50 and FMouseMovedSinceClear()
                // mouse has stopped, display message box
                MouseStatus()
                mouse_x = Query(MouseX)
                mouse_y = Query(MouseY)
                stWord = GetWordAtMouseCursor()
                if Length(stWord) >= MIN_WORD_LENGTH
					// make sure tags file is loaded
					stTitle = Get_Str(iProjectTitle)
					if stTitle == ""
						stTitle = SqueezePath(SplitPath(GetTagFilename(), _DRIVE_|_PATH_), 48)
					endif
					if Tags_Load(GetTagFilename(), FALSE) < 0
						goto Out
					endif

					// find tag
					iIndex = Tags_Lookup(stWord, 0, lookFirst|lookExact)
					if iIndex == -1
						goto Out
					endif
					iLast = Tags_Lookup(stWord, 0, lookLast|lookExact)
					if iLast > iIndex
						while iLast >= iIndex
							case Tags_GetType(iLast)
								when symClass		iTypeClass = iLast
								when symDefine		iTypeDefine = iLast
								when symEnumValue	iTypeEnumValue = iLast
								when symFunction	iTypeFunction = iLast
								when symEnum		iTypeEnum = iLast
								when symMember		iTypeMember = iLast
								when symPrototype	iTypePrototype = iLast
								when symStruct		iTypeStruct = iLast
								when symTypedef		iTypeTypedef = iLast
								when symUnion		iTypeUnion = iLast
								when symVariable	iTypeVariable = iLast
							endcase
							iLast = iLast - 1
						endwhile
						if iTypeFunction >= 0
							iIndex = iTypeFunction
						elseif iTypeMember >= 0
							iIndex = iTypeMember
						elseif iTypeVariable >= 0
							iIndex = iTypeVariable
						elseif iTypePrototype >= 0
							iIndex = iTypePrototype
						endif
					endif

					// get filename and target
					fn = Tags_GetFilename(iIndex)
					nLine = Tags_GetLine(iIndex)
					stTarget = Tags_GetSearchLine(iIndex)
					if not Pos(":", fn) and SubStr(fn, 1, 2) <> "\\"
						fn = AddTrailingSlash(SplitPath(GetTagFilename(), _DRIVE_|_PATH_))+fn
					endif

					// load file
					cid = GetBufferId()
					idAbandon = GetBufferId(fn)
					if idAbandon
						GotoBufferId(idAbandon)
						idAbandon = 0
					else
						idAbandon = CreateTempBuffer()
						if not idAbandon
							goto Out
						endif
						if not InsertFile(fn, _DONT_PROMPT_) or not NumLines()
							goto Out
						endif
					endif

					// find target
					PushPosition()
					BegFile()
					if nLine or lFind(stTarget, iif(Tags_FAnchorToEnd(iIndex), "^$", "^"))
						if nLine
							GotoLine(nLine)
						endif
						if lFind(stWord, "c")
							g_fVisible = TRUE
							//$ todo: parse out the real thing
							s = GetTipText()
							MessageBox(Length(s), 1, mouse_x, mouse_y, MOUSE_WIN_COLOR)
							PutStr(s)
							FullWindow()
//delay(4)
						endif
					endif
					PopPosition()
                endif
            endif
        endif
    endif

	if iTypeClass or iTypeDefine or iTypeEnumValue or iTypeEnum or
			iTypeStruct or iTypeTypedef or iTypeUnion
		// this avoids compiler warnings
	endif

Out:
	GotoBufferId(cid)
	AbandonFile(idAbandon)
	PopBlock()
	Set(RemoveTrailingWhite, rtw)
	Set(MsgLevel, ml)
end



proc WhenPurged()
    UnHook(Tooltip_Idle)
    UnHook(Tooltip_AfterCommand)
    ClearMouseWindow()
end

proc Main()
    UnHook(Tooltip_Idle)
    UnHook(Tooltip_AfterCommand)
    Hook(_IDLE_, Tooltip_Idle)
    Hook(_AFTER_COMMAND_, Tooltip_AfterCommand)
end
