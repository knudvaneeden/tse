section .text
global _start
greet:
    ret
_start:
    call greet
