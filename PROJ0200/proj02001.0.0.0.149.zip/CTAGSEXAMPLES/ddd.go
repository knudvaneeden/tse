// PROJ0200 CTags sample for Go.
package main

import "fmt"

func makeGreeting() string {
    return "Hello from Go"
}

func main() {
    fmt.Println(makeGreeting()) // F11 on makeGreeting.
}
