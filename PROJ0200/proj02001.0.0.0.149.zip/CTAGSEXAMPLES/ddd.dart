String greet() { return "Hello"; }
void main() { print(greet()); }
