module ddd;
  task greet; begin $display("Hello"); end endtask
  initial greet;
endmodule
