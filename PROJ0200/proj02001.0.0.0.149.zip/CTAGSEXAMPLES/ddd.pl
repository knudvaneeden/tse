use strict; use warnings;
sub greet { return "Hello"; }
print greet(), "\n";
