program ddd
  call greet()
contains
  subroutine greet()
    print *, "Hello"
  end subroutine greet
end program ddd
