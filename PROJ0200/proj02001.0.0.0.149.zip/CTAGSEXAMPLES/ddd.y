%token GREET
%%
start: greet ;
greet: GREET ;
%%
