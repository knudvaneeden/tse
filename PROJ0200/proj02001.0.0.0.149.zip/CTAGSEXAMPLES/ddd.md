# MarkdownExample

A Markdown document for PROJ0200 CTags navigation.

## Greet

Hello from Markdown.

## Usage

Put the cursor on Greet in the following line and press F12:

See Greet for the greeting above.

CTags should jump to the Greet heading.
