with Ada.Text_IO;
procedure Ddd is
   procedure Greet is
   begin
      Ada.Text_IO.Put_Line("Hello");
   end Greet;
begin
   Greet;
end Ddd;
