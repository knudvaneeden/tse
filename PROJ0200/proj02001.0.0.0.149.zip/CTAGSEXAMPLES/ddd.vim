" PROJ0200 VimScript CTags example.
function! Greet()
    echo 'Hello from VimScript'
endfunction

call Greet() " Put the cursor on Greet and press F12 in TSE.
