(defun greet () (format t "Hello~%"))
(greet)
