fun greet () = "Hello";
print (greet () ^ "\n");
