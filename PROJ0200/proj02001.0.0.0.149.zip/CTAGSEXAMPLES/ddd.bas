FUNCTION Greet$ ()
    Greet$ = "Hello"
END FUNCTION
PRINT Greet$()
