function greet():String { return "Hello"; }
trace(greet());
