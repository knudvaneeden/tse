using System;
class Ddd { static void Greet() { Console.WriteLine("Hello"); }
static void Main() { Greet(); } }
