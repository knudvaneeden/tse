greet :- write(hello), nl.
:- initialization(greet).
