// PROJ0200 CTags sample for TypeScript.
function formatName(name: string): string {
    return `Hello, ${name}`;
}

console.log(formatName("TypeScript")); // F11 on formatName.
