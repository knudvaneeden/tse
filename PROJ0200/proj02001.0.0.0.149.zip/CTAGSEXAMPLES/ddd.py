"""PROJ0200 CTags sample for Python."""

def greet():
    return "Hello from Python"


def main():
    print(greet())  # Put the cursor on greet and press F11.


if __name__ == "__main__":
    main()
