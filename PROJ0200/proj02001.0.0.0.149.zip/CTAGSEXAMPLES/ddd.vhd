entity ddd is end ddd;
architecture demo of ddd is
  procedure greet is begin report "Hello"; end procedure;
begin
  process begin greet; wait; end process;
end demo;
