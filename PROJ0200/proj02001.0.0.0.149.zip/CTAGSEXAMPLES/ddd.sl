define greet ()
{
    return "Hello from S-Lang";
}

vmessage ("%s", greet ()); % Put the cursor on greet here and press F12.
