       IDENTIFICATION DIVISION.
       PROGRAM-ID. DDD.
       PROCEDURE DIVISION.
           PERFORM GREET
           STOP RUN.
       GREET.
           DISPLAY "Hello".
