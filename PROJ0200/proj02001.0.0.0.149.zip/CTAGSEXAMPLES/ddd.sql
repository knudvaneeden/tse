-- MySQL greeting example. Safe to run repeatedly.
CREATE DATABASE IF NOT EXISTS tse_examples;
USE tse_examples;

CREATE TEMPORARY TABLE greeting (message VARCHAR(40));
INSERT INTO greeting (message) VALUES ('Hello');
SELECT message FROM greeting;
