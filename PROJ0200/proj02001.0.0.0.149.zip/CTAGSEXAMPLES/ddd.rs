// PROJ0200 CTags sample for Rust.
fn greet() -> &'static str {
    "Hello from Rust"
}

fn main() {
    println!("{}", greet()); // Put the cursor on greet and press F11.
}
