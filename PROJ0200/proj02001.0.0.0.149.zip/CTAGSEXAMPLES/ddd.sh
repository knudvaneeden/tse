#!/bin/sh
greet() { printf "Hello\n"; }
greet
