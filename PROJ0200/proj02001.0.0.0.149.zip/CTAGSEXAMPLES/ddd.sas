%macro greet;
%put Hello;
%mend greet;
%greet;
