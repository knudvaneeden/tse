GREETING = Hello from Make

all:
	@echo $(GREETING)
