greet <- function() { "Hello" }
print(greet())
