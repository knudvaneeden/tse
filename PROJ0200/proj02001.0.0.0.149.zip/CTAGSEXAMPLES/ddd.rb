def greet
  "Hello"
end
puts greet
