@echo off
call :greet
goto :eof
:greet
echo Hello
goto :eof
