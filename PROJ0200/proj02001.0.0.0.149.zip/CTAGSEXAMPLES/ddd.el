;;; PROJ0200 Emacs Lisp CTags example.
(defun emacs-greet ()
  (message "Hello from Emacs Lisp"))

(emacs-greet) ; Put the cursor on emacs-greet and press F12 in TSE.
