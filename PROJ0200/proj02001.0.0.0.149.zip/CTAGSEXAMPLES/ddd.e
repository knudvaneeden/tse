class DDD
create make
feature
    make do greet end
    greet do print ("Hello%N") end
end
