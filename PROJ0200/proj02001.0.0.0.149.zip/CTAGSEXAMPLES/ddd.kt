fun greet(): String { return "Hello" }
fun main() { println(greet()) }
