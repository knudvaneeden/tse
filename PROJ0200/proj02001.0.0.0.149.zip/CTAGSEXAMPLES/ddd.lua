local function greet() return "Hello" end
print(greet())
