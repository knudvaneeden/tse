(define (greet) "Hello")
(display (greet))
(newline)
