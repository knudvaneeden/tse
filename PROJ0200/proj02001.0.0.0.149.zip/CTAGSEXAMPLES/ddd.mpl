greet := proc()
    "Hello";
end proc:
greet();
