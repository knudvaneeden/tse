greet :: String
greet = "Hello"
main = putStrLn greet
