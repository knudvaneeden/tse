function greet() { return "Hello" }
BEGIN { print greet() }
