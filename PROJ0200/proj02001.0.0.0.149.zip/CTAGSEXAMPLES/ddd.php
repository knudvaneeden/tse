<?php
function greet() { return "Hello"; }
echo greet(), "\n";
