// PROJ0200 CTags sample for TSE SAL.
PROC FooBar()
    Warn("Hello from TSE SAL")
END

PROC Main()
    FooBar() // Put the cursor on FooBar and press F12.
END
