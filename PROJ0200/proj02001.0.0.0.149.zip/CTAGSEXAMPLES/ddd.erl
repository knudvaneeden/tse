-module(ddd).
-export([greet/0, main/0]).
greet() -> "Hello".
main() -> io:format("~s~n", [greet()]).
