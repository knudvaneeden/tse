function ddd()
    disp(greet());
end
function result = greet()
    result = "Hello";
end
