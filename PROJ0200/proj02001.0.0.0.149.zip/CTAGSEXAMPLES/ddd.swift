func greet() -> String { return "Hello" }
print(greet())
