proc greet {} { return "Hello" }
puts [greet]
