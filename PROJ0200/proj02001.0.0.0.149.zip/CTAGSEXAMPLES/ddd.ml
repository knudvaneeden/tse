let greet () = "Hello"
let () = print_endline (greet ())
