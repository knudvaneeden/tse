#include <iostream>
void greet() { std::cout << "Hello\n"; }
int main() { greet(); }
