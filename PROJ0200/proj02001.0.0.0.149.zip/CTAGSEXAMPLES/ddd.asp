<% Sub Greet()
Response.Write("Hello")
End Sub
Greet() %>
