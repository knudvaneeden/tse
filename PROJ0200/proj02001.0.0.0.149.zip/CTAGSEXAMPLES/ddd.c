#include <stdio.h>

static void draw_menu(void)
{
    puts("1. Open project");
    puts("2. Exit");
}

int main(void)
{
    draw_menu(); /* Put the cursor on draw_menu and press F11 in TSE. */
    return 0;
}
