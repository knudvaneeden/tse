program Ddd;
procedure Greet; begin Writeln('Hello'); end;
begin Greet; end.
