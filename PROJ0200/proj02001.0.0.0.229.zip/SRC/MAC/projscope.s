// PROJ0200 1.0.0.0.229 - OpenAI Codex (GPT-6)
// Separate scoped search/reload implementation avoids the main macro size limit.
#include ["projhistory.si"]
string g_scopeExpression[255] = ""
string g_scopeFindOptions[24] = "ix"
string proc GetInstallationDir()
    return(AddTrailingSlash(SplitPath(CurrMacroFilename(), _DRIVE_|_PATH_)))
end
proc PROJ_CenterList(integer width, integer maxHeight)
    integer boxWidth = Min(width + 2, Query(ScreenCols))
    integer boxHeight = Min(NumLines() + 4, Min(maxHeight, Query(ScreenRows) - 2))
    Set(X1, Max(1, (Query(ScreenCols) - boxWidth) / 2 + 1))
    Set(Y1, Max(1, (Query(ScreenRows) - boxHeight) / 2 + 1))
end
integer proc PROJ_CreateScopeRequest(integer scope)
    integer requestBuffer = 0
    if scope == GetGlobalInt("PROJ_ScopeWorkerScope")
        requestBuffer = GetGlobalInt("PROJ_ScopeWorkerRequest")
        SetGlobalInt("PROJ_ScopeWorkerRequest", 0)
    endif
    return(requestBuffer)
end

integer proc PROJ_RunScopeHelper(integer requestBuffer, integer listOnly)
    integer originalBuffer = GetBufferId()
    integer batchBuffer = CreateTempBuffer()
    integer succeeded = FALSE
    integer manifestBuffer = 0
    string root[255] = GetInstallationDir()
    string requestFile[255] = root + "proj0200_scope_request.txt"
    string manifestFile[255] = root + "proj0200_scope_manifest.txt"
    string batchFile[255] = root + "proj0200_scope_run.bat"
    string switches[20] = ""
    if not batchBuffer
        return(0)
    endif
    if listOnly
        switches = " -ListOnly"
    endif
    if FileExists(manifestFile)
        EraseDiskFile(manifestFile)
    endif
    GotoBufferId(requestBuffer)
    if SaveAs(requestFile, _DONT_PROMPT_|_OVERWRITE_)
        GotoBufferId(batchBuffer)
        AddLine("@echo off")
        // Split PowerShell invocation across batch lines to avoid SAL's 255 limit.
        AddLine('powershell.exe -NoP -NonI -W Hidden -ExecutionPolicy Bypass ^')
        AddLine(' -File "' + root + 'proj0200_archive_helper.ps1" ^')
        AddLine(' -Request "' + requestFile + '" ^')
        AddLine(' -Manifest "' + manifestFile + '"' + switches)
        if SaveAs(batchFile, _DONT_PROMPT_|_OVERWRITE_)
            Dos('cmd.exe /d /c ""' + batchFile + '""', _DONT_PROMPT_)
            succeeded = FileExists(manifestFile)
        endif
    endif
    AbandonFile(batchBuffer)
    GotoBufferId(originalBuffer)
    if succeeded
        manifestBuffer = EditBuffer(manifestFile, _SYSTEM_)
    else
        Warn("Cannot create the scope manifest. Check PowerShell and the package helper.")
    endif
    return(manifestBuffer)
end

proc PROJ_CleanupScope()
    integer originalBuffer = GetBufferId()
    integer batchBuffer = CreateTempBuffer()
    string root[255] = GetInstallationDir()
    string filename[255] = root + "proj0200_scope_cleanup.bat"
    if batchBuffer
        AddLine("@echo off")
        AddLine('powershell.exe -NoP -NonI -W Hidden -ExecutionPolicy Bypass ^')
        AddLine(' -File "' + root + 'proj0200_archive_helper.ps1" ^')
        AddLine(' -Manifest "' + root + 'proj0200_scope_manifest.txt" -Cleanup')
        if SaveAs(filename, _DONT_PROMPT_|_OVERWRITE_)
            Dos('cmd.exe /d /c ""' + filename + '""', _DONT_PROMPT_)
        endif
        AbandonFile(batchBuffer)
    endif
    GotoBufferId(originalBuffer)
end

proc PROJ_RunBufferSearch(integer mode)
    string worker[255] = GetInstallationDir() + "projbuffersearch.mac"
    if not FileExists(worker)
        Warn("Buffer search worker missing: rebuild with build.bat.")
        return()
    endif
    SetGlobalInt("PROJ_BufferSearchMode", mode)
    SetGlobalStr("PROJ_BufferSearchExpression", g_scopeExpression)
    SetGlobalStr("PROJ_BufferSearchOptions", g_scopeFindOptions)
    ExecMacro(QuotePath(worker))
    DelGlobalVar("PROJ_BufferSearchMode")
    DelGlobalVar("PROJ_BufferSearchExpression")
    DelGlobalVar("PROJ_BufferSearchOptions")
end
proc PROJ_SearchCurrentBuffer()
    PROJ_RunBufferSearch(1)
end
proc PROJ_SearchRing()
    PROJ_RunBufferSearch(2)
end

proc PROJ_SearchScope(integer scope)
    integer originalBuffer = GetBufferId()
    integer requestBuffer
    integer manifestBuffer
    integer resultBuffer
    integer sourceBuffer
    integer sourceWasOpen
    integer lineIndex
    integer manifestLines
    integer matches = 0
    integer files = 0
    string record[255]
    string disk[255]
    string display[255]
    string options[24] = ""
    string extension[20] = Lower(SplitPath(CurrFilename(), _EXT_))
    if not PROJ_HistoryAsk("Search string (TSE regular expressions supported):", g_scopeExpression, "PROJ0200:scopeops:PROJ_SearchScope:input1")
        return()
    endif
    if not Length(g_scopeExpression) or not PROJ_HistoryAsk("Search options: i=ignore case, x=TSE regex:", g_scopeFindOptions, "PROJ0200:scopeops:PROJ_SearchScope:input2")
        return()
    endif
    if scope == 1 and BufferType() == _NORMAL_ and
       extension <> ".zip" and extension <> ".jar" and extension <> ".tar" and
       extension <> ".tgz" and extension <> ".gz" and extension <> ".gzip" and
       extension <> ".7z" and extension <> ".rar" and extension <> ".bz2" and extension <> ".xz"
        PROJ_SearchCurrentBuffer()
        return()
    endif
    // Restrict find flags to avoid accidental global/block-only/backwards search.
    if Pos("i", Lower(g_scopeFindOptions))
        options = options + "i"
    endif
    if Pos("x", Lower(g_scopeFindOptions))
        options = options + "x"
    endif
    requestBuffer = PROJ_CreateScopeRequest(scope)
    if not requestBuffer
        return()
    endif
    manifestBuffer = PROJ_RunScopeHelper(requestBuffer, FALSE)
    AbandonFile(requestBuffer)
    if not manifestBuffer
        GotoBufferId(originalBuffer)
        return()
    endif
    resultBuffer = CreateTempBuffer()
    if not resultBuffer
        AbandonFile(manifestBuffer)
        PROJ_CleanupScope()
        return()
    endif
    AddLine("Search: " + g_scopeExpression, resultBuffer)
    GotoBufferId(manifestBuffer)
    manifestLines = NumLines()
    for lineIndex = 1 to manifestLines
        GotoBufferId(manifestBuffer)
        GotoLine(lineIndex)
        record = GetText(1, 255)
        if SubStr(record, 1, 1) == "F"
            disk = SubStr(record, 2, 255)
            GotoLine(lineIndex + 1)
            display = SubStr(GetText(1, 255), 2, 255)
            sourceBuffer = GetBufferId(disk)
            sourceWasOpen = sourceBuffer <> 0
            if not sourceBuffer and FileExists(disk)
                sourceBuffer = EditBuffer(disk, _SYSTEM_)
            endif
            if sourceBuffer
                GotoBufferId(sourceBuffer)
                PushPosition()
                BegFile()
                files = files + 1
                if lFind(g_scopeExpression, options)
                    repeat
                        AddLine(Format(display, "(", CurrLine(), ",", CurrCol(), "): ", GetText(1, 255)), resultBuffer)
                        matches = matches + 1
                    until not lRepeatFind()
                endif
                PopPosition()
                if not sourceWasOpen
                    AbandonFile(sourceBuffer)
                endif
            else
                AddLine("Could not read: " + display, resultBuffer)
            endif
        elseif SubStr(record, 1, 7) == "#ERROR="
            AddLine(record, resultBuffer)
        endif
    endfor
    AbandonFile(manifestBuffer)
    GotoBufferId(resultBuffer)
    AddLine(Format(matches, " matches in ", files, " files examined."))
    BegFile()
    PROJ_CenterList(100, Query(ScreenRows))
    lList("Scoped search results - archives use ::member notation", 100, Query(ScreenRows), _ENABLE_HSCROLL_)
    AbandonFile(resultBuffer)
    GotoBufferId(originalBuffer)
    PROJ_CleanupScope()
end

proc PROJ_RefreshScope(integer scope, integer asking)
    integer originalBuffer = GetBufferId()
    integer originalLine = CurrLine()
    integer originalColumn = CurrCol()
    integer requestBuffer = PROJ_CreateScopeRequest(scope)
    integer manifestBuffer
    integer manifestLines
    integer lineIndex
    integer bufferId
    integer stageBuffer
    integer approved
    integer unsavedFound = FALSE
    integer refreshed = 0
    integer skipped = 0
    integer failed = 0
    string record[255]
    string filename[255]
    if not requestBuffer
        return()
    endif
    manifestBuffer = PROJ_RunScopeHelper(requestBuffer, TRUE)
    AbandonFile(requestBuffer)
    if not manifestBuffer
        GotoBufferId(originalBuffer)
        return()
    endif
    GotoBufferId(manifestBuffer)
    manifestLines = NumLines()
    // Confirm once before the first change when unsaved buffers are in scope.
    if not asking
        for lineIndex = 1 to manifestLines
            GotoBufferId(manifestBuffer)
            GotoLine(lineIndex)
            record = GetText(1, 255)
            if SubStr(record, 1, 1) == "F"
                filename = SubStr(record, 2, 255)
                bufferId = GetBufferId(filename)
                if bufferId
                    GotoBufferId(bufferId)
                    if BufferType() == _NORMAL_ and FileChanged()
                        unsavedFound = TRUE
                        break
                    endif
                endif
            endif
        endfor
        if unsavedFound
            if YesNo("Refresh will overwrite unsaved edits with disk contents. Continue without individual questions?") <> 1
                AbandonFile(manifestBuffer)
                GotoBufferId(originalBuffer)
                PROJ_CleanupScope()
                return()
            endif
        endif
    endif
    PushBlock()
    for lineIndex = 1 to manifestLines
        GotoBufferId(manifestBuffer)
        GotoLine(lineIndex)
        record = GetText(1, 255)
        if SubStr(record, 1, 1) == "F"
            filename = SubStr(record, 2, 255)
            bufferId = GetBufferId(filename)
            if bufferId
                GotoBufferId(bufferId)
                if BufferType() == _NORMAL_
                    approved = TRUE
                    if asking
                        approved = YesNo("Reload from disk (unsaved edits will be lost): " + filename) == 1
                    endif
                    if approved
                        // Stage a complete read before touching the original buffer.
                        stageBuffer = CreateTempBuffer()
                        if stageBuffer
                            if InsertFile(filename, _DONT_PROMPT_)
                                UnMarkBlock()
                                if NumLines()
                                    MarkLine(1, NumLines())
                                endif
                                GotoBufferId(bufferId)
                                EmptyBuffer()
                                if IsBlockMarked()
                                    CopyBlock()
                                endif
                                UnMarkBlock()
                                FileChanged(FALSE)
                                refreshed = refreshed + 1
                            else
                                failed = failed + 1
                            endif
                            AbandonFile(stageBuffer)
                        else
                            failed = failed + 1
                        endif
                    else
                        skipped = skipped + 1
                    endif
                endif
            endif
        elseif SubStr(record, 1, 7) == "#ERROR="
            failed = failed + 1
        endif
    endfor
    PopBlock()
    AbandonFile(manifestBuffer)
    GotoBufferId(originalBuffer)
    GotoLine(originalLine)
    GotoColumn(originalColumn)
    PROJ_CleanupScope()
    Warn(Format(refreshed, " files refreshed, ", skipped, " declined, ", failed, " failed. Closed files stayed closed; project membership is unchanged."))
end

proc Main()
    integer originalBuffer = GetBufferId()
    integer requestBuffer
    integer mode = GetGlobalInt("PROJ_ScopeWorkerMode")
    case mode
        when 1 PROJ_SearchScope(GetGlobalInt("PROJ_ScopeWorkerScope"))
        when 2 PROJ_RefreshScope(GetGlobalInt("PROJ_ScopeWorkerScope"), GetGlobalInt("PROJ_ScopeWorkerAsking"))
        when 3 PROJ_SearchRing()
    endcase
    // Cancelled prompts and ordinary-buffer searches may not consume the request.
    requestBuffer = GetGlobalInt("PROJ_ScopeWorkerRequest")
    if requestBuffer
        SetGlobalInt("PROJ_ScopeWorkerRequest", 0)
        AbandonFile(requestBuffer)
    endif
    GotoBufferId(originalBuffer)
end
