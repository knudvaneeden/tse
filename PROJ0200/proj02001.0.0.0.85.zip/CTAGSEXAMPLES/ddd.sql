CREATE TABLE greeting (message VARCHAR(40));
INSERT INTO greeting (message) VALUES ('Hello');
SELECT message FROM greeting;
