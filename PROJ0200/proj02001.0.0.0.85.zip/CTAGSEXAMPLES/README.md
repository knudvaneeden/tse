# PROJ0200 CTags example inventory

These are test sources. Earlier F12 checks confirmed six languages with prior test files; these packaged examples still need individual verification. Add one file to a test project, regenerate CTags, put the cursor on the listed symbol at its use, and press F12. Some formats (HTML, Ant, Make, SQL) index a declaration or target rather than a function. The supplied Exuberant CTags 5.8 executable and regex configuration determine actual support. All examples are in `CTAGSEXAMPLES`. `ddd.s` and `ddd.si` test the two SAL extensions. Do not add both same-language variants to a project unless testing duplicate tags.

| Language | File | Symbol | Status |
|---|---|---|---|
| ActionScript | `CTAGSEXAMPLES/ddd.as` | `greet` | Custom regex parser; pending TSE test |
| Ada | `CTAGSEXAMPLES/ddd.adb` | `Greet` | Custom regex parser; pending TSE test |
| Ant | `CTAGSEXAMPLES/ddd.build.xml` | `AntGreeting` | Verified in TSE |
| Assembly | `CTAGSEXAMPLES/ddd.asm` | `greet` | Pending TSE test |
| ASP | `CTAGSEXAMPLES/ddd.asp` | `Greet` | Pending TSE test |
| AWK | `CTAGSEXAMPLES/ddd.awk` | `greet` | Pending TSE test |
| Basic | `CTAGSEXAMPLES/ddd.bas` | `Greet` | Pending TSE test |
| BETA | `CTAGSEXAMPLES/ddd.bet` | `greet` | Verified by user |
| C | `CTAGSEXAMPLES/ddd.c` | `draw_menu` | Language previously tested; packaged sample pending |
| C++ | `CTAGSEXAMPLES/ddd.cpp` | `greet` | Pending TSE test |
| C# | `CTAGSEXAMPLES/ddd.cs` | `Greet` | Pending TSE test |
| Cobol | `CTAGSEXAMPLES/ddd.cob` | `GREET` | Pending TSE test |
| DosBatch | `CTAGSEXAMPLES/ddd.bat` | `greet` | Pending TSE test |
| Eiffel | `CTAGSEXAMPLES/ddd.e` | `greet` | Pending TSE test |
| Erlang | `CTAGSEXAMPLES/ddd.erl` | `greet` | Pending TSE test |
| Flex (MXML) | `CTAGSEXAMPLES/ddd.mxml` | `greet` | Pending TSE test |
| Fortran | `CTAGSEXAMPLES/ddd.f90` | `greet` | Pending TSE test |
| HTML | `CTAGSEXAMPLES/ddd.html` | `HtmlGreeting` | Named anchor sample; pending TSE test |
| Java | `CTAGSEXAMPLES/ddd.java` | `greet` | Verified in TSE |
| JavaScript | `CTAGSEXAMPLES/ddd.js` | `greet` | Pending TSE test |
| Lisp | `CTAGSEXAMPLES/ddd.lisp` | `greet` | Pending TSE test |
| Lua | `CTAGSEXAMPLES/ddd.lua` | `greet` | Pending TSE test |
| Make | `CTAGSEXAMPLES/ddd.mak` | `GREETING` | F12 verified on Windows CTags 5.8 |
| MatLab | `CTAGSEXAMPLES/ddd.m` | `greet` | Pending TSE test |
| OCaml | `CTAGSEXAMPLES/ddd.ml` | `greet` | Pending TSE test |
| Pascal | `CTAGSEXAMPLES/ddd.pas` | `Greet` | Pending TSE test |
| Perl | `CTAGSEXAMPLES/ddd.pl` | `greet` | Pending TSE test |
| PHP | `CTAGSEXAMPLES/ddd.php` | `greet` | Pending TSE test |
| Python | `CTAGSEXAMPLES/ddd.py` | `greet` | Language previously tested; packaged sample pending |
| REXX | `CTAGSEXAMPLES/ddd.rx` | `greet` | Pending TSE test |
| Ruby | `CTAGSEXAMPLES/ddd.rb` | `greet` | Pending TSE test |
| Scheme | `CTAGSEXAMPLES/ddd.scm` | `greet` | Pending TSE test |
| Sh | `CTAGSEXAMPLES/ddd.sh` | `greet` | Pending TSE test |
| SLang | `CTAGSEXAMPLES/ddd.sl` | `greet` | Verified in TSE |
| SML | `CTAGSEXAMPLES/ddd.sml` | `greet` | Pending TSE test |
| SQL | `CTAGSEXAMPLES/ddd.sql` | `greeting` | Pending TSE test |
| Tcl | `CTAGSEXAMPLES/ddd.tcl` | `greet` | Pending TSE test |
| Tex | `CTAGSEXAMPLES/ddd.tex` | `TexGreeting` | F12 verified on Windows CTags 5.8 |
| Vera | `CTAGSEXAMPLES/ddd.vr` | `greet` | Pending TSE test |
| Verilog | `CTAGSEXAMPLES/ddd.v` | `greet` | Pending TSE test |
| VHDL | `CTAGSEXAMPLES/ddd.vhd` | `greet` | Pending TSE test |
| TSE SAL | `CTAGSEXAMPLES/ddd.si` | `Greet` | Language previously tested; packaged sample pending |
| Rust | `CTAGSEXAMPLES/ddd.rs` | `greet` | Language previously tested; packaged sample pending |
| TypeScript | `CTAGSEXAMPLES/ddd.ts` | `formatName` | Language previously tested; packaged sample pending |
| Go | `CTAGSEXAMPLES/ddd.go` | `makeGreeting` | Language previously tested; packaged sample pending |
| Dart | `CTAGSEXAMPLES/ddd.dart` | `greet` | Pending TSE test |
| Haskell | `CTAGSEXAMPLES/ddd.hs` | `greet` | Pending TSE test |
| Maple | `CTAGSEXAMPLES/ddd.mpl` | `greet` | Pending TSE test |
| R | `CTAGSEXAMPLES/ddd.r` | `greet` | Pending TSE test |
| Mathematica | `CTAGSEXAMPLES/ddd.wl` | `greet` | Pending TSE test |
| Swift | `CTAGSEXAMPLES/ddd.swift` | `greet` | Pending TSE test |
| SAS | `CTAGSEXAMPLES/ddd.sas` | `greet` | Pending TSE test |
| Kotlin | `CTAGSEXAMPLES/ddd.kt` | `greet` | Pending TSE test |
| Prolog | `CTAGSEXAMPLES/ddd.pro` | `greet` | Pending TSE test |
| PowerShell | `CTAGSEXAMPLES/ddd.ps1` | `Greet` | Pending TSE test |
| Scala | `CTAGSEXAMPLES/ddd.scala` | `greet` | Pending TSE test |
| ABAP | `CTAGSEXAMPLES/ddd.abap` | `greet` | Pending TSE test |
| Vim | `CTAGSEXAMPLES/ddd.vim` | `Greet` | Pending TSE test |
| YACC | `CTAGSEXAMPLES/ddd.y` | `greet` | Pending TSE test |

BETA (`ddd.bet`): ordinary pattern tags are enabled by the package configuration. Test F12 on `greet` at line 6; expected definition is line 4. Windows test pending.

Ant: F12 on `AntGreeting` in the dependency at line 5 should jump to the target at line 2. Regenerate tags first; Windows test pending.
