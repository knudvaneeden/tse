function! Greet()
    echo 'Hello'
endfunction
call Greet()
