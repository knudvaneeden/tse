# GREPZIPTSE test archives — version 1.0.0.0.42

All original ZIP regression archives are relocated here **byte-for-byte unchanged**.
The JAR/7z/TAR/TGZ/TAR.GZ fixtures from version 41 are also unchanged.

`r.rar` is a genuine RAR 2.0 archive with these files:

- `docs/match.txt` contains `foobar` and a newline; expect one matching line with the default search string.
- `docs/other.txt` contains `no match in this line` and a newline; expect zero matches.

Note: The RAR sample is comparable by search expression, but its file contents are not necessarily byte-for-byte identical to the longer non-RAR fixture files. The RAR file was checked using the `rarfile` parser; full extraction in GREPZIPTSE requires the configured WinRAR/7-Zip executable.

Use search string `foobar` and options `ix` as in `grepziptse.ini`. The ZIP regressions have their own expected counts; do not assume every archive produces exactly one hit.
