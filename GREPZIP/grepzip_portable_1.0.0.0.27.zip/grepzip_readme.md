# GREPZIP

**Version:** 1.0.0.0.27  
**Date:** 2026-11-08  
**Authoring model:** OpenAI Codex

GREPZIP is a portable TSE Pro SAL macro for recursively searching file contents with a **TSE SAL regular expression**. It accepts one or more directories, files, or file specifications and also searches files stored in ZIP, JAR, TAR, TGZ, 7Z and RAR archives. Supported archives stored inside other supported archives are expanded and searched recursively.

## Package contents

- `grepzip.s` - TSE SAL source.
- `grepzip_helper.ps1` - portable Windows file and archive enumerator.
- `grepzip.ini` - configurable archive-tool paths and initial search values.
- `build.bat` - SAL build command.
- `grepzip_readme.md` - this documentation.

No Borland C++ DLL is required. ZIP and JAR support uses Windows PowerShell and the built-in .NET ZIP classes. TAR and TGZ support uses Windows `tar.exe`. RAR support uses configured `rar.exe`, with `7z.exe` as a fallback. 7Z support uses `7z.exe`. All text matching remains in TSE's own search engine.

## Requirements

- TSE Pro 4.50 for Windows.
- The `sc32` SAL compiler.
- Windows PowerShell 5.1 or another Windows PowerShell version providing `System.IO.Compression`.
- Windows `tar.exe` for TAR, TGZ and TAR.GZ archives. It is included with current Windows 10 and Windows 11 installations.
- 7-Zip command-line program `7z.exe` for 7Z archives and as a fallback for RAR archives.
- Optionally, WinRAR command-line program `rar.exe` for RAR archives.

## Build

1. Extract the complete package into one directory.
2. Open a command prompt in that directory.
3. Ensure `sc32.exe` is available through `PATH`, or edit `build.bat` to specify its full path.
4. Run `build.bat`.
5. Confirm that `GREPZIP.MAC` was created.

## Install

Keep these four files together in a directory from which TSE loads macros:

- `GREPZIP.MAC`
- `grepzip.s`
- `grepzip_helper.ps1`
- `grepzip.ini`

The macro obtains its own location with `CurrMacroFilename()`, so it does not depend on TSE's current working directory and does not use `LoadDir()`.

## Configuration

Edit `grepzip.ini` and enter the complete executable paths:

```ini
[ArchiveTools]
SevenZipExecutable=C:\Program Files\7-Zip\7z.exe
RarExecutable=C:\Program Files\WinRAR\Rar.exe

[SearchDefaults]
searchstring=foobar
searchoptions=ix
topdirectory=c:\temp\
showfilenames=true
searcharchives=yes
```

Paths may contain spaces and may optionally be enclosed in double quotes. Environment variables such as `%ProgramFiles%` are expanded. A configured path is used when it exists. If it is blank or invalid, GREPZIP searches `PATH` and the standard 7-Zip or WinRAR installation directories. If `rar.exe` cannot be found, GREPZIP tries `7z.exe` for RAR archives.

The prompt values under `[SearchDefaults]` provide the initial text displayed by the corresponding TSE `Ask()` prompts:

- `searchstring` initializes the search-string prompt.
- `searchoptions` initializes the options prompt, for example `i` or `ix`.
- `topdirectory` initializes the directories or file-specifications prompt. It may contain a semicolon-separated list.
- `showfilenames` controls whether each tested filename is displayed on TSE's message bar.
- `searcharchives` initializes the archive-search prompt; use `yes` or `no`.

The user can edit each prompt value before starting the search. Each `Ask()` prompt has its own named TSE history: `GREPZIP:searchstring`, `GREPZIP:searchoptions`, `GREPZIP:searchspecifications`, and `GREPZIP:searcharchives`. When the corresponding initial value is blank, GREPZIP recalls the newest value from that prompt's dedicated history. A nonempty INI or built-in value has priority as the initial text, while the user's accepted prompt input remains final.

`showfilenames=true` is the default. It shows each filename only on TSE's message bar and refreshes the display during the TSE search stage. The main editing window remains on the file that was active when GREPZIP started until the final results buffer is displayed. Use `false`, `no`, `0`, or `off` to disable filename progress.

Before PowerShell begins enumerating files and expanding archives, GREPZIP displays `GREPZIP: Enumerating files and expanding archives...` on the message bar. That message remains visible during the synchronous enumeration stage. When enumeration finishes, changing filenames replace it during TSE's text-search stage.

GREPZIP validates active lines in `grepzip.ini`. It reports unknown sections, unknown or empty parameter names, missing equals signs, duplicate parameters, parameters in the wrong section, and invalid `showfilenames` or `searcharchives` values in one consolidated warning. The common typo `opdirectory` is specifically reported with a suggestion to use `topdirectory`. Comments beginning with `;` are ignored. Valid settings remain available after the warning is dismissed.

## Run

Run `GREPZIP` as a macro, or press **Ctrl+Alt+Shift+F**. Press **Ctrl+Alt+Shift+R** to open TSE's built-in **Regular Expression Operators** help topic.

1. Enter the search string.
2. Enter TSE search options, for example `i` or `ix`.
3. Enter one or more directories, files, or file specifications. Separate multiple entries with semicolons (`;`).
4. Enter `yes` or `no` when asked whether archived files should be searched.
5. Wait while GREPZIP enumerates files, optionally expands supported archives, and asks TSE to search each file. If `showfilenames` is enabled, the currently searched virtual filename is refreshed on TSE's message bar.
6. Review the results buffer.

Examples of source specifications:

```text
C:\SOURCE
C:\SOURCE\*.S
C:\SOURCE\README.MD
C:\ARCHIVES\*.ZIP
C:\ARCHIVES\*.TAR
C:\ARCHIVES\*.7Z
C:\ARCHIVES\*.RAR
C:\SOURCE;D:\SOURCE;F:\ARCHIVES\*.ZIP
```

Each entry is processed independently, then all selected files are combined into one search and one results buffer. A file specification is applied recursively below its parent directory. A directory searches all files below it. A literal filename searches only that file. Whitespace surrounding each entry and empty entries are ignored.

An invalid or unavailable entry is skipped without stopping the remaining entries. GREPZIP also tolerates an accidental equals sign immediately before an absolute drive specification, for example `=F:\SOURCE`.

For example:

```text
C:\SOURCE;D:\PROJECTS\*.S;F:\ARCHIVES
```

searches every file below `C:\SOURCE`, matching `.S` files below `D:\PROJECTS`, and every file and supported archive below `F:\ARCHIVES`.

## Regular expressions

The search string is passed directly to TSE's `lFind()`. The separate options prompt controls matching. GREPZIP searches each temporary file buffer separately and does not add TSE's global-buffer option.

- `i` - ignore case.
- `x` - interpret the search string as a TSE regular expression.
- `ix` - ignore case and use TSE regular expressions.
- Leave `x` out for a literal text search, such as `Dos`.

Use TSE regular-expression syntax when `x` is present, not PowerShell or Perl syntax. GREPZIP does not translate the expression.

### TSE regular-expression operators

The following operators are accepted directly by TSE when option `x` is used:

- `\\` - TSE regular-expression escape character. Use it before an operator when that character must be matched literally.
- `.` - any single character.
- `^` - anchor the following sub-pattern to the beginning of the line.
- `$` - anchor the preceding sub-pattern to the end of the line.
- `|` - OR; match the preceding or following sub-pattern.
- `?` - zero or one occurrence of the preceding sub-pattern.
- `[abc]` - match one character from the class.
- `[A-Za-z]` - match one character from the indicated ASCII ranges.
- `[~abc]` - match one character not present in the class; `~` must immediately follow `[`. 
- `*` - minimum-closure zero or more occurrences of the preceding sub-pattern.
- `+` - minimum-closure one or more occurrences of the preceding sub-pattern.
- `@` - maximum-closure (greedy) zero or more occurrences of the preceding sub-pattern.
- `#` - maximum-closure (greedy) one or more occurrences of the preceding sub-pattern.
- `{pattern}` - tag/group a sub-pattern; tags may be nested.

Examples:

```text
Do.*
Dos?Command
Dos+Command
file\\.zip
Do@
Do#
[A-Za-z]#
[~0-9]@
{Begin}|{End}File
^Dos$
```

In `file\\.zip`, the backslash escapes the dot, so the dot is matched literally.

Character classes remain case-sensitive even when option `i` is selected. Include both cases explicitly, for example `[A-Za-z]`. OR alternatives are tried from left to right, put a longer alternative before a shorter one when one contains the other.

Examples:

```text
TODO
proc[ \t]+Main
Version[ \t]*:[ \t]*1\.0
```

Whether matching is case-sensitive follows the active TSE search behavior and expression/options supported by the installed TSE version.

## Results

The results buffer supports direct navigation:

- Left-click a matching result line or place the cursor on it and press `Enter` to open the file at the reported line and column.
- Press `Ctrl+Alt+Shift+G` to return to the current GREPZIP results buffer.
- Header, instruction, blank, and summary lines are not navigation targets.

For ordinary files, navigation opens the original file. For archive members, GREPZIP opens the physical temporary extraction file associated with the displayed virtual archive path. The extraction tree is retained after the search so those links remain usable. Starting the next GREPZIP search removes the previous extraction tree and creates a new one; an older archive-result link may therefore no longer be available after another search.

Each match is shown as:

```text
filename(line,column): matching line
```

Archive members use `::` to show archive nesting, for example:

```text
C:\DATA\outer.zip::docs/inner.zip::source/test.s(42,7): proc Main()
C:\DATA\outer.tgz::source.tar::source/test.s(42,7): proc Main()
```

## Archive behavior

- ZIP, JAR, TAR, TGZ, TAR.GZ, 7Z and RAR archives are searched.
- Any supported archive may be nested inside any other supported archive.
- Nested archives are searched to a maximum depth of 32.
- Archive directory entries are ignored.
- Encrypted, damaged, or unsupported archives are skipped.
- With a wildcard source specification, the mask selects ordinary files both outside and inside archives; supported archive files are still opened so matching members can be found.
- Extracted temporary members use unique names below `%TEMP%`.
- The manifest contains system paths only temporarily; search output retains the archive/member path.
- The extraction tree and manifest remain available after searching so archive-result navigation works.
- Starting the next GREPZIP search removes the previous extraction tree and manifest.

## Current limits

- TSE SAL strings and displayed result lines are limited to 255 characters; the complete semicolon-separated source list must fit in one 255-character SAL string, and very long paths or lines can be truncated.
- TSE SAL integers are signed 32-bit.
- Binary files may not be meaningful to TSE's text search.
- Password-protected archives are not searched.
- TAR/TGZ searching requires `tar.exe`; those formats are skipped if it is unavailable.
- 7Z searching requires `7z.exe`.
- RAR searching requires either `rar.exe` or `7z.exe`.
- Missing archive programs do not prevent GREPZIP from running; only their corresponding formats are skipped.

## Version history

### 1.0.0.0.27 - 2026-11-08

- Fixes `Illegal characters in path` when a source directory ends in a backslash.
- Normalizes slash characters using their ASCII character codes, avoiding ambiguous SAL string literals.
- Places the directory or file specification last on the PowerShell command line so a final backslash cannot consume the following archive option.

### 1.0.0.0.26 - 2026-11-08

- Restores the `Search archived files (yes/no)` prompt.
- Gives the archive-search prompt its own dedicated TSE input history.
- Adds the validated `searcharchives=yes|no` setting to `[SearchDefaults]` in `grepzip.ini`.
- Passes the selected archive behavior explicitly to the PowerShell helper.
- With `no`, archive files are skipped while ordinary files are still searched recursively.

### 1.0.0.0.25 - 2026-11-08

- Verifies that `GREPZIP_HELPER.PS1` exists beside the running macro before starting a search.
- Deletes the previous manifest before launching PowerShell and stops if it cannot be removed.
- Requires PowerShell to create a new manifest containing the current `#STATS` marker.
- Prevents a failed or mismatched helper from silently reusing stale file entries from an earlier search.

### 1.0.0.0.24 - 2026-11-08

- Adds separate result counters for files enumerated by PowerShell, searchable manifest entries written by PowerShell, and manifest entries processed by TSE.
- Reports the PowerShell helper error count and first error message when an error occurs.
- Makes it possible to locate enumeration loss precisely between filesystem traversal, manifest creation, and TSE manifest processing.

### 1.0.0.0.23 - 2026-11-08

- Replaces PowerShell's single `Get-ChildItem -Recurse` enumeration with an explicit directory-stack walker.
- Ensures every accessible subdirectory is visited even when another directory is inaccessible or problematic.
- Applies the same robust traversal to extracted TAR, TGZ, 7Z and RAR directory trees.
- Skips directory reparse points to prevent junction or symbolic-link recursion loops.

### 1.0.0.0.22 - 2026-11-08

- Replaces shared `_EDIT_HISTORY_` use with three dedicated named histories for the search-string, search-options, and source-specifications prompts.
- Uses the newest value from the corresponding history when that prompt's INI or built-in initial value is blank.
- Stops with a clear warning if TSE cannot allocate all three dedicated history numbers.

### 1.0.0.0.21 - 2026-10-17

- Extends the final search-summary dialog with navigation instructions.
- Explains that clicking a matching result line, or pressing `Enter`, opens the file at the recorded line and column.
- Explains that `Ctrl+Alt+Shift+G` returns to the GREPZIP search results.

### 1.0.0.0.20 - 2026-10-16

- Makes matching result lines navigable with a left click or `Enter`.
- Opens each selected result at its recorded line and column.
- Adds `Ctrl+Alt+Shift+G` to return to the current results buffer.
- Stores a hidden physical-file mapping for every visible match.
- Supports navigation into nested archive members by retaining their extracted temporary files.
- Cleans the preceding search's extraction tree when the next GREPZIP search starts.

### 1.0.0.0.19 - 2026-10-16

- Preserves the buffer that was active when GREPZIP started.
- Restores that buffer before every filename progress refresh.
- Restricts changing filename progress to TSE's message bar.
- Prevents the hidden manifest filename list from being painted in the main editing window.

### 1.0.0.0.18 - 2026-10-16

- Displays an enumeration and archive-expansion status message before PowerShell starts.
- Keeps that message visible throughout the otherwise silent enumeration stage.
- Changes the supplied and built-in `showfilenames` default to `true`.
- Shows changing filenames automatically when TSE begins searching the completed manifest.

### 1.0.0.0.17 - 2026-10-16

- Validates parameter and section names while reading `grepzip.ini`.
- Detects missing equals signs, empty names, duplicates, misplaced parameters, and invalid `showfilenames` values.
- Suggests `topdirectory` when the misspelling `opdirectory` is encountered.
- Combines all detected configuration problems into one warning.
- Continues with recognized settings and safe defaults after the warning.

### 1.0.0.0.16 - 2026-10-16

- Prevents one malformed or unavailable source entry from stopping all later entries.
- Accepts an accidental leading equals sign before an absolute drive specification, such as `=F:\SOURCE`.
- Corrects the zero-files result caused when the first entry of a multi-directory search was malformed.

### 1.0.0.0.15 - 2026-10-16

- Accepts one or more top directories, literal files, or file specifications.
- Uses semicolons to separate source entries in the TSE `Ask()` prompt.
- Applies the same semicolon-separated syntax to `topdirectory` in `grepzip.ini`.
- Combines all selected sources into one manifest, search, and results buffer.
- Ignores empty entries and whitespace surrounding each source entry.

### 1.0.0.0.14 - 2026-09-18

- Adds `showfilenames=false` to `grepzip.ini`.
- Hides the per-file message-bar filename display by default.
- Accepts `true`, `yes`, `1`, or `on` to enable filename display and per-file screen refreshes.
- Avoids the display-refresh overhead when filename display is disabled.

### 1.0.0.0.13 - 2026-09-18

- Adds `searchstring`, `searchoptions`, and `topdirectory` to `grepzip.ini`.
- Initializes the three existing TSE input prompts from the non-empty INI values.
- Keeps every prompt editable, so the INI entries are initial values rather than forced search parameters.
- Falls back to the built-in GREPZIP defaults when an INI value is empty.

### 1.0.0.0.12 - 2026-09-15

- Adds `grepzip.ini` beside the macro and PowerShell helper.
- Stores separate full paths for `7z.exe` and `rar.exe` under `[ArchiveTools]`.
- Prefers configured executable paths and retains automatic discovery as a fallback.
- Uses `rar.exe` for RAR archives when available and otherwise tries `7z.exe`.
- Keeps all other searches operational if either optional executable is missing.

### 1.0.0.0.11 - 2026-09-15

- Adds recursive 7Z and RAR searching through `7z.exe`.
- Locates `7z.exe` through `PATH` or the standard 32-bit and 64-bit 7-Zip installation directories.
- Allows 7Z and RAR archives to participate in mixed nested-archive chains with ZIP, JAR, TAR and TGZ.

### 1.0.0.0.10 - 2026-09-15

- Continues from the stable PowerShell-based version 1.0.0.0.7.
- Adds recursive JAR, TAR, TGZ and TAR.GZ searching.
- Allows supported archive types to be nested in any combination.
- Applies wildcard file specifications to ordinary files inside archives while still following nested archives.
- Refreshes TSE's display after every filename message to prevent the message-bar filename from appearing frozen.
- Changes the direct search key to Ctrl+Alt+Shift+F.
- Versions 1.0.0.0.8 and 1.0.0.0.9 were experimental DLL-enumeration versions and are not the basis of this release.

### 1.0.0.0.7 - 2026-09-08

- Adds the complete pasted TSE search-operator set to the search prompt and documentation.
- Documents `[]` character classes and ranges such as `[A-Za-z]`.
- Documents complement classes such as `[~0-9]`.
- Documents `{}` tags/groups and nested tags.
- Documents the `|` OR operator and its left-to-right precedence.
- Documents `^` and `$` line anchors.
- Distinguishes minimum closure (`*`, `+`) from maximum/greedy closure (`@`, `#`).
- Adds Ctrl+Alt+Shift+R to open TSE's built-in Regular Expression Operators help.

### 1.0.0.0.6 - 2026-09-08

- Traverses the manifest by stored line number instead of relying on the current buffer after a source file is abandoned.
- Explicitly restores the manifest buffer before reading every entry.
- Displays the number of files examined in the results and final warning.
- Adds TSE `@` greedy zero-or-more and `#` greedy one-or-more operators to the prompt and documentation.

### 1.0.0.0.5 - 2026-09-08

- Stops adding the `g` global-buffer option to each TSE search.
- Loads the manifest and source files with TSE `EditBuffer()`.
- Uses `lFind()` for the first match and `lRepeatFind()` for subsequent matches.
- Searches each source in its own current temporary buffer.
- Documents TSE's `\\` escape character and `.`, `*`, `+`, and `?` operators.
- Corrects literal and regular-expression searches such as `Dos` with options `ix`.

### 1.0.0.0.4 - 2026-09-08

- Removes every double-quote character from the entered source specification.
- Handles specifications containing only a leading quote or only a trailing quote.
- Converts forward slashes in the source specification to Windows backslashes.
- Fixes zero-file enumeration when the results header showed a leading quote.

### 1.0.0.0.3 - 2026-09-08

- Prevents PowerShell from prompting for a missing `Manifest` parameter.
- Uses `%TEMP%\\grepzip_manifest.txt` as the default manifest name.
- Shortens the command to stay within TSE's 255-character string limit.
- Starts PowerShell non-interactively with a hidden window.
- Uses the same hidden, non-interactive invocation during cleanup.

### 1.0.0.0.2 - 2026-09-08

- Changed the prompt order to search string, search options, then source specification.
- Added a separate TSE search-options prompt with default `ix`.
- Passes the selected `i` and `x` options to TSE `lFind()`.
- Removes surrounding quotes from a source path.
- Removes a non-root trailing slash so a quoted PowerShell argument remains valid.
- Corrected the empty-result problem demonstrated by searching for `Dos`.

### 1.0.0.0.1 - 2026-09-08

- Renamed the program and package from RGZIP to GREPZIP.
- Corrected `SplitPath()` to use the numeric `_DRIVE_|_PATH_` flag expression required by TSE SAL.
- Fixed compiler error 2336 at the former line 75.

### 1.0.0.0.0 - 2026-09-08

- Initial release.
- Recursive directory and file-specification enumeration.
- TSE SAL regular-expression content matching.
- ZIP and nested-ZIP searching.
- Results include line and column numbers plus virtual nested archive paths.
- Direct key binding in that release: Ctrl+Alt+Shift+G.
- Automatic cleanup of extracted ZIP members after the TSE search.
