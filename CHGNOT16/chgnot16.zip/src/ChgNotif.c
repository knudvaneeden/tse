// CHGNOTIF.C

// TO COMPILE AND LINK, using Microsoft C v10:
// cl -W3 -GD -LD chgnotif.c chgnotif.def user32.lib


// WARNING!!  Be extremely careful if you modify this file.  This is a
// multithreaded DLL, and if extreme care is not taken, you can easily
// introduce deadlocks (too much or incorrect thread synchronization) or
// crashes (not enough thread synchronization).



#define STRICT
//#define DEBUG

#include <windows.h>



// Types ------------------------------------------------------------------

#define MAXPATH			255
#define MAXNAME			128


// IMPORTANT!!! -----------------------------------------------
//		To avoid deadlocks, any time both g_csNotif and
//		g_csWatches are both entered, LOCKnotif must always be
//		the outer critsec!
// IMPORTANT!!! -----------------------------------------------
#define LOCKnotif		EnterCriticalSection(&g_csNotif)
#define UNLOCKnotif		LeaveCriticalSection(&g_csNotif)
#define LOCK			EnterCriticalSection(&g_csWatches)
#define UNLOCK			LeaveCriticalSection(&g_csWatches)
// IMPORTANT!!! -----------------------------------------------


#ifdef DEBUG
	#define TRACE(x) \
		do \
			{ \
			OutputDebugString(x); \
			OutputDebugString("\r\n"); \
			} \
		while (FALSE)

	#define TRACE1(x, a) \
		do \
			{ \
			char _____sz[255]; \
			wsprintf(_____sz, x, a); \
			OutputDebugString(_____sz); \
			OutputDebugString("\r\n"); \
			} \
		while (FALSE)

	#define TRACE2(x, a, b) \
		do \
			{ \
			char _____sz[255]; \
			wsprintf(_____sz, x, a, b); \
			OutputDebugString(_____sz); \
			OutputDebugString("\r\n"); \
			} \
		while (FALSE)

	#define TRACE3(x, a, b, c) \
		do \
			{ \
			char _____sz[255]; \
			wsprintf(_____sz, x, a, b, c); \
			OutputDebugString(_____sz); \
			OutputDebugString("\r\n"); \
			} \
		while (FALSE)

	#define TRACE4(x, a, b, c, d) \
		do \
			{ \
			char _____sz[255]; \
			wsprintf(_____sz, x, a, b, c, d); \
			OutputDebugString(_____sz); \
			OutputDebugString("\r\n"); \
			} \
		while (FALSE)
#else
	#define TRACE(x)
	#define TRACE1(x, a)
	#define TRACE2(x, a, b)
	#define TRACE3(x, a, b, c)
	#define TRACE4(x, a, b, c, d)
#endif

typedef struct WATCH
	{
	struct WATCH *m_pNext;
	struct WATCH *m_pPrev;

	char m_szPath[MAXNAME];
	char m_szName[MAXNAME];
	ULONG m_ulSize;
	ULONG m_ulAttr;
	FILETIME m_ftModified;

	HANDLE m_hNotify;

	WORD m_cChangeExpected;				// change expected (can be nested)
	ULONG m_ulChangeFlags;				// change detected

	unsigned m_fEverSaved:1;			// file was found on disk, we can now assume it should continue to be on the disk
	unsigned m_fRemoveMe:1;				// marked for removal (for BeginSync/EndSync)
	unsigned m_fDead:1;					// dead; file not accessible anymore
	} WATCH, FAR *LPWATCH;


typedef struct NOTIF
	{
	struct NOTIF *m_pNext;
	struct NOTIF *m_pPrev;

	HANDLE m_h;
	char m_szPath[MAXNAME];

	unsigned m_fDead:1;
	} NOTIF, FAR *LPNOTIF;


typedef struct STRING
	{
	unsigned short m_cLen;
	char m_sz[1];
	} FAR *LPSTRING;


#define cfNONE		0x0000
#define cfGONE		0x0001
#define cfCHANGED	0x0002



// Globals ----------------------------------------------------------------

// linear linked list of files
LPWATCH g_pwatchHead;
CRITICAL_SECTION g_csWatches;

// linear linked list of notification handles and associated info
LPNOTIF g_pnotifHead;
CRITICAL_SECTION g_csNotif;

HANDLE g_hThread;
DWORD g_idThread;
HWND g_hwnd;

HANDLE g_hRebuild;
HANDLE g_hGoodbye;

static s_fSyncing;



// Functions --------------------------------------------------------------

static int CompareFileAttr(DWORD dwAttr1, DWORD dwAttr2)
{
	return ((dwAttr1 & ~(FILE_ATTRIBUTE_NORMAL|FILE_ATTRIBUTE_ARCHIVE)) -
			(dwAttr2 & ~(FILE_ATTRIBUTE_NORMAL|FILE_ATTRIBUTE_ARCHIVE)));
}


LPWATCH FindEntry(LPSTR pszPath, LPSTR pszName)
{
	LPWATCH p;

	/*
#ifdef DEBUG
	if (pszName)
		TRACE2("FindEntry:  \"%s\",  \"%s\"", pszPath, pszName);
	else
		TRACE1("FindEntry:  \"%s\"", pszPath);
#endif
	*/

	for (p = g_pwatchHead; p; p = p->m_pNext)
		if (lstrcmpi(p->m_szPath, pszPath) == 0 &&
				(!pszName || lstrcmpi(p->m_szName, pszName) == 0))
			break;

	//TRACE1("FindEntry returns %08.8x", p);
	return p;
}


LPWATCH FindChange()
{
	LPWATCH pwatch;

	for (pwatch = g_pwatchHead; pwatch; pwatch = pwatch->m_pNext)
		if (pwatch->m_ulChangeFlags)
			return pwatch;
	return 0;
}


int NumNotifs()
{
	int n;
	LPNOTIF p;

	for (n = 0, p = g_pnotifHead; p; p = p->m_pNext, ++n);
	return n;
}


LPNOTIF FindNotif(LPSTR pszPath)
{
	LPNOTIF p;

	//TRACE1("  FindNotif:  %s", pszPath);

	for (p = g_pnotifHead; p; p = p->m_pNext)
		if (lstrcmpi(p->m_szPath, pszPath) == 0)
			break;

	//TRACE1("  FindNotif returns %08.8x", p);
	return p;
}


BOOL RemoveEntry(LPWATCH pwatch)
{
	TRACE("RemoveEntry");

	//$ locking must be done outside this function!
	if (!pwatch)
		return FALSE;

	// don't close notification handle; this doesn't own it

	// unlink
	if (pwatch->m_pPrev)
		pwatch->m_pPrev->m_pNext = pwatch->m_pNext;
	else
		g_pwatchHead = pwatch->m_pNext;
	if (pwatch->m_pNext)
		pwatch->m_pNext->m_pPrev = pwatch->m_pPrev;

	// free memory
	LocalFree((HLOCAL)pwatch);

	return TRUE;
}


BOOL RemoveNotif(LPNOTIF p)
{
	TRACE("RemoveNotif");

	//$ locking must be done outside this function!
	if (!p)
		return FALSE;

	// unlink
	if (p->m_pPrev)
		p->m_pPrev->m_pNext = p->m_pNext;
	else
		g_pnotifHead = p->m_pNext;
	if (p->m_pNext)
		p->m_pNext->m_pPrev = p->m_pPrev;

	// close notification handle
	if (p->m_h != INVALID_HANDLE_VALUE)
		FindCloseChangeNotification(p->m_h);

	// free memory
	LocalFree((HLOCAL)p);

	return TRUE;
}


BOOL FindThisFile(LPSTR pszPath, LPSTR pszName, WIN32_FIND_DATA *pinfo)
{
	HANDLE h;
	char sz[MAXPATH];

	TRACE("FindThisFile");

	// look for file
	lstrcpy(sz, pszPath);
	if (lstrlen(sz) > 0 && sz[lstrlen(sz)-1] != '\\')
		lstrcat(sz, "\\");
	lstrcat(sz, pszName);
	h = FindFirstFile(sz, pinfo);
	if (h == INVALID_HANDLE_VALUE)
		{
		TRACE1("  file not found \"%s\"", sz);
		return FALSE;
		}

	// success
	TRACE1("  found file \"%s\"", sz);
	FindClose(h);
	return TRUE;
}


ULONG __stdcall NotificationThread(void *pParam)
{
	HANDLE *pHandles;
	int cHandles;
	LPWATCH pwatch;
	LPNOTIF pnotif;
	LPNOTIF pnotifDel;
	DWORD dw;
	WIN32_FIND_DATA info;
	BOOL fFound;
	HANDLE h = INVALID_HANDLE_VALUE;

	TRACE("BEGIN - NotificationThread");

	do
		{
		dw = WAIT_OBJECT_0;

		LOCKnotif;
		// remove dead handles
		for (pnotif = g_pnotifHead; pnotif;)
			{
			pnotifDel = pnotif->m_fDead ? pnotif : 0;
			pnotif = pnotif->m_pNext;
			if (pnotifDel)
				RemoveNotif(pnotifDel);
			}

		// build handle array
		cHandles = NumNotifs() + 2;
		pHandles = (HANDLE*)LocalAlloc(LPTR, sizeof(HANDLE)*cHandles);
//TRACE1("pHandles == %08.8x", pHandles);
TRACE1("cHandles == %d", cHandles);
		if (pHandles)
			{
			cHandles = 0;
			pHandles[cHandles++] = g_hGoodbye;
			pHandles[cHandles++] = g_hRebuild;
//TRACE("building pHandles array");
			for (pnotif = g_pnotifHead; pnotif; pnotif = pnotif->m_pNext)
				{
				// get notification handles as necessary
				if (pnotif->m_h == INVALID_HANDLE_VALUE)
					{
					// get notification handle for this path
					h = FindFirstChangeNotification(pnotif->m_szPath,
							FALSE,
							FILE_NOTIFY_CHANGE_FILE_NAME|
							FILE_NOTIFY_CHANGE_SIZE|
							FILE_NOTIFY_CHANGE_LAST_WRITE
							);
//TRACE1("  FindFirstChangeNotification returns %08.8x", h);
					pnotif->m_h = h;

					// copy handle to entries with same path
					LOCK;
					for (pwatch = g_pwatchHead; pwatch; pwatch = pwatch->m_pNext)
						if (lstrcmpi(pwatch->m_szPath, pnotif->m_szPath) == 0)
							pwatch->m_hNotify = h;
					UNLOCK;
					}

				// if valid handle, copy into wait array
				h = pnotif->m_h;
				if (h != INVALID_HANDLE_VALUE)
					pHandles[cHandles++] = h;
				}
			}
		UNLOCKnotif;

		// wait
		while (pHandles)
			{
			// wait for signal
			dw = WaitForMultipleObjects(cHandles, pHandles, FALSE, INFINITE);

			// did wait fail?
			if (dw == WAIT_FAILED)
				{
				//$ todo: uh, what to do?
				TRACE1("WAIT_FAILED, GetLastError == %08.8x", GetLastError());
				// terminate the thread
				dw = WAIT_OBJECT_0;
				break;
				}

			// rebuild handle list, or goodbye?
			if (dw == WAIT_OBJECT_0 || dw == WAIT_OBJECT_0+1)
				break;

			// signal on a change notification handle?
			if (dw > WAIT_OBJECT_0 + 1 && dw < WAIT_OBJECT_0+cHandles)
				{
				// check files represented by this handle (handle is bound to pathname)
				LOCK;
				for (pwatch = g_pwatchHead; pwatch; pwatch = pwatch->m_pNext)
					{
					if (pwatch->m_hNotify == pHandles[dw - WAIT_OBJECT_0])
						{
						fFound = FindThisFile(pwatch->m_szPath, pwatch->m_szName, &info);
						// is the file there?
						if (!fFound)
							{
							TRACE2("  notify:  not found \"%s\\%s\"",
									pwatch->m_szPath, pwatch->m_szName);

							// record the change if it wasn't expected
							if (!pwatch->m_cChangeExpected &&
									pwatch->m_fEverSaved)
								pwatch->m_ulChangeFlags = cfGONE;
							else
								TRACE("           change was expected");

							// zero out file info
							pwatch->m_ulSize = 0;
							pwatch->m_ulAttr = 0;
							pwatch->m_ftModified.dwLowDateTime = 0;
							pwatch->m_ftModified.dwHighDateTime = 0;
							}
						// has the file changed?
						else
							{
							pwatch->m_fEverSaved = TRUE;
							if (pwatch->m_ulSize != info.nFileSizeLow ||
#if 0
									//$ review: (chrisant) something (eTrust?)
									// is making the attributes spuriously
									// different, so let's just ignore the
									// attributes for now.  the problem is
									// specific to Windows XP.
									CompareFileAttr(pwatch->m_ulAttr, info.dwFileAttributes) ||
#endif
									CompareFileTime(&pwatch->m_ftModified, &info.ftLastWriteTime))
								{
								TRACE2("  notify:  changed \"%s\\%s\"",
										pwatch->m_szPath, pwatch->m_szName);
								TRACE2("        %d  ->  %d\n", pwatch->m_ulSize, info.nFileSizeLow);
								TRACE2("        %08x  ->  %08x\n", pwatch->m_ulAttr, info.dwFileAttributes);
								TRACE4("        %08x%08x  ->  %08x%08x\n",
									   pwatch->m_ftModified.dwHighDateTime,
									   pwatch->m_ftModified.dwLowDateTime,
									   info.ftLastWriteTime.dwHighDateTime,
									   info.ftLastWriteTime.dwLowDateTime);

								// record the change if it wasn't expected
								if (!pwatch->m_cChangeExpected)
									pwatch->m_ulChangeFlags = cfCHANGED;
								else
									TRACE("           change was expected");

								// update file info
								pwatch->m_ulSize = info.nFileSizeLow;
								pwatch->m_ulAttr = info.dwFileAttributes;
								pwatch->m_ftModified = info.ftLastWriteTime;
								}
							}
						}
					}
				UNLOCK;

				// reset the notification handle
				FindNextChangeNotification(pHandles[dw - WAIT_OBJECT_0]);
				}

			//$ review: do i need to handle WAIT_ABANDONED_0?
			}

		// release handle array
		if (pHandles)
			{
			LocalFree((HLOCAL)pHandles);
			pHandles = 0;
			}

		// reset watches so they don't have handles
//		LOCK;
//		for (pwatch = g_pwatchHead; pwatch; pwatch = pwatch->m_pNext)
//			pwatch->m_hNotify = INVALID_HANDLE_VALUE;
//		UNLOCK;
		}
	while (dw != WAIT_OBJECT_0);

	TRACE("END - NotificationThread");

	return 0;
}


void KillThread()
{
	// terminate the thread
	if (g_hThread)
		{
		if (g_hGoodbye);
			{
			SetEvent(g_hGoodbye);
			WaitForSingleObject(g_hThread, INFINITE);
			}
		CloseHandle(g_hThread);
		g_hThread = 0;
		}
}


void StartThread()
{
	// start thread
	if (g_hGoodbye && g_hRebuild)
		{
		ResetEvent(g_hGoodbye);
		ResetEvent(g_hRebuild);
		g_hThread = CreateThread(0,						// security
								 2048,					// stack size
								 NotificationThread,	// start routine
								 0,						// parameter
								 0,						// creation flags
								 &g_idThread			// thread id
								 );
		}
}



// Exports ----------------------------------------------------------------

__declspec(dllexport)
BOOL Init(HWND hwnd)
{
	TRACE("Init");

	g_hwnd = hwnd;

	g_hGoodbye = CreateEvent(0,					// security
							 FALSE,				// FALSE = automatic reset
							 FALSE,				// FALSE = initial state not signaled
							 0					// name (string)
							 );
	g_hRebuild = CreateEvent(0,					// security
							 FALSE,				// FALSE = automatic reset
							 FALSE,				// FALSE = initial state not signaled
							 0					// name (string)
							 );

	// start thread
//	StartThread();

//	return (g_hGoodbye && g_hRebuild && g_hThread);
	return (g_hGoodbye && g_hRebuild);
}


__declspec(dllexport)
BOOL WatchFilename(LPSTR pszPath, LPSTR pszName, BOOL fWatch)
{
	BOOL fRet = FALSE;
	BOOL fRebuild = FALSE;
	WIN32_FIND_DATA info;
	LPWATCH pwatch;
	LPNOTIF pnotif;

	TRACE("WatchFilename");

	LOCKnotif;
	LOCK;

	if (fWatch)
		{
		pwatch = FindEntry(pszPath, pszName);
		if (pwatch)
			// clear removal flag (for BeginSync/EndSync)
			pwatch->m_fRemoveMe = FALSE;
		else
			{
			// add this filename
			pwatch = (LPWATCH)LocalAlloc(LPTR, sizeof(WATCH));
			if (pwatch)
				{
				// copy filename
				lstrcpy(pwatch->m_szPath, pszPath);
				lstrcpy(pwatch->m_szName, pszName);

				// add file info
				if (FindThisFile(pszPath, pszName, &info))
					{
					pwatch->m_fEverSaved = TRUE;
					pwatch->m_ulSize = info.nFileSizeLow;
					pwatch->m_ulAttr = info.dwFileAttributes;
					pwatch->m_ftModified = info.ftLastWriteTime;
					}
				pwatch->m_hNotify = INVALID_HANDLE_VALUE;

				// add notif path
//				LOCKnotif;
				pnotif = FindNotif(pszPath);
				if (!pnotif)
					{
					pnotif = (LPNOTIF)LocalAlloc(LPTR, sizeof(WATCH));
					if (pnotif)
						{
						if (!s_fSyncing)
							fRebuild = TRUE;

						lstrcpy(pnotif->m_szPath, pszPath);
						pnotif->m_h = INVALID_HANDLE_VALUE;

						pnotif->m_pPrev = 0;
						pnotif->m_pNext = g_pnotifHead;
						if (g_pnotifHead)
							g_pnotifHead->m_pPrev = pnotif;
						g_pnotifHead = pnotif;
						}
					}
				if (pnotif)
					pwatch->m_hNotify = pnotif->m_h;
//				UNLOCKnotif;

				// link it
//				LOCK;
				pwatch->m_pPrev = 0;
				pwatch->m_pNext = g_pwatchHead;
				if (g_pwatchHead)
					g_pwatchHead->m_pPrev = pwatch;
				g_pwatchHead = pwatch;
//				UNLOCK;

				// succeeded
				fRet = TRUE;
				}
			}
		}
	else
		{
		fRet = RemoveEntry(FindEntry(pszPath, pszName));
		pnotif = FindNotif(pszPath);
		if (pnotif && !FindEntry(pszPath, 0))
			// defer the removal, so the background thread is always in
			// control of the actual handles!
			pnotif->m_fDead = TRUE;
		}

	if (fRebuild)
		SetEvent(g_hRebuild);

	UNLOCK;
	UNLOCKnotif;

	return fRet;
}


__declspec(dllexport)
void ChangeExpected(LPSTR pszFilename, int cExpected)
{
	LPWATCH pwatch;
	WIN32_FIND_DATA info;
	char szPath[MAXPATH];
	char szName[MAXPATH];
	int i;

	TRACE("ChangeExpected");

	// extract path
	for (i = lstrlen(pszFilename); i-- >= 0;)
		if (pszFilename[i] == '\\' || pszFilename[i] == '/')
			break;
	if (i < 0)
		{
		TRACE1("  ERROR:  no slashes; expected full pathname, but received \"%s\"", pszFilename);
		return;
		}
	lstrcpy(szPath, pszFilename);
	if (i == 2 && pszFilename[1] == ':')
		// it's the root of some drive; only strip the file name
		szPath[i+1] = 0;
	else
		// strip trailing slash from path
		szPath[i] = 0;

	// extract name
	lstrcpy(szName, pszFilename+i+1);

	// look for entry
	LOCK;
	pwatch = FindEntry(szPath, szName);
	if (pwatch)
		{
		if (cExpected > 0)
			{
			TRACE2("  TRUE:  expect changes to \"%s\\%s\"", szPath, szName);

			// ignore change notifications for this file
			pwatch->m_cChangeExpected++;
			}
		else
			{
			TRACE3("  %s:  do not expect changes to \"%s\\%s\"",
				   (cExpected < 0) ? "FALSE" : "ZERO", szPath, szName);

			// record current file stats
			if (FindThisFile(szPath, szName, &info))
				{
				pwatch->m_fEverSaved = TRUE;
				pwatch->m_ulSize = info.nFileSizeLow;
				pwatch->m_ulAttr = info.dwFileAttributes;
				pwatch->m_ftModified = info.ftLastWriteTime;
				}

			// respond to change notifications for this file
			if (cExpected < 0)
				pwatch->m_cChangeExpected--;
			else
				pwatch->m_cChangeExpected = 0;
			}
		}
#ifdef DEBUG
	else
		TRACE2("  er, sorry, i couldn't find \"%s\\%s\"", szPath, szName);
#endif
	UNLOCK;
}


__declspec(dllexport)
void ForceChanged(LPSTR pszFilename, BOOL fChanged, BOOL fGone)
{
	LPWATCH pwatch;
	char szPath[MAXPATH];
	char szName[MAXPATH];
	int i;

	TRACE("ForceChanged");

	// extract path
	for (i = lstrlen(pszFilename); i-- >= 0;)
		if (pszFilename[i] == '\\' || pszFilename[i] == '/')
			break;
	if (i < 0)
		{
		TRACE1("  ERROR:  no slashes; expected full pathname, but received \"%s\"", pszFilename);
		return;
		}
	lstrcpy(szPath, pszFilename);
	if (i == 2 && pszFilename[1] == ':')
		// it's the root of some drive; only strip the file name
		szPath[i+1] = 0;
	else
		// strip trailing slash from path
		szPath[i] = 0;

	// extract name
	lstrcpy(szName, pszFilename+i+1);

	// look for entry
	LOCK;
	pwatch = FindEntry(szPath, szName);
	if (pwatch)
		{
		if (fChanged)
			pwatch->m_ulChangeFlags |= cfCHANGED;
		if (fGone)
			pwatch->m_ulChangeFlags |= cfGONE;
		if (!fGone && !fChanged)
			pwatch->m_ulChangeFlags = cfNONE;
		}
#ifdef DEBUG
	else
		TRACE2("  er, sorry, i couldn't find \"%s\\%s\"", szPath, szName);
#endif
	UNLOCK;
}


__declspec(dllexport)
BOOL FChanges()
{
	LPWATCH pwatch;
	HWND hwnd;
	BOOL fChanges = FALSE;

	hwnd = GetForegroundWindow();

	LOCK;
	pwatch = FindChange();
#ifdef DEBUG
	if (hwnd && hwnd == g_hwnd && pwatch)
		TRACE2("CHANGED:  %s\\%s", pwatch->m_szPath, pwatch->m_szName);
#endif
	UNLOCK;

	return (hwnd && hwnd == g_hwnd && pwatch);
}


__declspec(dllexport)
ULONG GetNextChange(LPSTRING pstFilename, int cMax)
{
	LPSTR psz, pszFn;
	LPWATCH pwatch;
	int i;
	ULONG ul = 0;

	TRACE("GetNextChange");

	LOCK;

	pwatch = FindChange();
	if (pwatch)
		{
		// copy filename that changed
		i = min(lstrlen(pwatch->m_szPath)+lstrlen(pwatch->m_szName)+1, cMax);
		pstFilename->m_cLen = i;
		pszFn = pstFilename->m_sz;

		// copy the path
		for (psz = pwatch->m_szPath; *psz && i--; psz++)
			*(pszFn++) = *psz;

		// add a trailing slash if one doesn't already exist
		psz = pwatch->m_szPath;
		if (lstrlen(psz) > 0 && psz[lstrlen(psz)-1] != '\\' && i--)
			*(pszFn++) = '\\';

		// append the name
		for (psz = pwatch->m_szName; *psz && i--; psz++)
			*(pszFn++) = *psz;

		// get the change flag, then reset it
		ul = pwatch->m_ulChangeFlags;
		pwatch->m_ulChangeFlags = 0;
		}

	UNLOCK;

	return ul;
}


__declspec(dllexport)
void BeginSync()
{
	LPWATCH pwatch;

	TRACE("BeginSync");

	KillThread();

	// mark all entries for removal
	LOCK;
	s_fSyncing = TRUE;
	for (pwatch = g_pwatchHead; pwatch; pwatch = pwatch->m_pNext)
		pwatch->m_fRemoveMe = TRUE;
	UNLOCK;
}


__declspec(dllexport)
void EndSync()
{
	LPWATCH pwatch;
	LPWATCH pwatchRemove;

	TRACE("EndSync");

	// remove any entries still marked for removal
	LOCK;
	for (pwatch = g_pwatchHead; pwatch;)
		{
		// remove this entry?
		pwatchRemove = (pwatch->m_fRemoveMe) ? pwatch : 0;

		// get next entry
		pwatch = pwatch->m_pNext;

		// maybe remove the entry
		if (pwatchRemove)
			RemoveEntry(pwatchRemove);
		}
	UNLOCK;

	// signal a rebuild
	s_fSyncing = FALSE;
	StartThread();
}


__declspec(dllexport)
void Goodbye()
{
	TRACE("Goodbye");

	// terminate the thread
	KillThread();
	// (thread is dead, so don't need to worry about locking past this point)

	// release watch list
	while (g_pwatchHead)
		RemoveEntry(g_pwatchHead);

	// release notif list
	while (g_pnotifHead)
		RemoveNotif(g_pnotifHead);

	// close stuff
	if (g_hRebuild)
		CloseHandle(g_hRebuild);
	if (g_hGoodbye)
		CloseHandle(g_hGoodbye);

	g_hGoodbye = 0;
	g_idThread = 0;
	g_hwnd = 0;
}



// DllEntryPoint ----------------------------------------------------------

BOOL WINAPI DllMain(HINSTANCE hinstDLL,	// handle of DLL module
					DWORD dwReason,		// reason for calling function
					LPVOID pvReserved	// reserved
					)
{
	TRACE("DllMain");

	if (dwReason == DLL_PROCESS_ATTACH)
		{
		TRACE("DLL_PROCESS_ATTACH");

		// init
		s_fSyncing = FALSE;
		g_hwnd = 0;
		g_pwatchHead = 0;
		g_pnotifHead = 0;
		g_hwnd = 0;
		g_hThread = 0;
		g_idThread = 0;
		g_hGoodbye = 0;
		g_hRebuild = 0;
		InitializeCriticalSection(&g_csWatches);
		InitializeCriticalSection(&g_csNotif);
		}
	else if (dwReason == DLL_PROCESS_DETACH)
		{
		TRACE("DLL_PROCESS_DETACH");

		DeleteCriticalSection(&g_csWatches);
		DeleteCriticalSection(&g_csNotif);
		}

	return TRUE;
}

